#pragma once
#include "framework/framework.hpp"
#include "../../features/features.hpp"
#include "../../engine/engine.hpp"
#include "../../engine/globals.hpp"
#include "../../features/cache_data/player_cache.hpp"

using namespace framework::engine;

inline void menu()
{
    ImVec2 pos{};

    ImGui::SetNextWindowPos({ 100, 100 }, ImGuiCond_Once);
    auto window = framework::gui::create_window("Spotify", { framework::gui::window_size.x, framework::gui::window_size.y });
    {
        pos = window->Pos;

        const auto size = window->Size;
        const auto draw_list = window->DrawList;

        draw_list->AddShadowRect({ window->Pos.x, window->Pos.y + window->Size.y }, { window->Pos.x + window->Size.x, window->Pos.y + window->Size.y }, framework::gui::theme_col, 120.f, { 1.f, 1.f }, 0, 0.f);

        ImGui::BeginChild("##sidebar", ImVec2(65.f, size.y), true, ImGuiWindowFlags_NoScrollbar);
        {
            framework::gui::create_tab("Combat", framework::gui::textures::crosshair, 0, framework::gui::selected_tab);
            framework::gui::create_tab("Visuals", framework::gui::textures::eye, 1, framework::gui::selected_tab);
            framework::gui::create_tab("Exploits", framework::gui::textures::exploits, 2, framework::gui::selected_tab);
            framework::gui::create_tab("Player List", framework::gui::textures::players, 3, framework::gui::selected_tab);
            framework::gui::create_tab("Lua VM", framework::gui::textures::code, 4, framework::gui::selected_tab);
            framework::gui::create_tab("Settings", framework::gui::textures::settings, 5, framework::gui::selected_tab);
        }
        ImGui::EndChild();

        ImGui::SameLine();

        ImGui::BeginChild("##main", ImVec2(0, 0), false);
        {
            ImGuiStyle* style = &ImGui::GetStyle();

            static float tab_alpha, tab_add;
            static int active_tab = 0;

            tab_alpha = ImClamp(tab_alpha + (4.f * ImGui::GetIO().DeltaTime * (framework::gui::selected_tab == active_tab ? 1.f : -1.f)), 0.f, 1.f);
            tab_add = ImClamp(tab_add + (std::round(350.f) * ImGui::GetIO().DeltaTime * (framework::gui::selected_tab == active_tab ? 1.f : -1.f)), 0.f, 1.f);

            if (tab_alpha == 0.f && tab_add == 0.f) 
                active_tab = framework::gui::selected_tab;

            ImGui::PushStyleVar(ImGuiStyleVar_Alpha, tab_alpha * style->Alpha);

            if (active_tab == 0)
            {
                static int sub_tab = 0;

                ImGui::BeginChild("##top_bar", ImVec2(ImGui::GetContentRegionAvail().x, 35.f), true, ImGuiWindowFlags_NoScrollbar);
                {
                    float tab_width = (ImGui::GetContentRegionAvail().x - style->ItemSpacing.x * 2.f) / 3.f;

                    framework::gui::create_sub_tab("Aimbot", { tab_width, 20.f }, 0, sub_tab);
                    ImGui::SameLine();
                    framework::gui::create_sub_tab("Silent Aim", { tab_width, 20.f }, 1, sub_tab);
                    ImGui::SameLine();
                    framework::gui::create_sub_tab("Triggerbot", { tab_width, 20.f }, 2, sub_tab);
                }
                ImGui::EndChild();

                if (sub_tab == 0)
                {
                    auto start = ImGui::GetCursorScreenPos().y;

                    framework::gui::create_child(draw_list, ImVec2(size.x / 2.5f, 300.f), "Aimbot");

                    framework::gui::create_checkbox("Enabled", &settings::aimbot.enabled);

                    framework::gui::create_checkbox("Draw FOV", &settings::aimbot.draw_fov);
                    framework::gui::create_checkbox("Humanization", &settings::aimbot.Humanization);

                    static std::vector<std::string> bones = {
                        "Head", "Neck", "Spine", "Root"
                    };

                    framework::gui::create_dropdown("Selected Bone", &settings::aimbot.selected_bone, bones);
                    framework::gui::create_checkbox("Use Closest Bone", &settings::aimbot.closest_bone);

                    framework::gui::create_checkbox("Target Dead", &settings::aimbot.target_dead);
                    framework::gui::create_checkbox("Target Ped", &settings::aimbot.target_bots);
                    framework::gui::create_checkbox("Friend Check", &settings::aimbot.friend_check);
                    framework::gui::create_checkbox("Visible Check", &settings::aimbot.visible_check);

                    framework::gui::end_child();

                    ImGui::SameLine();

                    ImGui::SetCursorScreenPos({ ImGui::GetCursorScreenPos().x, start });
                    framework::gui::create_child(draw_list, ImVec2(size.x / 2.5f, 350.f), "Settings");

                    framework::gui::create_checkbox("Overshoot", &settings::aimbot.overshoot);
                    framework::gui::slider_float("Overshoot Strength", &settings::aimbot.overshoot_strength, 0.01f, 1.f, "%.2f", 0);
                    framework::gui::slider_float("Overshoot Smoothness", &settings::aimbot.overshoot_smoothness, 0.01f, 1.f, "%.2f", 0);

                    framework::gui::slider_float("FOV Radius", &settings::aimbot.fov, 1.f, 500.f, "%.2f", 0);
                    framework::gui::slider_float("Smoothness", &settings::aimbot.smoothness, 0.001f, 0.5f, "%.2f", 0);

                    framework::gui::slider_int("Max Distance", &settings::aimbot.max_distance, 50, 500, "%d", 0);

                    framework::gui::create_keybind("Keybind", &settings::aimbot.key, &settings::aimbot.mode, settings::aimbot.id);

                    framework::gui::end_child();
                }
                else if (sub_tab == 1)
                {
                    auto start = ImGui::GetCursorScreenPos().y;

                    framework::gui::create_child(draw_list, ImVec2(size.x / 2.5f, 300.f), "Silent Aim");

                    framework::gui::create_checkbox("Enabled", &settings::silent_aim.enabled);

                    framework::gui::create_checkbox("Draw FOV", &settings::silent_aim.draw_fov);

                    static std::vector<std::string> bones = {
    "Head", "Neck", "Spine", "Root"
                    };

                    framework::gui::create_dropdown("Selected Bone", &settings::silent_aim.selected_bone, bones);
                    framework::gui::create_checkbox("Use Closest Bone", &settings::silent_aim.closest_bone);

                    framework::gui::create_checkbox("Target Dead", &settings::silent_aim.target_dead);
                    framework::gui::create_checkbox("Target Ped", &settings::silent_aim.target_bots);

                    framework::gui::create_checkbox("Friend Check", &settings::silent_aim.friend_check);
                    framework::gui::create_checkbox("Visible Check", &settings::silent_aim.visible_check);

                    framework::gui::end_child();

                    ImGui::SameLine();

                    ImGui::SetCursorScreenPos({ ImGui::GetCursorScreenPos().x, start });
                    framework::gui::create_child(draw_list, ImVec2(size.x / 2.5f, 350.f), "Settings");

                    framework::gui::slider_float("FOV Radius", &settings::silent_aim.fov, 1.f, 500.f, "%.2f", 0);
                    framework::gui::slider_int("Max Distance", &settings::silent_aim.max_distance, 50, 500, "%d", 0);

                    framework::gui::end_child();
                }
                else
                {
                    auto start = ImGui::GetCursorScreenPos().y;

                    framework::gui::create_child(draw_list, ImVec2(size.x / 2.5f, 300.f), "Triggerbot");

                    framework::gui::create_checkbox("Enabled", &settings::triggerbot.enabled);
                    framework::gui::create_checkbox("Automatic Mode", &settings::triggerbot.automatic_mode);

                    framework::gui::slider_int("Fire Delay", &settings::triggerbot.delay, 0, 100, "%d", 0);

                    framework::gui::end_child();

                    ImGui::SameLine();

                    ImGui::SetCursorScreenPos({ ImGui::GetCursorScreenPos().x, start });
                    framework::gui::create_child(draw_list, ImVec2(size.x / 2.5f, 350.f), "Settings");

                    framework::gui::create_keybind("Keybind", &settings::triggerbot.key, &settings::triggerbot.mode, settings::triggerbot.id);

                    framework::gui::end_child();
                }
            }
            else if (active_tab == 1)
            { 
                auto start = ImGui::GetCursorScreenPos().y;

                framework::gui::create_child(draw_list, ImVec2(size.x / 2.5f, 400.f), "Visuals");

                framework::gui::create_checkbox("Enabled", &settings::visuals.enabled);
                framework::gui::create_checkbox("Skeleton", &settings::visuals.skeleton);
                framework::gui::create_checkbox("Box", &settings::visuals.box);
                framework::gui::create_checkbox("Name", &settings::visuals.name);
                framework::gui::create_checkbox("Status", &settings::visuals.status);
                framework::gui::create_checkbox("Femboy", &settings::visuals.femboy);
                framework::gui::create_checkbox("Distance", &settings::visuals.distance);
                framework::gui::create_checkbox("Head Dot", &settings::visuals.head_dot);
                framework::gui::create_checkbox("Health Bar", &settings::visuals.healthbar);
                framework::gui::create_checkbox("Glow Fill", &settings::visuals.glow);

                framework::gui::create_checkbox("Friend Indicator", &settings::visuals.friend_indicator);

                framework::gui::end_child();

                ImGui::SameLine();

                ImGui::SetCursorScreenPos({ ImGui::GetCursorScreenPos().x, start });
                framework::gui::create_child(draw_list, ImVec2(size.x / 2.5f, 400.f), "Settings");

                framework::gui::create_color_picker("Skeleton Color", settings::visuals.skeleton_color, ImGuiColorEditFlags_NoInputs);
                framework::gui::create_color_picker("Box Color", settings::visuals.box_color, ImGuiColorEditFlags_NoInputs);
                framework::gui::create_color_picker("Name Color", settings::visuals.name_color, ImGuiColorEditFlags_NoInputs);
                framework::gui::create_color_picker("Status Color", settings::visuals.status_color, ImGuiColorEditFlags_NoInputs);
                framework::gui::create_color_picker("Distance Color", settings::visuals.distance_color, ImGuiColorEditFlags_NoInputs);
                framework::gui::create_color_picker("Health bar color", settings::visuals.health_bar_color, ImGuiColorEditFlags_NoInputs);
                framework::gui::create_color_picker("Glow Color", settings::visuals.glow_color, ImGuiColorEditFlags_NoInputs);

                framework::gui::create_color_picker("Friend Indicator Color", settings::visuals.friend_indicator_color, ImGuiColorEditFlags_NoInputs);

                static std::vector<std::string> vec = {
                    "Accurate", "Optimized"
                };

                framework::gui::create_checkbox("Cool Skeleton", &settings::visuals.cool_skeleton);
                ImGui::Text("Skeleton Type");
                framework::gui::create_dropdown("Skeleton Type", &settings::visuals.skeleton_type, vec);

                framework::gui::slider_int("Box Rounding", &settings::visuals.box_rounding, 0, 3, "%d", 0);
                framework::gui::slider_int("Skeleton Thickness", &settings::visuals.skeleton_thickness, 1, 3, "%d", 0);

                framework::gui::create_checkbox("Text Outline", &settings::visuals.text_outline);

                static std::vector<std::string> font_vec = {
                    "Smallest-Pixel", "Inter-Regular", "Inter-Bold"
                };
                ImGui::Text("Font");
                framework::gui::create_dropdown("Selected Font", &settings::visuals.font, font_vec);

                framework::gui::create_checkbox("Draw Dead", &settings::visuals.draw_dead);
                framework::gui::create_checkbox("Draw Peds", &settings::visuals.draw_bots);
                framework::gui::slider_int("Max Distance", &settings::visuals.max_distance, 50, 500, "%d", 0);

                framework::gui::end_child();
            }
            else if (active_tab == 2)
            {
                auto start = ImGui::GetCursorScreenPos().y;

                framework::gui::create_child(draw_list, ImVec2(size.x / 2.5f, 300.f), "Exploits");

                framework::gui::create_checkbox("Enabled", &settings::exploits.enabled);
                framework::gui::create_checkbox("No Ragdoll", &settings::exploits.no_ragdoll);
                framework::gui::create_checkbox("No Headshots", &settings::exploits.no_headshots);
                framework::gui::create_checkbox("Safe Godmode", &settings::exploits.safe_godmode);
                framework::gui::create_checkbox("Super Punch", &settings::exploits.super_punch);
                framework::gui::create_checkbox("Godmode", &settings::exploits.godmode);
                framework::gui::create_checkbox("Passive Mode", &settings::exploits.passive_mode);

                framework::gui::create_checkbox("Infinite Stamina", &settings::exploits.infinite_stamina);
                framework::gui::create_checkbox("One Tap", &settings::exploits.one_tap);

                framework::gui::create_checkbox("Shrink", &settings::exploits.shrink);
                framework::gui::create_checkbox("Bypass Exploits", &settings::exploits.bypass_exploits);

                framework::gui::end_child();

                ImGui::SameLine();

                ImGui::SetCursorScreenPos({ ImGui::GetCursorScreenPos().x, start });
                framework::gui::create_child(draw_list, ImVec2(size.x / 2.5f, 300.f), "Extra");

                static float max_health = 500.f;
                framework::gui::slider_float("Max Health", &max_health, 175.f, 10000.f, "%.2f", 0);

                if (framework::gui::create_button(20.f, "Set Max Health"))
                {
                    if (offsets::world)
                    {
                        auto world = g_sdk->get_world();
                        if (world.is_valid())
                        {
                            auto local_ped = world.get_local_ped();
                            if (local_ped.is_valid())
                            {
                                framework::gui::add_notification("Succesfully Set Max Health!");
                                local_ped.set_max_health(max_health);
                            }
                        }
                    }
                }

                if (framework::gui::create_button(20.f, "Fix Current Vehicle"))
                {
                    if (offsets::world)
                    {
                        auto world = g_sdk->get_world();
                        if (world.is_valid())
                        {
                            auto local_ped = world.get_local_ped();
                            if (local_ped.is_valid())
                            {
                                auto vehicle = local_ped.get_last_vehicle();
                                if (vehicle.is_valid() && local_ped.get_ped_config_flags(CPED_CONFIG_FLAG_InVehicle))
                                {
                                    framework::gui::add_notification("Succesfully Fixed Current Vehicle!");
                                    vehicle.fix();
                                }
                                else
                                {
                                    framework::gui::add_notification("Not In Vehicle!");
                                }
                            }
                        }
                    }
                }

                if (framework::gui::create_button(20.f, "Destroy Current Vehicle"))
                {
                    if (offsets::world)
                    {
                        auto world = g_sdk->get_world();
                        if (world.is_valid())
                        {
                            auto local_ped = world.get_local_ped();
                            if (local_ped.is_valid())
                            {
                                auto vehicle = local_ped.get_last_vehicle();
                                if (vehicle.is_valid() && local_ped.get_ped_config_flags(CPED_CONFIG_FLAG_InVehicle))
                                {
                                    framework::gui::add_notification("Succesfully Fixed Destroyed Vehicle!");
                                    auto val = -4000.f;
                                    globals::memory->write_memory(vehicle.addr + 0x7FC, val);
                                }
                                else
                                {
                                    framework::gui::add_notification("Not In Vehicle!");
                                }
                            }
                        }
                    }
                }

                if (framework::gui::create_button(20.f, "Heal"))
                {
                    if (offsets::world)
                    {
                        auto world = g_sdk->get_world();
                        if (world.is_valid())
                        {
                            auto local_ped = world.get_local_ped();
                            if (local_ped.is_valid())
                            {
                                framework::gui::add_notification("Succesfully Healed Local Player!");
                                local_ped.heal();
                            }
                        }
                    }
                }

                if (framework::gui::create_button(20.f, "Suicide"))
                {
                    if (offsets::world)
                    {
                        auto world = g_sdk->get_world();
                        if (world.is_valid())
                        {
                            auto local_ped = world.get_local_ped();
                            if (local_ped.is_valid())
                            {
                                framework::gui::add_notification("Succesfully Suicided!");
                                local_ped.kill();
                            }
                        }
                    }
                }

                framework::gui::create_keybind("Heal Keybind", &settings::exploits.heal_key, &settings::exploits.heal_mode, settings::exploits.heal_id);
                framework::gui::create_keybind("Fix Vehicle Keybind", &settings::exploits.fix_vehicle_key, &settings::exploits.fix_vehicle_mode, settings::exploits.fix_vehicle_id);

                framework::gui::end_child();
            }
            else if (active_tab == 3)
            {
                auto start = ImGui::GetCursorScreenPos().y;

                framework::gui::create_child(draw_list, ImVec2(size.x / 2.5f, 300.f), "Players");

                static player_cache::entity selected_entity{ };

                for (auto& entity : player_cache::get_entities())
                {
                    bool is_selected = (selected_entity.addr == entity.addr);

                    ImGui::PushID(entity.addr);

                    auto text = entity.net_id ? std::to_string(entity.net_id) : "Ped";
                    bool is_friend = friends.contains(entity.addr);

                    if (framework::gui::create_selectable_with_given_color(text.c_str(), &is_selected, is_friend ? IM_COL32(0, 255, 0, 255) : framework::gui::text_idle_col))
                    {
                        selected_entity = entity;
                    }

                    ImGui::PopID();
                }

                framework::gui::end_child();

                ImGui::SameLine();

                ImGui::SetCursorScreenPos({ ImGui::GetCursorScreenPos().x, start });
                framework::gui::create_child(draw_list, ImVec2(size.x / 2.5f, 300.f), "Options");

                if (selected_entity.is_valid())
                {
                    ImGui::Text("Net Id: %d", selected_entity.net_id);
                    ImGui::Text("Name: %s", selected_entity.name);
                    ImGui::Text("Health: %d", selected_entity.get_health());

                    auto status = selected_entity.get_status();

                    auto text = "";
                    if (status == sdk::ped::ped_status::godmode) text = "Godmode";
                    else if (status == sdk::ped::ped_status::suspicious) text = "Suspicious";
                    else text = "Normal";

                    ImGui::Text("Status: %s", text);

                    bool is_friend = friends.contains(selected_entity.addr);
                    if (framework::gui::create_button(20.f, is_friend ? "Remove Friend" : "Add Friend"))
                    {
                        if (is_friend)
                        {
                            framework::gui::add_notification("Succesfully removed " + selected_entity.name + " as friend!");
                            friends.erase(selected_entity.addr);
                        }
                        else
                        {
                            framework::gui::add_notification("Succesfully added " + selected_entity.name + " as friend!");
                            friends.insert(selected_entity.addr);
                        }
                    }

                    if (framework::gui::create_button(20.f, "Unlock Car"))
                    {
                        auto vehicle = selected_entity.get_last_vehicle();
                        if (vehicle.addr && selected_entity.get_ped_config_flags(CPED_CONFIG_FLAG_InVehicle))
                        {
                            framework::gui::add_notification("Succesfully unlocked car!");
                            vehicle.set_lock_state(VEHICLELOCK_UNLOCKED);
                        }
                    }

                    if (framework::gui::create_button(20.f, "Lock Car"))
                    {
                        auto vehicle = selected_entity.get_last_vehicle();
                        if (vehicle.addr && selected_entity.get_ped_config_flags(CPED_CONFIG_FLAG_InVehicle))
                        {
                            framework::gui::add_notification("Succesfully locked car!");
                            vehicle.set_lock_state(VEHICLELOCK_CANNOT_ENTER);
                        }
                    }

                    if (framework::gui::create_button(20.f, "Give Godmode"))
                    {
                        framework::gui::add_notification("Succesfully gave godmode!");
                        selected_entity.godmode(true);
                    }

                    if (framework::gui::create_button(20.f, "Shrink"))
                    {
                        framework::gui::add_notification("Succesfully shrunk model!");
                        selected_entity.set_ped_config_flags(CPED_CONFIG_FLAG_UseAmbientModelScaling, true);
                    }

                    if (framework::gui::create_button(20.f, "Fix Current Vehicle"))
                    {
                        auto vehicle = selected_entity.get_last_vehicle();
                        if (vehicle.is_valid() && selected_entity.get_ped_config_flags(CPED_CONFIG_FLAG_InVehicle))
                        {
                            framework::gui::add_notification("Succesfully Fixed Current Vehicle!");
                            vehicle.fix();
                        }
                        else
                        {
                            framework::gui::add_notification("Not In Vehicle!");
                        }
                    }

                    if (framework::gui::create_button(20.f, "Kick Out Of Vehicle"))
                    {
                        auto vehicle = selected_entity.get_last_vehicle();
                        if (vehicle.is_valid() && selected_entity.get_ped_config_flags(CPED_CONFIG_FLAG_InVehicle))
                        {
                            framework::gui::add_notification("Succesfully Kicked Player Out Of Vehicle!");
                            selected_entity.kick_player_out_of_vehicle();
                        }
                        else
                        {
                            framework::gui::add_notification("Not In Vehicle!");
                        }
                    }

                    if (framework::gui::create_button(20.f, "Teleport"))
                    {
                        auto world = g_sdk->get_world();
                        if (world.is_valid())
                        {
                            auto local_ped = world.get_local_ped();
                            if (local_ped.is_valid())
                            {
                                framework::gui::add_notification("Succesfully teleported to " + selected_entity.name + "!");
                                local_ped.set_pos(selected_entity.get_root());
                            }
                        }
                    }
                }

                framework::gui::end_child();
            }
            else if (active_tab == 5)
            {   
                auto start = ImGui::GetCursorScreenPos().y;
                framework::gui::create_child(draw_list, ImVec2(size.x / 2.5f, 300.f), "Settings");

                framework::gui::create_checkbox("VSync", &settings::settings.vsync);
                framework::gui::create_checkbox("Streamproof", &settings::settings.streamproof);

                framework::gui::create_checkbox("Performance Mode", &settings::settings.performance_mode);

                framework::gui::create_color_picker("Menu Theme", settings::settings.theme, ImGuiColorEditFlags_NoInputs);

                framework::gui::end_child();

                ImGui::SameLine();

                ImGui::SetCursorScreenPos({ ImGui::GetCursorScreenPos().x, start });

                framework::gui::create_child(draw_list, ImVec2(size.x / 2.5f, 300.f), "Extra");

                framework::gui::create_checkbox("Friend Key", &settings::friend_key.enabled);
                framework::gui::create_checkbox("Visible Check", &settings::friend_key.visible_check);
                framework::gui::create_checkbox("Target Dead", &settings::friend_key.target_dead);
                framework::gui::create_checkbox("Target Peds", &settings::friend_key.target_bots);
                framework::gui::create_keybind("Keybind", &settings::friend_key.key, &settings::friend_key.mode, settings::friend_key.id);

                if (framework::gui::create_button(20.f, "Clean"))
                {
                    features::cleaner();
                    framework::gui::add_notification("Succesfully Cleaned!");
                }

                if (framework::gui::create_button(20.f, "Unload"))
                {
                    if (settings::mutex) {
                        ReleaseMutex(settings::mutex);
                        CloseHandle(settings::mutex);
                    }

                    ExitProcess(0);
                }

                framework::gui::end_child();
            }

            ImGui::PopStyleVar();
        }
        ImGui::EndChild();
        framework::gui::end_window();
    }

    ImGui::SetNextWindowPos({ pos.x, pos.y - 40.f }, ImGuiCond_Always);
    auto watermark_window = framework::gui::create_window("Watermark", { framework::gui::window_size.x, 20.f });
    {
        const char* text = "FiveM External";
        auto text_size = ImGui::CalcTextSize(text);

        auto& g = *GImGui;
        watermark_window->DrawList->AddText(ImVec2(watermark_window->DC.CursorPos.x + (framework::gui::window_size.x - text_size.x) / 2.f, watermark_window->DC.CursorPos.y + (20.f - (g.Font->Ascent - g.Font->Descent)) / 2.f), IM_COL32(255, 255, 255, 255), text);
        framework::gui::end_window();
    }


    //ImVec2 img_size = ImVec2(150.f, 150.f);
    //ImVec2 img_pos = ImVec2(pos.x + (65.f - img_size.x) * 0.5f, pos.y - img_size.y + 35.f);

    //ImGui::GetForegroundDrawList()->AddImage(framework::gui::textures::anime_bae, img_pos, ImVec2(img_pos.x + img_size.x, img_pos.y + img_size.y));
}