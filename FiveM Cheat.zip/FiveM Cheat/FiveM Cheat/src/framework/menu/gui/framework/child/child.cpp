#include "../framework.hpp"

namespace framework::gui
{
    bool create_child(ImDrawList* draw, const ImVec2& size, const std::string& label)
	{
        ImVec2 pos = ImGui::GetCursorScreenPos();

        const char* text = label.c_str();
        ImVec2 text_size = ImGui::CalcTextSize(text);

        auto alpha = ImGui::GetStyleColorVec4(ImGuiStyleVar_Alpha);

        draw->AddText(ImVec2(pos.x + (size.x - text_size.x) * 0.5f, pos.y + (header_height - text_size.y) * 0.5f), IM_COL32(220, 220, 220, 255), text);

        ImGui::SetCursorScreenPos(ImVec2(pos.x, pos.y + header_height));

        ImU32 solid = theme_col;
        ImVec4 border = ImGui::ColorConvertU32ToFloat4(theme_col);
        ImU32 fade = ImGui::ColorConvertFloat4ToU32(ImVec4(border.x, border.y, border.z, 0.0f));

        float line_y = pos.y + header_height - 1.0f;
        float half_width = size.x * 0.5f;

        draw->AddRectFilledMultiColor(ImVec2(pos.x, line_y), ImVec2(pos.x + half_width, line_y + 2.0f), fade, solid, solid, fade);
        draw->AddRectFilledMultiColor(ImVec2(pos.x + half_width, line_y), ImVec2(pos.x + size.x, line_y + 2.0f), solid, fade, fade, solid);

        bool open = ImGui::BeginChild(text, ImVec2(size.x, size.y - header_height), false, ImGuiWindowFlags_NoBackground);

        ImGui::SetCursorPosY(ImGui::GetCursorPosY() + padding.y);

        return open;
	}

	void end_child()
	{
        ImGui::SetCursorPosY(ImGui::GetCursorPosY() - padding.y);
        ImGui::EndChild();
	}
}
