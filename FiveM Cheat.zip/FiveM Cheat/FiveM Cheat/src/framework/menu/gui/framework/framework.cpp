#include "framework.hpp"
#include "../assets/font.hpp"
#include "../assets/images.hpp"
#include "../../../../dependencies/imgui/imgui_freetype.h"

#include "../../overlay/overlay.hpp"

namespace framework::gui {
	void initialize()
	{
		ImGuiIO& io = ImGui::GetIO();

		ImFontConfig cfg;
		cfg.PixelSnapH = true;
		cfg.FontDataOwnedByAtlas = false;
		cfg.OversampleH = 5;
		cfg.OversampleV = 5;
		cfg.RasterizerMultiply = 1.2f;
		cfg.FontBuilderFlags = ImGuiFreeTypeBuilderFlags_ForceAutoHint | ImGuiFreeTypeBuilderFlags_Bitmap;

		fonts::inter_bold = io.Fonts->AddFontFromMemoryTTF(inter_extra_bold, sizeof(inter_extra_bold), 12.f, &cfg);
		fonts::inter_semi_bold = io.Fonts->AddFontFromMemoryTTF(inter_semi_bold, sizeof(inter_semi_bold), 12.f, &cfg);
		fonts::inter_regular = io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\tahoma.ttf", 12.f, &cfg);
		fonts::esp_font = io.Fonts->AddFontFromMemoryTTF(pixel_font, sizeof(pixel_font), 12.f, &cfg);

		auto device = framework::g_overlay->get_data().d3d_device;
		auto ctx = framework::g_overlay->get_data().d3d_device_ctx;
		if (device && ctx)
		{
			helpers::load_image(device, ctx, eye, sizeof(eye), &textures::eye);
			helpers::load_image(device, ctx, skull, sizeof(skull), &textures::crosshair);
			helpers::load_image(device, ctx, anime_bae, sizeof(anime_bae), &textures::anime_bae);
			helpers::load_image(device, ctx, code_icon, sizeof(code_icon), &textures::code);
			helpers::load_image(device, ctx, settings_icon, sizeof(settings_icon), &textures::settings);
			helpers::load_image(device, ctx, lab_icon, sizeof(lab_icon), &textures::exploits);
			helpers::load_image(device, ctx, femboy, sizeof(femboy), &textures::femboy);
			helpers::load_image(device, ctx, players_icon, sizeof(players_icon), &textures::players);
			helpers::load_image(device, ctx, keyboard_data, sizeof(keyboard_data), &textures::keybinds);
		}
	}
}