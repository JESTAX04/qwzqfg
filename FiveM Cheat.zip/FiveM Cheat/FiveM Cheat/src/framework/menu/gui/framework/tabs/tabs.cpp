#include "../framework.hpp"

namespace framework::gui
{
	struct tab_state {
		ImVec4 image_col;
	};

	bool create_tab(const char* name, ID3D11ShaderResourceView* texture, int id, int& selected)
	{
		ImGuiContext& g = *GImGui;
		ImGuiWindow* window = g.CurrentWindow;

		auto parsed_id = window->GetID(name);

		const auto pos = window->DC.CursorPos;

		const ImVec2 text_size = ImGui::CalcTextSize(name);

		ImVec2 icon_size = ImVec2(16.f, 16.f);
		float width = icon_size.x + 30.f;
		float height = icon_size.y + text_size.y + 2;

		const ImRect bb(pos, ImVec2(pos.x + width, pos.y + height));

		ImGui::ItemSize(bb, padding.y);
		if (!ImGui::ItemAdd(bb, parsed_id))
			return false;

		bool hovered, held, pressed = ImGui::ButtonBehavior(bb, parsed_id, &hovered, &held);
		bool active = selected == id;

		if (pressed)
			selected = id;

		static std::unordered_map<ImGuiID, tab_state> anim;
		auto& state = anim[parsed_id];

		state.image_col = ImLerp(state.image_col, ImLerp(ImGui::ColorConvertU32ToFloat4((active || hovered) ? theme_col : text_idle_col), ImVec4(1, 1, 1, 1), hovered && !active ? 0.25f : 0.f), g.IO.DeltaTime * 6.f);

		ImVec2 icon_pos = ImVec2(pos.x + (width - icon_size.x) / 2.f, pos.y + icon_size.y / 2.f);

		window->DrawList->AddImage(texture, icon_pos, ImVec2(icon_pos.x + icon_size.x, icon_pos.y + icon_size.y), ImVec2(0, 0), ImVec2(1, 1), ImColor(state.image_col));
		window->DrawList->AddText(ImVec2(pos.x + (width - text_size.x) / 2.f, icon_pos.y + text_size.y + 2), ImColor(state.image_col), name);

		return active;
	}

	struct sub_tab_state {
		ImVec4 background, text;
	};

	bool create_sub_tab(const char* name, const ImVec2& size, int id, int& selected)
	{
		auto& g = *GImGui;
		auto window = g.CurrentWindow;
		auto draw = window->DrawList;
		const ImGuiID im_id = window->GetID(name);

		const ImVec2 pos = window->DC.CursorPos;
		const ImRect bb(pos, ImVec2(pos.x + size.x, pos.y + size.y));

		ImGui::ItemSize(bb, padding.y);
		if (!ImGui::ItemAdd(bb, im_id)) return false;

		bool hovered, held, pressed = ImGui::ButtonBehavior(bb, im_id, &hovered, &held);
		bool active = selected == id;

		if (pressed)
			selected = id;

		static std::unordered_map<ImGuiID, sub_tab_state> anim;
		auto& state = anim[im_id];

		ImVec4 target_text = (active || hovered || held) ? ImGui::ColorConvertU32ToFloat4(text_active_col) : ImGui::ColorConvertU32ToFloat4(text_idle_col);
		auto col = ImGui::ColorConvertU32ToFloat4(theme_col);

		state.background = ImLerp(state.background, (active || hovered) ? ImColor(col.x, col.y, col.z, 0.2f) : ImColor(20, 20, 20, 0), g.IO.DeltaTime * 6.f);
		state.text = ImLerp(state.text, target_text, g.IO.DeltaTime * 6.f);

		helpers::draw_rect(draw, pos, pos, size, IM_COL32(20, 20, 20, 255), helpers::rect_type::filled, 0.f, 1.f);
		helpers::draw_rect(draw, pos, pos, size, IM_COL32(35, 35, 35, 255), helpers::rect_type::normal, 0.f, 1.f);

		helpers::draw_rect(draw, pos, pos, size, ImGui::ColorConvertFloat4ToU32(state.background), helpers::rect_type::filled, 0.f, 1.f);

		ImVec2 text_size = ImGui::CalcTextSize(name);

		ImVec2 text_pos = ImVec2(pos.x + (size.x - text_size.x) * 0.5f, pos.y + (size.y - (g.Font->Ascent - g.Font->Descent)) * 0.5f);
		draw->AddText(text_pos, ImGui::ColorConvertFloat4ToU32(state.text), name);

		return active;
	}
}

