#include "../engine.hpp"

#include "../../memory/helpers.hpp"
#include "../globals.hpp"


namespace framework::engine {
	float sdk::ped::get_health()
	{
		return globals::memory->simple_read<float>(this->addr + 0x280); 
	}

	void sdk::ped::set_health(float health)
	{
		globals::memory->write_memory(this->addr + 0x280, health);
	}

	float sdk::ped::get_max_health()
	{
		return globals::memory->simple_read<float>(this->addr + 0x284);
	}

	void sdk::ped::set_max_health(float max_health)
	{
		globals::memory->write_memory(this->addr + 0x284, max_health);
	}

	int sdk::ped::get_sweat()
	{
		return globals::memory->simple_read<int>(this->addr + 0x1474);
	}

	void sdk::ped::set_sweat(int sweat)
	{
		globals::memory->write_memory<int>(this->addr + 0x1474, sweat);
	}

	Vector3 sdk::ped::get_up_vector()
	{
		return globals::memory->simple_read<Vector3>(this->addr + 0x80);
	}

	Vector3 sdk::ped::get_right_vector()
	{
		return globals::memory->simple_read<Vector3>(this->addr + 0x60);
	}

	Vector3 sdk::ped::get_forward_vector()
	{
		return globals::memory->simple_read<Vector3>(this->addr + 0x70);
	}

	Matrix sdk::ped::get_matrix()
	{
		return globals::memory->simple_read<Matrix>(this->addr + 0x60);
	}

	Vector3 sdk::ped::get_root()
	{
		return globals::memory->simple_read<Vector3>(this->addr + 0x90);
	}

	bool sdk::ped::is_rendered()
	{
		uint8_t cfg = globals::memory->simple_read<uint8_t>(this->addr + 176);
		return (cfg & (1 << 4)) != 0;
	}

	bool sdk::ped::is_bullet_proof()
	{
		uint8_t cfg = globals::memory->simple_read<uint8_t>(this->addr + 392);
		return (cfg & (1 << 4)) != 0;
	}

	bool sdk::ped::is_fire_proof()
	{
		uint8_t cfg = globals::memory->simple_read<uint8_t>(this->addr + 392);
		return (cfg & (1 << 5)) != 0;
	}

	bool sdk::ped::is_melee_proof()
	{
		uint8_t cfg = globals::memory->simple_read<uint8_t>(this->addr + 392);
		return (cfg & (1 << 7)) != 0;
	}

	bool sdk::ped::is_explosion_proof()
	{
		uint8_t cfg = globals::memory->simple_read<uint8_t>(this->addr + 392);
		return (cfg & (1 << 11)) != 0;
	}

	bool sdk::ped::is_collision_proof()
	{
		uint8_t cfg = globals::memory->simple_read<uint8_t>(this->addr + 392);
		return (cfg & (1 << 6)) != 0;
	}

	void sdk::ped::set_ped_flag(uint8_t bit, bool value)
	{
		uint8_t cfg = globals::memory->simple_read<uint8_t>(this->addr + 392);

		if (value)
			cfg |= (1 << bit);   
		else
			cfg &= ~(1 << bit);  

		globals::memory->write_memory(this->addr + 392, cfg);
	}

	sdk::vehicle sdk::ped::get_last_vehicle()
	{
		return vehicle(globals::memory->simple_read<uintptr_t>(this->addr + 0xD10));
	}

	bool sdk::ped::get_ped_config_flags(ePedConfigFlags flag)
	{
		auto v4 = flag;
		auto v7 = this->addr;

		auto v8 = 1 << (v4 & 0x1F);
		auto v9 = v4 >> 5;

		auto cfg = globals::memory->simple_read<uint32_t>(this->addr + 4 * v9 + 0x1444);

		return (v8 & cfg) != 0;
	}

	void sdk::ped::set_ped_config_flags(ePedConfigFlags flag, BOOL value)
	{
		auto v4 = flag;
		auto v7 = this->addr;

		auto v8 = 1 << (v4 & 0x1F);
		auto v9 = v4 >> 5;

		auto cfg = globals::memory->simple_read<uint32_t>(this->addr + 4 * v9 + 0x1444);
		
		if (value != ((v8 & cfg) != 0))
		{
			auto val = v8 & cfg ^ -value;
			cfg ^= val;
			globals::memory->write_memory(this->addr + 4 * v9 + 0x1444, cfg);
		}
	}

	void sdk::ped::set_speed(int speed)
	{
		globals::memory->write_memory<int>(this->addr + 0x7C, speed);
	}

	void sdk::ped::set_invisible(bool value)
	{
		uint8_t cfg = globals::memory->simple_read<uint8_t>(this->addr + 44);

		if (value)
			cfg |= 1;
		else
			cfg &= ~1;		

		globals::memory->write_memory(this->addr + 44, cfg);
	}

	void sdk::ped::set_invincible(bool value)
	{
		uint8_t cfg = globals::memory->simple_read<uint8_t>(this->addr + 0x188);

		if (value)
			cfg |= (1 << 9);
		else
			cfg &= ~(1 << 9);

		globals::memory->write_memory(this->addr + 0x188, cfg);
	}

	void sdk::ped::set_collision(bool value)
	{
		uint8_t flags = globals::memory->simple_read<uint8_t>(this->addr + 5076);
		uint8_t flags_2 = globals::memory->simple_read<uint8_t>(this->addr + 0x13C4);

		if (value)
			flags |= 0x80000000;
		else
			flags &= ~0x80000000;

		flags_2 ^= flags;

		globals::memory->write_memory(this->addr + 5076, flags);
		globals::memory->write_memory(this->addr + 0x13C4, flags_2);
	}

	std::string sdk::ped::get_name(int net_id)
	{
		if (!net_id)
			return "ped";

		auto base = utilities::get_module_base(globals::memory->info.pid, "citizen-playernames-five.dll");

		auto player_names = globals::memory->simple_read< uintptr_t >( base + 0x31D98 );
                auto size = globals::memory->simple_read< uint16_t >( base + (0x31D98 + 8) );

		auto list = globals::memory->simple_read<uintptr_t>(player_names);

		for (uint16_t i = 0; i < size; i++)
		{
			int id = globals::memory->simple_read<int>(list + 0x10);

			if (id == net_id)
			{
				SIZE_T bytes_read;
				std::vector<char> buffer(512);
				globals::memory->read_bytes(list + 0x18, buffer.data(), 512, bytes_read);
				buffer[512 - 1] = '\0';
				return std::string(buffer.data());
			}

			list = globals::memory->simple_read<uintptr_t>(list + 0x8);
		}

		return "";
	}

	bool sdk::ped::is_npc()
	{
		return this->player_info().net_id() == 0; // npcs dont have net ids
	}

	bool sdk::ped::is_occluded()
	{
		uint32_t current_flags = globals::memory->simple_read<uint32_t>(this->addr + 0xC0);
		if (!(current_flags & (1 << 29))) {
			current_flags |= (1 << 29);
			globals::memory->write_memory(this->addr + 0xC0, current_flags);  // enable raycast
		}

		uintptr_t fx_draw_data = globals::memory->simple_read<uintptr_t>(this->addr + 0x48);
		if (!fx_draw_data)
			return false;

		uint32_t query_id = globals::memory->simple_read<uint8_t>(fx_draw_data + 0x2B) & 0xFF;
		if (!query_id)
			return false;

		int visibility_value = globals::memory->simple_read<int>(globals::memory->info.mod_info.base_address + 0x2559A50 + ((query_id - 1) * 0x80) + 0x78);
		return visibility_value > 100;
	}

	bool sdk::ped::is_godmode()
	{
		return globals::memory->simple_read<bool>(this->addr + 0x189);
	}

	void sdk::ped::godmode(bool value)
	{
		globals::memory->write_memory(this->addr + 0x189, value);
	}

	sdk::player_info sdk::ped::player_info()
	{
		return sdk::player_info(globals::memory->simple_read<uintptr_t>(this->addr + offsets::player_info));
	}

	sdk::skeleton_data sdk::ped::skeleton_data()
	{
		auto frag_inst = globals::memory->simple_read<uintptr_t>(this->addr + offsets::frag_inst);
		auto ptr = globals::memory->simple_read<uintptr_t>(frag_inst + 0x68);
		return sdk::skeleton_data(ptr, globals::memory->simple_read<uintptr_t>(ptr + 0x178));
	}

	Vector3 sdk::ped::get_velocity()
	{
		return globals::memory->simple_read<Vector3>(this->addr + 0x320);
	}

	void sdk::ped::set_pos(Vector3 pos)
	{
		auto navigation = globals::memory->simple_read<uintptr_t>(this->addr + 0x30);
		if (!navigation)
			return;

		globals::memory->write_memory(this->addr + 0x90, pos);
		globals::memory->write_memory(navigation + 0x50, pos);
	}

	sdk::ped::ped_status sdk::ped::get_status()
	{
		if (this->is_godmode())
		{
			return ped_status::godmode;
		}
		else if (get_max_health() > 200.f || is_bullet_proof() || is_melee_proof())
		{
			return ped_status::suspicious;
		}

		return ped_status::normal;
	}

	void sdk::ped::kill()
	{
		this->set_health(-1);
	}
	void sdk::ped::heal()
	{
		this->set_health(this->get_max_health());
	}

	void sdk::ped::kick_player_out_of_vehicle()
	{
		this->set_ped_config_flags(CPED_CONFIG_FLAG_InVehicle, false);
	}
}