#include "initialize.hpp"

#include <unordered_map>

#include "../features/cache_data/player_cache.hpp"
#include "../features/features.hpp"
#include "../menu/overlay/overlay.hpp"
#include "../menu/settings.hpp"

namespace framework::engine
{
    std::string get_version( )
    {
        auto name = globals::memory->info.process_name;
        auto pos = name.find( "_b" );

        if ( pos != std::string::npos )
        {
            name.erase( pos + 6 );
            return name.substr( pos + 1 );
        }
        return "stable";
    }

    static void start_overlay( )
    {
        g_overlay->start( );
    }

    static void start_initialize( )
    {
        SetThreadPriority( GetCurrentThread( ), THREAD_PRIORITY_LOWEST );

        threads::map[ "overlay" ] = std::make_unique< threads::thread >( );
        threads::map[ "overlay" ]->start( start_overlay );

        threads::map[ "player_cache" ] = std::make_unique< threads::thread >( );
        threads::map[ "player_cache" ]->start( player_cache::run );

        threads::map[ "exploits" ] = std::make_unique< threads::thread >( );
        threads::map[ "exploits" ]->start( features::exploits );

        threads::map[ "silent_aim" ] = std::make_unique< threads::thread >( );
        threads::map[ "silent_aim" ]->start( features::silent_aim );

        threads::map[ "aimbot" ] = std::make_unique< threads::thread >( );
        threads::map[ "aimbot" ]->start( features::aimbot );

        threads::map[ "triggerbot" ] = std::make_unique< threads::thread >( );
        threads::map[ "triggerbot" ]->start( features::triggerbot );

        while ( threads::should_run )
        {
            DWORD pid = utilities::get_pid_by_window_class_name( "grcWindow" );
            if ( !pid )
                scan_game( );

            if ( globals::memory && globals::memory->success )
            {
                auto temp_world = g_sdk->get_world( );
                if ( temp_world.addr && globals::world.addr && temp_world.addr == globals::world.addr && temp_world.get_local_ped( ).addr )
                {
                }
                else
                {
                    scan_game( );
                }
            }
            else
            {
                scan_game( );
            }

            std::this_thread::sleep_for( std::chrono::seconds( 1 ) );
            std::this_thread::yield( );
        }
    }

    void initialize( )
    {
        start_initialize( );
    }

    bool scan_game( )  // we dump offsets here
    {
        DWORD pid = 0;
        while ( !pid )
        {
            pid = utilities::get_pid_by_window_class_name( "grcWindow" );
            std::this_thread::sleep_for( std::chrono::milliseconds( 900 ) );
        }

        utilities::logging::print_value( "found fivem -> %d", pid, utilities::logging::success );

        globals::memory = std::make_unique< utilities::memory >( pid );
        while ( !globals::memory->success )
        {
            globals::memory = std::make_unique< utilities::memory >( pid );
            std::this_thread::sleep_for( std::chrono::milliseconds( 900 ) );
        }

        utilities::logging::print( "memory initialized", utilities::logging::success );

        globals::version = get_version( );

        auto parsed_regions = utilities::parse_process_bytes( globals::memory, globals::memory->info.mod_info );

        auto world_sig = utilities::signature::parse( "48 8B 05 ? ? ? ? 33 D2 48 8B 40 08 8A CA 48 85 C0 74 16 48 8B" );
        auto camera_sig = utilities::signature::parse( "48 8B 05 ? ? ? ? 48 8B 98 ? ? ? ? EB" );
        auto replay_sig = utilities::signature::parse(
            "48 8D 0D ?? ?? ?? ?? E8 ?? ?? ?? ?? 48 8D 4C 24 ?? E8 ?? ?? ?? ?? 48 8D 4C 24 ?? E8 ?? ?? ?? ?? 48 8B 9C 24" );
        auto stamina_sig = utilities::signature::parse( "F3 0F 11 B3 54 0D 00 00" );
        auto weapon_damage_sig = utilities::signature::parse( "F3 0F 10 88 ? ? ? ? EB ? 41 0F 28 CA" );
        auto player_info_sig = utilities::signature::parse( "48 8B 80 ? ? ? ? 48 85 C0 74 ? 39 90" );
        auto bullet_sig = utilities::signature::parse( "F3 41 0F 10 19 F3 41 0F 10 41 04 F3 41 0F 10 51 08" );
        auto triggerbot_sig =
            utilities::signature::parse( "48 8D 0D ?? ?? ?? ?? E8 ?? ?? ?? ?? 48 8B 0D ?? ?? ?? ?? 48 85 C9 74 05 E8 ?? ?? ?? ?? 8A CB" );
        auto names_sig = utilities::signature::parse( "48 8B 41 60 48 85 C0 74 0A" );

        auto world_len = world_sig.size( );
        auto camera_len = camera_sig.size( );
        auto replay_len = replay_sig.size( );
        auto bullet_len = bullet_sig.size( );
        auto player_info_len = player_info_sig.size( );
        auto weapon_damage_len = weapon_damage_sig.size( );
        auto stamina_len = stamina_sig.size( );
        auto triggerbot_len = triggerbot_sig.size( );
        auto names_len = names_sig.size( );

        // auto viewport_sig = utilities::signature::parse("48 8B 15 ? ? ? ? 48 8D 2D ? ? ? ? 48 8B CD");
        // auto viewport_len = viewport_sig.size();

        for ( auto& data : parsed_regions )
        {
            offsets::world = utilities::scan_cached_regions_for_sig( globals::memory, data.reg, data.buffer, { world_sig, world_len }, true );
            offsets::camera = utilities::scan_cached_regions_for_sig( globals::memory, data.reg, data.buffer, { camera_sig, camera_len }, true );
            offsets::replay_interface =
                utilities::scan_cached_regions_for_sig( globals::memory, data.reg, data.buffer, { replay_sig, replay_len }, true );
            offsets::handle_bullet =
                utilities::scan_cached_regions_for_sig( globals::memory, data.reg, data.buffer, { bullet_sig, bullet_len }, false );
            offsets::player_info =
                utilities::scan_cached_regions_for_sig( globals::memory, data.reg, data.buffer, { player_info_sig, player_info_len }, true );
            offsets::player_stamina =
                utilities::scan_cached_regions_for_sig( globals::memory, data.reg, data.buffer, { stamina_sig, stamina_len }, true );
            offsets::weapon_damage =
                utilities::scan_cached_regions_for_sig( globals::memory, data.reg, data.buffer, { weapon_damage_sig, weapon_damage_len }, true );
            offsets::triggerbot =
                utilities::scan_cached_regions_for_sig( globals::memory, data.reg, data.buffer, { triggerbot_sig, triggerbot_len }, true );
            offsets::names = utilities::scan_cached_regions_for_sig( globals::memory, data.reg, data.buffer, { names_sig, names_len }, true );

            if ( offsets::world && offsets::camera && offsets::replay_interface && offsets::handle_bullet && offsets::player_info &&
                 offsets::weapon_damage && offsets::player_stamina && offsets::triggerbot )
                break;
        }

        if ( !offsets::world || !offsets::camera || !offsets::replay_interface || !offsets::handle_bullet || !offsets::player_info ||
             !offsets::weapon_damage || !offsets::player_stamina || !offsets::triggerbot )
            return false;

        utilities::logging::print_value( "fivem version -> %s", globals::version, utilities::logging::info );

        utilities::logging::print_value(
            "ped_factory -> 0x%lx", offsets::world - globals::memory->info.mod_info.base_address, utilities::logging::info );
        utilities::logging::print_value( "camera -> 0x%lx", offsets::camera - globals::memory->info.mod_info.base_address, utilities::logging::info );
        utilities::logging::print_value(
            "handle_bullet -> 0x%lx", offsets::handle_bullet - globals::memory->info.mod_info.base_address, utilities::logging::info );
        utilities::logging::print_value(
            "replay_interface -> 0x%lx", offsets::replay_interface - globals::memory->info.mod_info.base_address, utilities::logging::info );
        utilities::logging::print_value( "player_info -> 0x%lx", offsets::player_info, utilities::logging::info );
        utilities::logging::print_value( "weapon_damage -> 0x%lx", offsets::weapon_damage, utilities::logging::info );
        utilities::logging::print_value( "player_stamina -> 0x%lx", offsets::player_stamina, utilities::logging::info );
        utilities::logging::print_value(
            "is_enemy_under_crosshair -> 0x%lx", offsets::triggerbot - globals::memory->info.mod_info.base_address, utilities::logging::info );

        offsets::viewport = 0x201DBA0;
        offsets::frag_inst = 0x1430;
        globals::world = engine::g_sdk->get_world( );

        globals::local_ped = sdk::ped( 0 );
        for ( int i = 0; i < 100; i++ )
        {
            globals::local_ped = globals::world.get_local_ped( );
            if ( globals::local_ped.addr )
                break;

            std::this_thread::sleep_for( std::chrono::milliseconds( 500 ) );
            std::this_thread::yield( );
        }

        if ( friends.size( ) > 0 )
        {
            friends.clear( );
        }

        globals::viewport = globals::memory->simple_read< uintptr_t >( globals::memory->info.mod_info.base_address + 0x201DBA0 );
        globals::replay = globals::memory->simple_read< uintptr_t >( offsets::replay_interface );

        return true;
    }
}  // namespace framework::engine