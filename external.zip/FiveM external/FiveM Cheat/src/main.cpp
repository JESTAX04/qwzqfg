#include "framework/engine/initialize.hpp"
#include <iostream>
#include <thread>
#include "framework/menu/settings.hpp"
#include "framework/memory/invoker.hpp"

using namespace framework::engine;

int main( )
{
	setvbuf( stdout, nullptr, _IONBF, 0 );  // live logs for redirected consoles

	settings::mutex = CreateMutexA(nullptr, TRUE, "_mtx");
	if (GetLastError() == ERROR_ALREADY_EXISTS) {
		MessageBoxA(nullptr, "Already open", "", ERROR);
		Sleep(3000);
		return 0;
	}

	GetSystemInfo(&utilities::sys_info);

	// initialize() never returns (it hosts the rescan loop), so the auto-probe
	// runs on its own thread and waits for both conditions there.
	std::thread([] {
		utilities::logging::print( "auto-probe armed: waiting for local ped + invoker", utilities::logging::info );
		while ( threads::should_run && ( !framework::engine::globals::local_ped.addr || !invoker::ready ) )
			Sleep(250);

		utilities::logging::print( "auto-probe conditions met, firing", utilities::logging::info );

		// GET_ENTITY_COORDS is a native wrapper, not a registered command — it
		// does not appear in the runtime map. Probe with a command native
		// instead: GET_PLAYER_NAME (0x6D0D6412E42E3DCA) on the local player
		// PLAYER_ID from the authoritative natives DB: 0x4F8644AF03D0E0D6.
		auto res = invoker::call(0x4F8644AF03D0E0D6 /* PLAYER_ID: PLAYER::PLAYER_ID */, { });
		if (!res.ok)
		{
			utilities::logging::print( ( "invoker probe (hijack): " + res.error ).c_str( ), utilities::logging::warning );
			res = invoker::call_via_thread(0x4F8644AF03D0E0D6, { });
		}
		if (res.ok)
		{
			char buf[96];
			std::snprintf( buf, sizeof( buf ), "invoker probe OK — rax=0x%016llx (player index)", static_cast< unsigned long long >( res.value ) );
			utilities::logging::print( buf, utilities::logging::success );
		}
		else
		{
			utilities::logging::print( ( "invoker probe failed: " + res.error ).c_str( ), utilities::logging::error );
		}
	}).detach();

	framework::engine::initialize();

	std::cin.get();

	if (settings::mutex) {
		ReleaseMutex(settings::mutex);
		CloseHandle(settings::mutex);
	}
} 