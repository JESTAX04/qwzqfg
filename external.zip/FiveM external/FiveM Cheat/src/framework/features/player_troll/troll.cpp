// language: C++, file: troll.cpp, target: Windows 11, MSVC
// Write-based player troll actions. Every offset used here comes from this
// project's own sdk (ped.cpp / engine.cpp); nothing invented per-call.

#include "troll.hpp"

#include <chrono>
#include <cstdio>
#include <mutex>
#include <set>
#include <thread>
#include <unordered_map>

#include "../features.hpp"
#include "../../engine/engine.hpp"
#include "../../engine/globals.hpp"
#include "../../menu/gui/framework/framework.hpp"

using namespace framework::engine;

namespace
{
    constexpr int k_freeze_hold_ms = 3000;
    constexpr int k_freeze_tick_ms = 100;
    constexpr float k_launch_speed = 150.0f;

    // Per-action cooldown so a held Enter on a button cannot hammer writes.
    std::mutex cooldown_mtx;
    std::unordered_map<int, std::chrono::steady_clock::time_point> last_run;

    bool cooldown_ready(troll::action_id id)
    {
        std::lock_guard lock(cooldown_mtx);
        auto now = std::chrono::steady_clock::now();
        auto& slot = last_run[static_cast<int>(id)];
        if (now < slot)
            return false;
        slot = now + std::chrono::milliseconds(250);
        return true;
    }

    // Freeze worker: pins pos + zeroes velocity for a short window. Detached on
    // purpose — joining it from the UI thread would stall the overlay.
    std::mutex freeze_mtx;
    std::set<uintptr_t> active_freezes;

    void freeze_worker(uintptr_t ped_addr, Vector3 pinned)
    {
        const auto deadline = std::chrono::steady_clock::now() + std::chrono::milliseconds(k_freeze_hold_ms);
        const Vector3 still{ 0.f, 0.f, 0.f };

        while (std::chrono::steady_clock::now() < deadline)
        {
            if (!globals::memory)
                break;

            globals::memory->write_memory(ped_addr + 0x90, pinned);
            globals::memory->write_memory(ped_addr + 0x320, still);

            // Navigation transform follows so the ped does not snap back client-side.
            auto navigation = globals::memory->simple_read<uintptr_t>(ped_addr + 0x30);
            if (navigation)
                globals::memory->write_memory(navigation + 0x50, pinned);

            std::this_thread::sleep_for(std::chrono::milliseconds(k_freeze_tick_ms));
        }

        std::lock_guard lock(freeze_mtx);
        active_freezes.erase(ped_addr);
    }
}  // namespace

troll::troll_result troll::run_action(action_id id, const player_cache::entity& target)
{
    if (!target.addr || !utilities::is_valid_address(target.addr))
        return { false, "invalid target" };

    if (!globals::memory || !globals::memory->success)
        return { false, "not attached" };

    if (!cooldown_ready(id))
        return { false, "cooldown" };

    auto local = globals::world.get_local_ped();
    if (!local.is_valid())
        return { false, "local ped invalid" };

    switch (id)
    {
    case action_id::bring:
    {
        // Drop them 1.5m in front of the local player's facing vector.
        Vector3 local_pos{};
        if (!globals::memory->read_memory(local.addr + 0x90, local_pos) || !std::isfinite(local_pos.x))
            return { false, "local position unreadable" };

        Vector3 forward{};
        globals::memory->read_memory(local.addr + 0x70, forward);

        Vector3 dest = local_pos + forward * 1.5f;
        if (!target.set_pos_checked(dest))
            return { false, "position write failed" };

        return { true, "brought to you" };
    }

    case action_id::freeze:
    {
        {
            std::lock_guard lock(freeze_mtx);
            if (active_freezes.contains(target.addr))
                return { false, "already frozen" };
            active_freezes.insert(target.addr);
        }

        Vector3 pinned{};
        if (!globals::memory->read_memory(target.addr + 0x90, pinned) || !std::isfinite(pinned.x))
        {
            std::lock_guard lock(freeze_mtx);
            active_freezes.erase(target.addr);
            return { false, "target position unreadable" };
        }

        std::thread(freeze_worker, target.addr, pinned).detach();
        return { true, "frozen for 3s" };
    }

    case action_id::launch_sky:
    {
        const Vector3 up{ 0.f, 0.f, k_launch_speed };
        if (!globals::memory->write_memory(target.addr + 0x320, up))
            return { false, "velocity write failed" };
        return { true, "launched" };
    }

    case action_id::ram_with_truck:
    {
        auto replay = g_sdk->get_replay();
        if (!replay.is_valid())
            return { false, "replay interface missing" };

        auto veh_interface = replay.get_veh_interface();
        if (!veh_interface.is_valid())
            return { false, "vehicle interface missing" };

        auto veh_list = veh_interface.get_veh_list();
        if (!veh_list)
            return { false, "vehicle list null" };

        auto local_vehicle = local.get_last_vehicle();

        Vector3 dest{};
        if (!globals::memory->read_memory(target.addr + 0x90, dest) || !std::isfinite(dest.x))
            return { false, "target position unreadable" };
        dest.z += 3.0f;  // drop it onto them

        for (int i = 0; i < 256; i++)
        {
            auto veh = sdk::vehicle(globals::memory->simple_read<uintptr_t>(veh_list + (i * 0x10)));
            if (!veh.is_valid() || veh.addr == local_vehicle.addr)
                continue;

            // Same CEntity transform pattern as peds: root at 0x90, nav matrix at 0x30.
            auto navigation = globals::memory->simple_read<uintptr_t>(veh.addr + 0x30);
            if (!navigation)
                continue;

            globals::memory->write_memory(veh.addr + 0x90, dest);
            globals::memory->write_memory(navigation + 0x50, dest);

            const Vector3 down{ 0.f, 0.f, -10.0f };
            globals::memory->write_memory(veh.addr + 0x320, down);

            return { true, "vehicle teleported" };
        }

        return { false, "no vehicle found" };
    }

    case action_id::copy_outfit:
    {
        // Per-build constants, same class of hardcode as offsets::frag_inst.
        // Raw-range copy: replicates the drawable/texture/prop layout regardless
        // of the exact packing the current FiveM build uses.
        constexpr uintptr_t k_outfit_base = 0x11A0;
        constexpr size_t k_outfit_range = 0x90;

        struct outfit_blob
        {
            uint8_t data[k_outfit_range];
        };

        auto blob = globals::memory->simple_read<outfit_blob>(target.addr + k_outfit_base);
        if (!globals::memory->write_memory(local.addr + k_outfit_base, blob))
            return { false, "outfit write failed" };

        return { true, "outfit copied — re-sync if visuals lag" };
    }

    case action_id::disarm:
    {
        if (!invoker::ready)
            return { false, "invoker not ready" };

        // Remove all ped weapons is a loop native; the single-call equivalent:
        // SET_PED_DEFAULT_WEAPON_DELAY is wrong — correct tool is
        // REMOVE_ALL_PED_WEAPONS (0xF25DF915FA38C5F3): (Ped, BOOL)
        auto res = invoker::call(0xF25DF915FA38C5F3, { target.addr, 1 });
        if (!res.ok)
            return { false, "disarm: " + res.error };
        return { true, "disarmed" };
    }

    case action_id::silent_kill:
    {
        if (!target.set_health_checked(-1.0f))
            return { false, "health write failed" };
        return { true, "killed" };
    }

    // ---- invoker-backed actions (phase 3) ----

    case action_id::probe:
    {
        if (!invoker::ready)
            return { false, "invoker not ready: " + invoker::last_error };

        // Harmless round-trip: GET_ENTITY_COORDS on the target ped.
        // The stub must execute inside the game for this to return sane floats.
        auto res = invoker::call(nat::GET_ENTITY_COORDS, { target.addr, 0 });
        if (!res.ok)
            return { false, "probe: " + res.error };

        // The result slot holds a Vector3 return by value in rax:x8 — GTA
        // natives return vectors via a hidden out-pointer, so rax carries the
        // out-pointer we passed. The stub's return slot still proves execution.
        return { true, "probe executed, rax=0x" + [&] {
            char b[32];
            std::snprintf(b, sizeof(b), "%016llx", static_cast<unsigned long long>(res.value));
            return std::string(b);
        }() };
    }

    case action_id::explosion:
    {
        if (!invoker::ready)
            return { false, "invoker not ready" };

        Vector3 pos{};
        if (!globals::memory->read_memory(target.addr + 0x90, pos) || !std::isfinite(pos.x))
            return { false, "target position unreadable" };

        // ADD_EXPLOSION(x, y, z, type, damage, audible, invisible, camShake)
        // type 5 = grenade, modest dmg. Floats passed as raw uint64 bit patterns
        // (low 32 bits — the stub loads them into xmm via the stack spill).
        const uint64_t fx = static_cast<uint64_t>(pos.x), fy = static_cast<uint64_t>(pos.y), fz = static_cast<uint64_t>(pos.z);
        uint32_t dmg_f = 0; { float f = 50.0f; std::memcpy(&dmg_f, &f, 4); }
        uint32_t shake_f = 0; { float f = 0.5f; std::memcpy(&shake_f, &f, 4); }
        auto res = invoker::call(nat::ADD_EXPLOSION,
            { fx, fy, fz, 5, dmg_f, 1, 0, shake_f });
        if (!res.ok)
            return { false, "explosion: " + res.error };
        return { true, "boom" };
    }

    case action_id::burn:
    {
        if (!invoker::ready)
            return { false, "invoker not ready" };

        auto res = invoker::call(nat::START_ENTITY_FIRE, { target.addr });
        if (!res.ok)
            return { false, "burn: " + res.error };
        return { true, "burning" };
    }

    case action_id::ragdoll:
    {
        if (!invoker::ready)
            return { false, "invoker not ready" };

        // SET_PED_TO_RAGDOLL(ped, time1, time2, type, p4, p5, p6)
        // time in ms: 10000/10000, type 0 = standard.
        auto res = invoker::call(nat::SET_PED_TO_RAGDOLL,
            { target.addr, 10000, 10000, 0, 0, 0, 0 });
        if (!res.ok)
            return { false, "ragdoll: " + res.error };
        return { true, "ragdolled 10s" };
    }

    case action_id::cage:
    {
        if (!invoker::ready)
            return { false, "invoker not ready" };

        Vector3 pos{};
        if (!globals::memory->read_memory(target.addr + 0x90, pos) || !std::isfinite(pos.x))
            return { false, "target position unreadable" };

        // Cage = prop_container_dumper_a dropped over them. Request first,
        // spin until loaded (bounded), then create at their position.
        auto req = invoker::call(nat::REQUEST_MODEL, { nat::PROP_CONTAINER_DUMPER });
        if (!req.ok)
            return { false, "cage request: " + req.error };

        bool loaded = false;
        for (int i = 0; i < 50; i++)
        {
            auto has = invoker::call(nat::HAS_MODEL_LOADED, { nat::PROP_CONTAINER_DUMPER });
            if (has.ok && has.value)
            {
                loaded = true;
                break;
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(50));
        }
        if (!loaded)
            return { false, "cage model never loaded" };

        auto res = invoker::call(nat::CREATE_OBJECT,
            { nat::PROP_CONTAINER_DUMPER,
              static_cast<uint64_t>(pos.x), static_cast<uint64_t>(pos.y), static_cast<uint64_t>(pos.z),
              1, 1, 0, 0 });
        if (!res.ok)
            return { false, "cage create: " + res.error };

        char note[64];
        std::snprintf(note, sizeof(note), "caged, obj=0x%llx", static_cast<unsigned long long>(res.value));
        return { true, note };
    }
    }

    return { false, "unknown action" };
}
