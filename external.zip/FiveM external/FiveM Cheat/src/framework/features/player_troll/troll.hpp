#pragma once

#include <string>
#include <utility>
#include "../cache_data/player_cache.hpp"
#include "../../memory/invoker.hpp"

// GTA native hashes (FiveM cross-map keys, also valid as raw hashes because the
// runtime tree is keyed by the original hash).
namespace nat
{
    constexpr uint64_t PLAYER_ID                    = 0x4D816939A8D28249;  // GET_PLAYER_INDEX: () -> int (local = -1 sentinel handled by caller)
    constexpr uint64_t GET_PLAYER_PED               = 0x43A66C31C68491C0;  // (int playerIndex) -> Ped
    constexpr uint64_t GET_ENTITY_COORDS            = 0x3FEF770D40960D5A;  // (Entity, BOOL alive) -> Vector3*
    constexpr uint64_t ADD_EXPLOSION                = 0xE396470EE3CE4B92;  // (float x,y,z, int type, float dmg, BOOL audible, BOOL invisible, float camShake)
    constexpr uint64_t START_ENTITY_FIRE            = 0xF6A99296802570E4;  // (Entity)
    constexpr uint64_t SET_PED_TO_RAGDOLL           = 0xAEEDFB506E6E7F96;  // (Ped, time1, time2, ragdollType, BOOL p4, BOOL p5, BOOL p6)
    constexpr uint64_t CREATE_OBJECT                = 0x509D5878EB39E4A3;  // (Hash model, x,y,z, BOOL network, BOOL netDynamic, BOOL p7, BOOL p8)
    constexpr uint64_t FREEZE_ENTITY_POSITION       = 0x4C7E91107AA629CD;  // (Entity, BOOL toggle)
    constexpr uint64_t REQUEST_MODEL                = 0x963D8A3A0A00A739;  // (Hash)
    constexpr uint64_t HAS_MODEL_LOADED             = 0x98A4E0ED97158FB2;  // (Hash) -> BOOL
    constexpr uint64_t PROP_CONTAINER_DUMPER        = 0x997AB8508A2A7B29;  // prop_container_dumper_a model hash
}  // namespace nat

// External write-based player actions. Native-only actions live behind the
// invoker once phase 2 lands; everything here is pure memory read/write.
namespace troll
{
    enum class action_id
    {
        probe,          // invoker round-trip: PLAYER_ID -> GET_PLAYER_PED
        bring,
        freeze,
        launch_sky,
        ram_with_truck,
        copy_outfit,
        disarm,
        silent_kill,
        explosion,
        burn,
        ragdoll,
        cage,
    };

    struct troll_result
    {
        bool ok = false;
        std::string note;
    };

    // Runs one action against the selected cached entity. Returns a user-facing note.
    troll_result run_action(action_id id, const player_cache::entity& target);

    // One-line-per-subsystem status for the player tab header.
    inline std::string system_status()
    {
        using namespace framework::engine;
        std::string s;
        s += globals::memory && globals::memory->success ? "[OK] attached to FiveM" : "[..] waiting for FiveM window";
        s += "\n";
        s += offsets::world ? "[OK] world signature" : "[..] world signature";
        s += "\n";
        s += offsets::replay_interface ? "[OK] replay interface" : "[..] replay interface";
        s += "\n";
        s += globals::viewport ? "[OK] viewport" : "[..] viewport";
        s += "\n";
        if (invoker::ready)
            s += "[OK] native invoker — " + std::to_string(invoker::cross_map_count) + " natives";
        else if (!invoker::last_error.empty())
            s += "[!!] invoker: " + invoker::last_error;
        else
            s += "[..] native invoker";
        return s;
    }
}  // namespace troll
