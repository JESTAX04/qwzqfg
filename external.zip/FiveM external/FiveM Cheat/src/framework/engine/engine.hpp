#pragma once

#include <Inc/SimpleMath.h>
#include <Windows.h>

#include <memory>
#include <string>

using namespace DirectX::SimpleMath;

// struct CPedInventory
//{
//	virtual ~CPedInventory() = default;
//	void* unk;
//	void* ped;
//	//...
// };
//
// class WeaponInfo
//{
// public:
//	char pad_0000[16]; //0x0000
//	uint32_t hash; //0x0010
//	char pad_0014[76]; //0x0014
//	void* ammoInfo; //0x0060
//	char pad_0068[8]; //0x0068
//	uint32_t maxClipSize; //0x0070
//	//...
// };
//
// struct CWeapon
//{
//	virtual ~CWeapon() = default;
//	void* extensions;
//	Vector4 muzzleOffset;
//	Vector4 worldPosition;
//	char pad0[0x10]; //0x30-0x40
//	WeaponInfo* info; //0x40-0x48
//	int activeTime; //0x48-0x4C
//	int lastFiredTime; //0x4C-0x50
//	int activeTime2; //0x50-0x54
//	uint16_t ammoTotal;
//	uint16_t ammoInClip; //0x56-0x58
//	__int64 pWeaponObject;
//	CPedInventory* pInventoryPed; //0x60-=0x68
//	CWeapon* pUnkWeapon; //self? //0x68-0x70
//	char pad2[0xB0]; //0x70-0x120
//	void* clipComponent; //0x120-0x128
//	char pad3[0x30];
//	void* pUnk; //0x158-0x160
//	char pad4[0x60];
//	char ammoState; //0x1C0
//	DWORD weaponStateFlags; // 0x80 = silenced
// };

enum eVehicleLockState
{
    // No specific lock state, vehicle behaves according to the game's default settings.
    VEHICLELOCK_NONE = 0,
    // Vehicle is fully unlocked, allowing free entry by players and NPCs.
    VEHICLELOCK_UNLOCKED = 1,
    // Vehicle is locked, preventing entry by players and NPCs.
    VEHICLELOCK_LOCKED = 2,
    // Vehicle locks out only players, allowing NPCs to enter.
    VEHICLELOCK_LOCKOUT_PLAYER_ONLY = 3,
    // Vehicle is locked once a player enters, preventing others from entering.
    VEHICLELOCK_LOCKED_PLAYER_INSIDE = 4,
    // Vehicle starts in a locked state, but may be unlocked through game events.
    VEHICLELOCK_LOCKED_INITIALLY = 5,
    // Forces the vehicle's doors to shut and lock.
    VEHICLELOCK_FORCE_SHUT_DOORS = 6,
    // Vehicle is locked but can still be damaged.
    VEHICLELOCK_LOCKED_BUT_CAN_BE_DAMAGED = 7,
    // Vehicle is locked, but its trunk/boot remains unlocked.
    VEHICLELOCK_LOCKED_BUT_BOOT_UNLOCKED = 8,
    // Vehicle is locked and does not allow passengers, except for the driver.
    VEHICLELOCK_LOCKED_NO_PASSENGERS = 9,
    // Vehicle is completely locked, preventing entry entirely, even if previously inside.
    VEHICLELOCK_CANNOT_ENTER = 10
};

enum ePedBoneId : uint16_t
{
    SKEL_ROOT = 0x0,
    SKEL_Pelvis = 0x2E28,
    SKEL_L_Thigh = 0xE39F,
    SKEL_L_Calf = 0xF9BB,
    SKEL_L_Foot = 0x3779,
    SKEL_L_Toe0 = 0x83C,
    EO_L_Foot = 0x84C5,
    EO_L_Toe = 0x68BD,
    IK_L_Foot = 0xFEDD,
    PH_L_Foot = 0xE175,
    MH_L_Knee = 0xB3FE,
    SKEL_R_Thigh = 0xCA72,
    SKEL_R_Calf = 0x9000,
    SKEL_R_Foot = 0xCC4D,
    SKEL_R_Toe0 = 0x512D,
    EO_R_Foot = 0x1096,
    EO_R_Toe = 0x7163,
    IK_R_Foot = 0x8AAE,
    PH_R_Foot = 0x60E6,
    MH_R_Knee = 0x3FCF,
    RB_L_ThighRoll = 0x5C57,
    RB_R_ThighRoll = 0x192A,
    SKEL_Spine_Root = 0xE0FD,
    SKEL_Spine0 = 0x5C01,
    SKEL_Spine1 = 0x60F0,
    SKEL_Spine2 = 0x60F1,
    SKEL_Spine3 = 0x60F2,
    SKEL_L_Clavicle = 0xFCD9,
    SKEL_L_UpperArm = 0xB1C5,
    SKEL_L_Forearm = 0xEEEB,
    SKEL_L_Hand = 0x49D9,
    SKEL_L_Finger00 = 0x67F2,
    SKEL_L_Finger01 = 0xFF9,
    SKEL_L_Finger02 = 0xFFA,
    SKEL_L_Finger10 = 0x67F3,
    SKEL_L_Finger11 = 0x1049,
    SKEL_L_Finger12 = 0x104A,
    SKEL_L_Finger20 = 0x67F4,
    SKEL_L_Finger21 = 0x1059,
    SKEL_L_Finger22 = 0x105A,
    SKEL_L_Finger30 = 0x67F5,
    SKEL_L_Finger31 = 0x1029,
    SKEL_L_Finger32 = 0x102A,
    SKEL_L_Finger40 = 0x67F6,
    SKEL_L_Finger41 = 0x1039,
    SKEL_L_Finger42 = 0x103A,
    PH_L_Hand = 0xEB95,
    IK_L_Hand = 0x8CBD,
    RB_L_ForeArmRoll = 0xEE4F,
    RB_L_ArmRoll = 0x1470,
    MH_L_Elbow = 0x58B7,
    SKEL_R_Clavicle = 0x29D2,
    SKEL_R_UpperArm = 0x9D4D,
    SKEL_R_Forearm = 0x6E5C,
    SKEL_R_Hand = 0xDEAD,
    SKEL_R_Finger00 = 0xE5F2,
    SKEL_R_Finger01 = 0xFA10,
    SKEL_R_Finger02 = 0xFA11,
    SKEL_R_Finger10 = 0xE5F3,
    SKEL_R_Finger11 = 0xFA60,
    SKEL_R_Finger12 = 0xFA61,
    SKEL_R_Finger20 = 0xE5F4,
    SKEL_R_Finger21 = 0xFA70,
    SKEL_R_Finger22 = 0xFA71,
    SKEL_R_Finger30 = 0xE5F5,
    SKEL_R_Finger31 = 0xFA40,
    SKEL_R_Finger32 = 0xFA41,
    SKEL_R_Finger40 = 0xE5F6,
    SKEL_R_Finger41 = 0xFA50,
    SKEL_R_Finger42 = 0xFA51,
    PH_R_Hand = 0x6F06,
    IK_R_Hand = 0x188E,
    RB_R_ForeArmRoll = 0xAB22,
    RB_R_ArmRoll = 0x90FF,
    MH_R_Elbow = 0xBB0,
    SKEL_Neck_1 = 0x9995,
    SKEL_Head = 0x796E,
    IK_Head = 0x322C,
    FACIAL_facialRoot = 0xFE2C,
    FB_L_Brow_Out_000 = 0xE3DB,
    FB_L_Lid_Upper_000 = 0xB2B6,
    FB_L_Eye_000 = 0x62AC,
    FB_L_CheekBone_000 = 0x542E,
    FB_L_Lip_Corner_000 = 0x74AC,
    FB_R_Lid_Upper_000 = 0xAA10,
    FB_R_Eye_000 = 0x6B52,
    FB_R_CheekBone_000 = 0x4B88,
    FB_R_Brow_Out_000 = 0x54C,
    FB_R_Lip_Corner_000 = 0x2BA6,
    FB_Brow_Centre_000 = 0x9149,
    FB_UpperLipRoot_000 = 0x4ED2,
    FB_UpperLip_000 = 0xF18F,
    FB_L_Lip_Top_000 = 0x4F37,
    FB_R_Lip_Top_000 = 0x4537,
    FB_Jaw_000 = 0xB4A0,
    FB_LowerLipRoot_000 = 0x4324,
    FB_LowerLip_000 = 0x508F,
    FB_L_Lip_Bot_000 = 0xB93B,
    FB_R_Lip_Bot_000 = 0xC33B,
    FB_Tongue_000 = 0xB987,
    RB_Neck_1 = 0x8B93,
    SPR_L_Breast = 0xFC8E,
    SPR_R_Breast = 0x885F,
    IK_Root = 0xDD1C,
    SKEL_Neck_2 = 0x5FD4,
    SKEL_Pelvis1 = 0xD003,
    SKEL_PelvisRoot = 0x45FC,
    SKEL_SADDLE = 0x9524,
    MH_L_CalfBack = 0x1013,
    MH_L_ThighBack = 0x600D,
    SM_L_Skirt = 0xC419,
    MH_R_CalfBack = 0xB013,
    MH_R_ThighBack = 0x51A3,
    SM_R_Skirt = 0x7712,
    SM_M_BackSkirtRoll = 0xDBB,
    SM_L_BackSkirtRoll = 0x40B2,
    SM_R_BackSkirtRoll = 0xC141,
    SM_M_FrontSkirtRoll = 0xCDBB,
    SM_L_FrontSkirtRoll = 0x9B69,
    SM_R_FrontSkirtRoll = 0x86F1,
    SM_CockNBalls_ROOT = 0xC67D,
    SM_CockNBalls = 0x9D34,
    MH_L_Finger00 = 0x8C63,
    MH_L_FingerBulge00 = 0x5FB8,
    MH_L_Finger10 = 0x8C53,
    MH_L_FingerTop00 = 0xA244,
    MH_L_HandSide = 0xC78A,
    MH_Watch = 0x2738,
    MH_L_Sleeve = 0x933C,
    MH_R_Finger00 = 0x2C63,
    MH_R_FingerBulge00 = 0x69B8,
    MH_R_Finger10 = 0x2C53,
    MH_R_FingerTop00 = 0xEF4B,
    MH_R_HandSide = 0x68FB,
    MH_R_Sleeve = 0x92DC,
    FACIAL_jaw = 0xB21,
    FACIAL_underChin = 0x8A95,
    FACIAL_L_underChin = 0x234E,
    FACIAL_chin = 0xB578,
    FACIAL_chinSkinBottom = 0x98BC,
    FACIAL_L_chinSkinBottom = 0x3E8F,
    FACIAL_R_chinSkinBottom = 0x9E8F,
    FACIAL_tongueA = 0x4A7C,
    FACIAL_tongueB = 0x4A7D,
    FACIAL_tongueC = 0x4A7E,
    FACIAL_tongueD = 0x4A7F,
    FACIAL_tongueE = 0x4A80,
    FACIAL_L_tongueE = 0x35F2,
    FACIAL_R_tongueE = 0x2FF2,
    FACIAL_L_tongueD = 0x35F1,
    FACIAL_R_tongueD = 0x2FF1,
    FACIAL_L_tongueC = 0x35F0,
    FACIAL_R_tongueC = 0x2FF0,
    FACIAL_L_tongueB = 0x35EF,
    FACIAL_R_tongueB = 0x2FEF,
    FACIAL_L_tongueA = 0x35EE,
    FACIAL_R_tongueA = 0x2FEE,
    FACIAL_chinSkinTop = 0x7226,
    FACIAL_L_chinSkinTop = 0x3EB3,
    FACIAL_chinSkinMid = 0x899A,
    FACIAL_L_chinSkinMid = 0x4427,
    FACIAL_L_chinSide = 0x4A5E,
    FACIAL_R_chinSkinMid = 0xF5AF,
    FACIAL_R_chinSkinTop = 0xF03B,
    FACIAL_R_chinSide = 0xAA5E,
    FACIAL_R_underChin = 0x2BF4,
    FACIAL_L_lipLowerSDK = 0xB9E1,
    FACIAL_L_lipLowerAnalog = 0x244A,
    FACIAL_L_lipLowerThicknessV = 0xC749,
    FACIAL_L_lipLowerThicknessH = 0xC67B,
    FACIAL_lipLowerSDK = 0x7285,
    FACIAL_lipLowerAnalog = 0xD97B,
    FACIAL_lipLowerThicknessV = 0xC5BB,
    FACIAL_lipLowerThicknessH = 0xC5ED,
    FACIAL_R_lipLowerSDK = 0xA034,
    FACIAL_R_lipLowerAnalog = 0xC2D9,
    FACIAL_R_lipLowerThicknessV = 0xC6E9,
    FACIAL_R_lipLowerThicknessH = 0xC6DB,
    FACIAL_nose = 0x20F1,
    FACIAL_L_nostril = 0x7322,
    FACIAL_L_nostrilThickness = 0xC15F,
    FACIAL_noseLower = 0xE05A,
    FACIAL_L_noseLowerThickness = 0x79D5,
    FACIAL_R_noseLowerThickness = 0x7975,
    FACIAL_noseTip = 0x6A60,
    FACIAL_R_nostril = 0x7922,
    FACIAL_R_nostrilThickness = 0x36FF,
    FACIAL_noseUpper = 0xA04F,
    FACIAL_L_noseUpper = 0x1FB8,
    FACIAL_noseBridge = 0x9BA3,
    FACIAL_L_nasolabialFurrow = 0x5ACA,
    FACIAL_L_nasolabialBulge = 0xCD78,
    FACIAL_L_cheekLower = 0x6907,
    FACIAL_L_cheekLowerBulge1 = 0xE3FB,
    FACIAL_L_cheekLowerBulge2 = 0xE3FC,
    FACIAL_L_cheekInner = 0xE7AB,
    FACIAL_L_cheekOuter = 0x8161,
    FACIAL_L_eyesackLower = 0x771B,
    FACIAL_L_eyeball = 0x1744,
    FACIAL_L_eyelidLower = 0x998C,
    FACIAL_L_eyelidLowerOuterSDK = 0xFE4C,
    FACIAL_L_eyelidLowerOuterAnalog = 0xB9AA,
    FACIAL_L_eyelashLowerOuter = 0xD7F6,
    FACIAL_L_eyelidLowerInnerSDK = 0xF151,
    FACIAL_L_eyelidLowerInnerAnalog = 0x8242,
    FACIAL_L_eyelashLowerInner = 0x4CCF,
    FACIAL_L_eyelidUpper = 0x97C1,
    FACIAL_L_eyelidUpperOuterSDK = 0xAF15,
    FACIAL_L_eyelidUpperOuterAnalog = 0x67FA,
    FACIAL_L_eyelashUpperOuter = 0x27B7,
    FACIAL_L_eyelidUpperInnerSDK = 0xD341,
    FACIAL_L_eyelidUpperInnerAnalog = 0xF092,
    FACIAL_L_eyelashUpperInner = 0x9B1F,
    FACIAL_L_eyesackUpperOuterBulge = 0xA559,
    FACIAL_L_eyesackUpperInnerBulge = 0x2F2A,
    FACIAL_L_eyesackUpperOuterFurrow = 0xC597,
    FACIAL_L_eyesackUpperInnerFurrow = 0x52A7,
    FACIAL_forehead = 0x9218,
    FACIAL_L_foreheadInner = 0x843,
    FACIAL_L_foreheadInnerBulge = 0x767C,
    FACIAL_L_foreheadOuter = 0x8DCB,
    FACIAL_skull = 0x4221,
    FACIAL_foreheadUpper = 0xF7D6,
    FACIAL_L_foreheadUpperInner = 0xCF13,
    FACIAL_L_foreheadUpperOuter = 0x509B,
    FACIAL_R_foreheadUpperInner = 0xCEF3,
    FACIAL_R_foreheadUpperOuter = 0x507B,
    FACIAL_L_temple = 0xAF79,
    FACIAL_L_ear = 0x19DD,
    FACIAL_L_earLower = 0x6031,
    FACIAL_L_masseter = 0x2810,
    FACIAL_L_jawRecess = 0x9C7A,
    FACIAL_L_cheekOuterSkin = 0x14A5,
    FACIAL_R_cheekLower = 0xF367,
    FACIAL_R_cheekLowerBulge1 = 0x599B,
    FACIAL_R_cheekLowerBulge2 = 0x599C,
    FACIAL_R_masseter = 0x810,
    FACIAL_R_jawRecess = 0x93D4,
    FACIAL_R_ear = 0x1137,
    FACIAL_R_earLower = 0x8031,
    FACIAL_R_eyesackLower = 0x777B,
    FACIAL_R_nasolabialBulge = 0xD61E,
    FACIAL_R_cheekOuter = 0xD32,
    FACIAL_R_cheekInner = 0x737C,
    FACIAL_R_noseUpper = 0x1CD6,
    FACIAL_R_foreheadInner = 0xE43,
    FACIAL_R_foreheadInnerBulge = 0x769C,
    FACIAL_R_foreheadOuter = 0x8FCB,
    FACIAL_R_cheekOuterSkin = 0xB334,
    FACIAL_R_eyesackUpperInnerFurrow = 0x9FAE,
    FACIAL_R_eyesackUpperOuterFurrow = 0x140F,
    FACIAL_R_eyesackUpperInnerBulge = 0xA359,
    FACIAL_R_eyesackUpperOuterBulge = 0x1AF9,
    FACIAL_R_nasolabialFurrow = 0x2CAA,
    FACIAL_R_temple = 0xAF19,
    FACIAL_R_eyeball = 0x1944,
    FACIAL_R_eyelidUpper = 0x7E14,
    FACIAL_R_eyelidUpperOuterSDK = 0xB115,
    FACIAL_R_eyelidUpperOuterAnalog = 0xF25A,
    FACIAL_R_eyelashUpperOuter = 0xE0A,
    FACIAL_R_eyelidUpperInnerSDK = 0xD541,
    FACIAL_R_eyelidUpperInnerAnalog = 0x7C63,
    FACIAL_R_eyelashUpperInner = 0x8172,
    FACIAL_R_eyelidLower = 0x7FDF,
    FACIAL_R_eyelidLowerOuterSDK = 0x1BD,
    FACIAL_R_eyelidLowerOuterAnalog = 0x457B,
    FACIAL_R_eyelashLowerOuter = 0xBE49,
    FACIAL_R_eyelidLowerInnerSDK = 0xF351,
    FACIAL_R_eyelidLowerInnerAnalog = 0xE13,
    FACIAL_R_eyelashLowerInner = 0x3322,
    FACIAL_L_lipUpperSDK = 0x8F30,
    FACIAL_L_lipUpperAnalog = 0xB1CF,
    FACIAL_L_lipUpperThicknessH = 0x37CE,
    FACIAL_L_lipUpperThicknessV = 0x38BC,
    FACIAL_lipUpperSDK = 0x1774,
    FACIAL_lipUpperAnalog = 0xE064,
    FACIAL_lipUpperThicknessH = 0x7993,
    FACIAL_lipUpperThicknessV = 0x7981,
    FACIAL_L_lipCornerSDK = 0xB1C,
    FACIAL_L_lipCornerAnalog = 0xE568,
    FACIAL_L_lipCornerThicknessUpper = 0x7BC,
    FACIAL_L_lipCornerThicknessLower = 0xDD42,
    FACIAL_R_lipUpperSDK = 0x7583,
    FACIAL_R_lipUpperAnalog = 0x51CF,
    FACIAL_R_lipUpperThicknessH = 0x382E,
    FACIAL_R_lipUpperThicknessV = 0x385C,
    FACIAL_R_lipCornerSDK = 0xB3C,
    FACIAL_R_lipCornerAnalog = 0xEE0E,
    FACIAL_R_lipCornerThicknessUpper = 0x54C3,
    FACIAL_R_lipCornerThicknessLower = 0x2BBA,
    MH_MulletRoot = 0x3E73,
    MH_MulletScaler = 0xA1C2,
    MH_Hair_Scale = 0xC664,
    MH_Hair_Crown = 0x1675,
    SM_Torch = 0x8D6,
    FX_Light = 0x8959,
    FX_Light_Scale = 0x5038,
    FX_Light_Switch = 0xE18E,
    BagRoot = 0xAD09,
    BagPivotROOT = 0xB836,
    BagPivot = 0x4D11,
    BagBody = 0xAB6D,
    BagBone_R = 0x937,
    BagBone_L = 0x991,
    SM_LifeSaver_Front = 0x9420,
    SM_R_Pouches_ROOT = 0x2962,
    SM_R_Pouches = 0x4141,
    SM_L_Pouches_ROOT = 0x2A02,
    SM_L_Pouches = 0x4B41,
    SM_Suit_Back_Flapper = 0xDA2D,
    SPR_CopRadio = 0x8245,
    SM_LifeSaver_Back = 0x2127,
    MH_BlushSlider = 0xA0CE,
    SKEL_Tail_01 = 0x347,
    SKEL_Tail_02 = 0x348,
    MH_L_Concertina_B = 0xC988,
    MH_L_Concertina_A = 0xC987,
    MH_R_Concertina_B = 0xC8E8,
    MH_R_Concertina_A = 0xC8E7,
    MH_L_ShoulderBladeRoot = 0x8711,
    MH_L_ShoulderBlade = 0x4EAF,
    MH_R_ShoulderBladeRoot = 0x3A0A,
    MH_R_ShoulderBlade = 0x54AF,
    FB_R_Ear_000 = 0x6CDF,
    SPR_R_Ear = 0x63B6,
    FB_L_Ear_000 = 0x6439,
    SPR_L_Ear = 0x5B10,
    FB_TongueA_000 = 0x4206,
    FB_TongueB_000 = 0x4207,
    FB_TongueC_000 = 0x4208,
    SKEL_L_Toe1 = 0x1D6B,
    SKEL_R_Toe1 = 0xB23F,
    SKEL_Tail_03 = 0x349,
    SKEL_Tail_04 = 0x34A,
    SKEL_Tail_05 = 0x34B,
    SPR_Gonads_ROOT = 0xBFDE,
    SPR_Gonads = 0x1C00,
    FB_L_Brow_Out_001 = 0xE3DB,
    FB_L_Lid_Upper_001 = 0xB2B6,
    FB_L_Eye_001 = 0x62AC,
    FB_L_CheekBone_001 = 0x542E,
    FB_L_Lip_Corner_001 = 0x74AC,
    FB_R_Lid_Upper_001 = 0xAA10,
    FB_R_Eye_001 = 0x6B52,
    FB_R_CheekBone_001 = 0x4B88,
    FB_R_Brow_Out_001 = 0x54C,
    FB_R_Lip_Corner_001 = 0x2BA6,
    FB_Brow_Centre_001 = 0x9149,
    FB_UpperLipRoot_001 = 0x4ED2,
    FB_UpperLip_001 = 0xF18F,
    FB_L_Lip_Top_001 = 0x4F37,
    FB_R_Lip_Top_001 = 0x4537,
    FB_Jaw_001 = 0xB4A0,
    FB_LowerLipRoot_001 = 0x4324,
    FB_LowerLip_001 = 0x508F,
    FB_L_Lip_Bot_001 = 0xB93B,
    FB_R_Lip_Bot_001 = 0xC33B,
    FB_Tongue_001 = 0xB987
};
enum BlipColor
{
    ColorWhite = 0,
    ColorRed = 1,
    ColorGreen = 2,
    ColorBlue = 3,
    ColorPlayer = 4,
    ColorYellow = 5,
    ColorPurple = 7,
    ColorVehicle = 38,
    ColorMichael = 42,
    ColorFranklin = 43,
    ColorTrevor = 44,
    ColorMissionRed = 49,
    ColorMissionVehicle = 54,
    ColorYellowMission = 66,
    ColorYellowMission2 = 60,
    ColorWaypoint = 84
};

enum BlipSprite
{
    SpriteStandard = 1,
    SpriteBig = 2,
    SpritePoliceOfficer = 3,
    SpritePoliceArea = 4,
    SpriteSquare = 5,
    SpritePlayer = 6,
    SpriteNorth = 7,
    SpriteWaypoint = 8,
    SpriteBigCircle = 9,
    SpriteBigCircleOutline = 10,
    SpriteArrowUpOutlined = 11,
    SpriteArrowDownOutlined = 12,
    SpriteArrowUp = 13,
    SpriteArrowDown = 14,
    SpritePoliceHelicopterAnimated = 15,
    SpriteJet = 16,
    SpriteNumber1 = 17,
    SpriteNumber2 = 18,
    SpriteNumber3 = 19,
    SpriteNumber4 = 20,
    SpriteNumber5 = 21,
    SpriteNumber6 = 22,
    SpriteNumber7 = 23,
    SpriteNumber8 = 24,
    SpriteNumber9 = 25,
    SpriteNumber10 = 26,
    SpriteGTAOCrew = 27,
    SpriteGTAOFriendly = 28,
    SpriteLift = 36,
    SpriteRaceFinish = 38,
    SpriteSafehouse = 40,
    SpritePoliceOfficer2 = 41,
    SpritePoliceCarDot = 42,
    SpritePoliceHelicopter = 43,
    SpriteChatBubble = 47,
    SpriteGarage2 = 50,
    SpriteDrugs = 51,
    SpriteStore = 52,
    SpritePoliceCar = 56,
    SpritePolicePlayer = 58,
    SpritePoliceStation = 60,
    SpriteHospital = 61,
    SpriteHelicopter = 64,
    SpriteStrangersAndFreaks = 65,
    SpriteArmoredTruck = 66,
    SpriteTowTruck = 68,
    SpriteBarber = 71,
    SpriteLosSantosCustoms = 72,
    SpriteClothes = 73,
    SpriteTattooParlor = 75,
    SpriteSimeon = 76,
    SpriteLester = 77,
    SpriteMichael = 78,
    SpriteTrevor = 79,
    SpriteRampage = 84,
    SpriteVinewoodTours = 85,
    SpriteLamar = 86,
    SpriteFranklin = 88,
    SpriteChinese = 89,
    SpriteAirport = 90,
    SpriteBar = 93,
    SpriteBaseJump = 94,
    SpriteCarWash = 100,
    SpriteComedyClub = 102,
    SpriteDart = 103,
    SpriteFIB = 106,
    SpriteDollarSign = 108,
    SpriteGolf = 109,
    SpriteAmmuNation = 110,
    SpriteExile = 112,
    SpriteShootingRange = 119,
    SpriteSolomon = 120,
    SpriteStripClub = 121,
    SpriteTennis = 122,
    SpriteTriathlon = 126,
    SpriteOffRoadRaceFinish = 127,
    SpriteKey = 134,
    SpriteMovieTheater = 135,
    SpriteMusic = 136,
    SpriteMarijuana = 140,
    SpriteHunting = 141,
    SpriteArmsTraffickingGround = 147,
    SpriteNigel = 149,
    SpriteAssaultRifle = 150,
    SpriteBat = 151,
    SpriteGrenade = 152,
    SpriteHealth = 153,
    SpriteKnife = 154,
    SpriteMolotov = 155,
    SpritePistol = 156,
    SpriteRPG = 157,
    SpriteShotgun = 158,
    SpriteSMG = 159,
    SpriteSniper = 160,
    SpriteSonicWave = 161,
    SpritePointOfInterest = 162,
    SpriteGTAOPassive = 163,
    SpriteGTAOUsingMenu = 164,
    SpriteLink = 171,
    SpriteMinigun = 173,
    SpriteGrenadeLauncher = 174,
    SpriteArmor = 175,
    SpriteCastle = 176,
    SpriteCamera = 184,
    SpriteHandcuffs = 188,
    SpriteYoga = 197,
    SpriteCab = 198,
    SpriteNumber11 = 199,
    SpriteNumber12 = 200,
    SpriteNumber13 = 201,
    SpriteNumber14 = 202,
    SpriteNumber15 = 203,
    SpriteNumber16 = 204,
    SpriteShrink = 205,
    SpriteEpsilon = 206,
    SpritePersonalVehicleCar = 225,
    SpritePersonalVehicleBike = 226,
    SpriteCustody = 237,
    SpriteArmsTraffickingAir = 251,
    SpriteFairground = 266,
    SpritePropertyManagement = 267,
    SpriteAltruist = 269,
    SpriteEnemy = 270,
    SpriteChop = 273,
    SpriteDead = 274,
    SpriteHooker = 279,
    SpriteFriend = 280,
    SpriteBountyHit = 303,
    SpriteGTAOMission = 304,
    SpriteGTAOSurvival = 305,
    SpriteCrateDrop = 306,
    SpritePlaneDrop = 307,
    SpriteSub = 308,
    SpriteRace = 309,
    SpriteDeathmatch = 310,
    SpriteArmWrestling = 311,
    SpriteAmmuNationShootingRange = 313,
    SpriteRaceAir = 314,
    SpriteRaceCar = 315,
    SpriteRaceSea = 316,
    SpriteGarbageTruck = 318,
    SpriteMotorCycle = 348,
    SpriteSafehouseForSale = 350,
    SpritePackage = 351,
    SpriteMartinMadrazo = 352,
    SpriteEnemyHelicopter = 353,
    SpriteBoost = 354,
    SpriteDevin = 355,
    SpriteMarina = 356,
    SpriteGarage = 357,
    SpriteGolfFlag = 358,
    SpriteHangar = 359,
    SpriteHelipad = 360,
    SpriteJerryCan = 361,
    SpriteMasks = 362,
    SpriteHeistSetup = 363,
    SpriteIncapacitated = 364,
    SpritePickupSpawn = 365,
    SpriteBoilerSuit = 366,
    SpriteCompleted = 367,
    SpriteRockets = 368,
    SpriteGarageForSale = 369,
    SpriteHelipadForSale = 370,
    SpriteMarinaForSale = 371,
    SpriteHangarForSale = 372,
    SpriteBusiness = 374,
    SpriteBusinessForSale = 375,
    SpriteRaceBike = 376,
    SpriteParachute = 377,
    SpriteTeamDeathmatch = 378,
    SpriteRaceFoot = 379,
    SpriteVehicleDeathmatch = 380,
    SpriteBarry = 381,
    SpriteDom = 382,
    SpriteMaryAnn = 383,
    SpriteCletus = 384,
    SpriteJosh = 385,
    SpriteMinute = 386,
    SpriteOmega = 387,
    SpriteTonya = 388,
    SpritePaparazzo = 389,
    SpriteCrosshair = 390,
    SpriteCreator = 398,
    SpriteCreatorDirection = 399,
    SpriteAbigail = 400,
    SpriteBlimp = 401,
    SpriteRepair = 402,
    SpriteTestosterone = 403,
    SpriteDinghy = 404,
    SpriteFanatic = 405,
    SpriteInformation = 407,
    SpriteCaptureBriefcase = 408,
    SpriteLastTeamStanding = 409,
    SpriteBoat = 410,
    SpriteCaptureHouse = 411,
    SpriteJerryCan2 = 415,
    SpriteRP = 416,
    SpriteGTAOPlayerSafehouse = 417,
    SpriteGTAOPlayerSafehouseDead = 418,
    SpriteCaptureAmericanFlag = 419,
    SpriteCaptureFlag = 420,
    SpriteTank = 421,
    SpriteHelicopterAnimated = 422,
    SpritePlane = 423,
    SpriteJet2 = 424,
    SpritePlayerNoColor = 425,
    SpriteGunCar = 426,
    SpriteSpeedboat = 427,
    SpriteHeist = 428,
    SpriteStopwatch = 430,
    SpriteDollarSignCircled = 431,
    SpriteCrosshair2 = 432,
    SpriteDollarSignSquared = 434,
};

enum ePedConfigFlags
{
    CPED_CONFIG_FLAG_CreatedByFactory = 0,
    CPED_CONFIG_FLAG_CanBeShotInVehicle = 1,
    CPED_CONFIG_FLAG_NoCriticalHits,
    CPED_CONFIG_FLAG_DrownsInWater,
    CPED_CONFIG_FLAG_DrownsInSinkingVehicle,
    CPED_CONFIG_FLAG_DiesInstantlyWhenSwimming,
    CPED_CONFIG_FLAG_HasBulletProofVest,
    CPED_CONFIG_FLAG_UpperBodyDamageAnimsOnly,
    CPED_CONFIG_FLAG_NeverFallOffSkis,
    CPED_CONFIG_FLAG_NeverEverTargetThisPed,
    CPED_CONFIG_FLAG_ThisPedIsATargetPriority,
    CPED_CONFIG_FLAG_TargettableWithNoLos,
    CPED_CONFIG_FLAG_DoesntListenToPlayerGroupCommands,
    CPED_CONFIG_FLAG_NeverLeavesGroup,
    CPED_CONFIG_FLAG_DoesntDropWeaponsWhenDead,
    CPED_CONFIG_FLAG_SetDelayedWeaponAsCurrent,
    CPED_CONFIG_FLAG_KeepTasksAfterCleanUp,
    CPED_CONFIG_FLAG_BlockNonTemporaryEvents,
    CPED_CONFIG_FLAG_HasAScriptBrain,
    CPED_CONFIG_FLAG_WaitingForScriptBrainToLoad,
    CPED_CONFIG_FLAG_AllowMedicsToReviveMe,
    CPED_CONFIG_FLAG_MoneyHasBeenGivenByScript,
    CPED_CONFIG_FLAG_NotAllowedToCrouch,
    CPED_CONFIG_FLAG_DeathPickupsPersist,
    CPED_CONFIG_FLAG_IgnoreSeenMelee,
    CPED_CONFIG_FLAG_ForceDieIfInjured,
    CPED_CONFIG_FLAG_DontDragMeOutCar,
    CPED_CONFIG_FLAG_StayInCarOnJack,
    CPED_CONFIG_FLAG_ForceDieInCar,
    CPED_CONFIG_FLAG_GetOutUndriveableVehicle,
    CPED_CONFIG_FLAG_WillRemainOnBoatAfterMissionEnds,
    CPED_CONFIG_FLAG_DontStoreAsPersistent,
    CPED_CONFIG_FLAG_WillFlyThroughWindscreen,
    CPED_CONFIG_FLAG_DieWhenRagdoll,
    CPED_CONFIG_FLAG_HasHelmet,
    CPED_CONFIG_FLAG_UseHelmet,
    CPED_CONFIG_FLAG_DontTakeOffHelmet,
    CPED_CONFIG_FLAG_HideInCutscene,
    CPED_CONFIG_FLAG_PedIsEnemyToPlayer,
    CPED_CONFIG_FLAG_DisableEvasiveDives,
    CPED_CONFIG_FLAG_PedGeneratesDeadBodyEvents,
    CPED_CONFIG_FLAG_DontAttackPlayerWithoutWantedLevel,
    CPED_CONFIG_FLAG_DontInfluenceWantedLevel,
    CPED_CONFIG_FLAG_DisablePlayerLockon,
    CPED_CONFIG_FLAG_DisableLockonToRandomPeds,
    CPED_CONFIG_FLAG_AllowLockonToFriendlyPlayers,
    CPED_CONFIG_FLAG_DisableHornAudioWhenDead,
    CPED_CONFIG_FLAG_PedBeingDeleted,
    CPED_CONFIG_FLAG_BlockWeaponSwitching,
    CPED_CONFIG_FLAG_BlockGroupPedAimedAtResponse,
    CPED_CONFIG_FLAG_WillFollowLeaderAnyMeans,
    CPED_CONFIG_FLAG_BlippedByScript,
    CPED_CONFIG_FLAG_DrawRadarVisualField,
    CPED_CONFIG_FLAG_StopWeaponFiringOnImpact,
    CPED_CONFIG_FLAG_DissableAutoFallOffTests,
    CPED_CONFIG_FLAG_SteerAroundDeadBodies,
    CPED_CONFIG_FLAG_ConstrainToNavMesh,
    CPED_CONFIG_FLAG_SyncingAnimatedProps,
    CPED_CONFIG_FLAG_IsFiring,
    CPED_CONFIG_FLAG_WasFiring,
    CPED_CONFIG_FLAG_IsStanding,
    CPED_CONFIG_FLAG_WasStanding,
    CPED_CONFIG_FLAG_InVehicle,
    CPED_CONFIG_FLAG_OnMount,
    CPED_CONFIG_FLAG_AttachedToVehicle,
    CPED_CONFIG_FLAG_IsSwimming,
    CPED_CONFIG_FLAG_WasSwimming,
    CPED_CONFIG_FLAG_IsSkiing,
    CPED_CONFIG_FLAG_IsSitting,
    CPED_CONFIG_FLAG_KilledByStealth,
    CPED_CONFIG_FLAG_KilledByTakedown,
    CPED_CONFIG_FLAG_Knockedout,
    CPED_CONFIG_FLAG_ClearRadarBlipOnDeath,
    CPED_CONFIG_FLAG_JustGotOffTrain,
    CPED_CONFIG_FLAG_JustGotOnTrain,
    CPED_CONFIG_FLAG_UsingCoverPoint,
    CPED_CONFIG_FLAG_IsInTheAir,
    CPED_CONFIG_FLAG_KnockedUpIntoAir,
    CPED_CONFIG_FLAG_IsAimingGun,
    CPED_CONFIG_FLAG_HasJustLeftCar,
    CPED_CONFIG_FLAG_TargetWhenInjuredAllowed,
    CPED_CONFIG_FLAG_CurrLeftFootCollNM,
    CPED_CONFIG_FLAG_PrevLeftFootCollNM,
    CPED_CONFIG_FLAG_CurrRightFootCollNM,
    CPED_CONFIG_FLAG_PrevRightFootCollNM,
    CPED_CONFIG_FLAG_HasBeenBumpedInCar,
    CPED_CONFIG_FLAG_InWaterTaskQuitToClimbLadder,
    CPED_CONFIG_FLAG_NMTwoHandedWeaponBothHandsConstrained,
    CPED_CONFIG_FLAG_CreatedBloodPoolTimer,
    CPED_CONFIG_FLAG_DontActivateRagdollFromAnyPedImpact,
    CPED_CONFIG_FLAG_GroupPedFailedToEnterCover,
    CPED_CONFIG_FLAG_AlreadyChattedOnPhone,
    CPED_CONFIG_FLAG_AlreadyReactedToPedOnRoof,
    CPED_CONFIG_FLAG_ForcePedLoadCover,
    CPED_CONFIG_FLAG_BlockCoweringInCover,
    CPED_CONFIG_FLAG_BlockPeekingInCover,
    CPED_CONFIG_FLAG_JustLeftCarNotCheckedForDoors,
    CPED_CONFIG_FLAG_VaultFromCover,
    CPED_CONFIG_FLAG_AutoConversationLookAts,
    CPED_CONFIG_FLAG_UsingCrouchedPedCapsule,
    CPED_CONFIG_FLAG_HasDeadPedBeenReported,
    CPED_CONFIG_FLAG_ForcedAim,
    CPED_CONFIG_FLAG_SteersAroundPeds,
    CPED_CONFIG_FLAG_SteersAroundObjects,
    CPED_CONFIG_FLAG_OpenDoorArmIK,
    CPED_CONFIG_FLAG_ForceReload,
    CPED_CONFIG_FLAG_DontActivateRagdollFromVehicleImpact,
    CPED_CONFIG_FLAG_DontActivateRagdollFromBulletImpact,
    CPED_CONFIG_FLAG_DontActivateRagdollFromExplosions,
    CPED_CONFIG_FLAG_DontActivateRagdollFromFire,
    CPED_CONFIG_FLAG_DontActivateRagdollFromElectrocution,
    CPED_CONFIG_FLAG_IsBeingDraggedToSafety,
    CPED_CONFIG_FLAG_HasBeenDraggedToSafety,
    CPED_CONFIG_FLAG_KeepWeaponHolsteredUnlessFired,
    CPED_CONFIG_FLAG_ForceScriptControlledKnockout,
    CPED_CONFIG_FLAG_FallOutOfVehicleWhenKilled,
    CPED_CONFIG_FLAG_GetOutBurningVehicle,
    CPED_CONFIG_FLAG_BumpedByPlayer,
    CPED_CONFIG_FLAG_RunFromFiresAndExplosions,
    CPED_CONFIG_FLAG_TreatAsPlayerDuringTargeting,
    CPED_CONFIG_FLAG_IsHandCuffed,
    CPED_CONFIG_FLAG_IsAnkleCuffed,
    CPED_CONFIG_FLAG_DisableMelee,
    CPED_CONFIG_FLAG_DisableUnarmedDrivebys,
    CPED_CONFIG_FLAG_JustGetsPulledOutWhenElectrocuted,
    CPED_CONFIG_FLAG_UNUSED_REPLACE_ME,
    CPED_CONFIG_FLAG_WillNotHotwireLawEnforcementVehicle,
    CPED_CONFIG_FLAG_WillCommandeerRatherThanJack,
    CPED_CONFIG_FLAG_CanBeAgitated,
    CPED_CONFIG_FLAG_ForcePedToFaceLeftInCover,
    CPED_CONFIG_FLAG_ForcePedToFaceRightInCover,
    CPED_CONFIG_FLAG_BlockPedFromTurningInCover,
    CPED_CONFIG_FLAG_KeepRelationshipGroupAfterCleanUp,
    CPED_CONFIG_FLAG_ForcePedToBeDragged,
    CPED_CONFIG_FLAG_PreventPedFromReactingToBeingJacked,
    CPED_CONFIG_FLAG_IsScuba,
    CPED_CONFIG_FLAG_WillArrestRatherThanJack,
    CPED_CONFIG_FLAG_RemoveDeadExtraFarAway,
    CPED_CONFIG_FLAG_RidingTrain,
    CPED_CONFIG_FLAG_ArrestResult,
    CPED_CONFIG_FLAG_CanAttackFriendly,
    CPED_CONFIG_FLAG_WillJackAnyPlayer,
    CPED_CONFIG_FLAG_BumpedByPlayerVehicle,
    CPED_CONFIG_FLAG_DodgedPlayerVehicle,
    CPED_CONFIG_FLAG_WillJackWantedPlayersRatherThanStealCar,
    CPED_CONFIG_FLAG_NoCopWantedAggro,
    CPED_CONFIG_FLAG_DisableLadderClimbing,
    CPED_CONFIG_FLAG_StairsDetected,
    CPED_CONFIG_FLAG_SlopeDetected,
    CPED_CONFIG_FLAG_HelmetHasBeenShot,
    CPED_CONFIG_FLAG_CowerInsteadOfFlee,
    CPED_CONFIG_FLAG_CanActivateRagdollWhenVehicleUpsideDown,
    CPED_CONFIG_FLAG_AlwaysRespondToCriesForHelp,
    CPED_CONFIG_FLAG_DisableBloodPoolCreation,
    CPED_CONFIG_FLAG_ShouldFixIfNoCollision,
    CPED_CONFIG_FLAG_CanPerformArrest,
    CPED_CONFIG_FLAG_CanPerformUncuff,
    CPED_CONFIG_FLAG_CanBeArrested,
    CPED_CONFIG_FLAG_MoverConstrictedByOpposingCollisions,
    CPED_CONFIG_FLAG_PlayerPreferFrontSeatMP,
    CPED_CONFIG_FLAG_DontActivateRagdollFromImpactObject,
    CPED_CONFIG_FLAG_DontActivateRagdollFromMelee,
    CPED_CONFIG_FLAG_DontActivateRagdollFromWaterJet,
    CPED_CONFIG_FLAG_DontActivateRagdollFromDrowning,
    CPED_CONFIG_FLAG_DontActivateRagdollFromFalling,
    CPED_CONFIG_FLAG_DontActivateRagdollFromRubberBullet,
    CPED_CONFIG_FLAG_IsInjured,
    CPED_CONFIG_FLAG_DontEnterVehiclesInPlayersGroup,
    CPED_CONFIG_FLAG_SwimmingTasksRunning,
    CPED_CONFIG_FLAG_PreventAllMeleeTaunts,
    CPED_CONFIG_FLAG_ForceDirectEntry,
    CPED_CONFIG_FLAG_AlwaysSeeApproachingVehicles,
    CPED_CONFIG_FLAG_CanDiveAwayFromApproachingVehicles,
    CPED_CONFIG_FLAG_AllowPlayerToInterruptVehicleEntryExit,
    CPED_CONFIG_FLAG_OnlyAttackLawIfPlayerIsWanted,
    CPED_CONFIG_FLAG_PlayerInContactWithKinematicPed,
    CPED_CONFIG_FLAG_PlayerInContactWithSomethingOtherThanKinematicPed,
    CPED_CONFIG_FLAG_PedsJackingMeDontGetIn,
    CPED_CONFIG_FLAG_AdditionalRappellingPed,
    CPED_CONFIG_FLAG_PedIgnoresAnimInterruptEvents,
    CPED_CONFIG_FLAG_IsInCustody,
    CPED_CONFIG_FLAG_ForceStandardBumpReactionThresholds,
    CPED_CONFIG_FLAG_LawWillOnlyAttackIfPlayerIsWanted,
    CPED_CONFIG_FLAG_IsAgitated,
    CPED_CONFIG_FLAG_PreventAutoShuffleToDriversSeat,
    CPED_CONFIG_FLAG_UseKinematicModeWhenStationary,
    CPED_CONFIG_FLAG_EnableWeaponBlocking,
    CPED_CONFIG_FLAG_HasHurtStarted,
    CPED_CONFIG_FLAG_DisableHurt,
    CPED_CONFIG_FLAG_PlayerIsWeird,
    CPED_CONFIG_FLAG_PedHadPhoneConversation,
    CPED_CONFIG_FLAG_BeganCrossingRoad,
    CPED_CONFIG_FLAG_WarpIntoLeadersVehicle,
    CPED_CONFIG_FLAG_DoNothingWhenOnFootByDefault,
    CPED_CONFIG_FLAG_UsingScenario,
    CPED_CONFIG_FLAG_VisibleOnScreen,
    CPED_CONFIG_FLAG_DontCollideWithKinematic,
    CPED_CONFIG_FLAG_ActivateOnSwitchFromLowPhysicsLod,
    CPED_CONFIG_FLAG_DontActivateRagdollOnPedCollisionWhenDead,
    CPED_CONFIG_FLAG_DontActivateRagdollOnVehicleCollisionWhenDead,
    CPED_CONFIG_FLAG_HasBeenInArmedCombat,
    CPED_CONFIG_FLAG_UseDiminishingAmmoRate,
    CPED_CONFIG_FLAG_Avoidance_Ignore_All,
    CPED_CONFIG_FLAG_Avoidance_Ignored_by_All,
    CPED_CONFIG_FLAG_Avoidance_Ignore_Group1,
    CPED_CONFIG_FLAG_Avoidance_Member_of_Group1,
    CPED_CONFIG_FLAG_ForcedToUseSpecificGroupSeatIndex,
    CPED_CONFIG_FLAG_LowPhysicsLodMayPlaceOnNavMesh,
    CPED_CONFIG_FLAG_DisableExplosionReactions,
    CPED_CONFIG_FLAG_DodgedPlayer,
    CPED_CONFIG_FLAG_WaitingForPlayerControlInterrupt,
    CPED_CONFIG_FLAG_ForcedToStayInCover,
    CPED_CONFIG_FLAG_GeneratesSoundEvents,
    CPED_CONFIG_FLAG_ListensToSoundEvents,
    CPED_CONFIG_FLAG_AllowToBeTargetedInAVehicle,
    CPED_CONFIG_FLAG_WaitForDirectEntryPointToBeFreeWhenExiting,
    CPED_CONFIG_FLAG_OnlyRequireOnePressToExitVehicle,
    CPED_CONFIG_FLAG_ForceExitToSkyDive,
    CPED_CONFIG_FLAG_SteersAroundVehicles,
    CPED_CONFIG_FLAG_AllowPedInVehiclesOverrideTaskFlags,
    CPED_CONFIG_FLAG_DontEnterLeadersVehicle,
    CPED_CONFIG_FLAG_DisableExitToSkyDive,
    CPED_CONFIG_FLAG_ScriptHasDisabledCollision,
    CPED_CONFIG_FLAG_UseAmbientModelScaling,
    CPED_CONFIG_FLAG_DontWatchFirstOnNextHurryAway,
    CPED_CONFIG_FLAG_DisablePotentialToBeWalkedIntoResponse,
    CPED_CONFIG_FLAG_DisablePedAvoidance,
    CPED_CONFIG_FLAG_ForceRagdollUponDeath,
    CPED_CONFIG_FLAG_CanLosePropsOnDamage,
    CPED_CONFIG_FLAG_DisablePanicInVehicle,
    CPED_CONFIG_FLAG_AllowedToDetachTrailer,
    CPED_CONFIG_FLAG_HasShotBeenReactedToFromFront,
    CPED_CONFIG_FLAG_HasShotBeenReactedToFromBack,
    CPED_CONFIG_FLAG_HasShotBeenReactedToFromLeft,
    CPED_CONFIG_FLAG_HasShotBeenReactedToFromRight,
    CPED_CONFIG_FLAG_AllowBlockDeadPedRagdollActivation,
    CPED_CONFIG_FLAG_IsHoldingProp,
    CPED_CONFIG_FLAG_BlocksPathingWhenDead,
    CPED_CONFIG_FLAG_ForcePlayNormalScenarioExitOnNextScriptCommand,
    CPED_CONFIG_FLAG_ForcePlayImmediateScenarioExitOnNextScriptCommand,
    CPED_CONFIG_FLAG_ForceSkinCharacterCloth,
    CPED_CONFIG_FLAG_LeaveEngineOnWhenExitingVehicles,
    CPED_CONFIG_FLAG_PhoneDisableTextingAnimations,
    CPED_CONFIG_FLAG_PhoneDisableTalkingAnimations,
    CPED_CONFIG_FLAG_PhoneDisableCameraAnimations,
    CPED_CONFIG_FLAG_DisableBlindFiringInShotReactions,
    CPED_CONFIG_FLAG_AllowNearbyCoverUsage,
    CPED_CONFIG_FLAG_InStrafeTransition,
    CPED_CONFIG_FLAG_CanPlayInCarIdles,
    CPED_CONFIG_FLAG_CanAttackNonWantedPlayerAsLaw,
    CPED_CONFIG_FLAG_WillTakeDamageWhenVehicleCrashes,
    CPED_CONFIG_FLAG_AICanDrivePlayerAsRearPassenger,
    CPED_CONFIG_FLAG_PlayerCanJackFriendlyPlayers,
    CPED_CONFIG_FLAG_OnStairs,
    CPED_CONFIG_FLAG_SimulatingAiming,
    CPED_CONFIG_FLAG_AIDriverAllowFriendlyPassengerSeatEntry,
    CPED_CONFIG_FLAG_ParentCarIsBeingRemoved,
    CPED_CONFIG_FLAG_AllowMissionPedToUseInjuredMovement,
    CPED_CONFIG_FLAG_CanLoseHelmetOnDamage,
    CPED_CONFIG_FLAG_NeverDoScenarioExitProbeChecks,
    CPED_CONFIG_FLAG_SuppressLowLODRagdollSwitchWhenCorpseSettles,
    CPED_CONFIG_FLAG_PreventUsingLowerPrioritySeats,
    CPED_CONFIG_FLAG_JustLeftVehicleNeedsReset,
    CPED_CONFIG_FLAG_TeleportIfCantReachPlayer,
    CPED_CONFIG_FLAG_PedsInVehiclePositionNeedsReset,
    CPED_CONFIG_FLAG_PedsFullyInSeat,
    CPED_CONFIG_FLAG_AllowPlayerLockOnIfFriendly,
    CPED_CONFIG_FLAG_UseCameraHeadingForDesiredDirectionLockOnTest,
    CPED_CONFIG_FLAG_TeleportToLeaderVehicle,
    CPED_CONFIG_FLAG_Avoidance_Ignore_WeirdPedBuffer,
    CPED_CONFIG_FLAG_OnStairSlope,
    CPED_CONFIG_FLAG_HasPlayedNMGetup,
    CPED_CONFIG_FLAG_DontBlipCop,
    CPED_CONFIG_FLAG_SpawnedAtExtendedRangeScenario,
    CPED_CONFIG_FLAG_WalkAlongsideLeaderWhenClose,
    CPED_CONFIG_FLAG_KillWhenTrapped,
    CPED_CONFIG_FLAG_EdgeDetected,
    CPED_CONFIG_FLAG_AlwaysWakeUpPhysicsOfIntersectedPeds,
    CPED_CONFIG_FLAG_EquippedAmbientLoadOutWeapon,
    CPED_CONFIG_FLAG_AvoidTearGas,
    CPED_CONFIG_FLAG_StoppedSpeechUponFreezing,
    CPED_CONFIG_FLAG_DisableGoToWritheWhenInjured,
    CPED_CONFIG_FLAG_OnlyUseForcedSeatWhenEnteringHeliInGroup,
    CPED_CONFIG_FLAG_ThrownFromVehicleDueToExhaustion,
    CPED_CONFIG_FLAG_UpdateEnclosedSearchRegion,
    CPED_CONFIG_FLAG_DisableWeirdPedEvents,
    CPED_CONFIG_FLAG_ShouldChargeNow,
    CPED_CONFIG_FLAG_RagdollingOnBoat,
    CPED_CONFIG_FLAG_HasBrandishedWeapon,
    CPED_CONFIG_FLAG_AllowMinorReactionsAsMissionPed,
    CPED_CONFIG_FLAG_BlockDeadBodyShockingEventsWhenDead,
    CPED_CONFIG_FLAG_PedHasBeenSeen,
    CPED_CONFIG_FLAG_PedIsInReusePool,
    CPED_CONFIG_FLAG_PedWasReused,
    CPED_CONFIG_FLAG_DisableShockingEvents,
    CPED_CONFIG_FLAG_MovedUsingLowLodPhysicsSinceLastActive,
    CPED_CONFIG_FLAG_NeverReactToPedOnRoof,
    CPED_CONFIG_FLAG_ForcePlayFleeScenarioExitOnNextScriptCommand,
    CPED_CONFIG_FLAG_JustBumpedIntoVehicle,
    CPED_CONFIG_FLAG_DisableShockingDrivingOnPavementEvents,
    CPED_CONFIG_FLAG_ShouldThrowSmokeNow,
    CPED_CONFIG_FLAG_DisablePedConstraints,
    CPED_CONFIG_FLAG_ForceInitialPeekInCover,
    CPED_CONFIG_FLAG_CreatedByDispatch,
    CPED_CONFIG_FLAG_PointGunLeftHandSupporting,
    CPED_CONFIG_FLAG_DisableJumpingFromVehiclesAfterLeader,
    CPED_CONFIG_FLAG_DontActivateRagdollFromPlayerPedImpact,
    CPED_CONFIG_FLAG_DontActivateRagdollFromAiRagdollImpact,
    CPED_CONFIG_FLAG_DontActivateRagdollFromPlayerRagdollImpact,
    CPED_CONFIG_FLAG_DisableQuadrupedSpring,
    CPED_CONFIG_FLAG_IsInCluster,
    CPED_CONFIG_FLAG_ShoutToGroupOnPlayerMelee,
    CPED_CONFIG_FLAG_IgnoredByAutoOpenDoors,
    CPED_CONFIG_FLAG_PreferInjuredGetup,
    CPED_CONFIG_FLAG_ForceIgnoreMeleeActiveCombatant,
    CPED_CONFIG_FLAG_CheckLoSForSoundEvents,
    CPED_CONFIG_FLAG_JackedAbandonedCar,
    CPED_CONFIG_FLAG_CanSayFollowedByPlayerAudio,
    CPED_CONFIG_FLAG_ActivateRagdollFromMinorPlayerContact,
    CPED_CONFIG_FLAG_HasPortablePickupAttached,
    CPED_CONFIG_FLAG_ForcePoseCharacterCloth,
    CPED_CONFIG_FLAG_HasClothCollisionBounds,
    CPED_CONFIG_FLAG_HasHighHeels,
    CPED_CONFIG_FLAG_TreatAsAmbientPedForDriverLockOn,
    CPED_CONFIG_FLAG_DontBehaveLikeLaw,
    CPED_CONFIG_FLAG_SpawnedAtScenario,
    CPED_CONFIG_FLAG_DisablePoliceInvestigatingBody,
    CPED_CONFIG_FLAG_DisableWritheShootFromGround,
    CPED_CONFIG_FLAG_LowerPriorityOfWarpSeats,
    CPED_CONFIG_FLAG_DisableTalkTo,
    CPED_CONFIG_FLAG_DontBlip,
    CPED_CONFIG_FLAG_IsSwitchingWeapon,
    CPED_CONFIG_FLAG_IgnoreLegIkRestrictions,
    CPED_CONFIG_FLAG_ScriptForceNoTimesliceIntelligenceUpdate,
    CPED_CONFIG_FLAG_JackedOutOfMyVehicle,
    CPED_CONFIG_FLAG_WentIntoCombatAfterBeingJacked,
    CPED_CONFIG_FLAG_DontActivateRagdollForVehicleGrab,
    CPED_CONFIG_FLAG_ForcePackageCharacterCloth,
    CPED_CONFIG_FLAG_DontRemoveWithValidOrder,
    CPED_CONFIG_FLAG_AllowTaskDoNothingTimeslicing,
    CPED_CONFIG_FLAG_ForcedToStayInCoverDueToPlayerSwitch,
    CPED_CONFIG_FLAG_ForceProneCharacterCloth,
    CPED_CONFIG_FLAG_NotAllowedToJackAnyPlayers,
    CPED_CONFIG_FLAG_InToStrafeTransition,
    CPED_CONFIG_FLAG_KilledByStandardMelee,
    CPED_CONFIG_FLAG_AlwaysLeaveTrainUponArrival,
    CPED_CONFIG_FLAG_ForcePlayDirectedNormalScenarioExitOnNextScriptCommand,
    CPED_CONFIG_FLAG_OnlyWritheFromWeaponDamage,
    CPED_CONFIG_FLAG_UseSloMoBloodVfx,
    CPED_CONFIG_FLAG_EquipJetpack,
    CPED_CONFIG_FLAG_PreventDraggedOutOfCarThreatResponse,
    CPED_CONFIG_FLAG_ScriptHasCompletelyDisabledCollision,
    CPED_CONFIG_FLAG_NeverDoScenarioNavChecks,
    CPED_CONFIG_FLAG_ForceSynchronousScenarioExitChecking,
    CPED_CONFIG_FLAG_ThrowingGrenadeWhileAiming,
    CPED_CONFIG_FLAG_HeadbobToRadioEnabled,
    CPED_CONFIG_FLAG_ForceDeepSurfaceCheck,
    CPED_CONFIG_FLAG_DisableDeepSurfaceAnims,
    CPED_CONFIG_FLAG_DontBlipNotSynced,
    CPED_CONFIG_FLAG_IsDuckingInVehicle,
    CPED_CONFIG_FLAG_PreventAutoShuffleToTurretSeat,
    CPED_CONFIG_FLAG_DisableEventInteriorStatusCheck,
    CPED_CONFIG_FLAG_HasReserveParachute,
    CPED_CONFIG_FLAG_UseReserveParachute,
    CPED_CONFIG_FLAG_TreatDislikeAsHateWhenInCombat,
    CPED_CONFIG_FLAG_OnlyUpdateTargetWantedIfSeen,
    CPED_CONFIG_FLAG_AllowAutoShuffleToDriversSeat,
    CPED_CONFIG_FLAG_DontActivateRagdollFromSmokeGrenade,
    CPED_CONFIG_FLAG_LinkMBRToOwnerOnChain,
    CPED_CONFIG_FLAG_AmbientFriendBumpedByPlayer,
    CPED_CONFIG_FLAG_AmbientFriendBumpedByPlayerVehicle,
    CPED_CONFIG_FLAG_InFPSUnholsterTransition,
    CPED_CONFIG_FLAG_PreventReactingToSilencedCloneBullets,
    CPED_CONFIG_FLAG_DisableInjuredCryForHelpEvents,
    CPED_CONFIG_FLAG_NeverLeaveTrain,
    CPED_CONFIG_FLAG_DontDropJetpackOnDeath,
    CPED_CONFIG_FLAG_UseFPSUnholsterTransitionDuringCombatRoll,
    CPED_CONFIG_FLAG_ExitingFPSCombatRoll,
    CPED_CONFIG_FLAG_ScriptHasControlOfPlayer,
    CPED_CONFIG_FLAG_PlayFPSIdleFidgetsForProjectile,
    CPED_CONFIG_FLAG_DisableAutoEquipHelmetsInBikes,
    CPED_CONFIG_FLAG_DisableAutoEquipHelmetsInAircraft,
    CPED_CONFIG_FLAG_WasPlayingFPSGetup,
    CPED_CONFIG_FLAG_WasPlayingFPSMeleeActionResult,
    CPED_CONFIG_FLAG_PreferNoPriorityRemoval,
    CPED_CONFIG_FLAG_FPSFidgetsAbortedOnFire,
    CPED_CONFIG_FLAG_ForceFPSIKWithUpperBodyAnim,
    CPED_CONFIG_FLAG_SwitchingCharactersInFirstPerson,
    CPED_CONFIG_FLAG_IsClimbingLadder,
    CPED_CONFIG_FLAG_HasBareFeet,
    CPED_CONFIG_FLAG_UNUSED_REPLACE_ME_2,
    CPED_CONFIG_FLAG_GoOnWithoutVehicleIfItIsUnableToGetBackToRoad,
    CPED_CONFIG_FLAG_BlockDroppingHealthSnacksOnDeath,
    CPED_CONFIG_FLAG_ResetLastVehicleOnVehicleExit,
    CPED_CONFIG_FLAG_ForceThreatResponseToNonFriendToFriendMeleeActions,
    CPED_CONFIG_FLAG_DontRespondToRandomPedsDamage,
    CPED_CONFIG_FLAG_AllowContinuousThreatResponseWantedLevelUpdates,
    CPED_CONFIG_FLAG_KeepTargetLossResponseOnCleanup,
    CPED_CONFIG_FLAG_PlayersDontDragMeOutOfCar,
    CPED_CONFIG_FLAG_BroadcastRepondedToThreatWhenGoingToPointShooting,
    CPED_CONFIG_FLAG_IgnorePedTypeForIsFriendlyWith,
    CPED_CONFIG_FLAG_TreatNonFriendlyAsHateWhenInCombat,
    CPED_CONFIG_FLAG_DontLeaveVehicleIfLeaderNotInVehicle,
    CPED_CONFIG_FLAG_ChangeFromPermanentToAmbientPopTypeOnMigration,
    CPED_CONFIG_FLAG_AllowMeleeReactionIfMeleeProofIsOn,
    CPED_CONFIG_FLAG_UsingLowriderLeans,
    CPED_CONFIG_FLAG_UsingAlternateLowriderLeans,
    CPED_CONFIG_FLAG_UseNormalExplosionDamageWhenBlownUpInVehicle,
    CPED_CONFIG_FLAG_DisableHomingMissileLockForVehiclePedInside,
    CPED_CONFIG_FLAG_DisableTakeOffScubaGear,
    CPED_CONFIG_FLAG_IgnoreMeleeFistWeaponDamageMult,
    CPED_CONFIG_FLAG_LawPedsCanFleeFromNonWantedPlayer,
    CPED_CONFIG_FLAG_ForceBlipSecurityPedsIfPlayerIsWanted,
    CPED_CONFIG_FLAG_IsHolsteringWeapon,
    CPED_CONFIG_FLAG_UseGoToPointForScenarioNavigation,
    CPED_CONFIG_FLAG_DontClearLocalPassengersWantedLevel,
    CPED_CONFIG_FLAG_BlockAutoSwapOnWeaponPickups,
    CPED_CONFIG_FLAG_ThisPedIsATargetPriorityForAI,
    CPED_CONFIG_FLAG_IsSwitchingHelmetVisor,
    CPED_CONFIG_FLAG_ForceHelmetVisorSwitch,
    CPED_CONFIG_FLAG_IsPerformingVehicleMelee,
    CPED_CONFIG_FLAG_UseOverrideFootstepPtFx,
    CPED_CONFIG_FLAG_DisableVehicleCombat,
    CPED_CONFIG_FLAG_TreatAsFriendlyForTargetingAndDamage,
    CPED_CONFIG_FLAG_AllowBikeAlternateAnimations,
    CPED_CONFIG_FLAG_TreatAsFriendlyForTargetingAndDamageNonSynced,
    CPED_CONFIG_FLAG_UseLockpickVehicleEntryAnimations,
    CPED_CONFIG_FLAG_IgnoreInteriorCheckForSprinting,
    CPED_CONFIG_FLAG_SwatHeliSpawnWithinLastSpottedLocation,
    CPED_CONFIG_FLAG_DisableStartEngine,
    CPED_CONFIG_FLAG_IgnoreBeingOnFire,
    CPED_CONFIG_FLAG_DisableTurretOrRearSeatPreference,
    CPED_CONFIG_FLAG_DisableWantedHelicopterSpawning,
    CPED_CONFIG_FLAG_UseTargetPerceptionForCreatingAimedAtEvents,
    CPED_CONFIG_FLAG_DisableHomingMissileLockon,
    CPED_CONFIG_FLAG_ForceIgnoreMaxMeleeActiveSupportCombatants,
    CPED_CONFIG_FLAG_StayInDefensiveAreaWhenInVehicle,
    CPED_CONFIG_FLAG_DontShoutTargetPosition,
    CPED_CONFIG_FLAG_DisableHelmetArmor,
    CPED_CONFIG_FLAG_CreatedByConcealedPlayer,
    CPED_CONFIG_FLAG_PermanentlyDisablePotentialToBeWalkedIntoResponse,
    CPED_CONFIG_FLAG_PreventVehExitDueToInvalidWeapon,
    CPED_CONFIG_FLAG_IgnoreNetSessionFriendlyFireCheckForAllowDamage,
    CPED_CONFIG_FLAG_DontLeaveCombatIfTargetPlayerIsAttackedByPolice,
    CPED_CONFIG_FLAG_CheckLockedBeforeWarp,
    CPED_CONFIG_FLAG_DontShuffleInVehicleToMakeRoom,
    CPED_CONFIG_FLAG_GiveWeaponOnGetup,
    CPED_CONFIG_FLAG_DontHitVehicleWithProjectiles,
    CPED_CONFIG_FLAG_DisableForcedEntryForOpenVehiclesFromTryLockedDoor,
    CPED_CONFIG_FLAG_FiresDummyRockets,
    CPED_CONFIG_FLAG_PedIsArresting,
    CPED_CONFIG_FLAG_IsDecoyPed,
    CPED_CONFIG_FLAG_HasEstablishedDecoy,
    CPED_CONFIG_FLAG_BlockDispatchedHelicoptersFromLanding,
    CPED_CONFIG_FLAG_DontCryForHelpOnStun,
    CPED_CONFIG_FLAG_HitByTranqWeapon,
    CPED_CONFIG_FLAG_CanBeIncapacitated,
    CPED_CONFIG_FLAG_ForcedAimFromArrest,
};

namespace player_cache
{
    class entity;
}

namespace framework::engine
{
    struct sdk
    {
        class instance
        {
           public:
            uintptr_t addr;

            bool is_valid( );

            instance( ) = default;
            explicit instance( uintptr_t addr ) : addr( addr )
            {
            }
        };

        class weapon_info : public instance
        {
           public:
            using instance::instance;

            uint32_t get_max_clip_size( );
            void set_max_clip_size( uint32_t max_clip_size );
            float get_fire_rate( );
            void set_fire_rate( float fire_rate );
            uint32_t hash( );
        };

        class player_info : public instance
        {
           public:
            using instance::instance;

            float get_player_stamina( );
            void set_player_stamina( float player_stamina );

            float get_weapon_damage( );

            void set_weapon_damage( float weapon_damage );

            float get_punch_damage( );
            void set_punch_damage( float punch_damage );

            int net_id( );
        };

        class bone
        {
           public:
            uintptr_t parent;
            int bone_index;

            bone( ) = default;
            explicit bone( uintptr_t parent, int bone_index ) : parent( parent ), bone_index( bone_index )
            {
            }

            Vector3 pos( );
        };

        class skeleton_data
        {
           public:
            uintptr_t skeleton_ptr;
            uintptr_t skel_data;

            skeleton_data( ) = default;
            explicit skeleton_data( uintptr_t skeleton_ptr, uintptr_t skel_data ) : skeleton_ptr( skeleton_ptr ), skel_data( skel_data )
            {
            }

            bone get_bone( int bone );

           private:
            int convert_bone_id_to_index( int bone );
        };

        class vehicle : public instance
        {
           public:
            using instance::instance;

            void fix( );
            void set_lock_state( eVehicleLockState state );
            void destroy( );
        };

        class ped : public instance
        {
           public:
            using instance::instance;

            float get_health( );
            void set_health( float health );

            float get_max_health( );
            void set_max_health( float max_health );

            float get_armor( );
            void set_armor( float armor );

            int get_sweat( );
            void set_sweat( int sweat );

            Vector3 get_up_vector( );
            Vector3 get_right_vector( );
            Vector3 get_forward_vector( );

            Matrix get_matrix( );
            Vector3 get_root( );

            bool is_rendered( );  // can be done as like a performance wall check
            bool is_bullet_proof( );
            bool is_fire_proof( );
            bool is_melee_proof( );
            bool is_explosion_proof( );
            bool is_collision_proof( );

            void set_ped_flag( uint8_t bit, bool value );

            vehicle get_last_vehicle( );

            bool get_ped_config_flags( ePedConfigFlags flag );
            void set_ped_config_flags( ePedConfigFlags flag, BOOL value );

            void set_speed( int speed );
            void set_invisible( bool value );

            void set_invincible( bool value );
            void set_collision( bool value );

            std::string get_name( int net_id );

            bool is_npc( );
            bool is_occluded( );

            bool is_godmode( );
            void godmode( bool value );

            player_info player_info( );
            skeleton_data skeleton_data( );

            Vector3 get_velocity( );

            void set_pos( Vector3 pos );
            bool set_pos_checked( Vector3 pos ) const;

            enum class ped_status
            {
                godmode,
                suspicious,
                normal
            };

            ped_status get_status( );

            void kill( );
            void heal( );
            bool set_health_checked( float health ) const;
            void kick_player_out_of_vehicle( );
        };

        class camera
        {
           public:
        };

        class veh_interface : public instance
        {
           public:
            using instance::instance;

            int get_veh_count( );
            uintptr_t get_veh_list( );
        };

        class ped_interface : public instance
        {
           public:
            using instance::instance;

            int get_ped_count( );
            uintptr_t get_ped_list( );
        };

        class replay_interface : public instance
        {
           public:
            using instance::instance;

            ped_interface get_ped_interface( );
            veh_interface get_veh_interface( );
        };

        class world : public instance
        {
           public:
            using instance::instance;
            ped get_local_ped( );
        };

        world get_world( );
        camera get_camera( );
        replay_interface get_replay( );
        ped get_ped_from_index( uintptr_t ped_list, int index );

        Vector2 world_to_screen( Vector3 world_point, Matrix view_matrix );
        bool is_on_screen( Vector2 point );

        Vector3 get_camera_pos( );
        std::pair< Vector3, player_cache::entity* > get_closest_ped( );
    };

    inline std::unique_ptr g_sdk = std::make_unique< sdk >( );
}  // namespace framework::engine