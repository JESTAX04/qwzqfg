#pragma once
#include "framework/framework.hpp"
#include "../overlay/overlay.hpp"
#include "../../features/features.hpp"
#include "../../engine/engine.hpp"
#include "../../engine/globals.hpp"
#include "../../features/cache_data/player_cache.hpp"
#include "../../features/player_troll/troll.hpp"
#include <algorithm>
#include <cstring>
#include <filesystem>
#include <fstream>
#include <iterator>
#include <commdlg.h>
#pragma comment(lib, "comdlg32.lib")

using namespace framework::engine;

// Reference-inspired full-width animated toggle.
inline bool modern_toggle(const char* label, bool* value)
{
    ImGui::PushID(label);
    const ImVec2 pos = ImGui::GetCursorScreenPos();
    const float width = (std::max)(ImGui::GetContentRegionAvail().x, 80.f);
    const float height = 34.f;
    const ImGuiID id = ImGui::GetID("##switch");
    const bool pressed = ImGui::InvisibleButton("##switch", ImVec2(width, height));
    if (pressed) *value = !*value;
    const bool hovered = ImGui::IsItemHovered();
    ImGuiStorage* storage = ImGui::GetStateStorage();
    float anim = storage->GetFloat(id, *value ? 1.f : 0.f);
    anim = ImLerp(anim, *value ? 1.f : 0.f, (std::min)(ImGui::GetIO().DeltaTime * 12.f, 1.f));
    storage->SetFloat(id, anim);
    auto* draw = ImGui::GetWindowDrawList();
    if (hovered) draw->AddRectFilled(pos, ImVec2(pos.x + width, pos.y + height), IM_COL32(24,27,37,255), 5.f);
    draw->AddText(ImVec2(pos.x + 8.f, pos.y + (height - ImGui::GetTextLineHeight()) * .5f), IM_COL32(224,227,236,255), label);
    const ImVec2 a(pos.x + width - 44.f, pos.y + 9.f);
    const ImVec2 b(a.x + 34.f, a.y + 17.f);
    draw->AddRectFilled(a, b, *value ? IM_COL32(220,225,235,255) : IM_COL32(52,56,69,255), 9.f);
    draw->AddCircleFilled(ImVec2(a.x + 8.5f + 17.f * anim, a.y + 8.5f), 6.5f, *value ? IM_COL32(20,23,31,255) : IM_COL32(155,160,170,255));
    ImGui::PopID();
    return pressed;
}

inline void menu()
{
    ImVec2 pos{};

    ImGui::SetNextWindowPos({ 100, 100 }, ImGuiCond_Once);
    auto window = framework::gui::create_window("FiveM External", { framework::gui::window_size.x, framework::gui::window_size.y });
    {
        pos = window->Pos;

        const auto size = window->Size;
        const auto draw_list = window->DrawList;

        // Reference-style section switcher. This stays inside the existing overlay host.
        const int tab = framework::gui::selected_tab;
        const int mode = tab == 8 ? 2 : ((tab == 4 || tab == 6 || tab == 7) ? 1 : 0);
        ImGui::SetCursorPosX((size.x - 342.f) * 0.5f);
        auto section_button = [&](const char* label, int section, int target) {
            ImGui::PushStyleColor(ImGuiCol_Button, section == mode ? IM_COL32(35, 40, 54, 255) : IM_COL32(12, 14, 20, 255));
            ImGui::PushStyleColor(ImGuiCol_ButtonHovered, IM_COL32(40, 45, 60, 255));
            const bool pressed = ImGui::Button(label, ImVec2(108.f, 26.f));
            ImGui::PopStyleColor(2);
            if (pressed) framework::gui::selected_tab = target;
        };
        section_button("Online Menu", 0, 3); ImGui::SameLine();
        section_button("Lua Executor", 1, 4); ImGui::SameLine();
        section_button("Docs", 2, 8);
        ImGui::Separator();
        ImGui::BeginChild("##sidebar", ImVec2(58.f, 0.f), true, ImGuiWindowFlags_NoScrollbar);
        {
            if (framework::gui::textures::reference_logo)
                ImGui::Image(framework::gui::textures::reference_logo, ImVec2(42.f, 42.f));
            else
                ImGui::Dummy(ImVec2(42.f, 42.f));
            ImGui::Separator();
            auto icon_tab = [&](const char* label, ID3D11ShaderResourceView* texture, int id) {
                ImGui::PushID(id);
                const ImVec2 pos = ImGui::GetCursorScreenPos();
                const bool pressed = ImGui::InvisibleButton("##icon", ImVec2(42.f, 38.f));
                const bool hovered = ImGui::IsItemHovered();
                if (pressed) framework::gui::selected_tab = id;
                const bool active = framework::gui::selected_tab == id;
                auto* draw = ImGui::GetWindowDrawList();
                if (active || hovered) draw->AddRectFilled(pos, ImVec2(pos.x + 42.f, pos.y + 38.f), active ? IM_COL32(32,36,49,255) : IM_COL32(23,26,35,255), 5.f);
                if (active) draw->AddRect(pos, ImVec2(pos.x + 42.f, pos.y + 38.f), IM_COL32(200,205,220,255), 5.f);
                if (texture) draw->AddImage(texture, ImVec2(pos.x + 13.f, pos.y + 11.f), ImVec2(pos.x + 29.f, pos.y + 27.f), ImVec2(0,0), ImVec2(1,1), active ? IM_COL32_WHITE : IM_COL32(145,150,160,255));
                if (hovered) ImGui::SetTooltip("%s", label);
                ImGui::PopID();
            };
            if (mode == 0) {
                icon_tab("Players", framework::gui::textures::players, 3);
                icon_tab("Combat (unavailable)", framework::gui::textures::crosshair, 0);
                icon_tab("Visuals", framework::gui::textures::eye, 1);
                icon_tab("Tools (unavailable)", framework::gui::textures::exploits, 2);
                icon_tab("Settings", framework::gui::textures::settings, 5);
            } else if (mode == 1) {
                icon_tab("Executor", framework::gui::textures::code, 4);
                icon_tab("Resources", framework::gui::textures::code, 6);
                icon_tab("Server", framework::gui::textures::players, 7);
            } else {
                icon_tab("Documentation", framework::gui::textures::code, 8);
            }
        }
        ImGui::EndChild();

        ImGui::SameLine();

        ImGui::BeginChild("##main", ImVec2(0, 0), false);
        {
            ImGuiStyle* style = &ImGui::GetStyle();
            static const char* titles[] = { "Combat", "Visuals & ESP", "Tools", "Player List", "Executor", "Settings", "Resources", "Server", "Documentation" };
            ImGui::Spacing();
            ImGui::PushFont(framework::gui::fonts::name_font ? framework::gui::fonts::name_font : framework::gui::fonts::inter_bold);
            ImGui::TextUnformatted(titles[framework::gui::selected_tab]);
            ImGui::PopFont();
            ImGui::TextDisabled("FiveM External  /  configuration");
            ImGui::Separator();
            ImGui::Spacing();

            static float tab_alpha, tab_add;
            static int active_tab = 0;

            tab_alpha = ImClamp(tab_alpha + (4.f * ImGui::GetIO().DeltaTime * (framework::gui::selected_tab == active_tab ? 1.f : -1.f)), 0.f, 1.f);
            tab_add = ImClamp(tab_add + (std::round(350.f) * ImGui::GetIO().DeltaTime * (framework::gui::selected_tab == active_tab ? 1.f : -1.f)), 0.f, 1.f);

            if (tab_alpha == 0.f && tab_add == 0.f) 
                active_tab = framework::gui::selected_tab;

            ImGui::PushStyleVar(ImGuiStyleVar_Alpha, tab_alpha * style->Alpha);

            if (active_tab == 0)
            {
                ImGui::TextDisabled("Unavailable in this diagnostic build.");
                ImGui::BeginDisabled();
                static int sub_tab = 0;

                ImGui::BeginChild("##top_bar", ImVec2(ImGui::GetContentRegionAvail().x, 35.f), true, ImGuiWindowFlags_NoScrollbar);
                {
                    float tab_width = (ImGui::GetContentRegionAvail().x - style->ItemSpacing.x * 2.f) / 3.f;

                    framework::gui::create_sub_tab("Aimbot", { tab_width, 20.f }, 0, sub_tab);
                    ImGui::SameLine();
                    framework::gui::create_sub_tab("Silent Aim", { tab_width, 20.f }, 1, sub_tab);
                    ImGui::SameLine();
                    framework::gui::create_sub_tab("Triggerbot", { tab_width, 20.f }, 2, sub_tab);
                }
                ImGui::EndChild();

                if (sub_tab == 0)
                {
                    auto start = ImGui::GetCursorScreenPos().y;

                    framework::gui::create_child(draw_list, ImVec2((size.x - 190.f) / 2.f, 300.f), "Aimbot");

                    framework::gui::create_checkbox("Enabled", &settings::aimbot.enabled);

                    framework::gui::create_checkbox("Draw FOV", &settings::aimbot.draw_fov);
                    framework::gui::create_checkbox("Humanization", &settings::aimbot.Humanization);

                    static std::vector<std::string> bones = {
                        "Head", "Neck", "Spine", "Root"
                    };

                    framework::gui::create_dropdown("Selected Bone", &settings::aimbot.selected_bone, bones);
                    framework::gui::create_checkbox("Use Closest Bone", &settings::aimbot.closest_bone);

                    framework::gui::create_checkbox("Target Dead", &settings::aimbot.target_dead);
                    framework::gui::create_checkbox("Target Ped", &settings::aimbot.target_bots);
                    framework::gui::create_checkbox("Friend Check", &settings::aimbot.friend_check);
                    framework::gui::create_checkbox("Visible Check", &settings::aimbot.visible_check);

                    framework::gui::end_child();

                    ImGui::SameLine();

                    ImGui::SetCursorScreenPos({ ImGui::GetCursorScreenPos().x, start });
                    framework::gui::create_child(draw_list, ImVec2((size.x - 190.f) / 2.f, 350.f), "Settings");

                    framework::gui::create_checkbox("Overshoot", &settings::aimbot.overshoot);
                    framework::gui::slider_float("Overshoot Strength", &settings::aimbot.overshoot_strength, 0.01f, 1.f, "%.2f", 0);
                    framework::gui::slider_float("Overshoot Smoothness", &settings::aimbot.overshoot_smoothness, 0.01f, 1.f, "%.2f", 0);

                    framework::gui::slider_float("FOV Radius", &settings::aimbot.fov, 1.f, 500.f, "%.2f", 0);
                    framework::gui::slider_float("Smoothness", &settings::aimbot.smoothness, 0.001f, 0.5f, "%.2f", 0);

                    framework::gui::slider_int("Max Distance", &settings::aimbot.max_distance, 50, 500, "%d", 0);

                    framework::gui::create_keybind("Keybind", &settings::aimbot.key, &settings::aimbot.mode, settings::aimbot.id);

                    framework::gui::end_child();
                }
                else if (sub_tab == 1)
                {
                    auto start = ImGui::GetCursorScreenPos().y;

                    framework::gui::create_child(draw_list, ImVec2((size.x - 190.f) / 2.f, 300.f), "Silent Aim");

                    framework::gui::create_checkbox("Enabled", &settings::silent_aim.enabled);

                    framework::gui::create_checkbox("Draw FOV", &settings::silent_aim.draw_fov);

                    static std::vector<std::string> bones = {
    "Head", "Neck", "Spine", "Root"
                    };

                    framework::gui::create_dropdown("Selected Bone", &settings::silent_aim.selected_bone, bones);
                    framework::gui::create_checkbox("Use Closest Bone", &settings::silent_aim.closest_bone);

                    framework::gui::create_checkbox("Target Dead", &settings::silent_aim.target_dead);
                    framework::gui::create_checkbox("Target Ped", &settings::silent_aim.target_bots);

                    framework::gui::create_checkbox("Friend Check", &settings::silent_aim.friend_check);
                    framework::gui::create_checkbox("Visible Check", &settings::silent_aim.visible_check);

                    framework::gui::end_child();

                    ImGui::SameLine();

                    ImGui::SetCursorScreenPos({ ImGui::GetCursorScreenPos().x, start });
                    framework::gui::create_child(draw_list, ImVec2((size.x - 190.f) / 2.f, 350.f), "Settings");

                    framework::gui::slider_float("FOV Radius", &settings::silent_aim.fov, 1.f, 500.f, "%.2f", 0);
                    framework::gui::slider_int("Max Distance", &settings::silent_aim.max_distance, 50, 500, "%d", 0);

                    framework::gui::end_child();
                }
                else
                {
                    auto start = ImGui::GetCursorScreenPos().y;

                    framework::gui::create_child(draw_list, ImVec2((size.x - 190.f) / 2.f, 300.f), "Triggerbot");

                    framework::gui::create_checkbox("Enabled", &settings::triggerbot.enabled);
                    framework::gui::create_checkbox("Automatic Mode", &settings::triggerbot.automatic_mode);

                    framework::gui::slider_int("Fire Delay", &settings::triggerbot.delay, 0, 100, "%d", 0);

                    framework::gui::end_child();

                    ImGui::SameLine();

                    ImGui::SetCursorScreenPos({ ImGui::GetCursorScreenPos().x, start });
                    framework::gui::create_child(draw_list, ImVec2((size.x - 190.f) / 2.f, 350.f), "Settings");

                    framework::gui::create_keybind("Keybind", &settings::triggerbot.key, &settings::triggerbot.mode, settings::triggerbot.id);

                    framework::gui::end_child();
                }
                ImGui::EndDisabled();
            }
            else if (active_tab == 1)
            {
                const float available = ImGui::GetContentRegionAvail().x;
                const float left_width = (available - ImGui::GetStyle().ItemSpacing.x) * .5f;
                float pane_height = ImGui::GetContentRegionAvail().y - 6.f;
                if (pane_height < 120.f) pane_height = 120.f;
                ImGui::BeginChild("##visual_features", ImVec2(left_width, pane_height), true);
                ImGui::TextUnformatted("PLAYER ESP OPTIONS");
                ImGui::Separator();
                modern_toggle("Enable player ESP", &settings::visuals.enabled);
                modern_toggle("Box", &settings::visuals.box);
                modern_toggle("Skeleton", &settings::visuals.skeleton);
                modern_toggle("Name / ID", &settings::visuals.name);
                modern_toggle("Distance", &settings::visuals.distance);
                modern_toggle("Health bar", &settings::visuals.healthbar);
                modern_toggle("Head dot", &settings::visuals.head_dot);
                modern_toggle("Status", &settings::visuals.status);
                modern_toggle("Glow fill", &settings::visuals.glow);
                modern_toggle("Friend indicator", &settings::visuals.friend_indicator);
                ImGui::Spacing(); ImGui::TextUnformatted("FILTERS"); ImGui::Separator();
                modern_toggle("Draw peds", &settings::visuals.draw_bots);
                modern_toggle("Draw dead", &settings::visuals.draw_dead);
                ImGui::SliderInt("Max distance", &settings::visuals.max_distance, 50, 500, "%d m");
                ImGui::EndChild();
                ImGui::SameLine();
                ImGui::BeginChild("##visual_style", ImVec2(0.f, pane_height), true);
                ImGui::TextUnformatted("APPEARANCE"); ImGui::Separator();
                modern_toggle("Text outline", &settings::visuals.text_outline);
                modern_toggle("Cool skeleton", &settings::visuals.cool_skeleton);
                const char* skeleton_modes[] = { "Accurate", "Optimized" };
                ImGui::Combo("Skeleton type", &settings::visuals.skeleton_type, skeleton_modes, IM_ARRAYSIZE(skeleton_modes));
                ImGui::SliderInt("Skeleton thickness", &settings::visuals.skeleton_thickness, 1, 3);
                ImGui::SliderInt("Box rounding", &settings::visuals.box_rounding, 0, 3);
                const char* font_modes[] = { "Smallest Pixel", "Inter Regular", "Inter Bold" };
                ImGui::Combo("Other ESP font", &settings::visuals.font, font_modes, IM_ARRAYSIZE(font_modes));
                ImGui::TextDisabled("Name tags use the dedicated clearer font.");
                ImGui::Spacing(); ImGui::TextUnformatted("COLORS"); ImGui::Separator();
                const ImGuiColorEditFlags flags = ImGuiColorEditFlags_NoInputs;
                ImGui::ColorEdit4("Box color", settings::visuals.box_color, flags);
                ImGui::ColorEdit4("Skeleton color", settings::visuals.skeleton_color, flags);
                ImGui::ColorEdit4("Name color", settings::visuals.name_color, flags);
                ImGui::ColorEdit4("Status color", settings::visuals.status_color, flags);
                ImGui::ColorEdit4("Distance color", settings::visuals.distance_color, flags);
                ImGui::ColorEdit4("Health color", settings::visuals.health_bar_color, flags);
                ImGui::ColorEdit4("Glow color", settings::visuals.glow_color, flags);
                ImGui::ColorEdit4("Friend color", settings::visuals.friend_indicator_color, flags);
                ImGui::EndChild();
            }
            else if (active_tab == 2)
            {
                ImGui::TextDisabled("Unavailable in this diagnostic build.");
                ImGui::BeginDisabled();
                auto start = ImGui::GetCursorScreenPos().y;

                framework::gui::create_child(draw_list, ImVec2((size.x - 190.f) / 2.f, 300.f), "Exploits");

                framework::gui::create_checkbox("Enabled", &settings::exploits.enabled);
                framework::gui::create_checkbox("No Ragdoll", &settings::exploits.no_ragdoll);
                framework::gui::create_checkbox("No Headshots", &settings::exploits.no_headshots);
                framework::gui::create_checkbox("Safe Godmode", &settings::exploits.safe_godmode);
                framework::gui::create_checkbox("Super Punch", &settings::exploits.super_punch);
                framework::gui::create_checkbox("Godmode", &settings::exploits.godmode);
                framework::gui::create_checkbox("Passive Mode", &settings::exploits.passive_mode);

                framework::gui::create_checkbox("Infinite Stamina", &settings::exploits.infinite_stamina);
                framework::gui::create_checkbox("One Tap", &settings::exploits.one_tap);

                framework::gui::create_checkbox("Shrink", &settings::exploits.shrink);
                framework::gui::create_checkbox("Bypass Exploits", &settings::exploits.bypass_exploits);

                framework::gui::end_child();

                ImGui::SameLine();

                ImGui::SetCursorScreenPos({ ImGui::GetCursorScreenPos().x, start });
                framework::gui::create_child(draw_list, ImVec2((size.x - 190.f) / 2.f, 300.f), "Extra");

                static float max_health = 500.f;
                framework::gui::slider_float("Max Health", &max_health, 175.f, 10000.f, "%.2f", 0);

                if (framework::gui::create_button(20.f, "Set Max Health"))
                {
                    if (offsets::world)
                    {
                        auto world = g_sdk->get_world();
                        if (world.is_valid())
                        {
                            auto local_ped = world.get_local_ped();
                            if (local_ped.is_valid())
                            {
                                framework::gui::add_notification("Succesfully Set Max Health!");
                                local_ped.set_max_health(max_health);
                            }
                        }
                    }
                }

                if (framework::gui::create_button(20.f, "Fix Current Vehicle"))
                {
                    if (offsets::world)
                    {
                        auto world = g_sdk->get_world();
                        if (world.is_valid())
                        {
                            auto local_ped = world.get_local_ped();
                            if (local_ped.is_valid())
                            {
                                auto vehicle = local_ped.get_last_vehicle();
                                if (vehicle.is_valid() && local_ped.get_ped_config_flags(CPED_CONFIG_FLAG_InVehicle))
                                {
                                    framework::gui::add_notification("Succesfully Fixed Current Vehicle!");
                                    vehicle.fix();
                                }
                                else
                                {
                                    framework::gui::add_notification("Not In Vehicle!");
                                }
                            }
                        }
                    }
                }

                if (framework::gui::create_button(20.f, "Destroy Current Vehicle"))
                {
                    if (offsets::world)
                    {
                        auto world = g_sdk->get_world();
                        if (world.is_valid())
                        {
                            auto local_ped = world.get_local_ped();
                            if (local_ped.is_valid())
                            {
                                auto vehicle = local_ped.get_last_vehicle();
                                if (vehicle.is_valid() && local_ped.get_ped_config_flags(CPED_CONFIG_FLAG_InVehicle))
                                {
                                    framework::gui::add_notification("Succesfully Fixed Destroyed Vehicle!");
                                    auto val = -4000.f;
                                    globals::memory->write_memory(vehicle.addr + 0x7FC, val);
                                }
                                else
                                {
                                    framework::gui::add_notification("Not In Vehicle!");
                                }
                            }
                        }
                    }
                }

                if (framework::gui::create_button(20.f, "Heal"))
                {
                    if (offsets::world)
                    {
                        auto world = g_sdk->get_world();
                        if (world.is_valid())
                        {
                            auto local_ped = world.get_local_ped();
                            if (local_ped.is_valid())
                            {
                                framework::gui::add_notification("Succesfully Healed Local Player!");
                                local_ped.heal();
                            }
                        }
                    }
                }

                if (framework::gui::create_button(20.f, "Suicide"))
                {
                    if (offsets::world)
                    {
                        auto world = g_sdk->get_world();
                        if (world.is_valid())
                        {
                            auto local_ped = world.get_local_ped();
                            if (local_ped.is_valid())
                            {
                                framework::gui::add_notification("Succesfully Suicided!");
                                local_ped.kill();
                            }
                        }
                    }
                }

                framework::gui::create_keybind("Heal Keybind", &settings::exploits.heal_key, &settings::exploits.heal_mode, settings::exploits.heal_id);
                framework::gui::create_keybind("Fix Vehicle Keybind", &settings::exploits.fix_vehicle_key, &settings::exploits.fix_vehicle_mode, settings::exploits.fix_vehicle_id);

                framework::gui::end_child();
                ImGui::EndDisabled();
            }
            else if (active_tab == 3)
            {
                static player_cache::entity selected{};
                static ImGuiTextFilter filter;
                auto snapshot = player_cache::get_entities();
                bool selection_found = false;
                int player_count = 0;
                for (auto& entity : snapshot) {
                    if (entity.net_id <= 0 || entity.name.empty()) continue;
                    ++player_count;
                    if (selected.addr == entity.addr && selected.net_id == entity.net_id) {
                        selected = entity;
                        selection_found = true;
                    }
                }
                if (!selection_found) selected = player_cache::entity{};
                ImGui::TextDisabled("%d resolved nearby players", player_count);
                ImGui::SameLine();
                ImGui::SetNextItemWidth(180.f);
                if (ImGui::InputTextWithHint("##player_search", "Search player / ID...", filter.InputBuf, IM_ARRAYSIZE(filter.InputBuf))) filter.Build();
                float list_width = 210.f;
                float panel_height = ImGui::GetContentRegionAvail().y - 6.f;
                if (panel_height < 100.f) panel_height = 100.f;
                ImGui::BeginChild("##player_list", ImVec2(list_width, panel_height), true);
                for (auto& entity : snapshot) {
                    if (entity.net_id <= 0 || entity.name.empty()) continue;
                    const std::string label = entity.name + "  [#" + std::to_string(entity.net_id) + "]";
                    if (!filter.PassFilter(label.c_str())) continue;
                    ImGui::PushID(reinterpret_cast<void*>(entity.addr));
                    const bool active = selected.addr == entity.addr && selected.net_id == entity.net_id;
                    const ImVec2 card = ImGui::GetCursorScreenPos();
                    const float card_width = ImGui::GetContentRegionAvail().x;
                    if (ImGui::InvisibleButton("##player", ImVec2(card_width, 46.f))) selected = entity;
                    const bool hovered = ImGui::IsItemHovered();
                    auto* card_draw = ImGui::GetWindowDrawList();
                    card_draw->AddRectFilled(card, ImVec2(card.x + card_width, card.y + 46.f), active ? IM_COL32(27,31,44,255) : (hovered ? IM_COL32(23,26,35,255) : IM_COL32(16,18,25,255)), 4.f);
                    card_draw->AddRect(card, ImVec2(card.x + card_width, card.y + 46.f), active ? IM_COL32(155,160,175,255) : IM_COL32(32,35,46,255), 4.f);
                    if (active) card_draw->AddRectFilled(card, ImVec2(card.x + 3.f, card.y + 46.f), IM_COL32(235,238,245,255), 2.f);
                    card_draw->PushClipRect(ImVec2(card.x + 9.f, card.y + 3.f), ImVec2(card.x + card_width - 8.f, card.y + 43.f), true);
                    card_draw->AddText(ImVec2(card.x + 10.f, card.y + 6.f), IM_COL32(230,232,242,255), entity.name.c_str());
                    const std::string sub = "#" + std::to_string(entity.net_id) + (friends.contains(entity.addr) ? "   /   FRIEND" : "");
                    card_draw->AddText(ImVec2(card.x + 10.f, card.y + 25.f), IM_COL32(130,136,151,255), sub.c_str());
                    card_draw->PopClipRect();
                    ImGui::PopID();
                }
                ImGui::EndChild();
                ImGui::SameLine();
                ImGui::BeginChild("##player_details", ImVec2(0.f, panel_height), true);
                if (selected.addr && !selected.name.empty()) {
                    ImGui::Text("%s  [#%d]", selected.name.c_str(), selected.net_id);
                    ImGui::TextDisabled("Nearby entity  |  ID %d", selected.net_id);
                    ImGui::Text("HP  %.0f / %.0f", selected.cache.health, selected.cache.max_health);
                    ImGui::ProgressBar(selected.cache.max_health > 0.f ? (std::clamp)(selected.cache.health / selected.cache.max_health, 0.f, 1.f) : 0.f, ImVec2(-1.f, 4.f), "");
                    ImGui::Text("Armor  %.0f", selected.cache.armor);
                    ImGui::ProgressBar((std::clamp)(selected.cache.armor / 100.f, 0.f, 1.f), ImVec2(-1.f, 4.f), "");
                    ImGui::Separator();
                    ImGui::TextDisabled("SYSTEM STATUS");
                    ImGui::PushFont(framework::gui::fonts::inter_regular);
                    ImGui::TextUnformatted(troll::system_status().c_str());
                    ImGui::PopFont();
                    ImGui::Separator();
                    bool is_friend = friends.contains(selected.addr);
                    if (ImGui::Button(is_friend ? "Remove friend" : "Add friend", ImVec2(112.f, 30.f))) {
                        if (is_friend) friends.erase(selected.addr); else friends.insert(selected.addr);
                    }
                    ImGui::SameLine();
                    if (ImGui::Button("Teleport", ImVec2(112.f, 30.f))) {
                        if (offsets::world) {
                            auto world = g_sdk->get_world();
                            if (world.is_valid()) {
                                auto local = world.get_local_ped();
                                if (local.is_valid()) local.set_pos(selected.get_root());
                            }
                        }
                    }
                    ImGui::Spacing();
                    ImGui::TextDisabled("REFERENCE ACTIONS");
                    ImGui::Separator();
                    const char* actions[] = { "Bring", "Freeze ped", "Launch sky", "Ram with truck", "Copy outfit", "Silent kill", "Probe (test)", "Explosion", "Burn", "Ragdoll 10s", "Cage", "Disarm" };
                    const troll::action_id action_ids[] = {
                        troll::action_id::bring,
                        troll::action_id::freeze,
                        troll::action_id::launch_sky,
                        troll::action_id::ram_with_truck,
                        troll::action_id::copy_outfit,
                        troll::action_id::silent_kill,
                        troll::action_id::probe,
                        troll::action_id::explosion,
                        troll::action_id::burn,
                        troll::action_id::ragdoll,
                        troll::action_id::cage,
                        troll::action_id::disarm,
                    };
                    float w = (ImGui::GetContentRegionAvail().x - ImGui::GetStyle().ItemSpacing.x) * .5f;
                    for (int i = 0; i < IM_ARRAYSIZE(actions); ++i) {
                        if (ImGui::Button(actions[i], ImVec2(w, 27.f))) {
                            auto result = troll::run_action(action_ids[i], selected);
                            if (result.ok) framework::gui::add_notification("Player: " + result.note);
                            else if (result.note != "cooldown") framework::gui::add_notification("Player: " + result.note);
                        }
                        if ((i % 2) == 0 && i + 1 < IM_ARRAYSIZE(actions)) ImGui::SameLine();
                    }
                } else {
                    ImGui::TextUnformatted("Select a player");
                    ImGui::TextDisabled("Only players with resolved names are listed.");
                }
                ImGui::EndChild();
            }
            else if (active_tab == 4)
            {
                static char editor[32768]{};
                static std::string editor_status = "Editor ready. No execution backend is connected.";
                auto choose_file = [&](bool save) {
                    wchar_t path[MAX_PATH]{};
                    OPENFILENAMEW dialog{};
                    dialog.lStructSize = sizeof(dialog);
                    dialog.hwndOwner = framework::g_overlay->get_data().window_handle;
                    dialog.lpstrFilter = L"Lua scripts (*.lua)\0*.lua\0Text files (*.txt)\0*.txt\0All files (*.*)\0*.*\0\0";
                    dialog.lpstrFile = path;
                    dialog.nMaxFile = MAX_PATH;
                    dialog.lpstrDefExt = L"lua";
                    dialog.Flags = OFN_EXPLORER | OFN_NOCHANGEDIR | (save ? OFN_OVERWRITEPROMPT : (OFN_FILEMUSTEXIST | OFN_PATHMUSTEXIST));
                    const bool chosen = save ? GetSaveFileNameW(&dialog) != FALSE : GetOpenFileNameW(&dialog) != FALSE;
                    if (!chosen) { if (CommDlgExtendedError()) editor_status = "File dialog failed."; return; }
                    if (save) {
                        std::ofstream file(std::filesystem::path(path), std::ios::binary | std::ios::trunc);
                        if (!file) { editor_status = "Could not open file for writing."; return; }
                        file.write(editor, static_cast<std::streamsize>(std::strlen(editor)));
                        editor_status = file ? "File saved." : "File write failed.";
                    } else {
                        std::ifstream file(std::filesystem::path(path), std::ios::binary | std::ios::ate);
                        if (!file) { editor_status = "Could not open file."; return; }
                        const auto length = file.tellg();
                        if (length < 0 || length >= static_cast<std::streamoff>(sizeof(editor))) { editor_status = "File exceeds editor capacity (32 KiB)."; return; }
                        std::string text(static_cast<size_t>(length), '\0');
                        file.seekg(0);
                        if (!text.empty() && !file.read(text.data(), static_cast<std::streamsize>(text.size()))) { editor_status = "File read failed."; return; }
                        if (text.find('\0') != std::string::npos) { editor_status = "File contains NUL bytes."; return; }
                        std::memcpy(editor, text.data(), text.size()); editor[text.size()] = '\0';
                        editor_status = "File loaded.";
                    }
                };
                ImGui::TextDisabled("LUA EDITOR  /  EXECUTION BACKEND NOT CONNECTED");
                const float editor_height = (std::max)(150.f, ImGui::GetContentRegionAvail().y - 125.f);
                ImGui::InputTextMultiline("##lua_editor", editor, sizeof(editor), ImVec2(-1.f, editor_height), ImGuiInputTextFlags_AllowTabInput);
                ImGui::BeginDisabled(); ImGui::Button("Execute", ImVec2(88.f, 28.f)); ImGui::EndDisabled();
                ImGui::SameLine(); if (ImGui::Button("Clear", ImVec2(88.f, 28.f))) { editor[0] = '\0'; editor_status = "Editor cleared."; }
                ImGui::SameLine(); if (ImGui::Button("Open file", ImVec2(88.f, 28.f))) choose_file(false);
                ImGui::SameLine(); if (ImGui::Button("Save as", ImVec2(88.f, 28.f))) choose_file(true);
                ImGui::Separator();
                ImGui::TextUnformatted(editor_status.c_str());
            }
            else if (active_tab == 6 || active_tab == 7)
            {
                ImGui::Spacing();
                ImGui::TextUnformatted("Not implemented");
                ImGui::TextWrapped("The reference page has not been connected to a backend in this build.");
            }
            else if (active_tab == 8)
            {
                ImGui::BeginChild("##docs", ImVec2(0, 0), true);
                ImGui::TextUnformatted("Getting started");
                ImGui::Separator();
                ImGui::TextWrapped("Online Menu > Visuals contains the ESP settings. Enable Visuals and select Box, Skeleton or Name / ID.");
                ImGui::Spacing();
                ImGui::TextWrapped("Online Menu > Players lists nearby cached players with resolved names. Select a player to view details.");
                ImGui::Spacing();
                ImGui::TextWrapped("Lua Executor is an editor only. Execute remains disabled until an execution backend is implemented.");
                ImGui::Spacing();
                ImGui::TextWrapped("Combat and Tools are unavailable in this diagnostic build. Insert opens or closes the menu by default.");
                ImGui::EndChild();
            }
            else if (active_tab == 5)
            {
                const float available = ImGui::GetContentRegionAvail().x;
                const float pane_width = (available - ImGui::GetStyle().ItemSpacing.x) * .5f;
                float pane_height = (std::max)(ImGui::GetContentRegionAvail().y - 6.f, 120.f);
                ImGui::BeginChild("##settings_general", ImVec2(pane_width, pane_height), true);
                ImGui::TextUnformatted("GENERAL"); ImGui::Separator();
                modern_toggle("VSync", &settings::settings.vsync);
                modern_toggle("Streamproof", &settings::settings.streamproof);
                modern_toggle("Performance mode", &settings::settings.performance_mode);
                ImGui::Spacing(); ImGui::TextDisabled("MENU ACCENT");
                ImGui::ColorEdit4("##theme", settings::settings.theme, ImGuiColorEditFlags_NoInputs);
                ImGui::Spacing(); ImGui::TextDisabled("Press Insert to toggle the menu.");
                ImGui::EndChild(); ImGui::SameLine();
                ImGui::BeginChild("##settings_extra", ImVec2(0, pane_height), true);
                ImGui::TextUnformatted("FRIEND KEY"); ImGui::Separator();
                modern_toggle("Enabled", &settings::friend_key.enabled);
                modern_toggle("Visible check", &settings::friend_key.visible_check);
                modern_toggle("Target dead", &settings::friend_key.target_dead);
                modern_toggle("Target peds", &settings::friend_key.target_bots);
                framework::gui::create_keybind("Keybind", &settings::friend_key.key, &settings::friend_key.mode, settings::friend_key.id);
                ImGui::Spacing(); ImGui::Separator();
                if (ImGui::Button("Unload", ImVec2(-1.f, 34.f))) {
                    if (settings::mutex) { ReleaseMutex(settings::mutex); CloseHandle(settings::mutex); }
                    ExitProcess(0);
                }
                ImGui::EndChild();
            }

            ImGui::PopStyleVar();
        }
        ImGui::EndChild();
        framework::gui::end_window();
    }

}
