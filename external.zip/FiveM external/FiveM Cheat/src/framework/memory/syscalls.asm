.CODE

PUBLIC nt_read_virtual_mem
nt_read_virtual_mem PROC
	mov r10, rcx
	mov eax, 63
	syscall
	ret
nt_read_virtual_mem ENDP

PUBLIC nt_write_virtual_mem
nt_write_virtual_mem PROC
	mov r10, rcx
	mov eax, 58
	syscall
	ret
nt_write_virtual_mem ENDP

PUBLIC nt_alloc_virtual_mem
nt_alloc_virtual_mem PROC
    mov r10, rcx
    mov eax, 18h    
    syscall
    ret
nt_alloc_virtual_mem ENDP

; NtCreateThreadEx takes 12 args; we pass a params struct pointer in rcx and
; build the kernel frame here. SSN 0x4E is stable Win10 1607 -> Win11; renumber
; on a Windows update that shifts it, same caveat as the stubs above.
; params: +0x00 out handle, +0x08 process handle, +0x10 start, +0x18 arg, +0x20 flags
PUBLIC nt_create_thread_ex
nt_create_thread_ex PROC
    push rbp
    mov rbp, rsp
    sub rsp, 68h
    mov rax, rcx
    mov rcx, [rax+00h]          ; arg1 PHANDLE ThreadHandle
    mov r11d, 01FFFFFh
    mov rdx, r11                ; arg2 DesiredAccess = THREAD_ALL_ACCESS
    xor r8, r8                  ; arg3 ObjectAttributes
    mov r9, [rax+08h]           ; arg4 ProcessHandle
    mov r11, [rax+10h]
    mov [rsp+28h], r11          ; arg5 StartRoutine
    mov r11, [rax+18h]
    mov [rsp+30h], r11          ; arg6 Argument
    mov r11d, [rax+20h]
    mov [rsp+38h], r11          ; arg7 CreateFlags
    xor r11, r11
    mov [rsp+40h], r11          ; arg8 ZeroBits
    mov [rsp+48h], r11          ; arg9 StackZeroBits
    mov [rsp+50h], r11          ; arg10 StackCommit
    mov [rsp+58h], r11          ; arg11 StackReserve
    mov [rsp+60h], r11          ; arg12 AttributeList
    mov r10, rcx
    mov eax, 4Eh
    syscall
    add rsp, 68h
    pop rbp
    ret
nt_create_thread_ex ENDP

; NtQueueApcThread(ThreadHandle, ApcRoutine, Arg1, Arg2, Arg3) - direct 5-arg
; passthrough, arg5 arrives in the caller stack slot like nt_alloc above.
PUBLIC nt_queue_apc_thread
nt_queue_apc_thread PROC
    mov r10, rcx
    mov eax, 45h
    syscall
    ret
nt_queue_apc_thread ENDP

END