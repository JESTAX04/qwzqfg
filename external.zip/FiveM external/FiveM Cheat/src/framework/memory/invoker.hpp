// language: C++, file: invoker.hpp, target: Windows 11, MSVC
// External native invoker for FiveM. Resolves native hashes through FiveM's
// cross-mapping table, marshals args into a remote stub page, executes via
// thread hijack (primary) or NtCreateThreadEx (fallback), reads the result
// back from a status slot in the same allocation.
//
// All table layouts are per-build. The cross-map scanner validates candidate
// runs (sorted hashes + in-range handlers + minimum length) instead of trusting
// a single byte signature, so a FiveM update that shuffles the table needs a
// validation-rule re-check, not a redesign.

#pragma once

#include <array>
#include <chrono>
#include <cstdint>
#include <cstdio>
#include <cstring>
#include <mutex>
#include <string>
#include <thread>
#include <unordered_map>
#include <vector>

#include <Windows.h>
#include <TlHelp32.h>

#include "../memory/memory.hpp"
#include "../engine/globals.hpp"
#include "../logging/logging.hpp"

// The invoker always talks about the single live process.
namespace globals = framework::engine::globals;

namespace invoker
{
    inline std::mutex mtx;
    inline bool ready = false;
    inline std::string last_error;
    inline uintptr_t cross_map_base = 0;
    inline size_t cross_map_count = 0;
    inline uint64_t cross_map_xor = 0;  // per-build transform: orig ^ K = tree key

    // Status slot layout in the remote allocation (page + 0x200):
    //   +0x200 uint32 state        (call_state)
    //   +0x208 uint64 result       (native return value)
    //   +0x210 uint64 args[8]
    //   +0x250 uintptr handler     (patched per call)
    //   +0x260 uintptr scratch     (unused by current stub)
    enum call_state : uint32_t
    {
        state_idle = 0,
        state_running = 1,
        state_done_ok = 2,
        state_done_err = 3,
    };

    // Cross-map entry as FiveM lays it out in the module image (per-build):
    //   +0x00 uint64_t native_hash   (sorted ascending)
    //   +0x08 uintptr_t handler      (absolute in the loaded image)
    // Legacy table constants kept for reference; the live scanner walks the
    // runtime std::map trees instead (see build_cross_map notes below).
    constexpr size_t k_entry_size = 0x10;
    constexpr size_t k_min_run = 1000;

    inline std::unordered_map<uint64_t, uintptr_t> resolved_map;

    // -------- scanner --------

    // Native handler map reality check: FiveM does NOT keep a static
    // {hash, handler} table in any module image. Natives are registered at
    // runtime into std::map<uint64_t, NativeHandler> trees on the private heap
    // (one per script runtime). MSVC tree node layout:
    //   +0x00 _Left, +0x08 _Parent, +0x10 _Right, +0x18 _Color (byte)
    //   +0x20 uint64_t hash, +0x28 uintptr_t handler
    // Scanner v2: walk committed private RW regions, validate node shape
    // (children back-reference their parent, color is 0/1, handler lands in an
    // executable module), harvest every node that passes. No tree walk needed —
    // the back-reference check alone kills false positives.

    // -------- registration-record scanner (proven live) --------
    //
    // FiveM's DLLs carry a native registration table in their .data: a fixed
    // record array, stride 0x40, each record:
    //   +0x00 uint64 native hash  (ORIGINAL GTA hash — verified GET_PLAYER_PED
    //          0x43A66C31C68491C0 at extra-natives-five.dll img+0x184890)
    //   +0x08..+0x38 metadata (engine fields, ptrs into the owning DLL)
    //   +0x28 wrapper fn ptr  (trampoline into the owning DLL)
    //   +0x30 magic 0x800000xx
    //   +0x38 real handler fn ptr  (points into whichever DLL implements it)
    // Scanner: sweep every module image (R), find records whose +0x28/+0x38 are
    // valid fn pointers and whose +0x30 magic matches, harvest {hash -> +0x38}.

    struct module_range
    {
        uintptr_t start;
        uintptr_t end;
        bool executable;
    };

    inline std::vector<module_range> collect_module_ranges(DWORD pid)
    {
        std::vector<module_range> out;
        auto snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, pid);
        if (snapshot == INVALID_HANDLE_VALUE)
            return out;

        MODULEENTRY32 me{};
        me.dwSize = sizeof(me);
        if (Module32First(snapshot, &me))
        {
            do {
                out.push_back({ reinterpret_cast<uintptr_t>(me.modBaseAddr),
                                reinterpret_cast<uintptr_t>(me.modBaseAddr) + me.modBaseSize, false });
            } while (Module32Next(snapshot, &me));
        }
        CloseHandle(snapshot);

        // Mark executable: query protection of the first page of each module.
        for (auto& m : out)
        {
            MEMORY_BASIC_INFORMATION mbi{};
            if (VirtualQueryEx(globals::memory->info.handle, reinterpret_cast<LPCVOID>(m.start), &mbi, sizeof(mbi)))
                m.executable = (mbi.Protect & (PAGE_EXECUTE | PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY)) != 0;
        }
        return out;
    }

    inline bool handler_in_module(const std::vector<module_range>& mods, uintptr_t handler)
    {
        if (!handler)
            return false;
        for (const auto& m : mods)
            if (handler >= m.start && handler < m.end)
                return true;
        return false;
    }

    // Reads a region chunk-wise into a compact buffer. Uses 4 KiB steps so a
    // single dead page costs one failed syscall instead of a whole megabyte.
    inline size_t read_region_paged(uintptr_t start, size_t size, std::vector<uint8_t>& out)
    {
        out.clear();
        out.reserve(size);
        constexpr size_t k_chunk = 0x1000;  // page-sized: survive dead pages
        std::vector<uint8_t> tmp(k_chunk);
        for (uintptr_t off = 0; off < size; off += k_chunk)
        {
            const SIZE_T want = static_cast<SIZE_T>((off + k_chunk <= size) ? k_chunk : (size - off));
            SIZE_T got = 0;
            if (globals::memory->read_bytes(start + off, tmp.data(), want, got))
                out.insert(out.end(), tmp.data(), tmp.data() + got);
            else
                out.insert(out.end(), want, 0x00);  // keep offsets stable, zeros skipped by validation
        }
        return out.size();
    }

    inline size_t build_cross_map()
    {
        std::lock_guard lock(mtx);
        ready = false;
        cross_map_base = 0;
        cross_map_count = 0;
        resolved_map.clear();
        cross_map_xor = 0;

        if (!globals::memory || !globals::memory->success)
        {
            last_error = "no process attached";
            return 0;
        }

        const auto mods = collect_module_ranges(globals::memory->info.pid);
        if (mods.empty())
        {
            last_error = "no modules enumerated";
            return 0;
        }

        // Module census: how many modules did Toolhelp actually return?
        {
            char mb[128];
            std::snprintf(mb, sizeof(mb), "module census: %zu modules collected", mods.size());
            utilities::logging::print(mb, mods.size() > 10 ? utilities::logging::success : utilities::logging::error);
            for (size_t i = 0; i < mods.size() && i < 5; i++)
            {
                std::snprintf(mb, sizeof(mb), "  mod[%zu]: 0x%llx - 0x%llx",
                    i, static_cast<unsigned long long>(mods[i].start),
                    static_cast<unsigned long long>(mods[i].end));
                utilities::logging::print(mb, utilities::logging::info);
            }
            // decisive: is the known GET_PLAYER_PED handler inside any range?
            const uintptr_t known_handler = 0x7fff62aea5c0ull;
            const bool in = handler_in_module(mods, known_handler);
            std::snprintf(mb, sizeof(mb), "  in_module(0x7fff62aea5c0) = %d", static_cast<int>(in));
            utilities::logging::print(mb, in ? utilities::logging::success : utilities::logging::error);
        }

        // Registration-record sweep. Validation: +0x30 magic high dword must be
        // 0x80000000 AND the hash must appear as a nonzero key with at least
        // one module-range pointer at +0x38/+0x40. The self-test traces every
        // sighting of four known natives so gate behavior is observable.
        // NOTE (learned the hard way): `constexpr` locals in an inline header
        // function are fine, but a `for (uint64_t cand : { h38, h40 })` range
        // over an initializer_list inside a loop that ALSO mutates `found`
        // caused MSVC to miscompile the harvest (entries vanished). Use plain
        // if/else chains instead of the range-for with initializer lists.
        constexpr bool k_validate_records = true;
        constexpr bool k_debug_dump = false;  // set true to dump first 6 entries
        std::unordered_map<uint64_t, uintptr_t> found;
        size_t records = 0;
        int selftest_hits = 0;

        uintptr_t addr = reinterpret_cast<uintptr_t>(utilities::sys_info.lpMinimumApplicationAddress);
        const uintptr_t max_addr = reinterpret_cast<uintptr_t>(utilities::sys_info.lpMaximumApplicationAddress) - 0x1000;
        MEMORY_BASIC_INFORMATION mbi{};
        std::vector<uint8_t> buffer;

        while (addr < max_addr)
        {
            if (!VirtualQueryEx(globals::memory->info.handle, reinterpret_cast<LPCVOID>(addr), &mbi, sizeof(mbi)))
                break;

            const uintptr_t region_start = reinterpret_cast<uintptr_t>(mbi.BaseAddress);
            const size_t region_size = mbi.RegionSize;

            // MEM_IMAGE==0x1000000; accept any committed image region that reads.
            // (The record region on b3889 reports type=0x1000000, protect=4.)
            const bool image_rw = mbi.State == MEM_COMMIT && mbi.Type == MEM_IMAGE &&
                                  !(mbi.Protect & PAGE_NOACCESS) && !(mbi.Protect & PAGE_GUARD);
            // Fallback matcher: some loaders report private type for image-backed
            // RW pages. Match the module list ranges as well.
            bool in_module_rw = false;
            if (!image_rw && mbi.State == MEM_COMMIT)
            {
                for (const auto& m : mods)
                    if (region_start >= m.start && region_start < m.end)
                    {
                        in_module_rw = true;
                        break;
                    }
            }

            if (image_rw || in_module_rw)
            {
                read_region_paged(region_start, region_size, buffer);
                if (buffer.size() >= 0x48)
                {
                    const size_t limit = buffer.size() - 0x48;
                    for (size_t off = 0; off <= limit; off += 8)
                    {
                        const uint64_t hash = *reinterpret_cast<const uint64_t*>(buffer.data() + off);

                        // Self-test v4: dump for EVERY known native hash sighting,
                        // and log which module claims each candidate record so we
                        // can see the filter's effect directly.
                        if constexpr (k_validate_records)
                        {
                            const uint64_t watched[] = {
                                0x43A66C31C68491C0, 0x4F8644AF03D0E0D6,
                                0x3FEF770D40960D5A, 0xE396470EE3CE4B92,
                            };
                            for (uint64_t w : watched)
                            {
                                if (hash == w)
                                {
                                    const uint64_t m30 = *reinterpret_cast<const uint64_t*>(buffer.data() + off + 0x30);
                                    const uint64_t h38 = *reinterpret_cast<const uint64_t*>(buffer.data() + off + 0x38);
                                    const uint64_t h40 = *reinterpret_cast<const uint64_t*>(buffer.data() + off + 0x40);
                                    char st[288];
                                    std::snprintf(st, sizeof(st),
                                        "  selftest: hash=%016llx at 0x%llx +30=%llx +38=%llx +40=%llx",
                                        static_cast<unsigned long long>(hash),
                                        static_cast<unsigned long long>(region_start + off),
                                        static_cast<unsigned long long>(m30),
                                        static_cast<unsigned long long>(h38),
                                        static_cast<unsigned long long>(h40));
                                    utilities::logging::print(st, utilities::logging::success);
                                    selftest_hits++;
                                }
                            }
                        }

                        if (hash == 0)
                            continue;
                        const uint64_t magic = *reinterpret_cast<const uint64_t*>(buffer.data() + off + 0x30);

                        // Magic gate, third and final form. Live qwords:
                        //   0x000000008000005A, 0x0000000080000063 ...
                        // i.e. high dword = 0, low dword = 0x800000xx. Previous
                        // attempts compared the wrong half both times.
                        if (magic > 0xFFFFFFFFull || (magic & 0x80000000ull) == 0)
                            continue;

                        // Magic + hash seen. Harvest FIRST (handler may be
                        // zero — filled in second pass), resolve handler after.
                        const uint64_t h38 = *reinterpret_cast<const uint64_t*>(buffer.data() + off + 0x38);
                        const uint64_t h40 = *reinterpret_cast<const uint64_t*>(buffer.data() + off + 0x40);
                        uint64_t handler = 0;
                        if (handler_in_module(mods, static_cast<uintptr_t>(h38)))
                            handler = h38;
                        else if (handler_in_module(mods, static_cast<uintptr_t>(h40)))
                            handler = h40;

                        if (handler)
                        {
                            auto ins = found.emplace(hash, static_cast<uintptr_t>(handler));
                            if (ins.second)
                                records++;

                            if constexpr (k_validate_records)
                            {
                                if (hash == 0x43A66C31C68491C0 || hash == 0x4F8644AF03D0E0D6 ||
                                    hash == 0x3FEF770D40960D5A)
                                {
                                    char st2[192];
                                    std::snprintf(st2, sizeof(st2), "  HARVESTED %016llx -> %llx (new=%d)",
                                        static_cast<unsigned long long>(hash),
                                        static_cast<unsigned long long>(handler),
                                        static_cast<int>(ins.second));
                                    utilities::logging::print(st2, utilities::logging::success);
                                }
                            }
                        }
                    }
                }
            }

            addr = region_start + region_size;
        }

        char buf[128];
        std::snprintf(buf, sizeof(buf), "record scan: %zu natives, selftest hits=%d",
            found.size(), selftest_hits);
        utilities::logging::print(buf, found.size() > 100 ? utilities::logging::success : utilities::logging::warning);

        // DEBUG: dump a few harvested entries to see what they look like
        if constexpr (k_debug_dump)
        {
            size_t dumped = 0;
            for (const auto& [h, hd] : found)
            {
                std::snprintf(buf, sizeof(buf), "  entry: hash=0x%016llx handler=0x%llx",
                    static_cast<unsigned long long>(h), static_cast<unsigned long long>(hd));
                utilities::logging::print(buf, utilities::logging::info);
                if (++dumped >= 6)
                    break;
            }
        }

        // live confirmation against known natives (before threshold so we can
        // always see resolution state)
        const uint64_t known[] = {
            0x43A66C31C68491C0,  // GET_PLAYER_PED
            0x4F8644AF03D0E0D6,  // PLAYER_ID
            0x3FEF770D40960D5A,  // GET_ENTITY_COORDS
            0xE396470EE3CE4B92,  // ADD_EXPLOSION
        };
        for (uint64_t k : known)
        {
            const auto it = found.find(k);
            if (it != found.end())
            {
                std::snprintf(buf, sizeof(buf), "  known 0x%016llx -> handler 0x%llx",
                    static_cast<unsigned long long>(k), static_cast<unsigned long long>(it->second));
                utilities::logging::print(buf, utilities::logging::success);
            }
            else
            {
                std::snprintf(buf, sizeof(buf), "  known 0x%016llx -> missing",
                    static_cast<unsigned long long>(k));
                utilities::logging::print(buf, utilities::logging::warning);
            }
        }

        if (found.size() < 100)
        {
            std::snprintf(buf, sizeof(buf), "record scan found only %zu natives (selftest=%d)", found.size(), selftest_hits);
            last_error = buf;
            return 0;
        }

        resolved_map = std::move(found);
        cross_map_count = resolved_map.size();
        ready = true;
        last_error.clear();
        return cross_map_count;
    }

    struct resolution
    {
        uintptr_t handler = 0;
        uint64_t hash = 0;
    };

    inline resolution resolve(uint64_t hash)
    {
        std::lock_guard lock(mtx);
        resolution r;
        if (!ready)
        {
            last_error = "invoker not ready";
            return r;
        }
        // Lookup uses the build's transformed key when the XOR constant is known.
        auto it = resolved_map.find(cross_map_xor ? (hash ^ cross_map_xor) : hash);
        if (it == resolved_map.end())
        {
            char buf[64];
            std::snprintf(buf, sizeof(buf), "native not in cross-map: 0x%016llx",
                static_cast<unsigned long long>(hash));
            last_error = buf;
            return r;
        }
        r.hash = hash;
        r.handler = it->second;
        return r;
    }

    // -------- remote page + stub --------

    constexpr size_t k_page_size = 0x1000;

    struct remote_ctx
    {
        uintptr_t page = 0;
    };

    inline remote_ctx ctx;

    // Byte offset of the imm64 inside build_stub()'s `mov rax, imm64`:
    // pushes rax..r15 = 23 bytes (7 singles + 8 doubles), sub rsp = 4,
    // then 0x48 0xB8 = 2 opcode bytes -> imm64 starts at byte 29.
    constexpr size_t k_stub_base_patch_off = 29;
    static_assert(k_stub_base_patch_off == 29, "stub layout moved; recompute patch offset");

    // Stub, assembled once and patched with the page base:
    //   saves all gp regs, loads args from page, calls handler, stores result,
    //   restores regs, ret -> original RIP. The game thread resumes exactly.
    inline std::array<uint8_t, 0xC0> build_stub()
    {
        std::array<uint8_t, 0xC0> s{};
        size_t i = 0;
        auto emit = [&](std::initializer_list<uint8_t> bytes) {
            for (uint8_t b : bytes) s[i++] = b;
        };

        emit({ 0x50 });                                              // push rax
        emit({ 0x53 });                                              // push rbx
        emit({ 0x51 });                                              // push rcx
        emit({ 0x52 });                                              // push rdx
        emit({ 0x56 });                                              // push rsi
        emit({ 0x57 });                                              // push rdi
        emit({ 0x55 });                                              // push rbp
        emit({ 0x41, 0x50 });                                        // push r8
        emit({ 0x41, 0x51 });                                        // push r9
        emit({ 0x41, 0x52 });                                        // push r10
        emit({ 0x41, 0x53 });                                        // push r11
        emit({ 0x41, 0x54 });                                        // push r12
        emit({ 0x41, 0x55 });                                        // push r13
        emit({ 0x41, 0x56 });                                        // push r14
        emit({ 0x41, 0x57 });                                        // push r15
        emit({ 0x48, 0x83, 0xEC, 0x48 });                            // sub rsp,0x48
        emit({ 0x48, 0xB8, 0, 0, 0, 0, 0, 0, 0, 0 });                // mov rax, <page base>
        emit({ 0x48, 0x89, 0xC3 });                                  // mov rbx, rax
        emit({ 0x48, 0x8B, 0x88, 0x10, 0x02, 0x00, 0x00 });          // mov rcx,[rax+210]
        emit({ 0x48, 0x8B, 0x90, 0x18, 0x02, 0x00, 0x00 });          // mov rdx,[rax+218]
        emit({ 0x4C, 0x8B, 0x80, 0x20, 0x02, 0x00, 0x00 });          // mov r8, [rax+220]
        emit({ 0x4C, 0x8B, 0x88, 0x28, 0x02, 0x00, 0x00 });          // mov r9, [rax+228]
        emit({ 0x4C, 0x8B, 0x98, 0x30, 0x02, 0x00, 0x00 });          // mov r11,[rax+230]
        emit({ 0x4C, 0x89, 0x5C, 0x24, 0x20 });                      // mov [rsp+20],r11
        emit({ 0x4C, 0x8B, 0x98, 0x38, 0x02, 0x00, 0x00 });          // mov r11,[rax+238]
        emit({ 0x4C, 0x89, 0x5C, 0x24, 0x28 });                      // mov [rsp+28],r11
        emit({ 0x4C, 0x8B, 0x98, 0x40, 0x02, 0x00, 0x00 });          // mov r11,[rax+240]
        emit({ 0x4C, 0x89, 0x5C, 0x24, 0x30 });                      // mov [rsp+30],r11
        emit({ 0x4C, 0x8B, 0x98, 0x48, 0x02, 0x00, 0x00 });          // mov r11,[rax+248]
        emit({ 0x4C, 0x89, 0x5C, 0x24, 0x38 });                      // mov [rsp+38],r11
        emit({ 0xFF, 0x53, 0x50 });                                  // call [rbx+250]
        emit({ 0x48, 0x89, 0x43, 0x08 });                            // mov [rbx+208],rax
        emit({ 0xC7, 0x43, 0x00, 0x02, 0x00, 0x00, 0x00 });          // mov dword [rbx+200],2
        emit({ 0x48, 0x83, 0xC4, 0x48 });                            // add rsp,0x48
        emit({ 0x41, 0x5F });                                        // pop r15
        emit({ 0x41, 0x5E });                                        // pop r14
        emit({ 0x41, 0x5D });                                        // pop r13
        emit({ 0x41, 0x5C });                                        // pop r12
        emit({ 0x41, 0x5B });                                        // pop r11
        emit({ 0x41, 0x5A });                                        // pop r10
        emit({ 0x41, 0x59 });                                        // pop r9
        emit({ 0x41, 0x58 });                                        // pop r8
        emit({ 0x5D });                                              // pop rbp
        emit({ 0x5F });                                              // pop rdi
        emit({ 0x5E });                                              // pop rsi
        emit({ 0x5A });                                              // pop rdx
        emit({ 0x59 });                                              // pop rcx
        emit({ 0x5B });                                              // pop rbx
        emit({ 0x58 });                                              // pop rax
        emit({ 0xC3 });                                              // ret -> original RIP
        return s;
    }

    inline bool setup_remote()
    {
        if (!globals::memory || !globals::memory->success)
        {
            last_error = "no process attached";
            return false;
        }
        if (ctx.page)
            return true;

        PVOID base_addr = nullptr;
        SIZE_T region = k_page_size;
        const ULONG type = MEM_COMMIT | MEM_RESERVE;
        const ULONG protect = PAGE_EXECUTE_READWRITE;
        const long status = nt_alloc_virtual_mem(globals::memory->info.handle, &base_addr, &region, type, protect);
        if (status < 0 || !base_addr)
        {
            char buf[64];
            std::snprintf(buf, sizeof(buf), "remote alloc failed: 0x%lx", static_cast<unsigned long>(status));
            last_error = buf;
            return false;
        }

        ctx.page = reinterpret_cast<uintptr_t>(base_addr);

        auto stub = build_stub();
        const uint64_t page = ctx.page;
        std::memcpy(stub.data() + k_stub_base_patch_off, &page, sizeof(page));  // imm64 of `mov rax, imm64`

        SIZE_T written = 0;
        if (!globals::memory->write_bytes(ctx.page, stub.data(), stub.size(), written))
        {
            last_error = "stub write failed";
            ctx.page = 0;
            return false;
        }

        std::array<uint8_t, 0x70> zero{};
        if (!globals::memory->write_bytes(ctx.page + 0x200, zero.data(), zero.size(), written))
        {
            last_error = "status area init failed";
            ctx.page = 0;
            return false;
        }
        return true;
    }

    // -------- execution paths --------

    struct call_result
    {
        bool ok = false;
        uint64_t value = 0;
        std::string error;
    };

    inline bool poll_result(call_result& out)
    {
        for (int i = 0; i < 300; i++)  // 3s at 10ms
        {
            uint32_t state_now = 0;
            globals::memory->read_memory(ctx.page + 0x200, state_now);
            if (state_now == state_done_ok)
            {
                uint64_t result = 0;
                globals::memory->read_memory(ctx.page + 0x208, result);
                out.ok = true;
                out.value = result;
                return true;
            }
            if (state_now == state_done_err)
            {
                out.error = "remote stub reported failure";
                return true;
            }
            std::this_thread::sleep_for(std::chrono::milliseconds(10));
        }
        out.error = "native call timeout";
        return false;
    }

    inline bool patch_call_block(uint64_t handler, const std::array<uint64_t, 8>& args)
    {
        SIZE_T written = 0;
        std::array<uint8_t, 0x68> block{};
        const uint32_t st = state_running;
        std::memcpy(block.data() + 0x00, &st, sizeof(st));            // +0x200 state
        std::memcpy(block.data() + 0x10, args.data(), sizeof(args));  // +0x210 args
        std::memcpy(block.data() + 0x50, &handler, sizeof(handler));  // +0x250 handler
        return globals::memory->write_bytes(ctx.page + 0x200, block.data(), block.size(), written);
    }

    // Primary path: hijack a game thread. Suspend, redirect RIP into the stub
    // with a private stack inside our page, resume; the stub restores the full
    // register set and returns to the sampled RIP, so the thread resumes clean.
    inline call_result call(uint64_t hash, const std::array<uint64_t, 8>& args = {})
    {
        call_result out;

        const auto res = resolve(hash);
        if (!res.handler)
        {
            out.error = last_error;
            return out;
        }
        if (!setup_remote())
        {
            out.error = last_error;
            return out;
        }
        if (!patch_call_block(res.handler, args))
        {
            out.error = "arg write failed";
            return out;
        }

        // Pick a thread: any openable thread of the target process, prefer one
        // that is not the first (main) thread — script/runtime threads are less
        // likely to hold allocator locks the native needs.
        auto snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
        if (snapshot == INVALID_HANDLE_VALUE)
        {
            out.error = "thread snapshot failed";
            return out;
        }

        DWORD target_tid = 0;
        {
            std::vector<DWORD> tids;
            THREADENTRY32 te{};
            te.dwSize = sizeof(te);
            if (Thread32First(snapshot, &te))
            {
                do {
                    if (te.th32OwnerProcessID == globals::memory->info.pid)
                        tids.push_back(te.th32ThreadID);
                } while (Thread32Next(snapshot, &te));
            }
            CloseHandle(snapshot);

            if (tids.empty())
            {
                out.error = "no game threads found";
                return out;
            }
            target_tid = tids.size() > 1 ? tids[1] : tids[0];
        }

        HANDLE thread = OpenThread(THREAD_SUSPEND_RESUME | THREAD_GET_CONTEXT | THREAD_SET_CONTEXT, FALSE, target_tid);
        if (!thread)
        {
            out.error = "OpenThread failed";
            return out;
        }

        if (SuspendThread(thread) == static_cast<DWORD>(-1))
        {
            CloseHandle(thread);
            out.error = "SuspendThread failed";
            return out;
        }

        CONTEXT orig{};
        orig.ContextFlags = CONTEXT_FULL;
        bool hijacked = false;
        if (GetThreadContext(thread, &orig))
        {
            // Original RIP parked at the bottom of our fake stack; `ret` in the
            // stub pops it. rsp = page+0xE00, [rsp] = orig RIP.
            const uint64_t orig_rip = orig.Rip;
            SIZE_T written = 0;
            if (globals::memory->write_bytes(ctx.page + 0xE00,
                    reinterpret_cast<const void*>(&orig_rip), sizeof(orig_rip), written))
            {
                CONTEXT hijack = orig;
                hijack.ContextFlags = CONTEXT_FULL;
                hijack.Rip = ctx.page;
                hijack.Rsp = ctx.page + 0xE00;
                if (SetThreadContext(thread, &hijack))
                {
                    if (ResumeThread(thread) != static_cast<DWORD>(-1))
                        hijacked = true;
                }
            }
        }

        if (!hijacked)
        {
            ResumeThread(thread);  // undo the suspend before bailing
            CloseHandle(thread);
            out.error = "hijack setup failed";
            return out;
        }

        CloseHandle(thread);

        if (!poll_result(out))
        {
            // Timeout: the thread may not have reached the stub yet. Restore
            // nothing — the stub is reentrant-safe for a retry on the same
            // thread via call_via_thread as fallback.
            return out;
        }
        return out;
    }

    // Fallback path: NtCreateThreadEx remote thread running the same stub.
    // Louder, but immune to APC/thread-state problems.
    inline call_result call_via_thread(uint64_t hash, const std::array<uint64_t, 8>& args = {})
    {
        call_result out;
        const auto res = resolve(hash);
        if (!res.handler)
        {
            out.error = last_error;
            return out;
        }
        if (!setup_remote())
        {
            out.error = last_error;
            return out;
        }
        if (!patch_call_block(res.handler, args))
        {
            out.error = "arg write failed";
            return out;
        }

        // The stub ends in `ret` popping the fake-stack RIP — for a fresh
        // thread, park a terminator so it exits clean after one call.
        const uint64_t exit_rip = reinterpret_cast<uint64_t>(&ExitProcess);
        SIZE_T written = 0;
        globals::memory->write_bytes(ctx.page + 0xE00,
            reinterpret_cast<const void*>(&exit_rip), sizeof(exit_rip), written);

        // NtCreateThreadEx param struct, layout matches syscalls.asm:
        //   +0x00 PHANDLE out, +0x08 process, +0x10 start, +0x18 arg, +0x20 flags
        uint8_t params[0x28]{};
        HANDLE out_handle = nullptr;
        const HANDLE process = globals::memory->info.handle;
        const PVOID start = reinterpret_cast<PVOID>(ctx.page);
        std::memcpy(params + 0x00, &out_handle, sizeof(out_handle));
        std::memcpy(params + 0x08, &process, sizeof(process));
        std::memcpy(params + 0x10, &start, sizeof(start));
        // arg + flags stay zero

        const long status = nt_create_thread_ex(params);
        if (status < 0)
        {
            char buf[64];
            std::snprintf(buf, sizeof(buf), "thread create failed: 0x%lx", static_cast<unsigned long>(status));
            out.error = buf;
            return out;
        }

        HANDLE created = nullptr;
        std::memcpy(&created, params, sizeof(created));
        if (created)
            CloseHandle(created);

        poll_result(out);
        return out;
    }
}  // namespace invoker
