#pragma once 
#include "../memory/memory.hpp"
#include "engine.hpp"
#include <unordered_map>

namespace framework::engine::globals 
{
	inline sdk::world world;
	inline sdk::ped local_ped;
	inline uintptr_t replay = 0;
	inline uintptr_t camera = 0;
	inline uintptr_t viewport = 0;
	inline std::string version = "";

	inline std::unique_ptr<utilities::memory> memory;
}

namespace framework::engine::offsets 
{
	inline uintptr_t world = 0;
	inline uintptr_t player_info = 0;
	inline uintptr_t replay_interface = 0;
	inline uintptr_t handle_bullet = 0;
	inline uintptr_t camera = 0;
	inline uintptr_t weapon_damage = 0;
	inline uintptr_t triggerbot = 0;
        inline uintptr_t names = 0;
	inline uintptr_t frag_inst = 0;
	inline uintptr_t player_stamina = 0;
	inline uintptr_t viewport = 0;
}
