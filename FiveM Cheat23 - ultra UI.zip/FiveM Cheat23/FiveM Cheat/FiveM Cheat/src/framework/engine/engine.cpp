#include "engine.hpp"

#include "../features/cache_data/player_cache.hpp"
#include "../memory/helpers.hpp"
#include "../menu/gui/framework/framework.hpp"
#include "globals.hpp"

namespace framework::engine
{
    bool sdk::instance::is_valid( )
    {
        return utilities::is_valid_address( addr );
    }

    sdk::world sdk::get_world( )
    {
        return globals::memory->simple_read< world >( offsets::world );
    }

    sdk::camera sdk::get_camera( )
    {
        return globals::memory->simple_read< camera >( offsets::camera );
    }

    sdk::replay_interface sdk::get_replay( )
    {
        return replay_interface( globals::memory->simple_read< uintptr_t >( offsets::replay_interface ) );
    }

    sdk::ped sdk::get_ped_from_index( uintptr_t ped_list, int index )
    {
        return ped( globals::memory->simple_read< uintptr_t >( ped_list + ( index * 0x10 ) ) );
    }

    Vector2 sdk::world_to_screen( Vector3 world_point, Matrix view_matrix )
    {
        auto vm = view_matrix.Transpose( );

        auto vec_x = Vector4( vm._21, vm._22, vm._23, vm._24 ), vec_y = Vector4( vm._31, vm._32, vm._33, vm._34 ),
             vec_z = Vector4( vm._41, vm._42, vm._43, vm._44 );

        Vector3 view_space = { ( vec_x.x * world_point.x ) + ( vec_x.y * world_point.y ) + ( vec_x.z * world_point.z ) + vec_x.w,
                               ( vec_y.x * world_point.x ) + ( vec_y.y * world_point.y ) + ( vec_y.z * world_point.z ) + vec_y.w,
                               ( vec_z.x * world_point.x ) + ( vec_z.y * world_point.y ) + ( vec_z.z * world_point.z ) + vec_z.w };

        if ( view_space.z <= 0.5f )
            return { -1, -1 };

        view_space.z = 1.0f / view_space.z;
        view_space.x *= view_space.z;
        view_space.y *= view_space.z;

        float width = settings::rect.right - settings::rect.left;
        float height = settings::rect.bottom - settings::rect.top;

        float center_x = width / 2.f;
        float center_y = height / 2.f;

        view_space.x = center_x + float( 0.5f * view_space.x * width + 0.5f );
        view_space.y = center_y - float( 0.5f * view_space.y * height + 0.5f );

        return Vector2( std::roundf(view_space.x), std::roundf(view_space.y) );
    }

    bool sdk::is_on_screen( Vector2 point )
    {
        float width = settings::rect.right - settings::rect.left;
        float height = settings::rect.bottom - settings::rect.top;

        return point.x >= 0 && point.y >= 0 && point.x <= width && point.y <= height;
    }

    sdk::ped sdk::world::get_local_ped( )
    {
        return globals::memory->simple_read< ped >( this->addr + 0x8 );
    }

    Vector3 sdk::get_camera_pos( )
    {
        return globals::memory->simple_read< Vector3 >( globals::memory->info.mod_info.base_address + 0x201E100 );
    }

    std::pair< Vector3, player_cache::entity* > sdk::get_closest_ped( )
    {
        std::pair< Vector3, player_cache::entity* > result;
        float min_distance = FLT_MAX;

        auto vm = globals::memory->simple_read< Matrix >( globals::viewport + 0x24C );

        float width = settings::rect.right - settings::rect.left;
        float height = settings::rect.bottom - settings::rect.top;

        float center_x = width / 2.f;
        float center_y = height / 2.f;

        for ( auto& entity : player_cache::get_entities( ) )
        {
            auto pos = entity.bone_indexes[ player_cache::bone_id::HEAD ].pos( );
            auto screen_pos = g_sdk->world_to_screen( pos, vm );

            if ( !g_sdk->is_on_screen( screen_pos ) )
                continue;

            auto distance = ( Vector2( center_x, center_y ) - screen_pos ).Length( );
            if ( distance < min_distance )
            {
                result = { pos, &entity };
                min_distance = distance;
            }
        }

        return result;
    }
}  // namespace framework::engine