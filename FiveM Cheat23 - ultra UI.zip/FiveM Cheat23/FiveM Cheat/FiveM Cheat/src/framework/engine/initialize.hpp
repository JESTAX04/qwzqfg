#pragma once

#include <cstdint>
#include "../memory/scanner.hpp"
#include "globals.hpp"
#include <memory>
#include <thread>
#include <string>
#include "../threads.hpp"
#include "../logging/logging.hpp"

namespace framework::engine
{
	std::string get_version();

	template<typename any_type> 
	inline uintptr_t scan_for_known_value(uintptr_t base, any_type value, uintptr_t max = 1000)
	{
		for (uintptr_t offset = 0; offset < max; offset += sizeof(any_type))
		{
			any_type result{};
			if (!globals::memory->read_memory(base + offset, result))
				continue;

			if (result == value)
				return offset;
		}

		return 0;
	}

	void initialize();
	bool scan_game();
}