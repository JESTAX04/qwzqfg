#include "../engine.hpp"

#include "../../memory/helpers.hpp"
#include "../globals.hpp"

namespace framework::engine {
    struct mat34_v
    {
        __m128 col0;
        __m128 col1;
        __m128 col2;
        __m128 col3;
    };

    struct mat34_vi
    {
        __m128i col0;
        __m128i col1;
        __m128i col2;
        __m128i col3;
    };

    struct skel_data
    {
        uint8_t pad_0x00[0x8];  
        uintptr_t mtx;                
        uint8_t pad_0x10[0x18 - 0x10]; 
        uintptr_t index_table;        
    };

	Vector3 sdk::bone::pos()
	{
		Matrix v4;

		auto data = globals::memory->simple_read<skel_data>(this->parent);
		if (!data.mtx || !data.index_table)
			return Vector3();

        auto m1 = globals::memory->simple_read< mat34_v >( data.mtx );
        auto m2 = globals::memory->simple_read< mat34_vi >( data.index_table + ( this->bone_index << 6 ) );

        mat34_v mat;

        mat.col0 = _mm_add_ps(_mm_add_ps(_mm_mul_ps(m1.col1, _mm_castsi128_ps(_mm_shuffle_epi32(m2.col0, 85))), _mm_mul_ps(m1.col0, _mm_castsi128_ps(_mm_shuffle_epi32(m2.col0, 0)))), _mm_mul_ps(m1.col2, _mm_castsi128_ps(_mm_shuffle_epi32(m2.col0, 170))));
        mat.col1 = _mm_add_ps(_mm_add_ps(_mm_mul_ps(m1.col1, _mm_castsi128_ps(_mm_shuffle_epi32(m2.col1, 85))), _mm_mul_ps(m1.col0, _mm_castsi128_ps(_mm_shuffle_epi32(m2.col1, 0)))), _mm_mul_ps(m1.col2, _mm_castsi128_ps(_mm_shuffle_epi32(m2.col1, 170))));
        mat.col3 = _mm_add_ps(_mm_add_ps(_mm_add_ps(_mm_mul_ps(m1.col0, _mm_castsi128_ps(_mm_shuffle_epi32(m2.col3, 0))), m1.col3), _mm_mul_ps(m1.col1, _mm_castsi128_ps(_mm_shuffle_epi32(m2.col3, 85)))), _mm_mul_ps(m1.col2, _mm_castsi128_ps(_mm_shuffle_epi32(m2.col3, 170))));
        mat.col2 = _mm_add_ps(_mm_add_ps(_mm_mul_ps(m1.col1, _mm_castsi128_ps(_mm_shuffle_epi32(m2.col2, 85))), _mm_mul_ps(m1.col0, _mm_castsi128_ps(_mm_shuffle_epi32(m2.col2, 0)))), _mm_mul_ps(m1.col2, _mm_castsi128_ps(_mm_shuffle_epi32(m2.col2, 170))));
        
        return { mat.col3.m128_f32[0], mat.col3.m128_f32[1], mat.col3.m128_f32[2] };;
	}
}