#include "../engine.hpp"

#include "../../memory/helpers.hpp"
#include "../globals.hpp"

namespace framework::engine {
	uint32_t sdk::weapon_info::get_max_clip_size()
	{
		return globals::memory->simple_read<uint32_t>(this->addr + 0x70);
	}
	void sdk::weapon_info::set_max_clip_size(uint32_t max_clip_size)
	{
		globals::memory->write_memory(this->addr + 0x70, max_clip_size);
	}

	float sdk::weapon_info::get_fire_rate()
	{
		return globals::memory->simple_read<float>(this->addr + 0x120);
	}

	void sdk::weapon_info::set_fire_rate(float fire_rate)
	{
		globals::memory->write_memory<float>(this->addr + 0x120, fire_rate);
	}

	uint32_t sdk::weapon_info::hash()
	{
		return globals::memory->simple_read<uint32_t>(this->addr + 0x10);
	}
}