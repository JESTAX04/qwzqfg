#include "../../memory/helpers.hpp"
#include "../engine.hpp"
#include "../globals.hpp"

namespace framework::engine
{
    struct cr_skel_data_t
    {
        uint8_t pad_0x00[ 0x10 ];
        uintptr_t base;
        uint16_t size;
        uint16_t unk_0x1A;
        uint8_t pad_0x1C[ 0x5E - 0x1C ];
        uint16_t max;
    };

    int sdk::skeleton_data::convert_bone_id_to_index( int bone )
    {
        auto cr_skel_data = globals::memory->simple_read< uintptr_t >( this->skel_data );
        auto skel_data = globals::memory->simple_read< cr_skel_data_t >( cr_skel_data );

        if ( skel_data.unk_0x1A )
        {
            if ( skel_data.base && skel_data.size )
            {
                uintptr_t hash = globals::memory->simple_read< uintptr_t >( skel_data.base + 8 * ( bone % skel_data.size ) );

                for ( auto i = hash; i != 0; i = globals::memory->simple_read< uintptr_t >( i + 8 ) )
                {
                    int id = globals::memory->simple_read< int >( i );
                    if ( id == bone )
                        return globals::memory->simple_read< int >( i + 4 );
                }
            }
        }
        else
        {
            if ( bone < skel_data.max )
                return bone;
        }

        return 0;
    }

    sdk::bone sdk::skeleton_data::get_bone( int bone )
    {
        int bone_index = this->convert_bone_id_to_index( bone );
        return sdk::bone( this->skel_data, bone_index );
    }
}  // namespace framework::engine