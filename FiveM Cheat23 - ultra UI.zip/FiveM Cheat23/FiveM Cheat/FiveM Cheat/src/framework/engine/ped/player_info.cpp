#include "../engine.hpp"

#include "../../memory/helpers.hpp"
#include "../globals.hpp"


namespace framework::engine {
	float sdk::player_info::get_player_stamina()
	{
		return globals::memory->simple_read<float>(this->addr + offsets::player_stamina);
	}

	void sdk::player_info::set_player_stamina(float player_stamina)
	{
		globals::memory->write_memory(this->addr + offsets::player_stamina, player_stamina);
	}

	float sdk::player_info::get_weapon_damage()
	{
		return globals::memory->simple_read<float>(this->addr + offsets::weapon_damage);
	}

	void sdk::player_info::set_weapon_damage(float weapon_damage)
	{
		globals::memory->write_memory(this->addr + offsets::weapon_damage, weapon_damage);
	}

	float sdk::player_info::get_punch_damage()
	{
		if (!this->addr)
			return 0.f;

		return globals::memory->simple_read<float>(this->addr + (offsets::weapon_damage + 0x10));
	}

	void sdk::player_info::set_punch_damage(float punch_damage)
	{
		if (!this->addr)
			return;

		globals::memory->write_memory(this->addr + (offsets::weapon_damage + 0x10), punch_damage);
	}

	int sdk::player_info::net_id()
	{
		if (!this->addr)
			return 0;

		return globals::memory->simple_read<int>(this->addr + 0xE8);
	}

	float sdk::ped::get_armor()
	{
		return globals::memory->simple_read<float>(this->addr + 0x1474);
	}

	void sdk::ped::set_armor(float armor)
	{
		globals::memory->write_memory(this->addr + 0x1474, armor);
	}
}