#include "../../engine.hpp"

#include "../../../memory/helpers.hpp"
#include "../../globals.hpp"


namespace framework::engine {
	int sdk::veh_interface::get_veh_count()
	{
		return globals::memory->simple_read<int>(this->addr + 0x190);
	}

	uintptr_t sdk::veh_interface::get_veh_list()
	{
		return globals::memory->simple_read<uintptr_t>(this->addr + 0x180);
	}
}