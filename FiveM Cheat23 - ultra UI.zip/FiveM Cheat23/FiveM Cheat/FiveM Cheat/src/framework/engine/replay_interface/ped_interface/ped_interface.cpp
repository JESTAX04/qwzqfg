#include "../../engine.hpp"

#include "../../../memory/helpers.hpp"
#include "../../globals.hpp"


namespace framework::engine {
	int sdk::ped_interface::get_ped_count()
	{
		return globals::memory->simple_read<int>(this->addr + 0x110);
	}

	uintptr_t sdk::ped_interface::get_ped_list()
	{
		return globals::memory->simple_read<uintptr_t>(this->addr + 0x100);
	}
}