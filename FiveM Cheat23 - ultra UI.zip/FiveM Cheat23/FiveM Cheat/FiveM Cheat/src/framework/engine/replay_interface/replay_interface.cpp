#include "../engine.hpp"

#include "../../memory/helpers.hpp"
#include "../globals.hpp"


namespace framework::engine {
	sdk::ped_interface sdk::replay_interface::get_ped_interface()
	{
		return sdk::ped_interface(globals::memory->simple_read<uintptr_t>(this->addr + 0x18));
	}

	sdk::veh_interface sdk::replay_interface::get_veh_interface()
	{
		return sdk::veh_interface(globals::memory->simple_read<uintptr_t>(this->addr + 0x10));
	}
}