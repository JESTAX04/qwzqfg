#include "../engine.hpp"

#include "../../memory/helpers.hpp"
#include "../globals.hpp"

namespace framework::engine {
	void sdk::vehicle::fix()
	{
		BYTE val2 = 0x17;
		globals::memory->write_memory(this->addr + 0x972, val2);
	}

	void sdk::vehicle::set_lock_state(eVehicleLockState state)
	{
		globals::memory->write_memory(this->addr + 0x13C0, state);
	}
	
	void sdk::vehicle::destroy()
	{
		
	}
}