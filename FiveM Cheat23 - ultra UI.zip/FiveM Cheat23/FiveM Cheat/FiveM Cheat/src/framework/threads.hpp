#pragma once

#include <unordered_map>
#include <thread>
#include <string>
#include <functional>

namespace threads 
{
    inline bool should_run = true;

    struct thread 
    {
        std::thread worker;

        void start(std::function<void()> func) 
        {
            worker = std::thread(func);
        }

        void stop()
        {
            if (worker.joinable())
                worker.join();
        }

        ~thread() 
        {
            stop();
        }
    };

    inline std::unordered_map<std::string, std::unique_ptr<thread>> map;
} // namesopace thread

