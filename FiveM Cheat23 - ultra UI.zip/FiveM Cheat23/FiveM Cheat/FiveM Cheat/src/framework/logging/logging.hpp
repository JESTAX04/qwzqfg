#pragma once

#include <string>

namespace utilities::logging {
	enum type {
		success,
		info,
		warning,
		error
	};

	inline void print(const std::string& text, type type)
	{
		printf("[");

		switch (type) {
		case 0:
			printf("\033[32msuccess\033[0m");
			break;
		case 1:
			printf("\033[94minfo\033[0m");
			break;
		case 2:
			printf("\033[38;2;255;140;0mwarning\033[0m");
			break;
		case 3:
			printf("\033[31merror\033[0m");
			break;
		}

		printf("] ");

		std::string print_text = text + '\n';
		printf(print_text.c_str());
	}

	template<typename any_type>
	inline void print_value(const std::string& text, any_type value, type type)
	{
		printf("[");

		switch (type) {
		case 0:
			printf("\033[32msuccess\033[0m");
			break;
		case 1:
			printf("\033[94minfo\033[0m");
			break;
		case 2:
			printf("\033[38;2;255;140;0mwarning\033[0m");
			break;
		case 3:
			printf("\033[31merror\033[0m");
			break;
		}

		printf("] ");
		std::string print_text = text + '\n';
		printf(print_text.c_str(), value);
	}
}