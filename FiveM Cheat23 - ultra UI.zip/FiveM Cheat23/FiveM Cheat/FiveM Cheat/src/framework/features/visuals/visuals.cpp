#define NOMINMAX
#include <algorithm>
#include <chrono>
#include <cstdio>

#include "../../../dependencies/imgui/imgui.h"
#include "../../engine/engine.hpp"
#include "../../engine/globals.hpp"
#include "../../menu/gui/gui.hpp"
#include "../../menu/settings.hpp"
#include "../cache_data/player_cache.hpp"
#include "../features.hpp"

struct bounding_box
{
    ImVec2 min, max;

    bounding_box( ImVec2 min, ImVec2 max ) : min( min ), max( max )
    {
    }
};

bounding_box calculate_box( const std::vector< Vector2 >& points )
{
    Vector2 min = points[ 0 ];
    Vector2 max = points[ 0 ];

    for ( const auto& point : points )
    {
        min = Vector2::Min( min, point );
        max = Vector2::Max( max, point );
    }

    return { { min.x, min.y }, { max.x, max.y } };
}

ImU32 convert_float_4_to_col( float f[ 4 ] )
{
    auto vec4 = ImVec4( f[ 0 ], f[ 1 ], f[ 2 ], f[ 3 ] );
    return ImGui::ColorConvertFloat4ToU32( vec4 );
}

void draw_outlined_text( ImDrawList* draw_list, const ImVec2& pos, ImU32 col, const char* text )
{
    const ImVec2 pixel_pos( std::round( pos.x ), std::round( pos.y ) );
    if ( settings::visuals.text_outline )
    {
        const ImU32 outline = IM_COL32( 0, 0, 0, 255 );
        draw_list->AddText( ImVec2( pixel_pos.x - 1, pixel_pos.y ), outline, text );
        draw_list->AddText( ImVec2( pixel_pos.x + 1, pixel_pos.y ), outline, text );
        draw_list->AddText( ImVec2( pixel_pos.x, pixel_pos.y - 1 ), outline, text );
        draw_list->AddText( ImVec2( pixel_pos.x, pixel_pos.y + 1 ), outline, text );
    }
    draw_list->AddText( pixel_pos, col, text );
}

bool is_valid_vector3( Vector3 pos )
{
    if ( !std::isfinite( pos.x ) || !std::isfinite( pos.y ) || !std::isfinite( pos.z ) )
        return false;

    return true;
}

void features::visuals( )
{
    auto draw_list = ImGui::GetBackgroundDrawList( );

    if ( settings::silent_aim.draw_fov )
    {
        float width = settings::rect.right - settings::rect.left;
        float height = settings::rect.bottom - settings::rect.top;

        float center_x = width / 2.f;
        float center_y = height / 2.f;
        draw_list->AddCircle( { center_x, center_y }, settings::aimbot.fov, ImColor( 0, 0, 0, 255 ), 64, 3.f );
        draw_list->AddCircle( { center_x, center_y }, settings::aimbot.fov, ImColor( 255, 255, 255, 255 ), 64, 1.f );
    }

    if ( settings::aimbot.draw_fov )
    {
        float width = settings::rect.right - settings::rect.left;
        float height = settings::rect.bottom - settings::rect.top;

        float center_x = width / 2.f;
        float center_y = height / 2.f;
        draw_list->AddCircle( { center_x, center_y }, settings::aimbot.fov, ImColor( 0, 0, 0, 255 ), 64, 3.f );
        draw_list->AddCircle( { center_x, center_y }, settings::aimbot.fov, ImColor( 255, 255, 255, 255 ), 64, 1.f );
    }

    if ( !settings::visuals.enabled )
        return;

    if ( !globals::world.addr )
        return;

    if ( !globals::viewport )
        return;

    auto vm = framework::engine::globals::memory->simple_read< Matrix >( globals::viewport + 0x24C );
    // Measure from the local ped rather than an unverified camera RVA.
    Vector3 local_pos{};
    auto local_ped = globals::world.get_local_ped();
    if ( !local_ped.is_valid() || !globals::memory->read_memory( local_ped.addr + 0x90, local_pos ) || !is_valid_vector3( local_pos ) )
        return;
    int rejected_bot = 0, rejected_dead = 0, rejected_screen = 0, rejected_distance = 0, passed = 0;
    auto entities = player_cache::get_entities();

    for ( auto& entity : entities )
    {
        if ( !settings::visuals.draw_bots && !entity.net_id )
        { ++rejected_bot; continue; }

        if ( !settings::visuals.draw_dead && entity.cache.health <= 0 )
        { ++rejected_dead; continue; }

        auto head = entity.cache.head_2d;
        if ( !g_sdk->is_on_screen( head ) )
        { ++rejected_screen; continue; }

        auto distance = ( entity.cache.pos_3d - local_pos ).Length( );
        if ( !std::isfinite( distance ) || distance > settings::visuals.max_distance )
        { ++rejected_distance; continue; }
        ++passed;

        // 2d positions
        auto root = entity.cache.pos_2d;

        bool is_friend = settings::visuals.friend_indicator && friends.contains( entity.addr );

        // Use the projected feet when available instead of extrapolating from pelvis.
        auto left_foot = g_sdk->world_to_screen( entity.bone_indexes[ player_cache::bone_id::L_FOOT ].pos(), vm );
        auto right_foot = g_sdk->world_to_screen( entity.bone_indexes[ player_cache::bone_id::R_FOOT ].pos(), vm );
        float bottom = root.y;
        if ( g_sdk->is_on_screen( left_foot ) && g_sdk->is_on_screen( right_foot ) )
            bottom = (std::max)( left_foot.y, right_foot.y );
        else if ( g_sdk->is_on_screen( left_foot ) ) bottom = left_foot.y;
        else if ( g_sdk->is_on_screen( right_foot ) ) bottom = right_foot.y;
        else bottom = head.y + ( root.y - head.y ) * 2.0f;
        float height = bottom - head.y;
        if ( !std::isfinite( height ) || height < 4.0f ) continue;
        float width = height * 0.45f;
        float box_x = ( head.x + root.x ) * 0.5f;
        float top = head.y - height * 0.08f;
        bottom += height * 0.04f;

        if ( settings::visuals.glow )
        {
            draw_list->AddShadowRect(
                { box_x - width / 2.f, top },
                { box_x + width / 2.f, bottom },
                is_friend ? convert_float_4_to_col( settings::visuals.friend_indicator_color )
                          : convert_float_4_to_col( settings::visuals.glow_color ),
                50.f,
                { 0.f, 0.f } );
        }

        if ( settings::visuals.skeleton )
        {
            std::vector< std::pair< Vector2, Vector2 > > bone_pairs{};

            Vector2 r_thigh, l_thigh, l_forearm, r_forearm, l_clav, l_up, r_up, r_clav, l_calf, r_calf, l_hand, r_hand, neck;

            l_hand = g_sdk->world_to_screen( entity.bone_indexes[ player_cache::bone_id::L_HAND ].pos( ), vm );
            r_hand = g_sdk->world_to_screen( entity.bone_indexes[ player_cache::bone_id::R_HAND ].pos( ), vm );
            neck = g_sdk->world_to_screen( entity.bone_indexes[ player_cache::bone_id::NECK ].pos( ), vm );

            switch ( settings::visuals.skeleton_type )
            {
                case 0:
                    r_thigh = g_sdk->world_to_screen( entity.bone_indexes[ player_cache::bone_id::R_THIGH ].pos( ), vm );
                    l_thigh = g_sdk->world_to_screen( entity.bone_indexes[ player_cache::bone_id::L_THIGH ].pos( ), vm );

                    r_clav = g_sdk->world_to_screen( entity.bone_indexes[ player_cache::bone_id::R_CLAVICLE ].pos( ), vm );
                    r_up = g_sdk->world_to_screen( entity.bone_indexes[ player_cache::bone_id::R_UPPERARM ].pos( ), vm );

                    l_forearm = g_sdk->world_to_screen( entity.bone_indexes[ player_cache::bone_id::L_FOREARM ].pos( ), vm );
                    r_forearm = g_sdk->world_to_screen( entity.bone_indexes[ player_cache::bone_id::R_FOREARM ].pos( ), vm );

                    l_clav = g_sdk->world_to_screen( entity.bone_indexes[ player_cache::bone_id::L_CLAVICLE ].pos( ), vm );
                    l_up = g_sdk->world_to_screen( entity.bone_indexes[ player_cache::bone_id::L_UPPERARM ].pos( ), vm );

                    l_calf = g_sdk->world_to_screen( entity.bone_indexes[ player_cache::bone_id::L_CALF ].pos( ), vm );
                    r_calf = g_sdk->world_to_screen( entity.bone_indexes[ player_cache::bone_id::R_CALF ].pos( ), vm );

                    bone_pairs = { { head, neck },
                                   { neck, root },

                                   { neck, l_clav },

                                   { l_clav, l_up },
                                   { l_up, l_forearm },
                                   { l_forearm, l_hand },

                                   { neck, r_clav },

                                   { r_clav, r_up },
                                   { r_up, r_forearm },
                                   { r_forearm, r_hand },

                                   { root, l_thigh },
                                   { l_thigh, l_calf },
                                   { l_calf, g_sdk->world_to_screen( entity.bone_indexes[ player_cache::bone_id::L_FOOT ].pos( ), vm ) },

                                   { root, r_thigh },
                                   { r_thigh, r_calf },
                                   { r_calf, g_sdk->world_to_screen( entity.bone_indexes[ player_cache::bone_id::R_FOOT ].pos( ), vm ) } };
                    break;
                case 1:
                    bone_pairs = {
                        { head, neck },
                        { neck, root },

                        { neck, l_hand },
                        { neck, r_hand },

                        { root, g_sdk->world_to_screen( entity.bone_indexes[ player_cache::bone_id::L_FOOT ].pos( ), vm ) },
                        { root, g_sdk->world_to_screen( entity.bone_indexes[ player_cache::bone_id::R_FOOT ].pos( ), vm ) },
                    };
                    break;
            }

            float radius_delta = std::clamp( 100.0f / distance, 1.5f, 15.f );

            if ( settings::visuals.head_dot )
            {
                draw_list->AddCircle(
                    ImVec2( head.x, head.y ),
                    radius_delta,
                    is_friend ? convert_float_4_to_col( settings::visuals.friend_indicator_color )
                              : convert_float_4_to_col( settings::visuals.skeleton_color ),
                    64,
                    settings::visuals.skeleton_thickness );
            }

            for ( auto [ first, second ] : bone_pairs )
            {
                if ( settings::visuals.cool_skeleton )
                {
                    bool should_draw_first = first != neck;
                    bool should_draw_second = second != neck;

                    draw_list->AddLine(
                        { first.x, first.y + ( should_draw_first ? radius_delta : 0 ) },
                        { second.x, second.y - ( should_draw_second ? radius_delta : 0 ) },
                        is_friend ? convert_float_4_to_col( settings::visuals.friend_indicator_color )
                                  : convert_float_4_to_col( settings::visuals.skeleton_color ),
                        settings::visuals.skeleton_thickness );

                    if ( should_draw_first )
                    {
                        draw_list->AddCircleFilled(
                            { first.x, first.y },
                            radius_delta,
                            is_friend ? convert_float_4_to_col( settings::visuals.friend_indicator_color )
                                      : convert_float_4_to_col( settings::visuals.skeleton_color ),
                            64 );
                    }

                    if ( should_draw_second )
                    {
                        draw_list->AddCircleFilled(
                            { second.x, second.y },
                            radius_delta,
                            is_friend ? convert_float_4_to_col( settings::visuals.friend_indicator_color )
                                      : convert_float_4_to_col( settings::visuals.skeleton_color ),
                            64 );
                    }
                }
                else
                {
                    bool should_draw_first = first == head;
                    bool should_draw_second = second == head;

                    draw_list->AddLine(
                        { first.x, first.y + ( should_draw_first ? radius_delta : 0 ) },
                        { second.x, second.y - ( should_draw_second ? radius_delta : 0 ) },
                        is_friend ? convert_float_4_to_col( settings::visuals.friend_indicator_color )
                                  : convert_float_4_to_col( settings::visuals.skeleton_color ),
                        settings::visuals.skeleton_thickness );
                }
            }
        }

        if ( settings::visuals.box )
        {
            draw_list->AddRect(
                { box_x - width / 2.f, top },
                { box_x + width / 2.f, bottom },
                IM_COL32( 0, 0, 0, 255 ),
                settings::visuals.box_rounding,
                0,
                3.f );
            draw_list->AddRect(
                { box_x - width / 2.f, top },
                { box_x + width / 2.f, bottom },
                is_friend ? convert_float_4_to_col( settings::visuals.friend_indicator_color )
                          : convert_float_4_to_col( settings::visuals.box_color ),
                settings::visuals.box_rounding,
                0,
                1.f );
        }

        if ( settings::visuals.status )
        {
            auto status = entity.cache.status;
            auto text = "";
            if ( status == sdk::ped::ped_status::godmode )
                text = "GODMODE";
            else if ( status == sdk::ped::ped_status::suspicious )
                text = "SUSPICIOUS";
            else
                text = "NORMAL";

            draw_outlined_text(
                draw_list,
                { box_x + width / 2.f + 5.f, top },
                is_friend ? convert_float_4_to_col( settings::visuals.friend_indicator_color )
                          : convert_float_4_to_col( settings::visuals.status_color ),
                text );
        }

        if ( settings::visuals.healthbar )
        {
            float health = entity.cache.health;
            float health_delta = std::clamp( health / 200.0f, 0.f, 1.f );

            float bar_left = box_x - width / 2.f - 3.f;
            float bar_right = box_x - width / 2.f - 5.f;

            draw_list->AddRectFilled(
                ImVec2( bar_left, top - 1.0f ),
                ImVec2( bar_right, bottom + 1.0f ),
                IM_COL32( 0, 0, 0, 200 ) );

            draw_list->AddRectFilled(
                ImVec2( bar_left, top + height * ( 1.0f - health_delta ) ),
                ImVec2( bar_right, bottom ),
                is_friend ? convert_float_4_to_col( settings::visuals.friend_indicator_color )
                          : convert_float_4_to_col( settings::visuals.health_bar_color ) );
            draw_list->AddRect(
                ImVec2( bar_left, top - 1.0f ),
                ImVec2( bar_right, bottom + 1.0f ),
                IM_COL32( 0, 0, 0, 255 ),
                0,
                0,
                1.0f );
        }

        if ( settings::visuals.distance )
        {
            int distance_int = ( int )( std::round( distance ) );
            std::string text = std::to_string( distance_int ) + "m";
            draw_outlined_text(
                draw_list,
                { box_x - width / 2.f + ( width - ImGui::CalcTextSize( text.c_str( ) ).x ) / 2.f, bottom + 1.5f },
                is_friend ? convert_float_4_to_col( settings::visuals.friend_indicator_color )
                          : convert_float_4_to_col( settings::visuals.distance_color ),
                text.c_str( ) );
        }

        if ( settings::visuals.name )
        {
            std::string label = entity.name;
            if ( label.empty() ) label = entity.net_id > 0 ? "Player" : "Ped";
            if ( entity.net_id > 0 ) label += " [" + std::to_string( entity.net_id ) + "]";
            if ( framework::gui::fonts::name_font ) ImGui::PushFont( framework::gui::fonts::name_font );
            auto text_size = ImGui::CalcTextSize( label.c_str() );
            draw_outlined_text(
                draw_list, { box_x - text_size.x * 0.5f, top - text_size.y - 2.0f },
                is_friend ? convert_float_4_to_col( settings::visuals.friend_indicator_color )
                          : convert_float_4_to_col( settings::visuals.name_color ), label.c_str() );
            if ( framework::gui::fonts::name_font ) ImGui::PopFont();
        }
    }
    static auto next_report = std::chrono::steady_clock::now();
    if ( std::chrono::steady_clock::now() >= next_report ) {
        std::printf( "[render] cached=%zu bots=%d dead=%d offscreen=%d distance=%d passed=%d box=%d skeleton=%d name=%d max_distance=%d local=(%.1f,%.1f,%.1f)\n",
            entities.size(), rejected_bot, rejected_dead, rejected_screen, rejected_distance, passed,
            static_cast<int>(settings::visuals.box), static_cast<int>(settings::visuals.skeleton), static_cast<int>(settings::visuals.name),
            settings::visuals.max_distance, local_pos.x, local_pos.y, local_pos.z );
        next_report = std::chrono::steady_clock::now() + std::chrono::seconds( 5 );
    }
}
