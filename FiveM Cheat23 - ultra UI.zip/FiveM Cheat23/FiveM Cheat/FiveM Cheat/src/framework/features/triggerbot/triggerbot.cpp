#include "../features.hpp"
#include "../../engine/engine.hpp"
#include "../../engine/globals.hpp"
#include "../../threads.hpp"
#include "../../menu/gui/framework/framework.hpp"

void features::triggerbot()
{
	while (threads::should_run)
	{
		if (!settings::triggerbot.enabled)
		{
			std::this_thread::sleep_for(std::chrono::milliseconds(1500));
			std::this_thread::yield();
			continue;
		}

		settings::triggerbot.state = framework::gui::update_keybind(&settings::triggerbot.key, &settings::triggerbot.mode, settings::triggerbot.id);
		if (!settings::triggerbot.state)
		{
			std::this_thread::sleep_for(std::chrono::milliseconds(2));
			std::this_thread::yield();
			continue;
		}

		if (!framework::engine::offsets::triggerbot)
		{
			std::this_thread::sleep_for(std::chrono::milliseconds(1500));
			std::this_thread::yield();
			continue;
		}

		auto is_enemy_under_crosshair = framework::engine::sdk::ped(framework::engine::globals::memory->simple_read<uintptr_t>(framework::engine::offsets::triggerbot));
		static bool shot = false;

		if (is_enemy_under_crosshair.is_valid())
		{
			shot = true;
			mouse_event(MOUSEEVENTF_LEFTDOWN, 0, 0, 0, 0);

			if (!settings::triggerbot.automatic_mode)
			{
				mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
			}
		}
		else if (!is_enemy_under_crosshair.is_valid() && shot)
		{
			if (!settings::triggerbot.automatic_mode)
			{
				shot = false;
				mouse_event(MOUSEEVENTF_LEFTUP, 0, 0, 0, 0);
			}
		}

		std::this_thread::sleep_for(std::chrono::milliseconds(1 + settings::triggerbot.delay));
		std::this_thread::yield();
	}
}
