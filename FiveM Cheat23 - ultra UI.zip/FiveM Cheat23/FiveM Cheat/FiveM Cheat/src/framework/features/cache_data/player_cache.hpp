#pragma once

#include <array>
#include <cstdio>
#include <chrono>
#include <mutex>
#include <shared_mutex>
#include <vector>

#include "../../engine/engine.hpp"
#include "../../engine/globals.hpp"
#include "../../threads.hpp"

using namespace framework::engine;

namespace player_cache
{
    enum bone_id : uint8_t
    {
        HEAD,
        NECK,
        SPINE,
        PELVIS,

        L_CLAVICLE,
        L_UPPERARM,
        L_FOREARM,
        L_HAND,

        R_CLAVICLE,
        R_UPPERARM,
        R_FOREARM,
        R_HAND,

        L_THIGH,
        L_CALF,
        L_FOOT,

        R_THIGH,
        R_CALF,
        R_FOOT,
    };

    struct snapshot
    {
        float health;
        float max_health;
        float armor;
        Vector3 pos_3d;
        Vector2 pos_2d;
        Vector2 head_2d;
        bool is_visible;
        bool is_rendered;
        sdk::ped::ped_status status;
    };

    struct entity : public sdk::ped
    {
        int net_id;
        std::string name;
        snapshot cache;
        std::array< sdk::bone, 18 > bone_indexes;
    };

    inline std::vector< entity > entities;
    inline std::shared_mutex mtx;

    inline std::unordered_map< uintptr_t, std::array< sdk::bone, 18 > > bone_cache;

    inline std::vector< entity > get_entities()
    {
        std::vector< entity > entity_list;
        {
            std::shared_lock lock( mtx );
            entity_list = entities;
        }
        return entity_list;
    }

    inline void run( )
    {
        auto next_report = std::chrono::steady_clock::now();
        auto report_failure = [&]( const char* stage ) {
            if ( std::chrono::steady_clock::now() >= next_report ) {
                std::printf( "[esp] waiting: %s\n", stage );
                next_report = std::chrono::steady_clock::now() + std::chrono::seconds( 5 );
            }
            std::this_thread::sleep_for( std::chrono::milliseconds( 100 ) );
        };
        while ( threads::should_run )
        {
            std::vector< entity > vec;
            int valid_peds = 0, valid_skeletons = 0, on_screen = 0;
            uintptr_t sample_ped = 0, sample_frag = 0, sample_skeleton = 0, sample_skel_data = 0;

            if ( !globals::memory || !offsets::world || !globals::viewport )
            {
                report_failure( "memory, world signature or viewport" );
                continue;
            }

            auto world = g_sdk->get_world( );
            if ( !world.is_valid( ) )
            {
                report_failure( "world pointer invalid" );
                continue;
            }

            if ( !offsets::replay_interface )
            {
                report_failure( "replay signature missing" );
                continue;
            }

            auto replay = g_sdk->get_replay( );
            if ( !replay.is_valid( ) )
            {
                report_failure( "replay pointer invalid" );
                continue;
            }

            auto ped_interface = replay.get_ped_interface( );
            if ( !ped_interface.is_valid( ) )
            {
                report_failure( "ped interface pointer invalid" );
                continue;
            }

            auto ped_list = ped_interface.get_ped_list( );
            if ( !ped_list )
            {
                report_failure( "ped list pointer null" );
                continue;
            }

            auto local_ped = world.get_local_ped( );
            auto vm = globals::memory->simple_read< Matrix >( globals::viewport + 0x24C );

            for ( int i = 0; i < 256; i++ )
            {
                auto ped = g_sdk->get_ped_from_index( ped_list, i );
                if ( !ped.is_valid( ) || ped.addr == local_ped.addr )
                    continue;

                ++valid_peds;
                if ( !sample_ped ) {
                    sample_ped = ped.addr;
                    globals::memory->read_memory( sample_ped + offsets::frag_inst, sample_frag );
                    if ( utilities::is_valid_address( sample_frag ) )
                        globals::memory->read_memory( sample_frag + 0x68, sample_skeleton );
                    if ( utilities::is_valid_address( sample_skeleton ) )
                        globals::memory->read_memory( sample_skeleton + 0x178, sample_skel_data );
                }
                entity data;
                data.addr = ped.addr;

                struct ped_data_t
                {
                    std::uint8_t pad_0[ 0x90 ];
                    Vector3 pos;
                    std::uint8_t pad_1[ 0x280 - ( 0x90 + sizeof( Vector3 ) ) ];
                    float health;
                    float max_health;
                    std::uint8_t pad_2[ 0x14E0 - ( 0x284 + 4 ) ];
                    float armor;
                };

                auto ped_data = globals::memory->simple_read< ped_data_t >( ped.addr );
                
                data.cache.health = ped_data.health;
                data.cache.max_health = ped_data.max_health;
                data.cache.armor = ped_data.armor;
                data.cache.pos_3d = ped_data.pos;

                uint8_t rendered_flags = globals::memory->simple_read< uint8_t >( ped.addr + 176 );
                data.cache.is_rendered = ( rendered_flags & ( 1 << 4 ) ) != 0;

                if ( globals::memory->simple_read< bool >( ped.addr + 0x189 ))
                {
                    data.cache.status = sdk::ped::ped_status::godmode;
                }
                else if ( data.cache.max_health > 200.f || ( rendered_flags & ( 1 << 4 ) ) != 0 )
                {
                    data.cache.status = sdk::ped::ped_status::suspicious;
                }
                else
                {
                    data.cache.status = sdk::ped::ped_status::normal;
                }

                auto skeleton = ped.skeleton_data( );
                if ( !skeleton.skel_data )
                    continue;

                ++valid_skeletons;
                auto it = bone_cache.find( skeleton.skel_data );

                if ( it != bone_cache.end( ) )
                {
                    data.bone_indexes = it->second;
                }
                else
                {
                    std::array< sdk::bone, 18 > bones;

                    bones[ HEAD ] = skeleton.get_bone( SKEL_Head );
                    bones[ NECK ] = skeleton.get_bone( SKEL_Neck_1 );
                    bones[ SPINE ] = skeleton.get_bone( SKEL_Spine1 );
                    bones[ PELVIS ] = skeleton.get_bone( SKEL_ROOT );

                    bones[ L_CLAVICLE ] = skeleton.get_bone( SKEL_L_Clavicle );
                    bones[ L_UPPERARM ] = skeleton.get_bone( SKEL_L_UpperArm );
                    bones[ L_FOREARM ] = skeleton.get_bone( SKEL_L_Forearm );
                    bones[ L_HAND ] = skeleton.get_bone( SKEL_L_Hand );

                    bones[ R_CLAVICLE ] = skeleton.get_bone( SKEL_R_Clavicle );
                    bones[ R_UPPERARM ] = skeleton.get_bone( SKEL_R_UpperArm );
                    bones[ R_FOREARM ] = skeleton.get_bone( SKEL_R_Forearm );
                    bones[ R_HAND ] = skeleton.get_bone( SKEL_R_Hand );

                    bones[ L_THIGH ] = skeleton.get_bone( SKEL_L_Thigh );
                    bones[ L_CALF ] = skeleton.get_bone( SKEL_L_Calf );
                    bones[ L_FOOT ] = skeleton.get_bone( SKEL_L_Foot );

                    bones[ R_THIGH ] = skeleton.get_bone( SKEL_R_Thigh );
                    bones[ R_CALF ] = skeleton.get_bone( SKEL_R_Calf );
                    bones[ R_FOOT ] = skeleton.get_bone( SKEL_R_Foot );

                    bone_cache[ skeleton.skel_data ] = bones;
                    data.bone_indexes = bones;
                }

                data.cache.pos_2d = g_sdk->world_to_screen( data.bone_indexes[ PELVIS ].pos( ), vm );
                data.cache.head_2d = g_sdk->world_to_screen( data.bone_indexes[ HEAD ].pos( ), vm );

                if ( g_sdk->is_on_screen( data.cache.head_2d ) ) ++on_screen;
                data.net_id = offsets::player_info ? ped.player_info( ).net_id( ) : 0;
                data.name = offsets::player_info && data.net_id ? ped.get_name( data.net_id ) : std::string{};

                vec.emplace_back( data );
            }

            if ( std::chrono::steady_clock::now() >= next_report ) {
                std::printf( "[esp] replay=0x%llx ped_interface=0x%llx ped_list=0x%llx valid_peds=%d skeletons=%d on_screen=%d cached=%zu\n",
                    static_cast<unsigned long long>( replay.addr ), static_cast<unsigned long long>( ped_interface.addr ),
                    static_cast<unsigned long long>( ped_list ), valid_peds, valid_skeletons, on_screen, vec.size() );
                std::printf( "[esp] sample ped=0x%llx frag=0x%llx skeleton=0x%llx skel_data=0x%llx\n",
                    static_cast<unsigned long long>( sample_ped ), static_cast<unsigned long long>( sample_frag ),
                    static_cast<unsigned long long>( sample_skeleton ), static_cast<unsigned long long>( sample_skel_data ) );
                next_report = std::chrono::steady_clock::now() + std::chrono::seconds( 5 );
            }
            {
                std::unique_lock lock( mtx );
                entities.swap( vec );
            }

            std::this_thread::sleep_for( std::chrono::milliseconds( 5 ) );
            std::this_thread::yield( );
        }
    }
}  // namespace player_cache