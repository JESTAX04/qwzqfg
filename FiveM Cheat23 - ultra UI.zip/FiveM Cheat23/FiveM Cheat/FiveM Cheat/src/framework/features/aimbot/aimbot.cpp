#include "../utils.hpp"
#include <algorithm>
#include <chrono>

float circular(float t) {
	if (t < 0.5f) {
		return 0.5f * (1.0f - std::sqrt(1.0f - 4.0f * t * t));
	}
	else {
		t = t * 2.0f - 2.0f;
		return 0.5f * (std::sqrt(1.0f - t * t) + 1.0f);
	}
}

Vector3 circular_vec3(Vector3 t) {
	Vector3 result{};
	if (t.x < 0.5f) {
		result.x = 0.5f * (1.0f - std::sqrt(1.0f - 4.0f * t.x * t.x));
	}
	else {
		t.x = t.x * 2.0f - 2.0f;
		result.x = 0.5f * (std::sqrt(1.0f - t.x * t.x) + 1.0f);
	}

	if (t.y < 0.5f) {
		result.y = 0.5f * (1.0f - std::sqrt(1.0f - 4.0f * t.y * t.y));
	}
	else {
		t.y = t.y * 2.0f - 2.0f;
		result.y = 0.5f * (std::sqrt(1.0f - t.y * t.y) + 1.0f);
	}

	if (t.z < 0.5f) {
		result.z = 0.5f * (1.0f - std::sqrt(1.0f - 4.0f * t.z * t.z));
	}
	else {
		t.z = t.z * 2.0f - 2.0f;
		result.z = 0.5f * (std::sqrt(1.0f - t.z * t.z) + 1.0f);
	}
}

inline float get_delta_time()
{
	static auto last = std::chrono::high_resolution_clock::now();

	auto now = std::chrono::high_resolution_clock::now();
	std::chrono::duration<float> delta = now - last;

	last = now;
	return delta.count(); 
}

Vector3 prev_pos{};
Vector3 prev_vel{};

inline Vector3 calculate_velocity(Vector3 v0, Vector3 v1, float t)
{
	return (v0 - v1) / t;
}

inline Vector3 get_velocity(Vector3 current_pos)
{
	if (prev_pos == Vector3(0.f, 0.f, 0.f))
	{
		prev_pos = current_pos;
		return { 0.f, 0.f, 0.f };
	}

	auto time = get_delta_time();
	auto vel = calculate_velocity(current_pos, prev_pos, time);

	prev_vel = Vector3::Lerp(prev_vel, vel, settings::aimbot.overshoot_smoothness);
	prev_pos = current_pos;
	return prev_vel;
}

void features::aimbot()
{
	while (threads::should_run)
	{
		if (!settings::aimbot.enabled)
		{
			std::this_thread::sleep_for(std::chrono::milliseconds(5000));
			std::this_thread::yield();
			continue;
		}

		settings::aimbot.state = framework::gui::update_keybind(&settings::aimbot.key, &settings::aimbot.mode, settings::aimbot.id);
		if (!settings::aimbot.state)
		{
			std::this_thread::sleep_for(std::chrono::milliseconds(2));
			std::this_thread::yield();
			continue;
		}

		auto [pos, target] = utils::get_closest_ped(settings::aimbot);
		if (!target.addr)
		{
			std::this_thread::sleep_for(std::chrono::milliseconds(2));
			std::this_thread::yield();
			continue;
		}
				
		auto camera = globals::memory->simple_read<uintptr_t>(offsets::camera);
		if (!camera)
		{
			std::this_thread::sleep_for(std::chrono::milliseconds(2));
			std::this_thread::yield();
			continue;
		}

		Vector3 camera_pos = g_sdk->get_camera_pos();
		Vector3 view_angles = globals::memory->simple_read<Vector3>(camera + 0x3D0);

		if (settings::aimbot.overshoot)
		{
			pos += get_velocity(pos) * settings::aimbot.overshoot_strength;
		}

		Vector3 direction = pos - camera_pos;
		float dist = direction.Length();
		if (dist != 0)
		{
			direction = direction / dist;
		}

		float t = settings::aimbot.smoothness;

		Vector3 param{};

		if (settings::aimbot.Humanization)
		{
			auto scale = std::clamp(dist / 5.f, 0.1f, 1.f);

			view_angles += (direction - view_angles) * (t * scale);
		}
		else
		{
			view_angles = Vector3::Lerp(view_angles, direction, t);
		}

		globals::memory->write_memory<Vector3>(camera + 0x3D0, view_angles);

		if (settings::aimbot.Humanization)
		{
			int min = 2;
			int max = 10;

			int r = min + (rand() % (max - min + 1));

			std::this_thread::sleep_for(std::chrono::milliseconds(r));
		}
		else
		{
			std::this_thread::sleep_for(std::chrono::milliseconds(2));
		}

		std::this_thread::yield();
	}
}