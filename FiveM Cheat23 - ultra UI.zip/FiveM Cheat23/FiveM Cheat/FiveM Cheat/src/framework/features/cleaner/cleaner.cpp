#include "../features.hpp"
#include "../../engine/engine.hpp"
#include "../../engine/globals.hpp"
#include "../../memory/scanner.hpp"
#include "../../logging/logging.hpp"

std::vector<std::string> processes_to_clean = {
	"explorer.exe",
};

std::string get_current_exe_name()
{
	char buffer[MAX_PATH];
	GetModuleFileNameA(nullptr, buffer, MAX_PATH);

	std::string path(buffer);
	size_t pos = path.find_last_of("\\/");

	return (pos != std::string::npos) ? path.substr(pos + 1) : path;
}

void features::cleaner()
{
	auto name = get_current_exe_name();

	for (auto process : processes_to_clean)
	{
		auto pid = utilities::get_pid_by_name(process);
		if (!pid)
			continue;

		auto mem = std::make_unique<utilities::memory>(pid);

		auto parsed_regions = utilities::parse_process_bytes(mem);
		for (auto& data : parsed_regions)
		{
			utilities::scan_and_clean_strings(mem, data.reg, data.buffer, name);
		}
	}
}
