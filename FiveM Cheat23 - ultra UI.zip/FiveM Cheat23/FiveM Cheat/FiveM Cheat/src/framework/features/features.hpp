#pragma once

namespace features {
	void silent_aim();
	void triggerbot();
	void heal();
	void fix_vehicle();
	void exploits();
	void visuals();
	void cleaner();
	void aimbot();
	void friend_key();
}