#include "../utils.hpp"

void features::friend_key()
{
	if (!settings::friend_key.enabled)
		return;

	settings::friend_key.state = GetAsyncKeyState(settings::friend_key.key) & 1;
	if (!settings::friend_key.state)
		return;

	auto [pos, ped] = utils::get_closest_ped(settings::friend_key);
	if (!ped.is_valid())
	{
		framework::gui::add_notification("Could not fetch closest player!");
		return;
	}

	if (friends.contains(ped.addr))
	{
		friends.erase(ped.addr);
		framework::gui::add_notification("Removed " + ped.name + " as friend!");
	}
	else
	{
		friends.insert(ped.addr);
		framework::gui::add_notification("Added " + ped.name + " as friend!");
	}
}