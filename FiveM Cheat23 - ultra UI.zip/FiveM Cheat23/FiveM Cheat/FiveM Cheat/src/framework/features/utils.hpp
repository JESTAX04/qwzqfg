#pragma once

#include "features.hpp"
#include "../engine/engine.hpp"
#include "../engine/globals.hpp"
#include "../threads.hpp"
#include "../menu/gui/framework/framework.hpp"
#include "../menu/settings.hpp"
#include "cache_data/player_cache.hpp"

using namespace framework::engine;

namespace utils
{
	inline std::pair<Vector2, Vector3> get_closest_bone(player_cache::entity entity, const Matrix& vm, const float& center_x, const float& center_y, const Vector3& cam_pos, const float& max_distance)
	{
		std::pair<Vector2, Vector3> result;
		float min_distance = FLT_MAX;

		for (int i = 0; i < 18; i++)
		{
			auto pos = entity.bone_indexes[i].pos();
			auto dist = (pos - cam_pos).Length();
			if (dist > max_distance)
				continue;

			auto screen_pos = g_sdk->world_to_screen(pos, vm);
			if (!g_sdk->is_on_screen(screen_pos))
				continue;

			auto distance = (Vector2(center_x, center_y) - screen_pos).Length();

			if (distance < min_distance)
			{
				result = { screen_pos, pos };
				min_distance = distance;
			}
		}

		return result;
	}

	template<typename any_type>
	inline std::pair<Vector3, player_cache::entity> get_closest_ped(any_type config)
	{
		std::pair<Vector3, player_cache::entity> result;
		float min_distance = FLT_MAX;

		if (!globals::viewport)
			return result;

		auto vm = globals::memory->simple_read<Matrix>(globals::viewport + 0x24C);

		float width = settings::rect.right - settings::rect.left;
		float height = settings::rect.bottom - settings::rect.top;

		float center_x = width / 2.f;
		float center_y = height / 2.f;

		auto cam_pos = g_sdk->get_camera_pos();

		for (auto& entity : player_cache::get_entities())
		{
			if (!config.target_bots && !entity.net_id)
				continue;

			if (!config.target_dead && entity.get_health() <= 0)
				continue;

			if (config.friend_check && friends.contains(entity.addr))
				continue;

			if (config.visible_check && !entity.is_occluded())
				continue;

			Vector3 pos;
			Vector2 screen_pos;

			if (config.closest_bone)
			{
				auto closest_bone_result = get_closest_bone(entity, vm, center_x, center_y, cam_pos, config.max_distance);
				pos = closest_bone_result.second;
				screen_pos = closest_bone_result.first;
			}
			else
			{
				switch (config.selected_bone)
				{
				case 0:
					pos = entity.bone_indexes[player_cache::bone_id::HEAD].pos();
					break;
				case 1:
					pos = entity.bone_indexes[player_cache::bone_id::NECK].pos();
					break;
				case 2:
					pos = entity.bone_indexes[player_cache::bone_id::SPINE].pos();
					break;
				case 3:
					pos = entity.bone_indexes[player_cache::bone_id::PELVIS].pos();
					break;
				}

				auto dist = (pos - cam_pos).Length();
				if (dist > config.max_distance)
					continue;

				screen_pos = g_sdk->world_to_screen(pos, vm);
				if (!g_sdk->is_on_screen(screen_pos))
					continue;
			}

			auto distance = (Vector2(center_x, center_y) - screen_pos).Length();
			if (distance < config.fov && distance < min_distance)
			{
				result = { pos, entity };
				min_distance = distance;
			}
		}

		return result;
	}
}