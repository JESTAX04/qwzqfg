#include "../utils.hpp"

void features::silent_aim()
{
	while (threads::should_run)
	{
		if (!settings::silent_aim.enabled)
		{
			std::this_thread::sleep_for(std::chrono::milliseconds(5000));
			std::this_thread::yield();
			continue;
		}

		static bool hook_applied = false;

		auto [pos, target] = utils::get_closest_ped(settings::silent_aim);
		if (target.addr)
		{
			uintptr_t code_cave = globals::memory->info.mod_info.base_address + 0x34E;

			if (!hook_applied)
			{
				std::vector<uint8_t> patch = {
					0xE9,
					0x00, 0x00,
					0x00, 0x00
				};

				uint32_t offset = code_cave - (offsets::handle_bullet + 5);
				memcpy(patch.data() + 1, &offset, sizeof(offset));

				SIZE_T bytes_read = 0;
				globals::memory->write_bytes(offsets::handle_bullet, patch.data(), patch.size(), bytes_read);
				hook_applied = true;
			}

			union
			{
				float f;
				uint32_t i;
			}  pos_x, pos_y, pos_z;

			pos_x.f = pos.x; 
			pos_y.f = pos.y;
			pos_z.f = pos.z;

			uint32_t jmp_to = offsets::handle_bullet - (code_cave + 28);

			std::vector<uint8_t> shellcode = {
				0x41, 0xC7, 0x01,
				(uint8_t)(pos_x.i),
				(uint8_t)(pos_x.i >> 8),
				(uint8_t)(pos_x.i >> 16),
				(uint8_t)(pos_x.i >> 24),
				0x41, 0xC7, 0x41, 0x04,
				(uint8_t)(pos_y.i),
				(uint8_t)(pos_y.i >> 8),
				(uint8_t)(pos_y.i >> 16),
				(uint8_t)(pos_y.i >> 24),
				0x41, 0xC7, 0x41, 0x08,
				(uint8_t)(pos_z.i),
				(uint8_t)(pos_z.i >> 8),
				(uint8_t)(pos_z.i >> 16),
				(uint8_t)(pos_z.i >> 24),
				0xF3, 0x41, 0x0F, 0x10, 0x19,
				0xE9, 0x00, 0x00, 0x00, 0x00
			};

			memcpy(shellcode.data() + 29, &jmp_to, 4);

			SIZE_T bytes_read = 0;
			globals::memory->write_bytes(code_cave, shellcode.data(), shellcode.size(), bytes_read);
		}
		else 
		{
			if (hook_applied)
			{
				std::vector<uint8_t> old_bytes = {
					0xF3, 0x41, 0x0F, 0x10, 0x19,
					0xF3, 0x41, 0x0F, 0x10, 0x41, 0x04,
					0xF3, 0x41, 0x0F, 0x10, 0x51, 0x08
				};

				SIZE_T bytes_read = 0;
				globals::memory->write_bytes(offsets::handle_bullet, old_bytes.data(), old_bytes.size(), bytes_read);

				std::vector<uint8_t> nops =
				{
					0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
					0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
					0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
					0x00, 0x00, 0x00, 0x00, 0x00,
					0x00, 0x00, 0x00, 0x00, 0x00
				};

				SIZE_T bytes_read_2 = 0;
				uintptr_t code_cave = globals::memory->info.mod_info.base_address + 0x34E;
				globals::memory->write_bytes(code_cave, nops.data(), nops.size(), bytes_read_2);

				hook_applied = false;
			}
		}

		std::this_thread::sleep_for(std::chrono::milliseconds(5));
	}
}