#pragma once

#include "helpers.hpp"

extern "C"
{
	long nt_read_virtual_mem(HANDLE, PVOID, PVOID, SIZE_T, PSIZE_T);
	long nt_write_virtual_mem(HANDLE, PVOID, PVOID, SIZE_T, PSIZE_T);
	long nt_alloc_virtual_mem(HANDLE, PVOID, PSIZE_T, ULONG, ULONG);
}

namespace utilities {
	class memory {
	public:
		bool success;
		process_info info;

		memory(DWORD process_id)
		{
			success = false;

			info.process_name = get_process_name(process_id);
			if (info.process_name == "")
				return;

			info.mod_info = get_module_info(process_id, info.process_name);
			if (!info.mod_info.base_address || !info.mod_info.size)
				return;

			info.handle = OpenProcess(PROCESS_ALL_ACCESS, FALSE, process_id);
			if (!info.handle)
				return;

			info.pid = process_id;
			success = true;
		}

		~memory()
		{
			if (info.handle)
			{
				CloseHandle(info.handle);
			}
		}

		bool validate_nt_syscall(NTSTATUS status, size_t bytes_to_do, SIZE_T bytes_done)
		{
			if (NT_ERROR(status) || bytes_done != bytes_to_do)
			{
				return false;
			}

			return true;
		}
		template<typename any_type>
		any_type simple_read(uintptr_t address)
		{
			any_type buffer{};
			SIZE_T bytes_read = 0;
			size_t bytes_to_read = sizeof(buffer);
			nt_read_virtual_mem(info.handle, (PVOID)address, &buffer, bytes_to_read, &bytes_read);
			return buffer;
		}

		template<typename any_type>
		bool read_memory(uintptr_t address, any_type& buffer)
		{
			SIZE_T bytes_read = 0;
			size_t bytes_to_read = sizeof(buffer);
			NTSTATUS status = nt_read_virtual_mem(info.handle, (PVOID)address, &buffer, bytes_to_read, &bytes_read);
			return validate_nt_syscall(status, bytes_to_read, bytes_read);
		}

		template<typename any_type>
		bool write_memory(uintptr_t address, any_type& buffer)
		{
			SIZE_T bytes_written = 0;
			size_t bytes_to_write = sizeof(buffer);
			NTSTATUS status = nt_write_virtual_mem(info.handle, (PVOID)address, &buffer, bytes_to_write, &bytes_written);
			return validate_nt_syscall(status, bytes_to_write, bytes_written);
		}

		uint32_t calculate_relative_offset(uintptr_t current_address, uintptr_t target_address, int offset = 5)
		{
			return (uint32_t)(target_address - (current_address + offset));
		};

		bool read_bytes(uintptr_t address, void* buffer, size_t bytes_to_read, SIZE_T& bytes_read)
		{
			NTSTATUS status = nt_read_virtual_mem(info.handle, (PVOID)address, buffer, bytes_to_read, &bytes_read);
			return validate_nt_syscall(status, bytes_to_read, bytes_read);
		}

		bool write_bytes(uintptr_t address, void* buffer, size_t bytes_to_write, SIZE_T bytes_written)
		{
			NTSTATUS status = nt_write_virtual_mem(info.handle, (PVOID)address, buffer, bytes_to_write, &bytes_written);
			return validate_nt_syscall(status, bytes_to_write, bytes_written);
		}
	};
}

