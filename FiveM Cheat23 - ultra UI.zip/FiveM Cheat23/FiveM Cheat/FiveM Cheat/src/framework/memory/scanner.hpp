#pragma once 

#include "memory.hpp"
#include <memory>
#include <vector>
#include "zydis.hpp"
#include <algorithm>

#include "../logging/logging.hpp"

namespace utilities 
{
	struct signature {
		uint8_t bytes;
		bool wildcard;

		static std::vector<signature> parse(const std::string& raw_sig)
		{
			std::vector<signature> result{};

			std::istringstream parser(raw_sig);
			std::string part;

			while (parser >> part)
			{
				if (part == "?" || part == "??") {
					result.emplace_back(0, true);
				}
				else {
					result.emplace_back((uint8_t)(std::stoi(part, nullptr, 16)), false);
				}
			}

			return result;
		}
	};

	struct region {
		uintptr_t start;
		uintptr_t current;
		uintptr_t size;
		size_t bytes_read;
	};

	inline uintptr_t string_scan(std::unique_ptr<memory>& memory, const std::string& string, module_info mod_info = {})
	{
		uintptr_t start = (uintptr_t)sys_info.lpMinimumApplicationAddress;
		uintptr_t end = (uintptr_t)sys_info.lpMaximumApplicationAddress;

		if (mod_info.base_address && mod_info.size)
		{
			start = mod_info.base_address;
			end = start + mod_info.size;
		}

		MEMORY_BASIC_INFORMATION mbi{};
		uintptr_t current_address = start;
		size_t len = string.size();
		while (current_address < end)
		{
			VirtualQueryEx(memory->info.handle, (LPCVOID)current_address, &mbi, sizeof(mbi));

			if (is_valid_memory_region(mbi))
			{
				uintptr_t region_start = (uintptr_t)mbi.BaseAddress;
				uintptr_t region_size = mbi.RegionSize;

				SIZE_T bytes_read = 0;
				std::vector<char> buffer(region_size);

				if (!memory->read_bytes(region_start, buffer.data(), region_size, bytes_read))
				{
					current_address += region_size;
					continue;
				}

				if (bytes_read < len)
				{
					current_address += region_size;
					continue;
				}

				for (size_t pos = 0; pos <= bytes_read - len; pos++)
				{
					bool found = true;

					for (size_t i = 0; i < len; i++)
					{
						if (buffer[pos + i] != string[i])
						{
							found = false;
							break;
						}
					}

					if (found)
						return region_start + pos;
				}
			}

			current_address += mbi.RegionSize;
		}

		return 0;
	}

	inline uintptr_t calculate_rip_relative(const std::unique_ptr<memory>& memory, uintptr_t instruction_address)
	{
		uint8_t bytes[15];
		SIZE_T bytes_read = 0;

		if (!memory->read_bytes(instruction_address, bytes, sizeof(bytes), bytes_read))
			return 0;

		auto [operands, instruction] = decoder->decode(instruction_address, bytes);

		for (int i = 0; i < instruction.operand_count; i++)
		{
			if (operands[i].type == ZYDIS_OPERAND_TYPE_MEMORY)
			{

				if (operands[i].mem.base == ZYDIS_REGISTER_RIP)
				{
					return instruction_address + instruction.length + operands[i].mem.disp.value;
				}

				return operands[i].mem.disp.value;
			}
			else if (operands[i].type == ZYDIS_OPERAND_TYPE_IMMEDIATE)
			{
				return operands[i].imm.value.u;
			}
		}

		return 0;
	}

	struct region_data {
		std::vector<uint8_t> buffer;
		region reg;
	};

	inline std::vector<region_data> parse_process_bytes(const std::unique_ptr<memory>& memory, module_info mod_info = {})
	{
		uintptr_t start = (uintptr_t)sys_info.lpMinimumApplicationAddress;
		uintptr_t end = (uintptr_t)sys_info.lpMaximumApplicationAddress;

		std::vector<region_data> bytes;

		if (mod_info.base_address && mod_info.size)
		{
			start = mod_info.base_address;
			end = mod_info.base_address + mod_info.size;
		}

		MEMORY_BASIC_INFORMATION mbi{};
		uintptr_t current_address = start;
		while (current_address < end)
		{
			VirtualQueryEx(memory->info.handle, (LPCVOID)current_address, &mbi, sizeof(mbi));

			if (is_valid_memory_region(mbi))
			{
				uintptr_t region_start = (uintptr_t)mbi.BaseAddress;
				uintptr_t region_size = mbi.RegionSize;

				SIZE_T bytes_read = 0;
				std::vector<uint8_t> buffer(region_size);

				if (!memory->read_bytes(region_start, buffer.data(), region_size, bytes_read))
				{
					current_address += region_size;
					continue;
				}

				region reg = { region_start, current_address, region_size, bytes_read };
				bytes.emplace_back(buffer, reg);
			}

			current_address += mbi.RegionSize;
		}

		return bytes;
	}

	inline uintptr_t signature_scan(const std::unique_ptr<memory>& memory, const std::string& raw_sig, bool resolve_rip_relative = false, module_info mod_info = {})
	{
		uintptr_t start = (uintptr_t)sys_info.lpMinimumApplicationAddress;
		uintptr_t end = (uintptr_t)sys_info.lpMaximumApplicationAddress;

		if (mod_info.base_address && mod_info.size)
		{
			start = mod_info.base_address;
			end = mod_info.base_address + mod_info.size;
		}

		MEMORY_BASIC_INFORMATION mbi{};
		uintptr_t current_address = start;
		std::vector<signature> sig = signature::parse(raw_sig);
		size_t len = sig.size();
		while (current_address < end)
		{
			VirtualQueryEx(memory->info.handle, (LPCVOID)current_address, &mbi, sizeof(mbi));

			if (is_valid_memory_region(mbi))
			{
				uintptr_t region_start = (uintptr_t)mbi.BaseAddress;
				uintptr_t region_size = mbi.RegionSize;

				SIZE_T bytes_read = 0;
				std::vector<uint8_t> buffer(region_size);

				if (!memory->read_bytes(region_start, buffer.data(), region_size, bytes_read))
				{
					current_address += region_size;
					continue;
				}

				if (bytes_read < len)
				{
					current_address += region_size;
					continue;
				}

				for (size_t pos = 0; pos <= bytes_read - len; pos++)
				{
					bool found = true;

					for (size_t i = 0; i < len; i++)
					{
						if (!sig[i].wildcard && sig[i].bytes != buffer[pos + i])
						{
							found = false;
							break;
						}
					}

					if (found)
					{						
						return resolve_rip_relative ? calculate_rip_relative(memory, (uintptr_t)region_start + pos) : (uintptr_t)region_start + pos;
					}
				}
			}

			current_address += mbi.RegionSize;
		}

		return 0;
	}


	struct signature_data {
		std::vector<signature> sig;
		size_t len;
	};

	inline uintptr_t scan_cached_regions_for_string(const std::unique_ptr<memory>& memory, region& current_region, const std::vector<uint8_t>& buffer, const std::string& string, bool resolve_rip_relative = false)
	{
		auto len = string.size();

		if (current_region.bytes_read < len)
		{
			current_region.current += current_region.size;
			return 0;
		}

		for (size_t pos = 0; pos <= current_region.bytes_read - len; pos++)
		{
			bool found = true;

			for (size_t i = 0; i < len; i++)
			{
				if (buffer[pos + i] != string[i])
				{
					found = false;
					break;
				}
			}

			if (found)
			{
				return resolve_rip_relative ? calculate_rip_relative(memory, (uintptr_t)current_region.start + pos) : (uintptr_t)current_region.start + pos;
			}
		}

		return 0;
	}


	inline void scan_and_clean_strings(const std::unique_ptr<memory>& memory, region& current_region, const std::vector<uint8_t>& buffer, const std::string& string)
	{
		size_t len = string.size();
		size_t wide_len = len * 2;

		if (current_region.bytes_read < len)
		{
			current_region.current += current_region.size;
			return;
		}

		for (size_t pos = 0; pos < current_region.bytes_read; pos++)
		{
			uintptr_t base_address = (uintptr_t)current_region.start + pos;

			if (pos + len <= current_region.bytes_read)
			{
				bool found = true;

				for (size_t i = 0; i < len; i++)
				{
					if (buffer[pos + i] != static_cast<uint8_t>(string[i]))
					{
						found = false;
						break;
					}
				}

				if (found)
				{
					DWORD old;
					if (VirtualProtectEx(memory->info.handle, (LPVOID)base_address, len, PAGE_READWRITE, &old))
					{
						std::vector<uint8_t> zeros(len, 0);
						memory->write_memory(base_address, zeros);

						DWORD temp;
						VirtualProtectEx(memory->info.handle, (LPVOID)base_address, len, old, &temp);
					}
				}
			}

			if (pos + wide_len <= current_region.bytes_read)
			{
				bool found = true;

				for (size_t i = 0; i < len; i++)
				{
					if (buffer[pos + (i * 2)] != static_cast<uint8_t>(string[i]) ||
						buffer[pos + (i * 2) + 1] != 0x00)
					{
						found = false;
						break;
					}
				}

				if (found)
				{
					DWORD old;
					if (VirtualProtectEx(memory->info.handle, (LPVOID)base_address, wide_len, PAGE_READWRITE, &old))
					{
						std::vector<uint8_t> zeros(wide_len, 0);
						memory->write_memory(base_address, zeros);

						DWORD temp;
						VirtualProtectEx(memory->info.handle, (LPVOID)base_address, wide_len, old, &temp);
					}
				}
			}
		}
	}

	inline uintptr_t scan_cached_regions_for_sig(const std::unique_ptr<memory>& memory, region& current_region, const std::vector<uint8_t>& buffer, const signature_data& sig_data, bool resolve_rip_relative = false)
	{
		if (current_region.bytes_read < sig_data.len)
			return 0;

		for (size_t pos = 0; pos <= current_region.bytes_read - sig_data.len; pos++)
		{
			bool found = true;

			for (size_t i = 0; i < sig_data.len; i++)
			{
				if (!sig_data.sig[i].wildcard && sig_data.sig[i].bytes != buffer[pos + i])
				{
					found = false;
					break;
				}
			}

			if (found)
			{
				return resolve_rip_relative ? calculate_rip_relative(memory, (uintptr_t)current_region.start + pos) : (uintptr_t)current_region.start + pos;
			}
		}

		return 0;
	}
}