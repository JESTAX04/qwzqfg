#pragma once 

#include "memory.hpp"
#include <Zydis/Zydis.h>

namespace utilities {

	class zydis_decoder
	{
	public:
		ZydisDecoder decoder;

		zydis_decoder()
		{
			ZydisDecoderInit(&decoder, ZYDIS_MACHINE_MODE_LONG_64, ZYDIS_STACK_WIDTH_64);
		}

		std::pair<std::vector<ZydisDecodedOperand>, ZydisDecodedInstruction> decode(uintptr_t instruction_address, uint8_t bytes[15])
		{
			ZydisDecoderContext context{};
			ZydisDecodedOperand operands[ZYDIS_MAX_OPERAND_COUNT];
			ZydisDecodedInstruction instruction{};
			ZydisDecoderDecodeInstruction(&decoder, &context, bytes, sizeof(bytes), &instruction);

			ZydisDecoderDecodeOperands(&decoder, &context, &instruction, operands, instruction.operand_count);

			std::vector<ZydisDecodedOperand> ops(operands, operands + instruction.operand_count);
			return { ops, instruction };
		}
	};

	inline std::unique_ptr decoder = std::make_unique<zydis_decoder>();

	inline void nop(const std::unique_ptr<memory>& memory, uintptr_t address)
	{
		ZydisDecodedInstruction instruction;

		BYTE buffer[16];
		nt_read_virtual_mem(memory->info.handle, (PVOID)address, &buffer, sizeof(buffer), NULL);

		auto status = ZydisDecoderDecodeInstruction(&decoder->decoder, nullptr, buffer, sizeof(buffer), &instruction);

		if (!ZYAN_SUCCESS(status))
			return;

		BYTE nops[16];
		memset(nops, 0x90, instruction.length);

		nt_write_virtual_mem(memory->info.handle, (PVOID)address, nops, instruction.length, NULL);
	}
}