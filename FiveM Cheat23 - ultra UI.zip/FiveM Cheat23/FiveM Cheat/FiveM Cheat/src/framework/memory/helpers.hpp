#pragma once 

#include <Windows.h>
#include <string>
#include <TlHelp32.h>
#include <vector>
#include <winternl.h>
#include <sstream>

namespace utilities 
{
	inline SYSTEM_INFO sys_info{};

	struct module_info {
		uintptr_t base_address;
		size_t size;
	};

	struct process_info {
		DWORD pid = 0;
		std::string process_name;
		HANDLE handle = nullptr;
		module_info mod_info;
	};

	inline DWORD get_pid_by_window_class_name(const std::string& name)
	{
		auto window = FindWindowA(name.c_str(), nullptr);
		if (!window)
			return 0;

		DWORD pid = 0;
		GetWindowThreadProcessId(window, &pid);
		return pid;
	}

	inline std::vector<DWORD> get_pids_by_name(const std::string& name)
	{

		std::vector<DWORD> vec;
		auto snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL);

		PROCESSENTRY32 entry;
		entry.dwSize = sizeof(PROCESSENTRY32);

		if (!Process32First(snapshot, &entry))
		{
			CloseHandle(snapshot);
			return vec;
		}

		const char* str_2 = name.c_str();

		while (Process32Next(snapshot, &entry))
		{
			if (strcmp(entry.szExeFile, str_2) == 0)
			{
				vec.emplace_back(entry.th32ProcessID);
			}
		}

		CloseHandle(snapshot);
		return vec;
	}

	inline DWORD get_pid_by_name(const std::string& name)
	{
		auto snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL);

		PROCESSENTRY32 entry;
		entry.dwSize = sizeof(PROCESSENTRY32);

		if (!Process32First(snapshot, &entry))
		{
			CloseHandle(snapshot);
			return 0;
		}

		const char* str_2 = name.c_str();

		while (Process32Next(snapshot, &entry))
		{
			if (strcmp(entry.szExeFile, str_2) == 0)
			{
				CloseHandle(snapshot);
				return entry.th32ProcessID;
			}
		}

		CloseHandle(snapshot);
		return 0;
	}
	inline std::string get_process_name(DWORD pid)
	{
		auto snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, NULL);

		PROCESSENTRY32 entry;
		entry.dwSize = sizeof(PROCESSENTRY32);

		if (!Process32First(snapshot, &entry))
		{
			CloseHandle(snapshot);
			return "";
		}

		while (Process32Next(snapshot, &entry))
		{
			if (entry.th32ProcessID == pid)
			{
				CloseHandle(snapshot);
				return std::string(entry.szExeFile);
			}
		}

		CloseHandle(snapshot);
		return "";
	}
	inline module_info get_module_info(DWORD pid, const std::string& module_name)
	{
		auto snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, pid);

		MODULEENTRY32 entry;
		entry.dwSize = sizeof(MODULEENTRY32);

		if (!Module32First(snapshot, &entry))
		{
			CloseHandle(snapshot);
			return {};
		}

		const char* str_2 = module_name.c_str();

		if (strcmp(entry.szModule, str_2) == 0)
		{
			CloseHandle(snapshot);
			return { (uintptr_t)entry.modBaseAddr, entry.modBaseSize };
		}

		while (Module32Next(snapshot, &entry))
		{
			if (strcmp(entry.szModule, str_2) == 0)
			{
				CloseHandle(snapshot);
				return { (uintptr_t)entry.modBaseAddr, entry.modBaseSize };
			}
		}

		CloseHandle(snapshot);
		return {};
	}

	inline uintptr_t get_module_base(DWORD pid, const std::string& module_name)
	{
		auto snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32, pid);
		if (snapshot == INVALID_HANDLE_VALUE)
			return 0;
		MODULEENTRY32 entry{};
		entry.dwSize = sizeof(entry);
		uintptr_t result = 0;
		if (Module32First(snapshot, &entry))
		{
			do {
				if (_stricmp(entry.szModule, module_name.c_str()) == 0 ||
				    _stricmp(entry.szExePath, module_name.c_str()) == 0)
				{
					result = reinterpret_cast<uintptr_t>(entry.modBaseAddr);
					break;
				}
			} while (Module32Next(snapshot, &entry));
		}
		CloseHandle(snapshot);
		return result;
	}
	inline size_t get_module_size(DWORD pid, const std::string& module_name)
	{
		auto snapshot = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE, pid);
		if (!snapshot)
		{
			CloseHandle(snapshot);
			return 0;
		}

		MODULEENTRY32 entry;
		entry.dwSize = sizeof(MODULEENTRY32);

		if (!Module32First(snapshot, &entry))
		{
			CloseHandle(snapshot);
			return 0;
		}

		const char* str_2 = module_name.c_str();

		while (Module32Next(snapshot, &entry))
		{
			if (strcmp(entry.szExePath, str_2) == 0)
			{
				CloseHandle(snapshot);
				return entry.modBaseSize;
			}
		}

		CloseHandle(snapshot);
		return 0;
	}
	inline bool is_valid_memory_region(MEMORY_BASIC_INFORMATION mbi)
	{
		if (mbi.State != MEM_COMMIT) return false;

		DWORD protect = mbi.Protect;
		if (protect & PAGE_NOACCESS) return false;
		if (protect & PAGE_GUARD) return false;

		return true;
	}
	inline bool is_valid_address(uintptr_t address)
	{
		if (!address || address < (uintptr_t)sys_info.lpMinimumApplicationAddress || address > (uintptr_t)sys_info.lpMaximumApplicationAddress)
			return false;

		return true;
	}
}