#pragma once

#define inline __forceinline
#define no_inline __declspec(noinline)