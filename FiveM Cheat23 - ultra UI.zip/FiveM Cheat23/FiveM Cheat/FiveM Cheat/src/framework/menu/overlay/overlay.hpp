#pragma once

#include <memory>
#include <d3d11.h>
#include <string>

namespace framework {
	struct overlay_data {
		ID3D11Device* d3d_device;
		ID3D11DeviceContext* d3d_device_ctx;
		IDXGISwapChain* d3d_swap_chain;
		ID3D11RenderTargetView* d3d_render_target;
		HWND window_handle;
		WNDCLASSEX wc;
	};

	class overlay {
	private:
		overlay_data data;
		void cleanup_render_target();
		void cleanup_device_d3d();
		void create_render_target();
		void create_window(const std::string& name);
		void setup();
		bool start_render();
		void end_render();
		void move_window();
		void cleanup();
	public:
		LRESULT __stdcall wnd_proc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

		void start();

		overlay_data get_data() {
			return data;
		}
	};

	inline std::unique_ptr g_overlay = std::make_unique<overlay>();
	
}