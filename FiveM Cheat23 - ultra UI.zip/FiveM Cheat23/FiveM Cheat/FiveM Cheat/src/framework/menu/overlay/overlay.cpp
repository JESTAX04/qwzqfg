#include "overlay.hpp"
#include "../gui/gui.hpp"
#include "../../../dependencies/imgui/imgui_impl_win32.h"
#include "../../../dependencies/imgui/imgui_impl_dx11.h"

#include "../../threads.hpp"
#include <dwmapi.h>
#include "../gui/assets/font.hpp"
#include "../../features/features.hpp"

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

namespace framework {
	void overlay::cleanup_render_target()
	{
		if (data.d3d_render_target) {
			data.d3d_render_target->Release();
			data.d3d_render_target = nullptr;
		}
	}

	void overlay::cleanup_device_d3d()
	{
		cleanup_render_target();

		if (data.d3d_swap_chain) {
			data.d3d_swap_chain->Release();
			data.d3d_swap_chain = nullptr;
		}

		if (data.d3d_device_ctx) {
			data.d3d_device_ctx->Release();
			data.d3d_device_ctx = nullptr;
		}

		if (data.d3d_device) {
			data.d3d_device->Release();
			data.d3d_device = nullptr;
		}
	}

	void overlay::create_render_target()
	{
		ID3D11Texture2D* back_buffer;
		data.d3d_swap_chain->GetBuffer(0, IID_PPV_ARGS(&back_buffer));
		data.d3d_device->CreateRenderTargetView(back_buffer, nullptr, &data.d3d_render_target);
		back_buffer->Release();
	}

	LRESULT __stdcall overlay::wnd_proc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
		if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam))
			return true;

		switch (msg)
		{
		case WM_SIZE:
			if (data.d3d_device != nullptr && wParam != SIZE_MINIMIZED)
			{
				cleanup_render_target();
				data.d3d_swap_chain->ResizeBuffers(0, (UINT)LOWORD(lParam), (UINT)HIWORD(lParam), DXGI_FORMAT_UNKNOWN, 0);
				create_render_target();
			}
			return 0;
		case WM_SYSCOMMAND:
			if ((wParam & 0xfff0) == SC_KEYMENU)
				return 0;
			break;
		case WM_DESTROY:
			::PostQuitMessage(0);
			return 0;
		}
		return ::DefWindowProcW(hWnd, msg, wParam, lParam);
	}

	static LRESULT __stdcall wnd_procc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam)
	{
		return g_overlay->wnd_proc(hWnd, msg, wParam, lParam);
	}

	void overlay::create_window(const std::string& name)
	{
		WNDCLASSEX wc{};
		wc.cbClsExtra = NULL;
		wc.cbSize = sizeof(WNDCLASSEX);
		wc.cbWndExtra = NULL;
		wc.hbrBackground = CreateSolidBrush(RGB(0, 0, 0));;
		wc.hInstance = GetModuleHandleA(nullptr);
		wc.lpfnWndProc = wnd_procc;
		wc.lpszClassName = name.c_str();
		wc.lpszMenuName = nullptr;
		wc.style = CS_VREDRAW | CS_HREDRAW;

		RegisterClassEx(&wc);
		data.window_handle = CreateWindowEx(WS_EX_TOPMOST | WS_EX_TRANSPARENT | WS_EX_NOACTIVATE, wc.lpszClassName, name.c_str(), WS_POPUP, 0, 0, GetSystemMetrics(SM_CXSCREEN), GetSystemMetrics(SM_CYSCREEN), nullptr, nullptr, wc.hInstance, nullptr);

		SetLayeredWindowAttributes(data.window_handle, 0, 255, LWA_ALPHA);
		const MARGINS margin = { -1 };
		DwmExtendFrameIntoClientArea(data.window_handle, &margin);

		data.wc = wc;
	}

	void overlay::setup()
	{
		create_window("external");

		DXGI_SWAP_CHAIN_DESC swap_chain_description = {};
		ZeroMemory(&swap_chain_description, sizeof(swap_chain_description));
		swap_chain_description.BufferCount = 2;
		swap_chain_description.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
		swap_chain_description.BufferDesc.RefreshRate.Numerator = 60;
		swap_chain_description.BufferDesc.RefreshRate.Denominator = 1;
		swap_chain_description.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;
		swap_chain_description.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
		swap_chain_description.OutputWindow = data.window_handle;
		swap_chain_description.SampleDesc.Count = 1;
		swap_chain_description.SampleDesc.Quality = 0;
		swap_chain_description.Windowed = TRUE;
		swap_chain_description.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

		const UINT createDeviceFlags = 0;

		D3D_FEATURE_LEVEL featureLevel;
		const D3D_FEATURE_LEVEL featureLevelArray[2] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0, };
		HRESULT res = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, createDeviceFlags, featureLevelArray, 2, D3D11_SDK_VERSION, &swap_chain_description, &data.d3d_swap_chain, &data.d3d_device, &featureLevel, &data.d3d_device_ctx);
		if (res == DXGI_ERROR_UNSUPPORTED)
			res = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_WARP, nullptr, createDeviceFlags, featureLevelArray, 2, D3D11_SDK_VERSION, &swap_chain_description, &data.d3d_swap_chain, &data.d3d_device, &featureLevel, &data.d3d_device_ctx);
		if (res != S_OK)
		{
			cleanup_device_d3d();
			UnregisterClass(data.wc.lpszClassName, data.wc.hInstance);
			return;
		}

		ID3D11Texture2D* pBackBuffer;

		data.d3d_swap_chain->GetBuffer(0, IID_PPV_ARGS(&pBackBuffer));

		if (pBackBuffer)
		{
			data.d3d_device->CreateRenderTargetView(pBackBuffer, nullptr, &data.d3d_render_target);
			pBackBuffer->Release();
		}

		ShowWindow(data.window_handle, SW_SHOW);
		UpdateWindow(data.window_handle);

		IMGUI_CHECKVERSION();
		ImGui::CreateContext();

		ImGui_ImplWin32_Init(data.window_handle);
		ImGui_ImplDX11_Init(data.d3d_device, data.d3d_device_ctx);

		framework::gui::initialize();
	}

	bool overlay::start_render()
	{
		MSG msg;
		if (::PeekMessage(&msg, nullptr, 0U, 0U, PM_REMOVE))
		{
			::TranslateMessage(&msg);
			::DispatchMessage(&msg);
			if (msg.message == WM_QUIT)
				return false;
		}

		ImGui_ImplDX11_NewFrame();
		ImGui_ImplWin32_NewFrame();
		ImGui::NewFrame();

		return true;
	}

	void overlay::end_render()
	{
		ImGui::EndFrame();
		ImGui::Render();
		const float clear_color_with_alpha[4] = { 0.0f, 0.0f, 0.0f, 0.0f };
		data.d3d_device_ctx->OMSetRenderTargets(1, &data.d3d_render_target, nullptr);
		data.d3d_device_ctx->ClearRenderTargetView(data.d3d_render_target, clear_color_with_alpha);
		ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());

		data.d3d_swap_chain->Present(settings::settings.vsync ? 1 : 0, 0);
	}

	void overlay::move_window()
	{
		auto hwnd = FindWindowA("grcWindow", nullptr);
		GetClientRect(hwnd, &settings::rect);

		POINT top_left = { settings::rect.left, settings::rect.top };
		ClientToScreen(hwnd, &top_left);

		int width = settings::rect.right - settings::rect.left;
		int height = settings::rect.bottom - settings::rect.top;

		MoveWindow(data.window_handle, top_left.x, top_left.y, width, height, TRUE);
	}

	void overlay::start()
	{
		setup();

		while (threads::should_run)
		{
			if (!start_render())
				break;

			switch (settings::visuals.font)
			{
			case 0:
				ImGui::PushFont(gui::fonts::esp_font);
				break;
			case 1:
				ImGui::PushFont(gui::fonts::inter_regular);
				break;
			case 2:
				ImGui::PushFont(gui::fonts::inter_bold);
				break;
			}

			features::visuals();
			ImGui::PopFont();

			features::friend_key();
			features::heal();
			features::fix_vehicle();

			if (GetAsyncKeyState(gui::menu_key) & 1)
			{
				gui::should_show_menu = !gui::should_show_menu;
			}

			ImVec4 get_theme_col = ImVec4(settings::settings.theme[0], settings::settings.theme[1], settings::settings.theme[2], settings::settings.theme[3]);
			framework::gui::theme_col = ImGui::ColorConvertFloat4ToU32(get_theme_col);

			framework::gui::handle_notifications();

			static bool set_window_style = false;
			static bool set_windows_affinity = false;

			if (settings::settings.streamproof && !set_windows_affinity)
			{
				SetWindowDisplayAffinity(data.window_handle, WDA_EXCLUDEFROMCAPTURE);
			}
			else if (!settings::settings.streamproof && set_windows_affinity)
			{
				SetWindowDisplayAffinity(data.window_handle, WDA_NONE);
			}

			if (gui::should_show_menu)
			{
				if (!set_window_style)
				{
					SetWindowLongA(data.window_handle, GWL_EXSTYLE, WS_EX_TOPMOST | WS_EX_LAYERED | WS_EX_TOOLWINDOW);
					set_window_style = true;
				}

				menu();
			}
			else
			{
				if (set_window_style)
				{
					SetWindowLongA(data.window_handle, GWL_EXSTYLE, WS_EX_TOPMOST | WS_EX_TRANSPARENT | WS_EX_LAYERED | WS_EX_TOOLWINDOW);
					set_window_style = false;
				}
			}

			move_window();
			end_render();

			if (settings::settings.performance_mode)
			{
				std::this_thread::sleep_for(std::chrono::milliseconds(2));
			}

			std::this_thread::yield();
		}

		cleanup();
	}

	void overlay::cleanup()
	{
		ImGui_ImplDX11_Shutdown();
		ImGui_ImplWin32_Shutdown();
		ImGui::DestroyContext();

		cleanup_device_d3d();
		DestroyWindow(data.window_handle);
		UnregisterClass(data.wc.lpszClassName, data.wc.hInstance);
	}
	
}