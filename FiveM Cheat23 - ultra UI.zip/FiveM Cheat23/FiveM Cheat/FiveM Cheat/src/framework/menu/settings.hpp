#pragma once
#include <unordered_set>

inline std::unordered_set<uintptr_t> friends;

namespace settings {
	inline RECT rect;
	inline HANDLE mutex;

	struct aimbot_t {
		bool enabled;

		bool state = false;
		int key = 0;
		int mode = 1;
		int id = 0;

		float fov = 50.f;
		bool draw_fov = false;

		float smoothness = 0.12f;

		int selected_bone = 0;
		bool closest_bone = false;

		bool Humanization = false;

		bool target_dead = false;
		bool friend_check = false;
		bool visible_check = false;
		bool target_bots = true;

		bool overshoot = false;
		float overshoot_strength = 0.070f;
		float overshoot_smoothness = 0.12f;

		int max_distance = 350.f;
	} inline aimbot;

	struct triggerbot_t {
		bool enabled = false;
		int delay = 5;

		bool state = false;
		int key = 0;
		int mode = 1;
		int id = 0;

		bool automatic_mode;

	} inline triggerbot;

	struct silent_aim_t {
		bool enabled;
		float fov = 50.f;
		bool draw_fov = false;

		int selected_bone = 0;
		bool closest_bone = false;

		bool target_dead = false;
		bool friend_check = false;
		bool visible_check = false;
		bool target_bots = false;

		int max_distance = 350.f;

		bool magic_bullet = false;
	} inline silent_aim;

	struct exploits_t {
		bool enabled;
		bool safe_godmode;
		bool godmode;
		bool godmode_2;
		bool no_headshots;
		bool super_punch;
		bool infinite_stamina;
		bool passive_mode;
		bool legit_passive_mode;
		bool one_tap;

		bool shrink;

		bool bypass_exploits;

		bool heal;
		bool no_ragdoll;

		int heal_key;
		int heal_mode = 1;
		int heal_id;

		bool fix_vehicle;

		int fix_vehicle_key;
		int fix_vehicle_mode = 1;
		int fix_vehicle_id;
	} inline exploits;

	struct visuals_t {
		bool enabled;
		bool skeleton;
		bool box;
		bool distance;
		bool glow;
		bool femboy;
		bool name;
		bool healthbar;
		bool head_dot;
		bool cool_skeleton;
		bool status;

		bool following_line;

		bool friend_indicator = false;

		int skeleton_type = 1;
		int skeleton_thickness = 1;

		int box_rounding = 0;

		int max_distance = 350.f;
		bool draw_dead = false;
		bool draw_bots = false;

		bool text_outline = true;
		int font = 0;

		float box_color[4] = { 1.f, 1.f, 1.f, 1.f };
		float skeleton_color[4] = { 1.f, 1.f, 1.f, 1.f };
		float glow_color[4] = {1.f, 1.f, 1.f, 1.f};
		float status_color[4] = { 1.f, 1.f, 1.f, 1.f };
		float health_bar_color[4] = { 1.f, 1.f, 1.f, 1.f };
		float distance_color[4] = { 1.f, 1.f, 1.f, 1.f };
		float name_color[4] = { 1.f, 1.f, 1.f, 1.f };
		float friend_indicator_color[4] = { 0.f, 1.f, 0.f, 1.f };
		float following_line_color[4] = { 1.f, 1.f, 1.f, 1.f };
	} inline visuals;

	struct friend_key_t {
		bool enabled;

		float fov = 130.f;

		bool selected_bone = 0;
		bool closest_bone = false;

		bool target_dead = true;
		bool friend_check = false;
		bool visible_check = false;
		bool target_bots = true;

		int max_distance = 350.f;

		bool state;
		int key = 0;
		int mode = 1;
		int id = 0;
	} inline friend_key;

	struct settings_t {
		bool vsync = true;
		bool streamproof;

		float theme[4] = { 1.f, 1.f, 1.f, 1.f };

		bool performance_mode = true;
		bool run_cleaner = false;
	} inline settings;
}