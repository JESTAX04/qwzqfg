#include "../framework.hpp"

namespace framework::gui
{
    bool create_child(ImDrawList* draw, const ImVec2& size, const std::string& label)
	{
        ImVec2 pos = ImGui::GetCursorScreenPos();

        const char* text = label.c_str();
        draw->AddRectFilled(pos, ImVec2(pos.x + size.x, pos.y + size.y), IM_COL32(14, 15, 21, 255), 6.f);
        draw->AddRect(pos, ImVec2(pos.x + size.x, pos.y + size.y), IM_COL32(32, 35, 46, 255), 6.f);
        draw->AddText(ImVec2(pos.x + 12.f, pos.y + 10.f), IM_COL32(230, 232, 242, 255), text);
        draw->AddLine(ImVec2(pos.x + 1.f, pos.y + header_height), ImVec2(pos.x + size.x - 1.f, pos.y + header_height), IM_COL32(32, 35, 46, 255));
        ImGui::SetCursorScreenPos(ImVec2(pos.x + 8.f, pos.y + header_height));

        bool open = ImGui::BeginChild(text, ImVec2(size.x - 16.f, size.y - header_height - 6.f), false, ImGuiWindowFlags_NoBackground);

        ImGui::SetCursorPosY(ImGui::GetCursorPosY() + padding.y);

        return open;
	}

	void end_child()
	{
        ImGui::SetCursorPosY(ImGui::GetCursorPosY() - padding.y);
        ImGui::EndChild();
	}
}
