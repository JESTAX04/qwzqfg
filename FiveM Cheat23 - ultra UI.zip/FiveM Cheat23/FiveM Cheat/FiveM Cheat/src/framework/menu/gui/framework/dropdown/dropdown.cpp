#include "../framework.hpp"

namespace framework::gui
{
	bool create_dropdown(const char* label, int* current_item, const std::vector<std::string>& items)
	{
		ImGuiContext& g = *GImGui;
		ImGuiWindow* window = g.CurrentWindow;
		const auto id = window->GetID(label);

		const ImVec2 pos = window->DC.CursorPos;
		const float w = ImGui::GetContentRegionAvail().x;
		const ImVec2 size = ImVec2(w, 20.f);

		const ImRect bb(pos, ImVec2(pos.x + size.x, pos.y + size.y));
		ImGui::ItemSize(bb, padding.y);

		if (!ImGui::ItemAdd(bb, id))
		{
			return false;
		}

		bool hovered, held, pressed = ImGui::ButtonBehavior(bb, id, &hovered, &held);

		static std::unordered_map<ImGuiID, bool> opened;
		static std::unordered_map<ImGuiID, float> animations;

		if (pressed)
		{
			opened[id] = !opened[id];
		}

		float& anim = animations[id];
		anim = ImLerp(anim, (hovered || opened[id]) ? 1.0f : 0.0f, g.IO.DeltaTime * 14.f);

		window->DrawList->AddRectFilled(pos, ImVec2(pos.x + size.x, pos.y + size.y), IM_COL32(20, 20, 20, 255), 2.f);
		window->DrawList->AddRect(pos, ImVec2(pos.x + size.x, pos.y + size.y), IM_COL32(35, 35, 35, 255), 2.f);

		ImU32 interaction_col = IM_COL32(180 + (75 * anim), 180 + (75 * anim), 180 + (75 * anim), 255);
		ImVec2 arrow_pos = ImVec2(pos.x + size.x - 12.f, pos.y + size.y / 2.f);

		if (opened[id])
		{
			window->DrawList->AddTriangleFilled(ImVec2(arrow_pos.x - 4.f, arrow_pos.y + 2.f), ImVec2(arrow_pos.x + 4.f, arrow_pos.y + 2.f), ImVec2(arrow_pos.x, arrow_pos.y - 2.f), interaction_col);
		}
		else
		{
			window->DrawList->AddTriangleFilled(ImVec2(arrow_pos.x - 4.f, arrow_pos.y - 2.f), ImVec2(arrow_pos.x + 4.f, arrow_pos.y - 2.f), ImVec2(arrow_pos.x, arrow_pos.y + 2.f), interaction_col);
		}

		std::string preview_text = (*current_item >= 0 && *current_item < (int)items.size()) ? items[*current_item] : "None";

		ImGui::PushFont(fonts::inter_regular);
		window->DrawList->AddText(ImVec2(pos.x + 8.f, pos.y + (size.y - (g.Font->Ascent - g.Font->Descent)) / 2.f), interaction_col, preview_text.c_str());
		ImGui::PopFont();

		if (opened[id])
		{
			ImGui::SetNextWindowPos(ImVec2(pos.x, pos.y + size.y + 2.f));
			ImGui::SetNextWindowSize(ImVec2(size.x, 0.0f));

			ImGui::PushStyleColor(ImGuiCol_WindowBg, background_col);
			ImGui::PushStyleColor(ImGuiCol_Border, IM_COL32(40, 40, 40, 0));
			ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 3.f);
			ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(1, 1));

			std::string popup_id = "##dropdown_popup_" + std::string(label);
			if (ImGui::Begin(popup_id.c_str(), NULL, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_Tooltip))
			{
				ImGuiWindow* popup_window = ImGui::GetCurrentWindow();
				ImVec2 p_min = popup_window->Pos;
				ImVec2 p_max = ImVec2(p_min.x + popup_window->Size.x, p_min.y + popup_window->Size.y);

				popup_window->DrawList->AddRectFilled(p_min, p_max, background_col, 2.f);
				popup_window->DrawList->AddRect(p_min, p_max, IM_COL32(45, 45, 45, 255), 2.f);

				for (int i = 0; i < (int)items.size(); i++)
				{
					bool is_active = (*current_item == i);
					if (create_selectable(items[i].c_str(), &is_active))
					{
						*current_item = i;
						opened[id] = false;
					}
				}

				if (!ImGui::IsWindowHovered(ImGuiHoveredFlags_AllowWhenBlockedByActiveItem | ImGuiHoveredFlags_AnyWindow) && ImGui::IsMouseClicked(0))
				{
					opened[id] = false;
				}

				ImGui::End();
			}
			ImGui::PopStyleVar(2);
			ImGui::PopStyleColor(2);
		}

		return opened[id];
	}
}
