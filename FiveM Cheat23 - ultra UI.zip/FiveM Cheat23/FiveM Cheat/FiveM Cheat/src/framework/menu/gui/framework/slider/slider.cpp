#include "../framework.hpp"
#include <sstream>
#include <iomanip>
#include <algorithm>
#include <iostream>

namespace framework::gui {
	struct slider_state {
		ImVec4 background, text;
		float slider_offset;
	};

    bool slider_scalar(const char* label, ImGuiDataType data_type, void* p_data, const void* p_min, const void* p_max, const char* format, ImGuiSliderFlags flags)
    {
        auto& g = *GImGui;
        auto window = g.CurrentWindow;
        auto draw = window->DrawList;
        const auto id = window->GetID(label);

        const ImVec2 pos = window->DC.CursorPos;
        float w = ImGui::GetContentRegionAvail().x;
        ImVec2 size{ w, 7.f }; 

        const float spacing = 7.f;

        ImVec2 label_size = ImGui::CalcTextSize(label);

        ImVec2 text_pos = pos;
        ImVec2 slider_pos = ImVec2(pos.x, pos.y + label_size.y + spacing);

        ImRect frame_bb(slider_pos, ImVec2(slider_pos.x + size.x, slider_pos.y + size.y));
        ImRect total_bb(pos, ImVec2(pos.x + size.x, slider_pos.y + size.y));

        ImGui::ItemSize(total_bb, padding.y * 1.2f);
        if (!ImGui::ItemAdd(total_bb, id))
            return false;

        bool hovered, held, pressed = ImGui::ButtonBehavior(frame_bb, id, &hovered, &held);

        static std::unordered_map<std::string, float> animations;
        static std::unordered_map<ImGuiID, slider_state> animm;
        auto& state = animm[id];

        ImRect grab_bb;
        const bool value_changed = ImGui::SliderBehavior(frame_bb, id, data_type, p_data, p_min, p_max, format, flags, &grab_bb);
        if (value_changed) ImGui::MarkItemEdited(id);

        state.slider_offset = ImLerp(state.slider_offset, grab_bb.Min.x - frame_bb.Min.x, g.IO.DeltaTime * 6.f);

        float& anim = animations[label];
        anim = ImLerp(anim, (hovered || pressed) ? 1.f : 0.f, g.IO.DeltaTime * 14.f);

        helpers::draw_rect(draw, frame_bb.Min, frame_bb.Min, size, IM_COL32(25, 25, 25, 255), helpers::rect_type::filled, 0.f, 1.f);

        if (anim > 0.01f)
        {
            ImVec4 theme = ImGui::ColorConvertU32ToFloat4(theme_col);
            helpers::draw_rect(draw, frame_bb.Min, frame_bb.Min, size, IM_COL32(theme.x * 255.f, theme.y * 255.f, theme.z * 255.f, 30.f * anim), helpers::rect_type::filled, 0.f, 1.f);
        }

        state.slider_offset = std::clamp(state.slider_offset, 10.f, FLT_MAX);

        if (state.slider_offset > 0.f)
        {
            helpers::draw_rect(draw, frame_bb.Min, frame_bb.Min, ImVec2(state.slider_offset, size.y), theme_col, helpers::rect_type::filled, 0.f, 1.f);
        }

        float knob_radius = 5.f + (2.f * anim);
        draw->AddCircleFilled(ImVec2(frame_bb.Min.x + state.slider_offset, frame_bb.Min.y + size.y / 2.f), knob_radius, theme_col);
        draw->AddCircle(ImVec2(frame_bb.Min.x + state.slider_offset, frame_bb.Min.y + size.y / 2.f), knob_radius, IM_COL32(255, 255, 255, 120), 24, 1.f);

        if (anim > 0.01f)
            draw->AddCircle(ImVec2(frame_bb.Min.x + state.slider_offset, frame_bb.Min.y + size.y / 2.f), knob_radius + 3.f, IM_COL32_A_SET(theme_col, 50 * anim), 24, 2.0f);

        draw->AddText(ImVec2(pos.x, pos.y + (label_size.y - spacing) / 2), IM_COL32(200, 200, 200, 255), label);

        char value_buf[64];
        const char* value_buf_end = value_buf + ImGui::DataTypeFormatString(value_buf, IM_ARRAYSIZE(value_buf), data_type, p_data, format);
        draw->AddText(ImVec2(pos.x + size.x - ImGui::CalcTextSize(value_buf).x, pos.y + ( label_size.y - spacing) / 2), IM_COL32(255, 255, 255, 255), value_buf);

        return pressed;
    }

	bool slider_float(const char* label, float* v, float v_min, float v_max, const char* format, ImGuiSliderFlags flags)
	{
		return slider_scalar(label, ImGuiDataType_Float, v, &v_min, &v_max, format, flags);
	}

	bool slider_int(const char* label, int* v, int v_min, int v_max, const char* format, ImGuiSliderFlags flags)
	{
		return slider_scalar(label, ImGuiDataType_S32, v, &v_min, &v_max, format, flags);
	}
}
