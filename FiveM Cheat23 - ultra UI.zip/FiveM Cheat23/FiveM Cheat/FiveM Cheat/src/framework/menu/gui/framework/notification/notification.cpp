#include "../framework.hpp"

namespace framework::gui
{
	struct notification_t
	{
		std::string text;
		float time;
		float max_time;
		float alpha;
		float offset;
	};

	static std::vector<notification_t> notifications;

	void add_notification(const std::string& text)
	{
		notifications.push_back({ text, 5.0f, 5.0f, 0.0f, 0.0f });
	}

	void handle_notifications()
	{
		ImGuiContext& g = *GImGui;
		ImDrawList* draw = ImGui::GetForegroundDrawList();

		ImVec2 screen_size = g.IO.DisplaySize;
		float y_offset = 20.f;

		for (int i = 0; i < notifications.size(); i++)
		{
			auto& n = notifications[i];

			if (n.time > 0.0f)
			{
				n.alpha = ImLerp(n.alpha, 1.0f, g.IO.DeltaTime * 10.f);
				n.offset = ImLerp(n.offset, 0.0f, g.IO.DeltaTime * 10.f);
			}
			else
			{
				n.alpha = ImLerp(n.alpha, 0.0f, g.IO.DeltaTime * 10.f);
				n.offset = ImLerp(n.offset, 50.0f, g.IO.DeltaTime * 10.f);
			}

			n.time -= g.IO.DeltaTime;

			if (n.time < -1.0f)
			{
				notifications.erase(notifications.begin() + i);
				i--;
				continue;
			}

			ImGui::PushFont(fonts::inter_regular);
			ImVec2 text_size = ImGui::CalcTextSize(n.text.c_str());
			ImGui::PopFont();

			float w = text_size.x + 30.f;
			float h = 30.f;

			ImVec2 pos = ImVec2(screen_size.x - w - 20.f + n.offset, y_offset);
			ImU32 back_col = IM_COL32_A_SET(background_col, 240 * n.alpha);
			ImU32 accent_col = IM_COL32_A_SET(theme_col, 255 * n.alpha);
			ImU32 text_col = IM_COL32_A_SET(text_active_col, 255 * n.alpha);

			draw->AddRectFilled(pos, ImVec2(pos.x + w, pos.y + h), back_col, 3.f);
			draw->AddRect(pos, ImVec2(pos.x + w, pos.y + h), IM_COL32(40, 40, 40, 100 * n.alpha), 3.f);

			draw->AddRectFilled(ImVec2(pos.x, pos.y), ImVec2(pos.x + 3.f, pos.y + h), accent_col, 3.f, ImDrawFlags_RoundCornersLeft);

			ImGui::PushFont(fonts::inter_regular);
			draw->AddText(ImVec2(pos.x + 12.f, pos.y + (h - (g.Font->Ascent - g.Font->Descent)) / 2.f), text_col, n.text.c_str());
			ImGui::PopFont();

			y_offset += (h + 10.f) * n.alpha;
		}
	}
}
