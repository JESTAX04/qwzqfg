#include "../framework.hpp"

namespace framework::gui 
{
	ImGuiWindow* create_window(const std::string& name, const ImVec2& size)
	{
		ImGui::SetNextWindowSize(size);
		ImGui::Begin(name.c_str(), FALSE, ImGuiWindowFlags_NoDecoration);

		ImGuiContext& g = *GImGui; 
		g.CurrentWindow->WriteAccessed = true; 

		ImGuiWindow* window = g.CurrentWindow;

		menu_animation = ImLerp(menu_animation, 1.0f, ImGui::GetIO().DeltaTime * 12.0f);

		ImU32 bg = IM_COL32_A_SET(background_col, 255 * menu_animation);

		window->DrawList->PushClipRectFullScreen();

		helpers::draw_rect(window->DrawList, window->Pos, window->Pos, window->Size, bg, helpers::rect_type::filled, 1.f, window_rounding);
		helpers::draw_rect(window->DrawList, window->Pos, window->Pos, window->Size, IM_COL32(19, 19, 19, 255), helpers::rect_type::outlined, 1.f, window_rounding);

		ImGui::PushFont(fonts::menu_font ? fonts::menu_font : fonts::inter_regular);

		window->DrawList->PopClipRect();

		window->DrawList->PushClipRect(window->Pos, { window->Pos.x + window->Size.x, window->Pos.y + window->Size.y });

		return window;
	}

	void end_window()
	{
		ImGui::PopFont();
		ImGui::GetCurrentWindow()->DrawList->PopClipRect();
		ImGui::End();
	}
}