#include "../framework.hpp"

namespace framework::gui
{
	bool create_selectable(const char* label, bool* selected)
	{
		ImGuiContext& g = *GImGui;
		ImGuiWindow* window = g.CurrentWindow;
		const auto id = window->GetID(label);

		const ImVec2 pos = window->DC.CursorPos;
		const float w = ImGui::GetContentRegionAvail().x;
		const ImVec2 size = ImVec2(w, 24.f);

		const ImRect bb(pos, ImVec2(pos.x + size.x, pos.y + size.y));
		ImGui::ItemSize(bb, padding.y);

		if (!ImGui::ItemAdd(bb, id))
		{
			return false;
		}

		bool hovered, held, pressed = ImGui::ButtonBehavior(bb, id, &hovered, &held);

		if (pressed)
		{
			*selected = !*selected;
		}

		static std::unordered_map<ImGuiID, float> animations;
		float& anim = animations[id];
		anim = ImLerp(anim, (hovered || *selected) ? 1.0f : 0.0f, g.IO.DeltaTime * 14.f);

		if (anim > 0.01f)
		{
			ImVec4 theme = ImGui::ColorConvertU32ToFloat4(theme_col);
			ImU32 bg_col = IM_COL32(theme.x * 255.f, theme.y * 255.f, theme.z * 255.f, (*selected ? 35.f : 15.f) * anim);
			window->DrawList->AddRectFilled(pos, ImVec2(pos.x + size.x, pos.y + size.y), bg_col, 2.f);
		}

		if (*selected)
		{
			window->DrawList->AddRectFilled(pos, ImVec2(pos.x + 2.f, pos.y + size.y), theme_col, 1.f);
		}

		ImU32 text_col = IM_COL32(180 + (75 * anim), 180 + (75 * anim), 180 + (75 * anim), 255);

		ImGui::PushFont(fonts::inter_regular);
		window->DrawList->AddText(ImVec2(pos.x + 10.f + (4.f * anim), pos.y + (size.y - (g.Font->Ascent - g.Font->Descent)) / 2.f), text_col, label);
		ImGui::PopFont();

		return pressed;
	}

	bool create_selectable_with_given_color(const char* label, bool* selected, ImU32 col)
	{
		ImGuiContext& g = *GImGui;
		ImGuiWindow* window = g.CurrentWindow;
		const auto id = window->GetID(label);

		const ImVec2 pos = window->DC.CursorPos;
		const float w = ImGui::GetContentRegionAvail().x;
		const ImVec2 size = ImVec2(w, 24.f);

		const ImRect bb(pos, ImVec2(pos.x + size.x, pos.y + size.y));
		ImGui::ItemSize(bb, padding.y);

		if (!ImGui::ItemAdd(bb, id))
		{
			return false;
		}

		bool hovered, held, pressed = ImGui::ButtonBehavior(bb, id, &hovered, &held);

		if (pressed)
		{
			*selected = !*selected;
		}

		static std::unordered_map<ImGuiID, float> animations;
		float& anim = animations[id];
		anim = ImLerp(anim, (hovered || *selected) ? 1.0f : 0.0f, g.IO.DeltaTime * 14.f);

		if (anim > 0.01f)
		{
			ImVec4 theme = ImGui::ColorConvertU32ToFloat4(col);
			ImU32 bg_col = IM_COL32(theme.x * 255.f, theme.y * 255.f, theme.z * 255.f, (*selected ? 35.f : 15.f) * anim);
			window->DrawList->AddRectFilled(pos, ImVec2(pos.x + size.x, pos.y + size.y), bg_col, 2.f);
		}

		if (*selected)
		{
			window->DrawList->AddRectFilled(pos, ImVec2(pos.x + 2.f, pos.y + size.y), col, 1.f);
		}

		ImU32 text_col = IM_COL32(180 + (75 * anim), 180 + (75 * anim), 180 + (75 * anim), 255);

		ImGui::PushFont(fonts::inter_regular);
		window->DrawList->AddText(ImVec2(pos.x + 10.f + (4.f * anim), pos.y + (size.y - (g.Font->Ascent - g.Font->Descent)) / 2.f), col, label);
		ImGui::PopFont();

		return pressed;
	}
}
