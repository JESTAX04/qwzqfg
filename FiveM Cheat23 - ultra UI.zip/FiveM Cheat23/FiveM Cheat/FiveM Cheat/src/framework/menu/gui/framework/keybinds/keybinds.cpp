#include "../framework.hpp"

namespace framework::gui
{
	static const char* key_names[] =
	{
		"None", "M1", "M2", "CN", "M3", "M4", "M5", "Unk", "Back", "Tab", "Unk", "Unk", "Clr", "Ret", "Unk", "Unk", "Shift", "Ctl", "Alt", "Pause", "Cap", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Esc", "Unk", "Unk", "Unk", "Unk", "Space", "PgUp", "PgDn", "End", "Home", "Left", "Up", "Right", "Down", "Sel", "Prnt", "Exec", "PrtSc", "Ins", "Del", "Help", "0", "1", "2", "3", "4", "5", "6", "7", "8", "9", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z", "LWin", "RWin", "Apps", "Unk", "Sleep", "Num0", "Num1", "Num2", "Num3", "Num4", "Num5", "Num6", "Num7", "Num8", "Num9", "*", "+", "Sep", "-", ".", "/", "F1", "F2", "F3", "F4", "F5", "F6", "F7", "F8", "F9", "F10", "F11", "F12", "F13", "F14", "F15", "F16", "F17", "F18", "F19", "F20", "F21", "F22", "F23", "F24", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "NumLk", "ScrLk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "LShift", "RShift", "LCtrl", "RCtrl", "LMenu", "RMenu", "MBack", "MFor", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", ";", "+", ",", "-", ".", "/", "~", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "[", "\\", "]", "'", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk", "Unk"
	};

	std::unordered_map<ImGuiID, bool> waiting_for_key;

	bool update_keybind(int* key, int* mode, int id)
	{
		static std::unordered_map<int, bool> toggle_states;

		if (waiting_for_key.count(id) && waiting_for_key[id])
			return false;

		if (*mode == 0)
			return true;

		if (*key == 0)
			return false;

		if (*mode == 1)
		{
			return (GetAsyncKeyState(*key) & 0x8000) != 0;
		}

		if (*mode == 2)
		{
			if (GetAsyncKeyState(*key) & 1) 
				toggle_states[id] = !toggle_states[id];

			return toggle_states[id];
		}

		return false;
	}

	bool create_keybind(const char* label, int* key, int* mode, int& identifier)
	{
		ImGuiContext& g = *GImGui;
		ImGuiWindow* window = g.CurrentWindow;
		const auto id = window->GetID(label);

		identifier = id;

		const ImVec2 pos = window->DC.CursorPos;
		const float w = ImGui::GetContentRegionAvail().x;
		const ImVec2 size = ImVec2(w, 18.f);

		const ImRect bb(pos, ImVec2(pos.x + size.x, pos.y + size.y));
		ImGui::ItemSize(bb, padding.y);

		if (!ImGui::ItemAdd(bb, id))
		{
			return false;
		}

		bool hovered, held, pressed = ImGui::ButtonBehavior(bb, id, &hovered, &held);

		static std::unordered_map<ImGuiID, bool> opened;
		static std::unordered_map<ImGuiID, float> animations;

		if (pressed)
		{
			opened[id] = !opened[id];
		}

		float& anim = animations[id];
		anim = ImLerp(anim, (hovered || opened[id]) ? 1.0f : 0.0f, g.IO.DeltaTime * 14.f);

		ImU32 text_col = IM_COL32(180 + (75 * anim), 180 + (75 * anim), 180 + (75 * anim), 255);

		ImGui::PushFont(fonts::inter_regular);
		window->DrawList->AddText(ImVec2(pos.x, pos.y + (size.y - (g.Font->Ascent - g.Font->Descent)) / 2.f), text_col, label);
		ImGui::PopFont();

		const float icon_size = 14.f;
		const ImVec2 icon_pos = ImVec2(pos.x + size.x - icon_size - 2.f, pos.y + (size.y - icon_size) / 2.f);

		window->DrawList->AddImage(framework::gui::textures::keybinds, icon_pos, ImVec2(icon_pos.x + icon_size, icon_pos.y + icon_size), ImVec2(0, 0), ImVec2(1, 1), text_col);

		if (opened[id])
		{
			ImGui::SetNextWindowPos(ImVec2(pos.x + size.x + 5.f, pos.y));
			ImGui::SetNextWindowSize(ImVec2(100.f, 0.0f));

			ImGui::PushStyleColor(ImGuiCol_WindowBg, background_col);
			ImGui::PushStyleColor(ImGuiCol_Border, IM_COL32(40, 40, 40, 0));
			ImGui::PushStyleVar(ImGuiStyleVar_WindowRounding, 3.f);
			ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(6, 6));

			std::string popup_id = "##keybind_popup_" + std::string(label);
			if (ImGui::Begin(popup_id.c_str(), NULL, ImGuiWindowFlags_NoDecoration | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_AlwaysAutoResize | ImGuiWindowFlags_NoSavedSettings | ImGuiWindowFlags_Tooltip))
			{
				ImGuiWindow* popup_window = ImGui::GetCurrentWindow();
				ImVec2 p_min = popup_window->Pos;
				ImVec2 p_max = ImVec2(p_min.x + popup_window->Size.x, p_min.y + popup_window->Size.y);

				popup_window->DrawList->AddRectFilled(p_min, p_max, background_col, 2.f);
				popup_window->DrawList->AddRect(p_min, p_max, IM_COL32(45, 45, 45, 255), 2.f);

				std::string key_label = waiting_for_key[id] ? "..." : (*key >= 0 && *key < 256 ? key_names[*key] : "None");

				if (create_button(18.f, key_label.c_str()))
				{
					waiting_for_key[id] = true;
				}

				if (waiting_for_key[id])
				{
					for (int i = 0x01; i <= 0xFE; i++)
					{
						bool pressed_key = false;
						if (i >= 0x01 && i <= 0x06)
						{
							int mouse_idx = -1;
							if (i == 0x01) mouse_idx = 0;
							if (i == 0x02) mouse_idx = 1;
							if (i == 0x04) mouse_idx = 2;
							if (i == 0x05) mouse_idx = 3;
							if (i == 0x06) mouse_idx = 4;

							if (mouse_idx != -1 && ImGui::IsMouseClicked(mouse_idx))
							{
								pressed_key = true;
							}
						}
						else if (ImGui::IsKeyPressed((ImGuiKey)i))
						{
							pressed_key = true;
						}

						if (pressed_key)
						{
							if (i == VK_ESCAPE)
							{
								*key = 0;
							}
							else
							{
								*key = i;
							}
							waiting_for_key[id] = false;
							break;
						}
					}
				}

				spacing(2.f);

				static const std::vector<std::string> modes = { "Always", "Hold", "Toggle" };
				create_dropdown("##mode", mode, modes);

				if (!ImGui::IsWindowHovered(ImGuiHoveredFlags_AllowWhenBlockedByActiveItem | ImGuiHoveredFlags_AnyWindow) && ImGui::IsMouseClicked(0))
				{
					opened[id] = false;
					waiting_for_key[id] = false;
				}

				ImGui::End();
			}

			ImGui::PopStyleVar(2);
			ImGui::PopStyleColor(2);
		}

		return true;
	}
}
