#include "../framework.hpp"

namespace framework::gui
{
	struct tab_state {
		ImVec4 image_col;
	};

	bool create_tab(const char* name, ID3D11ShaderResourceView* texture, int id, int& selected)
	{
		ImGui::PushID(id);
		const ImVec2 pos = ImGui::GetCursorScreenPos();
		const float width = ImGui::GetContentRegionAvail().x;
		const float height = 38.f;
		const bool pressed = ImGui::InvisibleButton("##navigation", ImVec2(width, height));
		const bool hovered = ImGui::IsItemHovered();
		if (pressed) selected = id;
		const bool active = selected == id;
		auto draw = ImGui::GetWindowDrawList();
		if (active || hovered)
			draw->AddRectFilled(pos, ImVec2(pos.x + width, pos.y + height), active ? IM_COL32(28,32,45,255) : IM_COL32(24,27,38,220), 6.f);
		if (active) {
			draw->AddRect(pos, ImVec2(pos.x + width, pos.y + height), IM_COL32(120,125,140,220), 6.f);
			draw->AddRectFilled(ImVec2(pos.x, pos.y + 6.f), ImVec2(pos.x + 3.f, pos.y + height - 6.f), IM_COL32(245,248,255,255), 2.f);
		}
		const ImU32 color = active ? IM_COL32(250,250,255,255) : IM_COL32(160,164,176,255);
		if (texture) draw->AddImage(texture, ImVec2(pos.x + 12.f, pos.y + 11.f), ImVec2(pos.x + 28.f, pos.y + 27.f), ImVec2(0,0), ImVec2(1,1), color);
		draw->AddText(ImVec2(pos.x + 38.f, pos.y + (height - ImGui::GetTextLineHeight()) * .5f), color, name);
		ImGui::PopID();
		return active;
	}

	struct sub_tab_state {
		ImVec4 background, text;
	};

	bool create_sub_tab(const char* name, const ImVec2& size, int id, int& selected)
	{
		auto& g = *GImGui;
		auto window = g.CurrentWindow;
		auto draw = window->DrawList;
		const ImGuiID im_id = window->GetID(name);

		const ImVec2 pos = window->DC.CursorPos;
		const ImRect bb(pos, ImVec2(pos.x + size.x, pos.y + size.y));

		ImGui::ItemSize(bb, padding.y);
		if (!ImGui::ItemAdd(bb, im_id)) return false;

		bool hovered, held, pressed = ImGui::ButtonBehavior(bb, im_id, &hovered, &held);
		bool active = selected == id;

		if (pressed)
			selected = id;

		static std::unordered_map<ImGuiID, sub_tab_state> anim;
		auto& state = anim[im_id];

		ImVec4 target_text = (active || hovered || held) ? ImGui::ColorConvertU32ToFloat4(text_active_col) : ImGui::ColorConvertU32ToFloat4(text_idle_col);
		auto col = ImGui::ColorConvertU32ToFloat4(theme_col);

		state.background = ImLerp(state.background, (active || hovered) ? ImColor(col.x, col.y, col.z, 0.2f) : ImColor(20, 20, 20, 0), g.IO.DeltaTime * 6.f);
		state.text = ImLerp(state.text, target_text, g.IO.DeltaTime * 6.f);

		helpers::draw_rect(draw, pos, pos, size, IM_COL32(20, 20, 20, 255), helpers::rect_type::filled, 0.f, 1.f);
		helpers::draw_rect(draw, pos, pos, size, IM_COL32(35, 35, 35, 255), helpers::rect_type::normal, 0.f, 1.f);

		helpers::draw_rect(draw, pos, pos, size, ImGui::ColorConvertFloat4ToU32(state.background), helpers::rect_type::filled, 0.f, 1.f);

		ImVec2 text_size = ImGui::CalcTextSize(name);

		ImVec2 text_pos = ImVec2(pos.x + (size.x - text_size.x) * 0.5f, pos.y + (size.y - (g.Font->Ascent - g.Font->Descent)) * 0.5f);
		draw->AddText(text_pos, ImGui::ColorConvertFloat4ToU32(state.text), name);

		return active;
	}
}

