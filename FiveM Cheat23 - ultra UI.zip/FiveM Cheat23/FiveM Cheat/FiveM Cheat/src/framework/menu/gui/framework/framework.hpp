#pragma once
#include "../../../../dependencies/imgui/imgui_internal.h"
#include <string>
#include <Windows.h>
#include <d3d11.h>
#include <unordered_map>

#include "../../settings.hpp"

#ifndef IM_COL32_A_SET
#define IM_COL32_A_SET(_COLOR, _ALPHA) (((_COLOR) & 0x00FFFFFF) | (((unsigned int)(_ALPHA)) << 24))
#endif

namespace framework::gui {
	namespace fonts {
		inline ImFont* inter_bold;
		inline ImFont* inter_semi_bold;
		inline ImFont* inter_regular;
		inline ImFont* esp_font;
		inline ImFont* name_font;
		inline ImFont* menu_font;
	}
	namespace textures {
		inline ID3D11ShaderResourceView* reference_logo;
		inline ID3D11ShaderResourceView* eye;
		inline ID3D11ShaderResourceView* crosshair;
		inline ID3D11ShaderResourceView* anime_bae;
		inline ID3D11ShaderResourceView* code;
		inline ID3D11ShaderResourceView* settings;
		inline ID3D11ShaderResourceView* players;
		inline ID3D11ShaderResourceView* keybinds;
		inline ID3D11ShaderResourceView* femboy;
		inline ID3D11ShaderResourceView* exploits;
	}
	namespace helpers {
		enum class rect_type {
			outlined,
			normal,
			filled
		};
		enum class text_type {
			outlined,
			normal
		};
		void draw_rect(ImDrawList* draw, const ImVec2& min, const ImVec2& max, const ImVec2& size, ImU32 col, rect_type type, float thickness, float rounding);
		void draw_text(ImDrawList* draw, const ImVec2& pos, ImU32 col, const std::string& text, text_type type);
		void draw_centered_text(ImDrawList* draw, const ImVec2& pos, const ImVec2& size, ImU32 col, const std::string& text, text_type type);
		HRESULT load_image(ID3D11Device* device, ID3D11DeviceContext* context, const uint8_t* data, size_t size, ID3D11ShaderResourceView** out);
	}
	inline int menu_key = VK_INSERT;
	inline bool should_show_menu = false;
	inline float menu_animation = 0.f;
	inline int selected_tab = 3;
	inline ImVec2 window_size{ 860.f, 580.f };
	inline float window_rounding = 8.f;

	inline float header_height = 35.f;
	inline ImVec2 padding{ 5.f, 5.f };

	inline ImVec4 get_theme_col = ImVec4(settings::settings.theme[0], settings::settings.theme[1], settings::settings.theme[2], settings::settings.theme[3]);

	inline ImU32 theme_col = ImGui::ColorConvertFloat4ToU32(get_theme_col);
	inline ImU32 background_col = IM_COL32(11, 12, 16, 255);

	inline ImU32 text_idle_col = IM_COL32(200, 200, 200, 255);
	inline ImU32 text_active_col = IM_COL32(255, 255, 255, 255);

	inline ImVec2 checkbox_size{ 18.f, 18.f };

	void initialize();
	ImGuiWindow* create_window(const std::string& name, const ImVec2& size);
	void end_window();

	bool create_checkbox(const char* label, bool* v);
	bool create_tab(const char* name, ID3D11ShaderResourceView* texture, int id, int& selected);
	bool create_sub_tab(const char* name, const ImVec2& size, int id, int& selected);
	bool create_button(float size_y, const char* label);
	bool slider_scalar(const char* label, ImGuiDataType data_type, void* p_data, const void* p_min, const void* p_max, const char* format, ImGuiSliderFlags flags);
	bool slider_float(const char* label, float* v, float v_min, float v_max, const char* format, ImGuiSliderFlags flags);
	bool slider_int(const char* label, int* v, int v_min, int v_max, const char* format, ImGuiSliderFlags flags);
	bool create_selectable(const char* label, bool* selected);

	bool create_selectable_with_given_color(const char* label, bool* selected, ImU32 col);

	bool create_dropdown(const char* label, int* current_item, const std::vector<std::string>& items);
	bool create_color_picker(const char* label, float* col, ImGuiColorEditFlags flags);

	bool update_keybind(int* key, int* mode, int id);
	bool create_keybind(const char* label, int* key, int* mode, int& identifier);

	void handle_notifications();
	void add_notification(const std::string& text);

	bool create_child(ImDrawList* draw, const ImVec2& size, const std::string& label);
	void end_child();

	inline void spacing(float size = 0)
	{
		ImGui::Dummy({ 0, padding.y + size });
	}
}