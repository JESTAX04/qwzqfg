#include "../framework.hpp"

namespace framework::gui
{
	struct checkbox_state {
		ImVec4 background, circle, text;
        float rect_offset;
	};

    bool create_checkbox(const char* label, bool* v)
    {
        auto& g = *GImGui;
        auto window = g.CurrentWindow;
        auto draw = window->DrawList;
        const auto id = window->GetID(label);

        const ImVec2 pos = window->DC.CursorPos;

        float w = ImGui::GetContentRegionAvail().x;

        const ImRect bounding_box(pos, ImVec2(pos.x + w, pos.y + 18.f));
        ImGui::ItemSize(bounding_box, padding.y);

        if (!ImGui::ItemAdd(bounding_box, id)) return false;

        bool hovered, held, pressed = ImGui::ButtonBehavior(bounding_box, id, &hovered, &held);

        static std::unordered_map<ImGuiID, checkbox_state> anim;
        auto& state = anim[id];

        state.rect_offset = ImLerp(state.rect_offset, *v ? 2.f : 10.f, g.IO.DeltaTime * 6.f);
        state.background = ImLerp(state.background, *v ? ImColor(theme_col) : ImColor(20, 20, 20, 255), g.IO.DeltaTime * 6.f);

        ImVec4 target_text = (hovered || held) ? ImGui::ColorConvertU32ToFloat4(text_active_col) : ImGui::ColorConvertU32ToFloat4(text_idle_col);

        state.text = ImLerp(state.text, target_text, g.IO.DeltaTime * 6.f);

        if (pressed)
        {
            *v = !(*v);
            ImGui::MarkItemEdited(id);
        }

        window->DrawList->AddRectFilled(ImVec2(pos.x + w - 18.f, bounding_box.Min.y), bounding_box.Max, ImColor(20, 20, 20, 255), 5.f);
        window->DrawList->AddRectFilled(ImVec2(pos.x + w - 18.f + state.rect_offset, bounding_box.Min.y + state.rect_offset), ImVec2(bounding_box.Max.x - state.rect_offset, bounding_box.Max.y - state.rect_offset), ImColor(state.background), 3.f);
        window->DrawList->AddRect(ImVec2(pos.x + w - 18.f, bounding_box.Min.y), bounding_box.Max, IM_COL32(35, 35, 35, 255), 5.f, 0, 1.1f);

        ImVec2 text_pos = ImVec2(pos.x, pos.y + (18.f - ImGui::CalcTextSize(label).y) / 2.f);
        window->DrawList->AddText(text_pos, ImGui::GetColorU32(state.text), label);

        return pressed;
    }
}