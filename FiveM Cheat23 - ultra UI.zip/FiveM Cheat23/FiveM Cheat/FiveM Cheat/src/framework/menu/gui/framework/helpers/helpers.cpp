#include "../framework.hpp"
#include <DirectXTex/DirectXTex.h>

namespace framework::gui::helpers 
{
	void draw_rect(ImDrawList* draw, const ImVec2& min, const ImVec2& max, const ImVec2& size, ImU32 col, rect_type type, float thickness, float rounding)
	{
		ImVec2 p_min = min;
		ImVec2 p_max = ImVec2(max.x + size.x, max.y + size.y);

		switch (type)
		{
		case rect_type::outlined:
			draw->AddRect(p_min, p_max, IM_COL32(0, 0, 0, 255), rounding, ImDrawFlags_RoundCornersAll, 3.5f);
			draw->AddRect(p_min, p_max, col, rounding, ImDrawFlags_RoundCornersAll, 1.5f);
			break;
		case rect_type::normal:
			draw->AddRect(p_min, p_max, col, rounding, ImDrawFlags_RoundCornersAll, thickness);
			break;
		case rect_type::filled:
			draw->AddRectFilled(p_min, p_max, col, rounding, ImDrawFlags_RoundCornersAll);
			break;
		}
	}

	void draw_text(ImDrawList* draw, const ImVec2& pos, ImU32 col, const std::string& text, text_type type = text_type::normal)
	{
		const char* text_char = text.c_str();

		switch (type)
		{
		case text_type::normal:
			draw->AddText(pos, col, text_char);
			break;
		case text_type::outlined:

			ImU32 outline_col = IM_COL32(0, 0, 0, 255);

			draw->AddText(pos, col, text_char);
			draw->AddText(ImVec2(pos.x + 1, pos.y + 1), outline_col, text_char);
			draw->AddText(ImVec2(pos.x - 1, pos.y - 1), outline_col, text_char);
			draw->AddText(ImVec2(pos.x - 1, pos.y + 1), outline_col, text_char);
			draw->AddText(ImVec2(pos.x + 1, pos.y - 1), outline_col, text_char);

			draw->AddText(ImVec2(pos.x + 1, pos.y), outline_col, text_char);
			draw->AddText(ImVec2(pos.x - 1, pos.y), outline_col, text_char);
			draw->AddText(ImVec2(pos.x, pos.y + 1), outline_col, text_char);
			draw->AddText(ImVec2(pos.x, pos.y - 1), outline_col, text_char);
			break;
		}
	}

	void draw_centered_text(ImDrawList* draw, const ImVec2& pos, const ImVec2& size, ImU32 col, const std::string& text, text_type type = text_type::normal)
	{
		const char* text_char = text.c_str();

		ImVec2 text_size = ImGui::CalcTextSize(text_char);
		ImVec2 centered_pos = ImVec2(pos.x + (text_size.x - size.x), pos.y + (text_size.y - size.y));

		switch (type)
		{
		case text_type::normal:
			draw->AddText(centered_pos, col, text_char);
			break;
		case text_type::outlined:
			ImU32 outline_col = IM_COL32(0, 0, 0, 255);

			draw->AddText(centered_pos, col, text_char);
			draw->AddText(ImVec2(centered_pos.x + 1, centered_pos.y + 1), outline_col, text_char);
			draw->AddText(ImVec2(centered_pos.x - 1, centered_pos.y - 1), outline_col, text_char);
			draw->AddText(ImVec2(centered_pos.x - 1, centered_pos.y + 1), outline_col, text_char);
			draw->AddText(ImVec2(centered_pos.x + 1, centered_pos.y - 1), outline_col, text_char);

			draw->AddText(ImVec2(centered_pos.x + 1, centered_pos.y), outline_col, text_char);
			draw->AddText(ImVec2(centered_pos.x - 1, centered_pos.y), outline_col, text_char);
			draw->AddText(ImVec2(centered_pos.x, centered_pos.y + 1), outline_col, text_char);
			draw->AddText(ImVec2(centered_pos.x, centered_pos.y - 1), outline_col, text_char);
			break;
		}
	}

	HRESULT load_image(ID3D11Device* device, ID3D11DeviceContext* context, const uint8_t* data, size_t size, ID3D11ShaderResourceView** out)
	{
		DirectX::ScratchImage image;
		DirectX::TexMetadata metadata;

		HRESULT hr = LoadFromWICMemory(data, size, DirectX::WIC_FLAGS_NONE, &metadata, image);
		if (FAILED(hr))
			return hr;

		ID3D11Resource* texture = nullptr;
		hr = CreateTexture(device, image.GetImages(), image.GetImageCount(), metadata, &texture);
		if (FAILED(hr))
			return hr;

		hr = device->CreateShaderResourceView(texture, nullptr, out);

		context->GenerateMips(*out);

		texture->Release();
		return hr;
	}

}