#include "framework.hpp"
#include "../assets/font.hpp"
#include "../assets/images.hpp"
#include "../assets/reference_logo.hpp"
#include "../../../../dependencies/imgui/imgui_freetype.h"

#include "../../overlay/overlay.hpp"

namespace framework::gui {
	void initialize()
	{
		ImGuiIO& io = ImGui::GetIO();
        ImGuiStyle& style = ImGui::GetStyle();
        style.WindowRounding = 8.f;
        style.ChildRounding = 6.f;
        style.FrameRounding = 4.f;
        style.ScrollbarRounding = 5.f;
        style.WindowPadding = ImVec2(10.f, 10.f);
        style.FramePadding = ImVec2(10.f, 7.f);
        style.ItemSpacing = ImVec2(8.f, 7.f);
        style.GrabRounding = 5.f;
        style.ScrollbarSize = 9.f;
        style.WindowBorderSize = 1.f;
        style.ChildBorderSize = 1.f;
        style.Colors[ImGuiCol_WindowBg] = ImVec4(11/255.f, 12/255.f, 16/255.f, 1.f);
        style.Colors[ImGuiCol_ChildBg] = ImVec4(14/255.f, 15/255.f, 21/255.f, 1.f);
        style.Colors[ImGuiCol_Border] = ImVec4(32/255.f, 35/255.f, 46/255.f, 1.f);
        style.Colors[ImGuiCol_FrameBg] = ImVec4(18/255.f, 20/255.f, 28/255.f, 1.f);
        style.Colors[ImGuiCol_Text] = ImVec4(230/255.f, 232/255.f, 242/255.f, 1.f);
        style.Colors[ImGuiCol_TextDisabled] = ImVec4(110/255.f, 115/255.f, 130/255.f, 1.f);
        style.Colors[ImGuiCol_Button] = ImVec4(20/255.f, 22/255.f, 30/255.f, 1.f);
        style.Colors[ImGuiCol_ButtonHovered] = ImVec4(32/255.f, 35/255.f, 48/255.f, 1.f);
        style.Colors[ImGuiCol_ButtonActive] = ImVec4(45/255.f, 50/255.f, 68/255.f, 1.f);
        style.Colors[ImGuiCol_FrameBgHovered] = ImVec4(26/255.f, 29/255.f, 40/255.f, 1.f);
        style.Colors[ImGuiCol_Header] = ImVec4(26/255.f, 28/255.f, 38/255.f, 1.f);
        style.Colors[ImGuiCol_HeaderHovered] = ImVec4(38/255.f, 42/255.f, 56/255.f, 1.f);
        style.Colors[ImGuiCol_HeaderActive] = ImVec4(52/255.f, 58/255.f, 78/255.f, 1.f);
        style.Colors[ImGuiCol_Separator] = ImVec4(32/255.f, 35/255.f, 46/255.f, 1.f);
        style.Colors[ImGuiCol_CheckMark] = ImVec4(.92f, .94f, .98f, 1.f);
        style.Colors[ImGuiCol_SliderGrab] = ImVec4(.75f, .80f, .90f, 1.f);
        style.Colors[ImGuiCol_SliderGrabActive] = ImVec4(.96f, .97f, 1.f, 1.f);
        style.Colors[ImGuiCol_PopupBg] = ImVec4(14/255.f, 15/255.f, 21/255.f, 1.f);

		ImFontConfig cfg;
		cfg.PixelSnapH = true;
		cfg.FontDataOwnedByAtlas = false;
		cfg.OversampleH = 5;
		cfg.OversampleV = 5;
		cfg.RasterizerMultiply = 1.2f;
		cfg.FontBuilderFlags = ImGuiFreeTypeBuilderFlags_ForceAutoHint | ImGuiFreeTypeBuilderFlags_Bitmap;

		fonts::inter_bold = io.Fonts->AddFontFromMemoryTTF(inter_extra_bold, sizeof(inter_extra_bold), 12.f, &cfg);
		fonts::inter_semi_bold = io.Fonts->AddFontFromMemoryTTF(inter_semi_bold, sizeof(inter_semi_bold), 12.f, &cfg);
		fonts::inter_regular = io.Fonts->AddFontFromFileTTF("C:\\Windows\\Fonts\\tahoma.ttf", 12.f, &cfg);
		fonts::esp_font = io.Fonts->AddFontFromMemoryTTF(pixel_font, sizeof(pixel_font), 12.f, &cfg);

		// Dedicated native-size name font; keep the small pixel font for other ESP text.
		ImFontConfig name_cfg;
		name_cfg.FontDataOwnedByAtlas = false;
		name_cfg.PixelSnapH = true;
		name_cfg.OversampleH = 3;
		name_cfg.OversampleV = 2;
		name_cfg.FontBuilderFlags = ImGuiFreeTypeBuilderFlags_ForceAutoHint;
		fonts::name_font = io.Fonts->AddFontFromMemoryTTF(inter_semi_bold, sizeof(inter_semi_bold), 16.f, &name_cfg, io.Fonts->GetGlyphRangesCyrillic());
        fonts::menu_font = io.Fonts->AddFontFromMemoryTTF(inter_semi_bold, sizeof(inter_semi_bold), 14.f, &name_cfg, io.Fonts->GetGlyphRangesCyrillic());

		auto device = framework::g_overlay->get_data().d3d_device;
		auto ctx = framework::g_overlay->get_data().d3d_device_ctx;
		if (device && ctx)
		{
            helpers::load_image(device, ctx, reference_logo, sizeof(reference_logo), &textures::reference_logo);
			helpers::load_image(device, ctx, eye, sizeof(eye), &textures::eye);
			helpers::load_image(device, ctx, skull, sizeof(skull), &textures::crosshair);
			helpers::load_image(device, ctx, anime_bae, sizeof(anime_bae), &textures::anime_bae);
			helpers::load_image(device, ctx, code_icon, sizeof(code_icon), &textures::code);
			helpers::load_image(device, ctx, settings_icon, sizeof(settings_icon), &textures::settings);
			helpers::load_image(device, ctx, lab_icon, sizeof(lab_icon), &textures::exploits);
			helpers::load_image(device, ctx, femboy, sizeof(femboy), &textures::femboy);
			helpers::load_image(device, ctx, players_icon, sizeof(players_icon), &textures::players);
			helpers::load_image(device, ctx, keyboard_data, sizeof(keyboard_data), &textures::keybinds);
		}
	}
}