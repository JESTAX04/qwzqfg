#include "../framework.hpp"

namespace framework::gui
{
	struct button_state {
		ImVec4 background, text;
	};

    bool create_button(float size_y, const char* label)
    {
        auto& g = *GImGui;
        auto window = g.CurrentWindow;
        auto draw = window->DrawList;
        const ImGuiID id = window->GetID(label);

        const auto w = ImGui::GetContentRegionAvail().x;

        ImVec2 size{ w, size_y };

        const ImVec2 pos = window->DC.CursorPos;
        const ImRect bb(pos, ImVec2(pos.x + size.x, pos.y + size.y));

        ImGui::ItemSize(bb, padding.y);
        if (!ImGui::ItemAdd(bb, id)) return false;

        bool hovered, held, pressed = ImGui::ButtonBehavior(bb, id, &hovered, &held);

        static std::unordered_map<ImGuiID, button_state> anim;
        auto& state = anim[id];

        ImVec4 target_text = (hovered || held) ? ImGui::ColorConvertU32ToFloat4(text_active_col) : ImGui::ColorConvertU32ToFloat4(text_idle_col);
        auto col = ImGui::ColorConvertU32ToFloat4(theme_col);

        state.background = ImLerp(state.background, hovered ? ImColor(col.x, col.y, col.z, 0.2f) : ImColor(20, 20, 20, 0), g.IO.DeltaTime * 6.f);
        state.text = ImLerp(state.text, target_text, g.IO.DeltaTime * 6.f);

        helpers::draw_rect(draw, pos, pos, size, IM_COL32(20, 20, 20, 255), helpers::rect_type::filled, 0.f, 1.f);
        helpers::draw_rect(draw, pos, pos, size, IM_COL32(35, 35, 35, 255), helpers::rect_type::normal, 0.f, 1.f);

        helpers::draw_rect(draw, pos, pos, size, ImGui::ColorConvertFloat4ToU32(state.background), helpers::rect_type::filled, 0.f, 1.f);

        ImVec2 text_size = ImGui::CalcTextSize(label);

        ImVec2 text_pos = ImVec2(pos.x + (size.x - text_size.x) * 0.5f, pos.y + (size.y - (g.Font->Ascent - g.Font->Descent)) * 0.5f);
        draw->AddText(text_pos, ImGui::ColorConvertFloat4ToU32(state.text), label);

        return pressed;
    }
}
