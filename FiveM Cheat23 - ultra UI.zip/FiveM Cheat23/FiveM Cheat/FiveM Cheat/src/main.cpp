#include "framework/engine/initialize.hpp"
#include <iostream>
#include "framework/menu/settings.hpp"

int main( )
{
	settings::mutex = CreateMutexA(nullptr, TRUE, "_mtx");
	if (GetLastError() == ERROR_ALREADY_EXISTS) {
		MessageBoxA(nullptr, "Already open", "", ERROR);
		Sleep(3000);
		return 0;
	}

	GetSystemInfo(&utilities::sys_info);

	framework::engine::initialize();

	std::cin.get();

	if (settings::mutex) {
		ReleaseMutex(settings::mutex);
		CloseHandle(settings::mutex);
	}
} 