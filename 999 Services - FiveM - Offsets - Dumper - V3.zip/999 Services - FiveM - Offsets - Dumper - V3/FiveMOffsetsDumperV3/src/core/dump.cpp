// language: C++, file: src/core/dump.cpp, target: Windows 11, MSVC, x64
#include "core/dump.hpp"

#include <algorithm>
#include <ctime>
#include <fstream>
#include <iomanip>
#include <set>
#include <sstream>

namespace dmp::out {
namespace {

std::string hex64(uint64_t v, int width = 16) {
    std::ostringstream ss;
    ss << "0x" << std::hex << std::uppercase << std::setfill('0') << std::setw(width) << v;
    return ss.str();
}

std::string rva32(uint32_t v) {
    std::ostringstream ss;
    ss << "0x" << std::hex << std::uppercase << std::setfill('0') << std::setw(8) << v;
    return ss.str();
}

std::string json_escape(const std::string& s) {
    std::string o;
    o.reserve(s.size() + 8);
    for (char c : s) {
        switch (c) {
        case '"':  o += "\\\""; break;
        case '\\': o += "\\\\"; break;
        case '\n': o += "\\n";  break;
        case '\r': o += "\\r";  break;
        case '\t': o += "\\t";  break;
        default:
            if (static_cast<unsigned char>(c) < 0x20) {
                char buf[8];
                std::snprintf(buf, sizeof(buf), "\\u%04X", c);
                o += buf;
            } else {
                o += c;
            }
        }
    }
    return o;
}

std::string status_counts(const Bundle& b) {
    std::ostringstream ss;
    uint32_t ok = 0, bad = 0;
    for (const rv::Result& r : b.symbols) {
        if (r.verify.status == rv::Status::Ok) ++ok; else ++bad;
    }
    ss << ok << " verified, " << bad << " not";
    return ss.str();
}

}  // namespace

std::string sanitize_identifier(const std::string& raw) {
    std::string o;
    o.reserve(raw.size() + 4);
    for (char c : raw) {
        const bool ok = (c >= 'A' && c <= 'Z') || (c >= 'a' && c <= 'z') ||
                        (c >= '0' && c <= '9') || c == '_';
        o += ok ? c : '_';
    }
    if (o.empty()) o = "unnamed";
    if (o[0] >= '0' && o[0] <= '9') o.insert(o.begin(), '_');
    return o;
}

std::filesystem::path module_dir(const std::filesystem::path& root,
                                 const std::string& module_name) {
    std::string safe = module_name.empty() ? "unknown_module" : module_name;
    for (char& c : safe) {
        if (c == '\\' || c == '/' || c == ':' || c == '*' || c == '?' ||
            c == '"' || c == '<' || c == '>' || c == '|') {
            c = '_';
        }
    }
    return root / safe;
}

// --------------------------------------------------------------------- JSON --

std::string to_json(const Bundle& b) {
    std::ostringstream j;
    const Provenance& p = b.prov;

    j << "{\n";
    j << "  \"schema\": \"999services.offsets/1\",\n";
    j << "  \"tool\": \"" << json_escape(p.tool) << "\",\n";
    j << "  \"generated_utc\": \"" << json_escape(p.generated_utc) << "\",\n";
    j << "  \"module\": {\n";
    j << "    \"name\": \"" << json_escape(p.module) << "\",\n";
    j << "    \"build\": " << p.build << ",\n";
    j << "    \"image_path\": \"" << json_escape(p.image_path) << "\",\n";
    j << "    \"load_base\": \"" << hex64(p.load_base) << "\",\n";
    j << "    \"size\": \"" << hex64(p.module_size, 8) << "\",\n";
    j << "    \"pe_timestamp\": \"" << hex64(p.pe_timestamp, 8) << "\",\n";
    j << "    \"code_hash_fnv64\": \"" << hex64(p.code_hash) << "\",\n";
    j << "    \"code_sections\": \"" << json_escape(p.code_sections) << "\"\n";
    j << "  },\n";
    j << "  \"scan\": { \"patterns\": " << b.patterns_total
      << ", \"duration_ms\": " << b.scan_ms
      << ", \"verified\": \"" << json_escape(status_counts(b)) << "\" },\n";

    j << "  \"symbols\": [\n";
    for (size_t i = 0; i < b.symbols.size(); ++i) {
        const rv::Result& r = b.symbols[i];
        j << "    {"
          << "\"name\": \"" << json_escape(r.name) << "\", "
          << "\"kind\": \"" << rv::kind_name(r.kind) << "\", "
          << "\"status\": \"" << rv::status_name(r.verify.status) << "\", "
          << "\"rva\": \"" << rva32(r.rva) << "\", "
          << "\"address\": \"" << hex64(r.address) << "\", "
          << "\"match_rva\": \"" << rva32(r.match_rva) << "\", "
          << "\"from_code\": " << (r.from_code ? "true" : "false") << ", "
          << "\"refs\": " << r.refs << ", "
          << "\"readable\": " << (r.verify.readable ? "true" : "false") << ", "
          << "\"executable\": " << (r.verify.executable ? "true" : "false") << ", "
          << "\"in_image\": " << (r.verify.in_image ? "true" : "false") << ", "
          << "\"probe\": \"" << hex64(r.verify.probe) << "\", "
          << "\"pattern\": \"" << json_escape(r.pattern) << "\", "
          << "\"operand_offset\": " << r.operand_offset << ", "
          << "\"target_delta\": " << r.target_delta
          << "}";
        if (i + 1 < b.symbols.size()) j << ",";
        j << "\n";
    }
    j << "  ]";

    if (b.rtti.enumerated > 0) {
        j << ",\n  \"rtti\": {\n";
        j << "    \"vftables_found\": " << b.rtti.enumerated << ",\n";
        j << "    \"classes_named\": " << b.rtti.named << ",\n";
        j << "    \"signatures\": " << b.rtti.signatures << ",\n";
        j << "    \"field_sets\": " << b.rtti.field_sets << ",\n";
        j << "    \"tables\": [\n";
        for (size_t i = 0; i < b.rtti.tables.size(); ++i) {
            const rtti::Vtable& t = b.rtti.tables[i];
            j << "      { \"vftable_rva\": \"" << rva32(t.rva) << "\", "
              << "\"col_rva\": \"" << rva32(t.col_rva) << "\", "
              << "\"class\": \"" << json_escape(t.class_name) << "\", "
              << "\"name\": \"" << json_escape(t.short_name) << "\", "
              << "\"methods\": [";
            for (size_t k = 0; k < t.methods.size(); ++k) {
                const rtti::Method& m = t.methods[k];
                j << "{ \"slot\": " << m.slot
                  << ", \"rva\": \"" << rva32(m.rva) << "\""
                  << ", \"pattern\": \"" << json_escape(m.has_signature ? m.sig.pattern.str() : std::string()) << "\"";
                if (!m.fields.empty()) {
                    j << ", \"fields\": [";
                    for (size_t f = 0; f < m.fields.size(); ++f) {
                        const dis::FieldAccess& fa = m.fields[f];
                        j << "{ \"field\": \"" << rva32(fa.field) << "\""
                          << ", \"size\": " << fa.size
                          << ", \"deref_delta\": " << fa.deref_delta
                          << ", \"read\": " << (fa.read ? "true" : "false")
                          << ", \"write\": " << (fa.write ? "true" : "false")
                          << ", \"float\": " << (fa.is_float ? "true" : "false")
                          << " }";
                        if (f + 1 < m.fields.size()) j << ", ";
                    }
                    j << "]";
                }
                j << " }";
                if (k + 1 < t.methods.size()) j << ", ";
            }
            j << "] }";
            if (i + 1 < b.rtti.tables.size()) j << ",";
            j << "\n";
        }
        j << "    ]\n  }";
    }

    j << "\n}\n";
    return j.str();
}

// ------------------------------------------------------------------- header --

std::string to_header(const Bundle& b) {
    std::ostringstream h;
    const Provenance& p = b.prov;

    h << "#pragma once\n";
    h << "// Generated by " << p.tool << "\n";
    h << "// " << p.generated_utc << "\n";
    h << "//\n";
    h << "// module        " << p.module << "\n";
    h << "// build         " << p.build << "\n";
    h << "// load base     " << hex64(p.load_base) << "\n";
    h << "// image size    " << hex64(p.module_size, 8) << "\n";
    h << "// pe timestamp  " << hex64(p.pe_timestamp, 8) << "\n";
    h << "// code hash     " << hex64(p.code_hash) << "  (FNV-1a over executable sections)\n";
    h << "// code sections " << p.code_sections << "\n";
    h << "//\n";
    h << "// Every rva below is relative to the load base. Re-run the dumper after every\n";
    h << "// game or FiveM update: nothing here is stable across a PE timestamp change, and\n";
    h << "// `pattern` + `operand_offset` + `target_delta` are what let it be re-resolved\n";
    h << "// rather than guessed.\n";
    // <cstddef> as well as <cstdint>: the table and the recovered offsets are typed
    // std::size_t and std::ptrdiff_t, and neither is guaranteed by <cstdint> alone.
    // A generated header that does not compile on its own is not an artifact.
    h << "#include <cstddef>\n#include <cstdint>\n\n";
    h << "namespace fivem_offsets {\n\n";

    h << "enum class Kind : std::uint8_t {\n";
    h << "    Function,       // call base + rva\n";
    h << "    Instruction,    // patch site at base + rva\n";
    h << "    GlobalPointer,  // *(base + rva) is the object\n";
    h << "    DataGlobal,     // base + rva is the address of the global\n";
    h << "    Vtable,         // *(base + rva) is the first virtual method\n";
    h << "    FieldOffset,    // a byte offset inside an object, not an address\n";
    h << "    DerefChain,     // (field, then deref, then offset)\n";
    h << "    Unknown\n";
    h << "};\n\n";

    h << "inline constexpr std::int32_t kNoOperand = -1;\n\n";

    h << "struct Entry {\n";
    h << "    const char*  name;\n";
    h << "    Kind         kind;\n";
    h << "    std::uint32_t rva;             // as dumped, on this build only\n";
    h << "    const char*  pattern;          // signature to re-resolve it\n";
    h << "    std::int32_t operand_offset;   // kNoOperand = direct\n";
    h << "    std::int32_t target_delta;\n";
    h << "};\n\n";

    h << "// Re-resolution: when operand_offset < 0 the target is base + match + delta.\n";
    h << "// Otherwise read a disp32 at (match + operand_offset + 1) and the target is\n";
    h << "// base + match + operand_offset + 5 + disp32.\n";
    h << "// Kind::FieldOffset rows are the exception: the rva column carries the byte\n";
    h << "// offset itself, not an address, and re-resolution re-reads the disp32 at\n";
    h << "// (match + operand_offset) after a fresh scan of `pattern`.\n";
    h << "inline constexpr Entry kEntries[] = {\n";
    for (const rv::Result& r : b.symbols) {
        h << "    { \"" << r.name << "\", Kind::" << [&] {
            switch (r.kind) {
            case rv::Kind::Function:      return "Function";
            case rv::Kind::Instruction:   return "Instruction";
            case rv::Kind::GlobalPointer: return "GlobalPointer";
            case rv::Kind::DataGlobal:    return "DataGlobal";
            case rv::Kind::Vtable:        return "Vtable";
            case rv::Kind::FieldOffset:   return "FieldOffset";
            case rv::Kind::DerefChain:    return "DerefChain";
            case rv::Kind::Unknown:       break;
            }
            return "Unknown";
        }() << ", "
          << rva32(r.rva) << "u, \"" << r.pattern << "\", "
          << r.operand_offset << ", " << r.target_delta << " },\n";
    }
    h << "};\n";
    h << "inline constexpr std::size_t kEntryCount = sizeof(kEntries) / sizeof(kEntries[0]);\n\n";

    h << "namespace symbols {\n";
    for (const rv::Result& r : b.symbols) {
        h << "inline constexpr std::uint32_t " << sanitize_identifier(r.name)
          << " = " << rva32(r.rva) << "u;  // " << rv::kind_name(r.kind)
          << " / " << rv::status_name(r.verify.status) << "\n";
    }
    h << "}  // namespace symbols\n";

    if (b.rtti.enumerated > 0) {
        h << "\n// ------------------------------------------------------------- RTTI --\n";
        h << "// Recovered from the image's own RTTI. vftable rvas are stable only for the\n";
        h << "// build above; the per-method patterns are what survives a rebuild.\n";
        h << "namespace classes {\n";

        // A class with multiple inheritance owns one vftable per base sub-object, so
        // the same type descriptor appears more than once. Emitting one namespace
        // per table would redefine every identifier in it, so namespaces are made
        // unique and identifiers are deduplicated within each one.
        std::set<std::string> used_namespaces;
        std::set<std::string> used_identifiers;

        for (const rtti::Vtable& t : b.rtti.tables) {
            if (t.methods.empty()) continue;

            const std::string base = t.short_name.empty()
                                   ? ("unnamed_" + rva32(t.rva))
                                   : t.short_name;
            std::string name = sanitize_identifier(base);
            if (used_namespaces.count(name)) {
                name = sanitize_identifier(base + "_" + rva32(t.rva));
            }
            for (int n = 2; used_namespaces.count(name); ++n) {
                name = sanitize_identifier(base + "_" + rva32(t.rva) + "_" + std::to_string(n));
            }
            used_namespaces.insert(name);
            used_identifiers.clear();
            used_identifiers.insert("vtable_rva");

            h << "\nnamespace " << name << " {\n";
            h << "// " << (t.class_name.empty() ? "<no type descriptor>" : t.class_name) << "\n";
            h << "inline constexpr std::uint32_t vtable_rva = " << rva32(t.rva) << "u;\n";

            for (const rtti::Method& m : t.methods) {
                if (m.has_signature) {
                    const std::string id = "method_" + std::to_string(m.slot);
                    if (used_identifiers.insert(id).second) {
                        h << "inline constexpr std::uint32_t " << id
                          << " = " << rva32(m.rva) << "u;  // sig: "
                          << m.sig.pattern.str() << "\n";
                    }
                }
                for (const dis::FieldAccess& f : m.fields) {
                    std::ostringstream raw;
                    if (f.indirect()) {
                        raw << "deref_" << rva32(f.field) << "_plus_" << rva32(f.deref_delta);
                    } else {
                        raw << "field_" << rva32(f.field);
                    }
                    const std::string label = sanitize_identifier(raw.str());
                    // Several methods reach the same field; the first mention wins,
                    // because the offset means the same thing every time.
                    if (!used_identifiers.insert(label).second) continue;

                    h << "inline constexpr std::ptrdiff_t " << label << " = "
                      << rva32(f.indirect() ? f.deref_delta : f.field) << ";  // "
                      << f.size << "B " << (f.read ? "r" : "") << (f.write ? "w" : "")
                      << (f.is_float ? " float" : "")
                      << ", via slot " << m.slot << "\n";
                }
            }
            h << "}  // namespace " << name << "\n";
        }
        h << "\n}  // namespace classes\n";
    }

    h << "\n}  // namespace fivem_offsets\n";
    return h.str();
}

// -------------------------------------------------------------------- table --

std::string to_table(const Bundle& b) {
    std::ostringstream t;
    const Provenance& p = b.prov;

    // Line-oriented on purpose: it stays readable when opened by hand, and it
    // diffs cleanly, whereas reformatting a JSON blob rewrites the whole file and
    // buries the one line that actually changed.
    t << "# 999services offsets table v1\n";
    t << "tool " << p.tool << "\n";
    t << "generated " << p.generated_utc << "\n";
    t << "module " << p.module << "\n";
    t << "build " << p.build << "\n";
    t << "base " << hex64(p.load_base) << "\n";
    t << "size " << hex64(p.module_size, 8) << "\n";
    t << "pets " << hex64(p.pe_timestamp, 8) << "\n";
    t << "codehash " << hex64(p.code_hash) << "\n";
    t << "#name\tkind\tstatus\trva\toperand_offset\ttarget_delta\tpattern\n";

    for (const rv::Result& r : b.symbols) {
        t << r.name << '\t'
          << rv::kind_name(r.kind) << '\t'
          << rv::status_name(r.verify.status) << '\t'
          << rva32(r.rva) << '\t'
          << r.operand_offset << '\t'
          << r.target_delta << '\t'
          << r.pattern << '\n';
    }

    if (b.rtti.enumerated > 0) {
        t << "#\n#rtti\t" << b.rtti.enumerated << " vftables, "
          << b.rtti.named << " named, "
          << b.rtti.signatures << " signatures, "
          << b.rtti.field_sets << " field sets\n";
        t << "#class\tvftable_rva\tslot\tmethod_rva\tpattern\tfield\tsize\tderef\n";
        for (const rtti::Vtable& v : b.rtti.tables) {
            for (const rtti::Method& m : v.methods) {
                if (m.fields.empty() && !m.has_signature) continue;
                t << (v.short_name.empty() ? std::string("<unnamed>") : v.short_name) << '\t'
                  << rva32(v.rva) << '\t'
                  << m.slot << '\t'
                  << rva32(m.rva) << '\t'
                  << (m.has_signature ? m.sig.pattern.str() : std::string("-")) << '\t';
                if (m.fields.empty()) {
                    t << "-\t0\t-1\n";
                } else {
                    for (size_t i = 0; i < m.fields.size(); ++i) {
                        const dis::FieldAccess& f = m.fields[i];
                        if (i) t << "\t\t\t\t\t";
                        t << rva32(f.field) << '\t' << f.size << '\t' << f.deref_delta << '\n';
                    }
                }
            }
        }
    }
    return t.str();
}

// ------------------------------------------------------------------- report --

std::string to_report(const Bundle& b) {
    std::ostringstream r;
    const Provenance& p = b.prov;

    r << "# Dump report - " << p.module << "\n\n";
    r << "| field | value |\n|---|---|\n";
    r << "| generated | " << p.generated_utc << " |\n";
    r << "| tool | " << p.tool << " |\n";
    r << "| module | " << p.module << " |\n";
    r << "| build | " << p.build << " |\n";
    r << "| load base | " << hex64(p.load_base) << " |\n";
    r << "| image size | " << hex64(p.module_size, 8) << " |\n";
    r << "| PE timestamp | " << hex64(p.pe_timestamp, 8) << " |\n";
    r << "| code hash | " << hex64(p.code_hash) << " |\n";
    r << "| code sections | " << p.code_sections << " |\n";
    r << "| scan time | " << b.scan_ms << " ms |\n\n";

    uint32_t ok = 0, not_found = 0, ambiguous = 0, unverified = 0, other = 0;
    for (const rv::Result& s : b.symbols) {
        switch (s.verify.status) {
        case rv::Status::Ok:         ++ok; break;
        case rv::Status::NotFound:   ++not_found; break;
        case rv::Status::Ambiguous:  ++ambiguous; break;
        case rv::Status::Unverified: ++unverified; break;
        default:                     ++other; break;
        }
    }
    r << "## Patterns\n\n";
    r << "- requested: " << b.patterns_total << "\n";
    r << "- verified: " << ok << "\n";
    r << "- not found: " << not_found << "\n";
    r << "- ambiguous (>1 match in code): " << ambiguous << "\n";
    r << "- unverified (matched outside code): " << unverified << "\n";
    r << "- other failures: " << other << "\n\n";

    if (not_found || ambiguous || unverified || other) {
        r << "## Not clean\n\n";
        r << "| symbol | status | note |\n|---|---|---|\n";
        for (const rv::Result& s : b.symbols) {
            if (s.verify.status == rv::Status::Ok) continue;
            const char* note = "";
            switch (s.verify.status) {
            case rv::Status::NotFound:    note = "pattern absent on this build"; break;
            case rv::Status::Ambiguous:   note = "more than one match; needs a longer signature"; break;
            case rv::Status::Unverified:  note = "matched outside executable memory"; break;
            case rv::Status::NotReadable: note = "resolved but the page does not read"; break;
            case rv::Status::NotExecutable: note = "resolved into non-executable memory"; break;
            case rv::Status::NullPointer: note = "dereferenced to null"; break;
            case rv::Status::DerefFailed: note = "dereference landed on unmapped memory"; break;
            case rv::Status::OutsideImage:note = "outside the module image"; break;
            default: break;
            }
            r << "| " << s.name << " | " << rv::status_name(s.verify.status)
              << " | " << note << " |\n";
        }
        r << "\n";
    }

    if (b.rtti.enumerated > 0) {
        r << "## RTTI\n\n";
        r << "- vftables confirmed: " << b.rtti.enumerated << "\n";
        r << "- classes named: " << b.rtti.named << "\n";
        r << "- unique method signatures: " << b.rtti.signatures << "\n";
        r << "- methods with recovered fields: " << b.rtti.field_sets << "\n\n";

        if (!b.rtti.tables.empty()) {
            r << "| class | vftable | methods | fields |\n|---|---|---|---|\n";
            uint32_t shown = 0;
            for (const rtti::Vtable& t : b.rtti.tables) {
                if (shown++ >= 60) break;
                uint32_t fields = 0;
                for (const rtti::Method& m : t.methods) fields += static_cast<uint32_t>(m.fields.size());
                r << "| " << (t.short_name.empty() ? "<unnamed>" : t.short_name)
                  << " | " << rva32(t.rva)
                  << " | " << t.methods.size()
                  << " | " << fields << " |\n";
            }
            r << "\n";
        }
    }
    r << "---\n\nRe-run after every game or FiveM update. The `pattern` and\n";
    r << "`operand_offset`/`target_delta` columns in `offsets.table` are what let a\n";
    r << "consumer re-resolve these addresses instead of trusting the frozen rvas.\n";
    return r.str();
}

// -------------------------------------------------------------------- write --

Written write_all(const Bundle& b, const WriteOptions& opt) {
    Written w;
    std::error_code ec;

    const std::filesystem::path dir = module_dir(opt.out_dir, b.prov.module);
    std::filesystem::create_directories(dir, ec);
    if (ec) {
        w.errors.push_back("cannot create " + dir.string() + ": " + ec.message());
        return w;
    }

    auto emit = [&](const char* filename, bool enabled, const std::string& text) {
        if (!enabled) return;
        const std::filesystem::path path = dir / filename;
        std::ofstream f(path, std::ios::binary | std::ios::trunc);
        if (!f) {
            w.errors.push_back("cannot open " + path.string());
            return;
        }
        f.write(text.data(), static_cast<std::streamsize>(text.size()));
        if (!f) {
            w.errors.push_back("short write to " + path.string());
            return;
        }
        w.paths.push_back(path);
    };

    emit("offsets.json",  opt.write_json,   to_json(b));
    emit("offsets.hpp",   opt.write_header, to_header(b));
    emit("offsets.table", opt.write_table,  to_table(b));
    emit("report.md",     opt.write_report, to_report(b));

    if (!opt.include_rtti) {
        // The RTTI block is embedded in each artifact rather than written
        // separately, so "exclude" is honoured by the caller not calling recover().
    }
    return w;
}

}  // namespace dmp::out
