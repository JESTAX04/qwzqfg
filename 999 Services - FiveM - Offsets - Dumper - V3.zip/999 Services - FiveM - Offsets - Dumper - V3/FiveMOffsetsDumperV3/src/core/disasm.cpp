// language: C++, file: src/core/disasm.cpp, target: Windows 11, MSVC, x64
#include "core/disasm.hpp"

#include <algorithm>
#include <cstring>

namespace dmp::dis {
namespace {

constexpr uint32_t kMaxFieldOffset = 0x4000;  // beyond this it is not a field

enum class RSrc : uint8_t { None, This, Deref };

struct RegState {
    RSrc     src   = RSrc::None;
    uint32_t field = 0;   // meaningful for Deref
};

struct MemOp {
    bool    valid        = false;
    int     base_reg     = -1;
    int     index_reg    = -1;
    int     scale        = 1;
    int64_t disp         = 0;
    bool    rip_relative = false;
};

struct Cursor {
    const uint8_t* buf = nullptr;
    uint32_t       size = 0;
    uint32_t       pos  = 0;

    bool has(uint32_t n) const { return pos + n <= size; }
    uint8_t at(uint32_t i) const { return buf[i]; }
    uint8_t cur() const { return buf[pos]; }
};

// Volatile under the MSVC x64 convention. A call destroys them, so any register
// that was tracking `this` stops being trustworthy the moment one is crossed.
bool is_volatile(int reg) {
    switch (reg) {
    case 0: case 1: case 2:                    // rax rcx rdx
    case 8: case 9: case 10: case 11:          // r8..r11
        return true;
    default:
        return false;
    }
}

// Decodes ModRM (plus SIB and displacement) at cur.pos. On success advances the
// cursor past the operand and reports the memory form, if any.
bool decode_modrm(Cursor& c, uint8_t rex, MemOp& mem, int& reg_field) {
    if (!c.has(1)) return false;
    const uint8_t modrm = c.cur();
    ++c.pos;

    const int mod = (modrm >> 6) & 3;
    const int reg = ((modrm >> 3) & 7) | ((rex & 0x04) ? 8 : 0);
    const int rm  = (modrm & 7) | ((rex & 0x01) ? 8 : 0);
    reg_field = reg;

    if (mod == 3) {
        // Register direct: no memory operand. The caller reads reg_field and rm
        // to propagate register-to-register copies of `this`.
        mem.valid = false;
        mem.base_reg = rm;
        return true;
    }

    mem.valid = true;
    bool need_disp32 = false;

    if (rm == 4) {
        if (!c.has(1)) return false;
        const uint8_t sib = c.cur();
        ++c.pos;
        const int ss    = (sib >> 6) & 3;
        const int index = ((sib >> 3) & 7) | ((rex & 0x02) ? 8 : 0);
        const int base  = (sib & 7) | ((rex & 0x01) ? 8 : 0);
        mem.scale = 1 << ss;
        if (index != 4) mem.index_reg = index;   // index 4 encodes "no index"
        if ((sib & 7) == 5 && mod == 0) {
            need_disp32 = true;                  // no base, disp32 only
        } else {
            mem.base_reg = base;
        }
    } else if (rm == 5 && mod == 0) {
        mem.rip_relative = true;
        need_disp32 = true;
    } else {
        mem.base_reg = rm;
    }

    if (mod == 1) {
        if (!c.has(1)) return false;
        mem.disp = static_cast<int8_t>(c.cur());
        ++c.pos;
    } else if (mod == 2 || need_disp32) {
        if (!c.has(4)) return false;
        int32_t d = 0;
        std::memcpy(&d, c.buf + c.pos, 4);
        c.pos += 4;
        mem.disp = d;
    }
    return true;
}

// Advances past the immediate/offset an opcode carries, if any. Returns false when
// the form is not one this decoder knows, which stops the walk.
bool skip_imm(Cursor& c, uint32_t bytes) {
    if (!c.has(bytes)) return false;
    c.pos += bytes;
    return true;
}

struct Sink {
    std::vector<FieldAccess> out;
    uint32_t site = 0;

    void add(uint32_t field, uint32_t size, int32_t deref_delta,
             bool read, bool write, bool is_float) {
        if (field > kMaxFieldOffset) return;
        for (FieldAccess& f : out) {
            if (f.field == field && f.deref_delta == deref_delta) {
                f.read     = f.read || read;
                f.write    = f.write || write;
                f.size     = (std::max)(f.size, size);
                return;
            }
        }
        FieldAccess f;
        f.field       = field;
        f.size        = size;
        f.deref_delta = deref_delta;
        f.read        = read;
        f.write       = write;
        f.is_float    = is_float;
        f.site_rva    = site;
        out.push_back(f);
    }
};

// Records an access expressed as [base + disp] and returns the register state the
// destination register ends up holding when the instruction is a load.
int32_t chain_of(const MemOp& mem, const RegState* regs) {
    if (mem.index_reg >= 0) return -2;          // indexed addressing, not a field
    if (mem.base_reg < 0) return -2;            // RIP-relative or absolute
    const RegState& b = regs[mem.base_reg];
    if (b.src == RSrc::This) return -1;         // direct: this + disp
    if (b.src == RSrc::Deref) {
        // *(this + b.field) + disp -- only meaningful when the outer displacement
        // is zero, otherwise the chain gained an arithmetic step we cannot name.
        return static_cast<int32_t>(b.field);
    }
    return -2;
}

void clear_volatile(RegState* regs) {
    for (int i = 0; i < 16; ++i) {
        if (is_volatile(i)) regs[i] = RegState{};
    }
}

// Classifies a memory operand against `this`. Returns false when the operand does
// not reference `this` at all, in which case nothing is recorded.
bool record(const MemOp& mem, const RegState* regs, Sink& sink,
            uint32_t size, bool read, bool write, bool is_float) {
    if (!mem.valid) return false;
    const int32_t chain = chain_of(mem, regs);
    if (chain == -2) return false;

    if (chain == -1) {
        if (mem.disp < 0) return false;
        sink.add(static_cast<uint32_t>(mem.disp), size, -1, read, write, is_float);
        return true;
    }
    if (mem.disp < 0) return false;
    sink.add(static_cast<uint32_t>(chain), size, static_cast<int32_t>(mem.disp),
             read, write, is_float);
    return true;
}

}  // namespace

std::vector<FieldAccess> fields_of(const pe::Image& img, uint32_t fn_rva,
                                   uint32_t fn_end, uint32_t max_insns) {
    std::vector<FieldAccess> empty;
    if (fn_end <= fn_rva + 1) return empty;
    if (!img.in_range(fn_rva, fn_end - fn_rva)) return empty;

    Cursor c;
    c.buf  = img.at(fn_rva);
    c.size = fn_end - fn_rva;

    RegState regs[16];
    regs[kThisReg] = RegState{ RSrc::This, 0 };

    Sink sink;

    for (uint32_t insn = 0; insn < max_insns && c.pos < c.size; ++insn) {
        sink.site = fn_rva + c.pos;
        const uint32_t insn_start = c.pos;

        uint8_t  rex    = 0;
        bool     is_f3  = false;
        bool     is_66  = false;
        bool     is_f2  = false;
        bool     lock   = false;

        // Prefixes. Segment overrides (fs/gs) are accepted and ignored: they change
        // where the operand resolves, not whether it is a field of `this`.
        for (;;) {
            if (!c.has(1)) return sink.out;
            const uint8_t p = c.cur();
            if (p >= 0x40 && p <= 0x4F) { rex = p; ++c.pos; continue; }
            if (p == 0xF3) { is_f3 = true; ++c.pos; continue; }
            if (p == 0xF2) { is_f2 = true; ++c.pos; continue; }
            if (p == 0x66) { is_66 = true; ++c.pos; continue; }
            if (p == 0xF0) { lock = true; ++c.pos; continue; }
            if (p == 0x2E || p == 0x36 || p == 0x3E || p == 0x26 ||
                p == 0x64 || p == 0x65) { ++c.pos; continue; }
            break;
        }
        (void)lock;
        const bool w64 = (rex & 0x08) != 0;

        if (!c.has(1)) return sink.out;
        const uint8_t op = c.cur();
        ++c.pos;

        MemOp mem;
        int   reg_field = -1;

        switch (op) {
        // ---- push/pop, nop, control flow -------------------------------------
        case 0x90: case 0x50: case 0x51: case 0x52: case 0x53:
        case 0x54: case 0x55: case 0x56: case 0x57:
        case 0x58: case 0x59: case 0x5A: case 0x5B:
        case 0x5C: case 0x5D: case 0x5E: case 0x5F:
            break;

        case 0xC3:   // ret
        case 0xCB:   // retf
        case 0xCC:   // int3 -- padding after the function body
        case 0xC2:   // ret imm16
            if (op == 0xC2 && !skip_imm(c, 2)) return sink.out;
            return sink.out;

        case 0xE8:   // call rel32
            if (!skip_imm(c, 4)) return sink.out;
            clear_volatile(regs);
            break;

        case 0xE9:   // jmp rel32
        case 0xEB:   // jmp rel8
            return sink.out;   // control leaves; the tail is a different function

        case 0x70: case 0x71: case 0x72: case 0x73: case 0x74: case 0x75:
        case 0x76: case 0x77: case 0x78: case 0x79: case 0x7A: case 0x7B:
        case 0x7C: case 0x7D: case 0x7E: case 0x7F:
            if (!skip_imm(c, 1)) return sink.out;
            break;

        // ---- MOV family -------------------------------------------------------
        case 0x8B: {   // mov r, r/m
            if (!decode_modrm(c, rex, mem, reg_field)) return sink.out;
            const uint32_t size = w64 ? 8u : 4u;
            if (mem.valid) {
                record(mem, regs, sink, size, true, false, false);
                const int32_t chain = chain_of(mem, regs);
                if (chain == -1 && mem.disp == 0) {
                    regs[reg_field] = RegState{ RSrc::This, 0 };
                } else if (chain >= 0 && mem.disp == 0) {
                    regs[reg_field] = RegState{ RSrc::Deref, static_cast<uint32_t>(chain) };
                } else {
                    regs[reg_field] = RegState{};
                }
            } else if (mem.base_reg == kThisReg || mem.base_reg >= 0) {
                regs[reg_field] = regs[mem.base_reg];   // mov rax, rcx
            }
            break;
        }

        case 0x89: {   // mov r/m, r
            if (!decode_modrm(c, rex, mem, reg_field)) return sink.out;
            const uint32_t size = w64 ? 8u : 4u;
            if (mem.valid) record(mem, regs, sink, size, false, true, false);
            break;
        }

        case 0x8A:     // mov r8, r/m8
        case 0x8C:     // mov r/m16, sreg (ModRM, no immediate)
        case 0x8E:     // mov sreg, r/m16
            if (!decode_modrm(c, rex, mem, reg_field)) return sink.out;
            if (mem.valid) record(mem, regs, sink, 1, true, false, false);
            break;

        case 0x88:     // mov r/m8, r8
            if (!decode_modrm(c, rex, mem, reg_field)) return sink.out;
            if (mem.valid) record(mem, regs, sink, 1, false, true, false);
            break;

        case 0x8D:     // lea r, m -- computes the address, does not read it
            if (!decode_modrm(c, rex, mem, reg_field)) return sink.out;
            if (mem.valid) {
                const int32_t chain = chain_of(mem, regs);
                if (chain == -1 && mem.disp == 0) {
                    regs[reg_field] = RegState{ RSrc::This, 0 };
                } else {
                    regs[reg_field] = RegState{};
                }
            }
            break;

        case 0x8F:     // pop r/m
            if (!decode_modrm(c, rex, mem, reg_field)) return sink.out;
            if (mem.valid) record(mem, regs, sink, 8, false, true, false);
            break;

        // ---- ALU group 1 with immediate ---------------------------------------
        case 0x80: case 0x82: {   // r/m8, imm8
            if (!decode_modrm(c, rex, mem, reg_field)) return sink.out;
            if (!skip_imm(c, 1)) return sink.out;
            if (mem.valid) record(mem, regs, sink, 1, true, true, false);
            break;
        }
        case 0x81: {              // r/m32/64, imm32
            if (!decode_modrm(c, rex, mem, reg_field)) return sink.out;
            if (!skip_imm(c, 4)) return sink.out;
            if (mem.valid) record(mem, regs, sink, w64 ? 8u : 4u, true, true, false);
            break;
        }
        case 0x83: {              // r/m32/64, imm8
            if (!decode_modrm(c, rex, mem, reg_field)) return sink.out;
            if (!skip_imm(c, 1)) return sink.out;
            if (mem.valid) record(mem, regs, sink, w64 ? 8u : 4u, true, true, false);
            break;
        }

        // ---- ALU group 1 register/memory, no immediate ------------------------
        case 0x00: case 0x01: case 0x08: case 0x09:
        case 0x10: case 0x11: case 0x18: case 0x19:
        case 0x20: case 0x21: case 0x28: case 0x29:
        case 0x30: case 0x31: case 0x38: case 0x39:
            if (!decode_modrm(c, rex, mem, reg_field)) return sink.out;
            if (mem.valid) record(mem, regs, sink, (op & 1) && w64 ? 8u : (op & 1) ? 4u : 1u,
                                  true, true, false);
            break;

        // ---- TEST / NOT / NEG / MUL / IMUL / DIV / IDIV -----------------------
        case 0xF6: case 0xF7: {
            if (!decode_modrm(c, rex, mem, reg_field)) return sink.out;
            const int sub = (c.buf[c.pos - 1] >> 3) & 7;
            const uint32_t size = (op == 0xF7) ? (w64 ? 8u : 4u) : 1u;
            if (sub == 0 || sub == 1) {          // test: carries an immediate
                if (op == 0xF6) { if (!skip_imm(c, 1)) return sink.out; }
                else            { if (!skip_imm(c, 4)) return sink.out; }
            }
            if (mem.valid) record(mem, regs, sink, size,
                                  sub == 0 || sub == 1, sub >= 2, false);
            break;
        }

        // ---- MOV r/m, imm -----------------------------------------------------
        case 0xC6: {
            if (!decode_modrm(c, rex, mem, reg_field)) return sink.out;
            if (!skip_imm(c, 1)) return sink.out;
            if (mem.valid) record(mem, regs, sink, 1, false, true, false);
            break;
        }
        case 0xC7: {
            if (!decode_modrm(c, rex, mem, reg_field)) return sink.out;
            if (!skip_imm(c, 4)) return sink.out;
            if (mem.valid) record(mem, regs, sink, w64 ? 8u : 4u, false, true, false);
            break;
        }

        // ---- INC/DEC/CALL/JMP r/m ---------------------------------------------
        case 0xFE: case 0xFF: {
            if (!decode_modrm(c, rex, mem, reg_field)) return sink.out;
            const int sub = (c.buf[c.pos - 1] >> 3) & 7;
            if (op == 0xFF && (sub == 2 || sub == 3)) {   // call / callf
                clear_volatile(regs);
                break;
            }
            if (op == 0xFF && (sub == 4 || sub == 5)) return sink.out;  // jmp
            if (mem.valid) record(mem, regs, sink, 1, true, true, false);
            break;
        }

        // ---- BT/BTS/BTR/BTC, IMUL, MOVZX/MOVSX, SSE ---------------------------
        case 0x0F: {
            if (!c.has(1)) return sink.out;
            const uint8_t op2 = c.cur();
            ++c.pos;

            switch (op2) {
            case 0xB6: case 0xB7: case 0xBE: case 0xBF: {   // movzx / movsx
                if (!decode_modrm(c, rex, mem, reg_field)) return sink.out;
                const uint32_t size = (op2 == 0xB6 || op2 == 0xBE) ? 1u : 2u;
                if (mem.valid) {
                    record(mem, regs, sink, size, true, false, false);
                    const int32_t chain = chain_of(mem, regs);
                    if (chain >= 0 && mem.disp == 0) {
                        regs[reg_field] = RegState{ RSrc::Deref, static_cast<uint32_t>(chain) };
                    } else if (chain == -1 && mem.disp == 0) {
                        regs[reg_field] = RegState{ RSrc::This, 0 };
                    } else {
                        regs[reg_field] = RegState{};
                    }
                }
                break;
            }

            case 0x10: case 0x11: case 0x28: case 0x29:
            case 0x6E: case 0x7E: case 0xD6: case 0x12: case 0x13:
            case 0x14: case 0x15: case 0x16: case 0x17:
            case 0x2A: case 0x2C: case 0x2D: case 0x2E: case 0x2F:
            case 0x50: case 0x51: case 0x52: case 0x53: case 0x54:
            case 0x55: case 0x56: case 0x57: case 0x58: case 0x59:
            case 0x5A: case 0x5C: case 0x5D: case 0x5E: case 0x5F: {
                if (!decode_modrm(c, rex, mem, reg_field)) return sink.out;
                const bool store = (op2 == 0x11 || op2 == 0x29 || op2 == 0x13 ||
                                    op2 == 0x17 || op2 == 0x7E);
                uint32_t width = 16;
                bool flt = false;
                if (is_f3)      { width = 4; flt = true; }   // ss
                else if (is_f2) { width = 8; flt = true; }   // sd
                else if (is_66) { width = 8; flt = true; }   // pd
                if (op2 == 0x6E || op2 == 0x7E || op2 == 0xD6) { width = w64 ? 8u : 4u; flt = false; }
                if (op2 == 0x2A || op2 == 0x2C || op2 == 0x2D)  { width = 4; flt = true; }
                if (mem.valid) record(mem, regs, sink, width, !store, store, flt);
                break;
            }

            case 0x1F:     // multi-byte nop
                if (!decode_modrm(c, rex, mem, reg_field)) return sink.out;
                break;

            case 0xA3: case 0xAB: case 0xB3: case 0xBB:     // bt/bts/btr/btc r/m, r
            case 0xBA:                                       // group 8 with imm8
                if (!decode_modrm(c, rex, mem, reg_field)) return sink.out;
                if (op2 == 0xBA && !skip_imm(c, 1)) return sink.out;
                if (mem.valid) record(mem, regs, sink, w64 ? 8u : 4u, true, true, false);
                break;

            case 0xAF:     // imul r, r/m
                if (!decode_modrm(c, rex, mem, reg_field)) return sink.out;
                if (mem.valid) record(mem, regs, sink, w64 ? 8u : 4u, true, false, false);
                break;

            case 0x80: case 0x81: case 0x82: case 0x83:
            case 0x84: case 0x85: case 0x86: case 0x87:
            case 0x88: case 0x89: case 0x8A: case 0x8B:
            case 0x8C: case 0x8D: case 0x8E: case 0x8F:
                if (!skip_imm(c, 4)) return sink.out;       // jcc rel32
                break;

            case 0x05: case 0x07: case 0x31: case 0x34: case 0x35:
                return sink.out;   // syscall / rdtsc-shaped, no ModRM to follow

            default:
                // Unknown 0F form. Guessing a length here is how a decoder
                // desynchronises and invents fields that were never accessed.
                return sink.out;
            }
            break;
        }

        default:
            // Unknown one-byte opcode. Stop rather than guess.
            c.pos = insn_start;
            return sink.out;
        }
    }

    return sink.out;
}

}  // namespace dmp::dis
