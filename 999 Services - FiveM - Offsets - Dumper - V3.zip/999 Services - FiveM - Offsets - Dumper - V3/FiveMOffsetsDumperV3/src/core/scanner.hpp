// language: C++, file: src/core/scanner.hpp, target: Windows 11, MSVC, x64
// Pattern scanning and code-signature synthesis over a parsed PE image.
//
// Two things make this different from a per-pattern byte loop:
//
//   * scan_all() walks each executable section ONCE for the whole table. Every
//     pattern is bucketed by the value of its first fully-concrete byte, so a
//     position in the image only ever tests the handful of patterns that could
//     possibly start there. Thirty patterns cost one pass, not thirty.
//
//   * sign_code() synthesises a pattern from a function's own bytes and proves it
//     unique before emitting it. Any RIP-relative displacement inside the window
//     is wildcarded first: a displacement that survives into the emitted signature
//     is a signature that dies on the next build, and a signature that is not
//     proven unique is a signature that resolves to the wrong function.
#pragma once
#include "core/image.hpp"
#include "core/pattern.hpp"
#include "core/pdata.hpp"

#include <cstdint>
#include <optional>
#include <string>
#include <vector>

namespace dmp::scan {

// A pattern hit, carrying the section it landed in so a result can be reported
// with its provenance rather than as a bare number.
struct Match {
    uint32_t          pattern_index = 0;
    uint32_t          rva           = 0;
    const pe::Section* section      = nullptr;
};

// One pass over every executable section, all patterns at once.
// Each pattern contributes at most `max_per_pattern` matches.
std::vector<Match> scan_all(const pe::Image& img,
                            const std::vector<pat::Pattern>& pats,
                            uint32_t max_per_pattern = 8);

// One pass over the WHOLE image, including non-executable sections. Used only as
// a fallback for a pattern that was not found in code, and the caller must record
// that the hit is unverified: a byte string appearing in .rdata or .data is not a
// function and resolving it as one produces a confident, wrong offset.
std::vector<Match> scan_all_image(const pe::Image& img,
                                  const std::vector<pat::Pattern>& pats,
                                  uint32_t max_per_pattern = 4);

// Occurrences of one pattern across every executable section, counted up to `cap`.
// Stops as soon as `cap` matches are seen, so cap=2 answers "unique?" cheaply.
uint32_t count_code(const pe::Image& img, const pat::Pattern& p, uint32_t cap = 2);

// Occurrences of one pattern across the whole image, counted up to `cap`.
uint32_t count_image(const pe::Image& img, const pat::Pattern& p, uint32_t cap = 2);

// ------------------------------------------------------------- rel32 sites --

// Every x86-64 RIP-relative form places a ModRM byte with mod=00, rm=101 and a
// disp32 immediately after it, and computes RIP as (modrm + 5). That is
// independent of instruction length, so a ModRM byte can be recognised without a
// disassembler and its target recovered without knowing the opcode.
inline bool is_rip_modrm(uint8_t modrm) { return (modrm & 0xC7u) == 0x05u; }

inline int32_t disp32_at(const uint8_t* p) {
    int32_t d = 0;
    std::memcpy(&d, p, 4);
    return d;
}

// RVA the RIP-relative reference at `modrm_rva` points at, or nullopt when the
// byte is not a RIP ModRM or the computed target leaves the image.
std::optional<uint32_t> rip_target_rva(const pe::Image& img, uint32_t modrm_rva);

// Every ModRM position in [begin, begin + size) whose RIP target equals target_rva.
std::vector<uint32_t> find_rip_refs(const pe::Image& img, uint32_t target_rva,
                                    uint32_t begin, uint32_t size);

// Every E8 rel32 call in [begin, begin + size) whose destination equals target_rva.
std::vector<uint32_t> find_call_refs(const pe::Image& img, uint32_t target_rva,
                                     uint32_t begin, uint32_t size);

// Wildcards every embedded displacement inside `p` that provably targets inside
// the image, given that the pattern sits at `pattern_rva`. Conservative by design:
// a displacement is masked only when its computed target is a valid RVA, so
// ordinary constants are never sacrificed. Returns how many bytes were masked.
uint32_t mask_rel32_operands(const pe::Image& img, pat::Pattern& p, uint32_t pattern_rva);

// ------------------------------------------------------------- repair tools --

// A pattern that occurs more than once does not identify anything. stabilise()
// appends the bytes that follow the ORIGINAL site until the pattern occurs
// exactly once, so a match that shared a compiler boilerplate prefix with other
// code becomes unique.
//
// The match start never moves, which matters: operand_offset is expressed from the
// match start, so shifting it would silently point the resolution at a different
// displacement.
struct Widened {
    pat::Pattern pattern;
    uint32_t     extra = 0;    // bytes appended
    uint32_t     count = 0;    // occurrences before widening
    bool         unique = false;
};

Widened stabilise(const pe::Image& img, const pat::Pattern& p, uint32_t anchor_rva,
                  uint32_t max_extra = 96);

// A near match: the pattern differs from the bytes at `rva` in exactly
// `mismatches` of its concrete bytes. This is how a signature that stopped
// matching a patched build is located again -- the site is usually still there,
// one or two constants have moved.
struct FuzzyHit {
    uint32_t rva        = 0;
    uint32_t mismatches = 0;
    uint32_t concrete   = 0;
    bool     executable = false;
};

// Nearest matches of `p` across executable sections, best first, up to `limit`.
// Bounded by `max_bytes` of differing concrete bytes.
std::vector<FuzzyHit> fuzzy_code(const pe::Image& img, const pat::Pattern& p,
                                 uint32_t max_mismatch, uint32_t limit = 16);

// Nearest matches across the whole image, used when code holds nothing close.
std::vector<FuzzyHit> fuzzy_image(const pe::Image& img, const pat::Pattern& p,
                                  uint32_t max_mismatch, uint32_t limit = 16);

// Reads the bytes at a site and rebuilds them as a candidate signature, with every
// embedded displacement wildcarded. This is the pattern to adopt when a signature
// has drifted: it is taken from the live bytes rather than reconstructed by hand.
pat::Pattern pattern_from_site(const pe::Image& img, uint32_t rva, uint32_t length);

// ---------------------------------------------------------- signature build --

enum class Quality { Unique, Ambiguous, Absent };

struct Signature {
    pat::Pattern pattern;
    uint32_t     match_rva       = 0;   // where in the image the pattern sits
    uint32_t     anchor_rva      = 0;   // the function entry it identifies
    uint32_t     match_count     = 0;   // occurrences in code
    uint32_t     skipped         = 0;   // boilerplate bytes skipped past the entry
    uint32_t     wildcards       = 0;
    Quality      quality         = Quality::Absent;

    // How a consumer turns a future match back into the address it wants.
    //   operand_offset <  0 -> target = base + match_rva + target_delta
    //   operand_offset >= 0 -> read disp32 at (match_rva + operand_offset + 1) and
    //                          target = base + match_rva + operand_offset + 5 + disp32
    // The second form covers both an E8 call and a RIP-relative data reference:
    // the rel32 sits one byte past the opcode/ModRM in either case.
    int32_t operand_offset = -1;
    int32_t target_delta   = 0;

    bool ok() const { return quality == Quality::Unique && match_count == 1; }
};

struct SigOptions {
    uint32_t min_len    = 12;   // shortest window tried
    uint32_t max_len    = 28;   // longest window tried
    uint32_t max_skip   = 64;   // how far past the entry boilerplate may run
    bool     mask_rel32 = true;
};

// Signature for the function starting at fn_rva. Walks past shared compiler
// boilerplate (starting at the .pdata prolog length) and widens the window until
// exactly one occurrence exists in code. Returns a Signature with quality Absent
// when no unique window is found within the options.
Signature sign_code(const pe::Image& img, const pd::Inventory& inv,
                    uint32_t fn_rva, const SigOptions& opt = {});

// How many times the bytes at [fn_rva + off, fn_rva + off + len) occur in code.
// A count above one means the window is compiler boilerplate and identifies
// nothing on its own.
uint32_t shared_prefix_hits(const pe::Image& img, uint32_t fn_rva,
                            uint32_t off, uint32_t len);

}  // namespace dmp::scan
