// language: C++, file: src/core/table.hpp, target: Windows 11, MSVC, x64
// The built-in signature table.
//
// Each entry states three things the previous generation of this tool left out:
//
//   Form    how the match turns into an address. A 7-byte RIP-relative operand
//           lands on the VARIABLE; a 5-byte E8 call lands on the FUNCTION it
//           calls. Treating those the same is how a table silently pins the wrong
//           thing, because both produce a plausible number.
//
//   Kind    what the resolved address is, so a consumer knows whether to call it,
//           dereference it, or patch it.
//
//   Delta   applied AFTER resolution, never before. Adding it to the instruction
//           address first corrupts the displacement arithmetic, which is why the
//           old `extra_offset` field was a landmine the moment anyone set it.
#pragma once
#include "core/resolve.hpp"

#include <cstdint>
#include <string>

namespace dmp::tbl {

enum class Form {
    RipRelative,  // 7-byte instruction: mov/lea reg, [rip + disp32]
    Call,         // 5-byte instruction: call rel32
    Direct,       // the instruction address itself
    // An exported symbol. Nothing has to be hunted and nothing has to be
    // re-derived after a patch: the name is read straight out of the module's
    // export directory, which the loader relocates for us. For a table entry with
    // this form, `signature` carries the MANGLED EXPORT NAME rather than bytes.
    Export,
    // The match is a `mov reg, [base + disp32]` instruction and the value the
    // entry yields is that disp32 itself: a byte offset inside the object held in
    // the base register, not any address. This is how per-object offsets (a ped's
    // weapon-manager pointer, a vehicle's handling field) are carried without
    // freezing an address that the next rebuild moves.
    DispField
};

struct Entry {
    const char* name;
    const char* signature;
    Form        form;
    rv::Kind    kind;
    int32_t     target_delta;
    // Byte offset of the resolved instruction INSIDE the match, for a pattern whose
    // instruction is not at offset 0. Real tables do this constantly: a signature
    // is often anchored on preceding bytes, so the `E8` it cares about can be nine
    // bytes in. Defaulting to 0 keeps every entry that starts on its own
    // instruction meaning exactly what it did before.
    int32_t     insn_offset = 0;
};

// Operand offsets are reported relative to the MATCH start, so the value a consumer
// re-reads later lines up with the pattern that is exported alongside it.
inline int32_t operand_offset_of(Form f, int32_t insn_offset = 0) {
    switch (f) {
    case Form::RipRelative: return insn_offset + 3;
    case Form::Call:        return insn_offset + 1;
    case Form::DispField:   return insn_offset + 3;
    case Form::Direct:
    case Form::Export:      break;
    }
    return -1;
}

inline int32_t instruction_size_of(Form f) {
    switch (f) {
    case Form::RipRelative: return 7;
    case Form::Call:        return 5;
    case Form::DispField:
    case Form::Direct:
    case Form::Export:      break;
    }
    return 0;
}

inline const Entry kTable[] = {
    // Base pointers. A RIP-relative operand lands on the GLOBAL VARIABLE, so the
    // consumer dereferences it once to reach the object -- but only when the
    // instruction is a load. `48 8D 0D` is `lea`, which hands over the address of
    // the object itself, and dereferencing that reads the object's first member.
    // The Kind recorded here is the declared intent; the pipeline re-derives it
    // from the operand instruction and the bytes win when the two disagree.
    {"m_World",                "48 8B 05 ? ? ? ? 33 D2 48 8B 40 08 8A CA 48 85 C0 74 16 48 8B", Form::RipRelative, rv::Kind::GlobalPointer, 0},
    // b3751: this pattern matched 31 times. Widened from the live bytes at the
    // first site until it occurred exactly once; see --audit-live.
    {"m_ReplayInterFace",      "48 8D 0D ? ? ? ? 48 ? ? E8 ? ? ? ? 48 8D 0D ? ? ? ? 8A D8 E8 ? ? ? ? 84 DB 75 13 48 8D 0D ? ? ? ? 48 8B D7 E8 ? ? ? ? 84 C0 74 BC 8B 8F E8 02 00 00 3B 0D 30", Form::RipRelative, rv::Kind::DataGlobal, 0},
    {"m_ViewPort",             "48 8B 15 ? ? ? ? 48 8D 2D ? ? ? ? 48 8B CD", Form::RipRelative, rv::Kind::GlobalPointer, 0},
    {"m_BlipList",             "4C 8D 05 ? ? ? ? 0F B7 C1", Form::RipRelative, rv::Kind::DataGlobal, 0},
    {"m_CamGameplayDirector",  "4C 8B 35 ? ? ? ? 33 FF 32 DB", Form::RipRelative, rv::Kind::GlobalPointer, 0},
    {"aim_cped",               "48 8D 0D ? ? ? ? E8 ? ? ? ? 48 8B 0D ? ? ? ? 48 85 C9 74 05 E8 ? ? ? ? 8A CB", Form::RipRelative, rv::Kind::DataGlobal, 0},
    {"c_sky_settings",         "48 8D 0D ? ? ? ? E8 ? ? ? ? 83 25 ? ? ? ? 00 48 8D 0D ? ? ? ? F3", Form::RipRelative, rv::Kind::DataGlobal, 0},

    // Call sites. An E8 resolves to the callee, so these are function entries.
    {"m_ArmsKinematics",       "E8 ? ? ? ? 48 83 C3 60 48 FF CF 75 E6 48 8B 5C 24", Form::Call, rv::Kind::Function, 0},
    {"m_LegsKinematics",       "E8 ? ? ? ? 48 83 C3 60 48 FF CF 75 DF 48 8B 5C 24 ? 48 8B 6C 24 ? 48 8B 74 24", Form::Call, rv::Kind::Function, 0},

    // The E8 here sits three bytes into the match, so the match start is the
    // address a consumer patches, not the callee. Left as a direct instruction:
    // resolving it as a call site would point somewhere else entirely.
    {"m_InfiniteAmmo1",        "41 2B D1 E8", Form::Direct, rv::Kind::Instruction, 0},

    // Function prologues.
    {"m_GiveWeapon",           "48 89 5c 24 ? 48 89 6c 24 ? 48 89 74 24 ? 57 48 83 ec ? 41 8b f0 8b fa 48 8b d9 e8", Form::Direct, rv::Kind::Function, 0},
    {"set_ped_in_to_vehicle",  "48 8B C4 44 89 48 ? 44 89 40 ? 48 89 50 ? 48 89 48 ? 55 53 56 57 41 54 41 55 41 56 41 57 48 8D A8 ? ? ? ? 48 81 EC ? ? ? ? 83 BA", Form::Direct, rv::Kind::Function, 0},

    // Patch sites. These are instruction addresses to write at, not functions.
    // b3751: the previous signature was absent. Recovered from the nearest site
    // (1 differing byte) and widened to unique; the register moved rax -> rcx.
    {"m_SilentAim",            "48 8D 4D C0 F3 0F 10 00 F3 0F 10 48 04 F3 0F 11 45 C0 F3 0F 10 40 08", Form::Direct, rv::Kind::Instruction, 0},
    // b3751: the previous signature was absent. Recovered from the nearest site
    // (3 differing bytes, all register encodings) and unique as it stands.
    {"m_InfiniteAmmo0",        "41 2B C5 3B D0 0F 4D D0", Form::Direct, rv::Kind::Instruction, 0},
    {"m_MagicBulletsPatch",    "0F 29 4F ? 83 8F ? ? ? ? ? 48 8B 4F", Form::Direct, rv::Kind::Instruction, 0},
    {"m_InfiniteCombatRoll",   "89 81 ? ? ? ? 8B 87 ? ? ? ? F7 D0", Form::Direct, rv::Kind::Instruction, 0},
    {"m_OffsetPool",           "0F B7 CA 83 F9 07 7F 5E", Form::Direct, rv::Kind::Instruction, 0},
    {"m_Speed",                "0F 2F C2 77 ? F3 0F 10 83 ? ? ? ? 48 83 C4", Form::Direct, rv::Kind::Instruction, 0},
    {"m_VehicleEngineHealth",  "F3 0F 11 80 ? ? ? ? 48 8B 87 ? ? ? ? F3 0F 10 05", Form::Direct, rv::Kind::Instruction, 0},
    {"m_Spread",               "F3 41 0F 10 B0 ? ? ? ? 48 8B CA", Form::Direct, rv::Kind::Instruction, 0},
    {"m_Recoil",               "F3 0F 10 B0 ? ? ? ? 49 8B 87", Form::Direct, rv::Kind::Instruction, 0},
    {"m_CObject",              "4C 8B 41 ? 4D 85 C9", Form::Direct, rv::Kind::Instruction, 0},
    {"m_CWeapon",              "48 8B 8B ? ? ? ? 48 8B D7 E8 ? ? ? ? 48 8B 8B ? ? ? ? 48 8B D7 E8", Form::Direct, rv::Kind::Instruction, 0},
    // Same anchor as m_CWeapon: `mov rcx,[rbx+disp32]` where rbx carries the ped
    // and the disp32 is the weapon-manager pointer's offset inside that object.
    // Emitted as a field offset, not an address -- the number survives a rebuild
    // that moves code, and the consumer re-reads it at operand_offset after a
    // fresh scan of the same pattern.
    {"m_WeaponManager",        "48 8B 8B ? ? ? ? 48 8B D7 E8 ? ? ? ? 48 8B 8B ? ? ? ? 48 8B D7 E8", Form::DispField, rv::Kind::FieldOffset, 0},
    {"m_VehicleDriver",        "4C 8B 94 C7 ? ? ? ? EB ? 4D 8B D6 41 8A 82", Form::Direct, rv::Kind::Instruction, 0},
    {"m_NoRagDoll",            "8B 81 ? ? ? ? 83 E0 ? C1 E0 ? 3D ? ? ? ? 0F 8F", Form::Direct, rv::Kind::Instruction, 0},
    {"m_SeatBealt",            "F6 81 ? ? ? ? ? 75 ? 8B 83", Form::Direct, rv::Kind::Instruction, 0},
    {"m_VehicleDoorsLockState","74 ? 83 B9 ? ? ? ? ? 75 ? 45 84 F6", Form::Direct, rv::Kind::Instruction, 0},
    {"m_Handling",             "48 8B 83 ? ? ? ? 8B D5 48 89 44 24 ? 4C 89 74 24", Form::Direct, rv::Kind::Instruction, 0},

    // Legacy entries kept for continuity with earlier tables.
    {"bullet",                 "F3 41 0F 10 19 F3 41 0F 10 41 04", Form::Direct, rv::Kind::Instruction, 0},
};

inline constexpr size_t kTableCount = sizeof(kTable) / sizeof(kTable[0]);

// ------------------------------------------------------------ Lua state ------
//
// The Lua interpreter lives in its own module, so it gets its own table. The
// anchor is an EXPORT, and that is the whole point: `lua_rpmalloc_state` is
// `fx::LuaStateHolder`'s allocator entry point, it is exported by name, and the
// loader relocates it for us. No signature to hunt, nothing to re-derive when
// FiveM patches -- read the export directory and the address falls out.
//
// What it yields is the holder, and `holder + 0x00` is the `lua_State*`. That
// relationship was established in-process (the holder arrives as `this` in rcx on
// entry to the exported function and the state is read out of the register), not
// by scanning, because the read-only route is exhausted: a lua_State scan across
// this module produces thousands of candidates and proves none of them.
//
// Read-only resolution therefore stops at the holder address. Getting a LIVE
// lua_State needs a detour on the exported function; the two RVAs here are what
// that detour has to agree with before it patches anything.
inline const Entry kLuaTable[] = {
    // Both names read out of the live module's export directory, not guessed. The
    // `_free` signature differs from `_state` in more than its last token, which is
    // exactly the kind of thing a hand-written table gets wrong.
    {"fx::LuaStateHolder::lua_rpmalloc_state",
     "?lua_rpmalloc_state@LuaStateHolder@fx@@CAPEAUlua_State@@AEAPEAX@Z",
     Form::Export, rv::Kind::Function, 0},
    {"fx::LuaStateHolder::lua_rpmalloc_free",
     "?lua_rpmalloc_free@LuaStateHolder@fx@@CAXPEAX@Z",
     Form::Export, rv::Kind::Function, 0},
    // Not exported, so this one is still a signature. The call it resolves is nine
    // bytes into the match, which is why the anchor carries an instruction offset:
    // the match address and the function the reference table records are two
    // different numbers, and conflating them points the symbol at the caller.
    {"fx::LuaStateHolder_creator",
     "48 48 85 C0 74 0D 48 8B C8 E8",
     Form::Call, rv::Kind::Function, 0, 9},
};

inline constexpr size_t kLuaTableCount = sizeof(kLuaTable) / sizeof(kLuaTable[0]);

// The table a module is dumped with. Selection is by module name because the
// symbols live in different images: the GTA globals are in the game process, the
// Lua state is in the scripting module. Dumping one module with the other's table
// would report every symbol absent and look like a catastrophic regression.
struct TableRef {
    const Entry* entries = nullptr;
    size_t       count   = 0;
    const char*  label   = "";
};

inline TableRef table_for(const std::string& module_name) {
    if (module_name.find("scripting-lua") != std::string::npos) {
        return TableRef{ kLuaTable, kLuaTableCount, "lua" };
    }
    if (module_name.find("scripting-v8") != std::string::npos) {
        return TableRef{ nullptr, 0, "v8 (no table yet)" };
    }
    return TableRef{ kTable, kTableCount, "gta" };
}

}  // namespace dmp::tbl
