// language: C++, file: src/core/image.cpp, target: Windows 11, MSVC, x64
#include "core/image.hpp"

#include <algorithm>
#include <fstream>

// The PE structures below are redeclared rather than taken from <windows.h> so
// their layout is stated explicitly and asserted. windows.h is still included for
// the two live-process calls (VirtualQueryEx / ReadProcessMemory); NOMINMAX keeps
// its min/max macros out of std::min's way.
#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>

namespace dmp::pe {
namespace {

// Copies a remote image region by region. A single ReadProcessMemory over the
// whole SizeOfImage fails outright on the first unmapped or guard page inside the
// range -- common once the loader has trimmed or discarded sections -- which would
// lose the entire image. Walking VirtualQueryEx keeps every readable page and
// leaves unreadable ones zeroed, so the scan surface is defined rather than absent.
bool read_mapped(void* process, uintptr_t remote_base, uint8_t* out, uint32_t size) {
#if defined(_WIN32)
    uint32_t offset = 0;
    uint32_t readable = 0;
    while (offset < size) {
        MEMORY_BASIC_INFORMATION mbi{};
        const uintptr_t addr = remote_base + offset;
        if (VirtualQueryEx(process, reinterpret_cast<LPCVOID>(addr), &mbi, sizeof(mbi)) == 0) {
            return readable > 0;
        }
        uintptr_t region_end = reinterpret_cast<uintptr_t>(mbi.BaseAddress) + mbi.RegionSize;
        const uintptr_t image_end = remote_base + size;
        if (region_end > image_end) region_end = image_end;

        const uintptr_t start = reinterpret_cast<uintptr_t>(mbi.BaseAddress);
        if (start > addr) {
            // A gap in the mapping; skip to the start of the next region.
            offset = static_cast<uint32_t>(start - remote_base);
            if (offset >= size) break;
            continue;
        }
        uint32_t chunk = static_cast<uint32_t>(region_end - addr);
        if (chunk == 0) break;

        const bool usable = (mbi.State == MEM_COMMIT) &&
                            (mbi.Protect & (PAGE_GUARD | PAGE_NOACCESS)) == 0;
        if (usable) {
            SIZE_T got = 0;
            if (ReadProcessMemory(process, reinterpret_cast<LPCVOID>(addr),
                                  out + offset, chunk, &got)) {
                readable += static_cast<uint32_t>(got);
            }
        }
        offset += chunk;
    }
    return readable > 0;
#else
    (void)process; (void)remote_base; (void)out; (void)size;
    return false;
#endif
}


struct DosHeader {
    uint16_t e_magic;   // 0x00
    uint16_t _pad[29];
    int32_t  e_lfanew;  // 0x3C
};
static_assert(sizeof(DosHeader) == 0x40, "DosHeader layout");

struct FileHeader {
    uint16_t machine;                 // +0x00
    uint16_t number_of_sections;      // +0x02
    uint32_t time_date_stamp;         // +0x04
    uint32_t pointer_to_symbols;      // +0x08
    uint32_t number_of_symbols;       // +0x0C
    uint16_t size_of_optional;        // +0x10
    uint16_t characteristics;         // +0x12
};
static_assert(sizeof(FileHeader) == 20, "FileHeader layout");

struct OptionalHeader64 {
    uint16_t magic;                   // +0x00
    uint8_t  major_linker, minor_linker;
    uint32_t size_of_code;            // +0x04
    uint32_t size_of_init_data;       // +0x08
    uint32_t size_of_uninit_data;     // +0x0C
    uint32_t entry_point;             // +0x10
    uint32_t base_of_code;            // +0x14
    uint64_t image_base;              // +0x18
    uint32_t section_alignment;       // +0x20
    uint32_t file_alignment;          // +0x24
    uint16_t os_ver_maj, os_ver_min;
    uint16_t img_ver_maj, img_ver_min;
    uint16_t sub_ver_maj, sub_ver_min;
    uint32_t win32_ver;               // +0x34
    uint32_t size_of_image;           // +0x38
    uint32_t size_of_headers;         // +0x3C
    uint32_t checksum;                // +0x40
    uint16_t subsystem;               // +0x44
    uint16_t dll_characteristics;     // +0x46
    uint64_t stack_reserve;           // +0x48
    uint64_t stack_commit;            // +0x50
    uint64_t heap_reserve;            // +0x58
    uint64_t heap_commit;             // +0x60
    uint32_t loader_flags;            // +0x68
    uint32_t number_of_rva_and_sizes; // +0x6C
    // DataDirectory[] follows at +0x70
};
static_assert(offsetof(OptionalHeader64, size_of_image) == 0x38, "SizeOfImage offset");
static_assert(offsetof(OptionalHeader64, number_of_rva_and_sizes) == 0x6C, "dir count offset");

struct DataDirectory64 { uint32_t rva, size; };

struct SectionHeader {
    char     name[8];
    uint32_t virtual_size;            // +0x08
    uint32_t virtual_address;         // +0x0C
    uint32_t size_of_raw_data;        // +0x10
    uint32_t pointer_to_raw_data;     // +0x14
    uint32_t pointer_to_relocations;  // +0x18
    uint32_t pointer_to_linenumbers;  // +0x1C
    uint16_t number_of_relocations;   // +0x20
    uint16_t number_of_linenumbers;   // +0x22
    uint32_t characteristics;         // +0x24
};
static_assert(sizeof(SectionHeader) == 40, "SectionHeader layout");

struct ExportDirectory {
    uint32_t characteristics;
    uint32_t time_date_stamp;
    uint16_t major_version, minor_version;
    uint32_t name;                  // +0x0C
    uint32_t ordinal_base;          // +0x10
    uint32_t number_of_functions;   // +0x14
    uint32_t number_of_names;       // +0x18
    uint32_t address_of_functions;  // +0x1C
    uint32_t address_of_names;      // +0x20
    uint32_t address_of_ordinals;   // +0x24
};
static_assert(sizeof(ExportDirectory) == 40, "ExportDirectory layout");

struct DebugDirectory {
    uint32_t characteristics;
    uint32_t time_date_stamp;
    uint16_t major_version, minor_version;
    uint32_t type;                // +0x0C
    uint32_t size_of_data;        // +0x10
    uint32_t address_of_raw_data; // +0x14
    uint32_t pointer_to_raw_data; // +0x18
};
static_assert(sizeof(DebugDirectory) == 28, "DebugDirectory layout");

constexpr uint32_t kDebugTypeCodeview = 2;

std::string cstr_at(const uint8_t* base, size_t available, size_t cap) {
    size_t n = 0;
    while (n < available && n < cap && base[n] != 0) ++n;
    return std::string(reinterpret_cast<const char*>(base), n);
}

}  // namespace

// -------------------------------------------------------------- header parse --

bool Image::parse_headers() {
    if (data_.size() < sizeof(DosHeader)) return false;
    const auto* dos = reinterpret_cast<const DosHeader*>(data_.data());
    if (dos->e_magic != kDosSig) return false;
    if (dos->e_lfanew < 0 ||
        !in_range(static_cast<uint32_t>(dos->e_lfanew),
                  sizeof(FileHeader) + sizeof(OptionalHeader64) + 64)) {
        return false;
    }

    const uint32_t nt = static_cast<uint32_t>(dos->e_lfanew);
    if (read_or<uint32_t>(nt, 0) != kNtSig) return false;

    const auto* fh = reinterpret_cast<const FileHeader*>(data_.data() + nt + 4);
    if (fh->number_of_sections == 0 || fh->number_of_sections > 96) return false;

    const uint32_t opt_at = nt + 4 + sizeof(FileHeader);
    const auto* oh = reinterpret_cast<const OptionalHeader64*>(data_.data() + opt_at);
    if (oh->magic != kMagicPe32p) return false;

    info_.machine        = fh->machine;
    info_.size_of_image  = oh->size_of_image;
    info_.preferred_base = oh->image_base;
    info_.entry          = oh->entry_point;
    info_.timestamp      = fh->time_date_stamp;
    // A mapped image is exactly SizeOfImage bytes; anything else means the read
    // was short and every RVA past the truncation point would be a lie.
    if (info_.size_of_image == 0 || data_.size() != info_.size_of_image) return false;

    const uint32_t dir_count = oh->number_of_rva_and_sizes;
    dirs_.assign(dir_count < 16 ? 16 : dir_count, DataDir{});
    for (uint32_t i = 0; i < dir_count && i < dirs_.size(); ++i) {
        const auto* dd = reinterpret_cast<const DataDirectory64*>(
            data_.data() + opt_at + offsetof(OptionalHeader64, number_of_rva_and_sizes) + 4
            + i * sizeof(DataDirectory64));
        dirs_[i] = DataDir{ dd->rva, dd->size };
    }

    const uint32_t sec_at = opt_at + fh->size_of_optional;
    sections_.clear();
    sections_.reserve(fh->number_of_sections);
    for (uint16_t i = 0; i < fh->number_of_sections; ++i) {
        const uint32_t at = sec_at + i * sizeof(SectionHeader);
        if (!in_range(at, sizeof(SectionHeader))) return false;
        const auto* sh = reinterpret_cast<const SectionHeader*>(data_.data() + at);
        Section s;
        s.name     = cstr_at(reinterpret_cast<const uint8_t*>(sh->name), 8, 8);
        s.vsize    = sh->virtual_size;
        s.rva      = sh->virtual_address;
        s.raw_size = sh->size_of_raw_data;
        s.raw_ptr  = sh->pointer_to_raw_data;
        s.chars    = sh->characteristics;
        sections_.push_back(std::move(s));
    }
    return true;
}

// ---------------------------------------------------------- file -> mapped --

bool Image::build_from(const uint8_t* file_bytes, size_t file_size) {
    if (file_size < sizeof(DosHeader)) return false;
    const auto* dos = reinterpret_cast<const DosHeader*>(file_bytes);
    if (dos->e_magic != kDosSig) return false;

    // Bounds-check against the FILE buffer: data_ is still empty here, so
    // in_range() -- which measures the mapped image -- would reject everything.
    const uint32_t nt = static_cast<uint32_t>(dos->e_lfanew);
    if (static_cast<uint64_t>(nt) + sizeof(FileHeader) + sizeof(OptionalHeader64) > file_size) {
        return false;
    }
    if (*reinterpret_cast<const uint32_t*>(file_bytes + nt) != kNtSig) return false;

    const auto* fh = reinterpret_cast<const FileHeader*>(file_bytes + nt + 4);
    const auto* oh = reinterpret_cast<const OptionalHeader64*>(
        file_bytes + nt + 4 + sizeof(FileHeader));
    if (oh->magic != kMagicPe32p) return false;

    const uint32_t size_of_image = oh->size_of_image;
    if (size_of_image == 0 || size_of_image > kMaxImageBytes) return false;

    data_.assign(size_of_image, 0);
    const uint32_t header_bytes =
        static_cast<uint32_t>(size_of_image < file_size ? size_of_image : file_size);
    std::memcpy(data_.data(), file_bytes, header_bytes);

    const uint32_t sec_at = nt + 4 + sizeof(FileHeader) + fh->size_of_optional;
    for (uint16_t i = 0; i < fh->number_of_sections; ++i) {
        const uint32_t at = sec_at + i * sizeof(SectionHeader);
        if (at + sizeof(SectionHeader) > file_size) continue;
        const auto* sh = reinterpret_cast<const SectionHeader*>(file_bytes + at);
        const uint32_t copy = sh->virtual_size < sh->size_of_raw_data
                            ? sh->virtual_size : sh->size_of_raw_data;
        if (copy == 0) continue;
        if (static_cast<uint64_t>(sh->virtual_address) + copy > size_of_image) continue;
        if (static_cast<uint64_t>(sh->pointer_to_raw_data) + copy > file_size) continue;
        std::memcpy(data_.data() + sh->virtual_address,
                    file_bytes + sh->pointer_to_raw_data, copy);
    }

    info_.preferred_base = oh->image_base;
    info_.size_of_image  = size_of_image;
    return parse_headers();
}

std::optional<Image> Image::from_file(const std::filesystem::path& path) {
    std::error_code ec;
    if (!std::filesystem::is_regular_file(path, ec)) return std::nullopt;

    std::ifstream f(path, std::ios::binary);
    if (!f) return std::nullopt;
    f.seekg(0, std::ios::end);
    const std::streamoff len = f.tellg();
    if (len <= 0 || len > static_cast<std::streamoff>(kMaxImageBytes)) return std::nullopt;
    f.seekg(0, std::ios::beg);

    std::vector<uint8_t> raw(static_cast<size_t>(len));
    if (!f.read(reinterpret_cast<char*>(raw.data()), len)) return std::nullopt;

    Image img;
    if (!img.build_from(raw.data(), raw.size())) return std::nullopt;
    img.info_.name      = path.filename().string();
    img.info_.load_base = img.info_.preferred_base;
    return img;
}

std::optional<Image> Image::from_process(void* process, uintptr_t remote_base,
                                         std::string name) {
#if defined(_WIN32)
    if (!process || !remote_base) return std::nullopt;

    uint8_t head[0x1000] = {};
    size_t  got = 0;
    if (!ReadProcessMemory(process, reinterpret_cast<const void*>(remote_base), head,
                           sizeof(head), &got)) {
        return std::nullopt;
    }
    const auto* dos = reinterpret_cast<const DosHeader*>(head);
    if (dos->e_magic != kDosSig) return std::nullopt;

    const uint32_t nt = static_cast<uint32_t>(dos->e_lfanew);
    if (nt + 4 + sizeof(FileHeader) + sizeof(OptionalHeader64) >= sizeof(head)) {
        return std::nullopt;
    }
    const auto* oh = reinterpret_cast<const OptionalHeader64*>(
        head + nt + 4 + sizeof(FileHeader));
    if (oh->magic != kMagicPe32p) return std::nullopt;

    const uint32_t size_of_image = oh->size_of_image;
    if (size_of_image == 0 || size_of_image > kMaxImageBytes) return std::nullopt;

    Image img;
    img.data_.assign(size_of_image, 0);
    if (!read_mapped(process, remote_base, img.data_.data(), size_of_image)) {
        return std::nullopt;
    }
    if (!img.parse_headers()) return std::nullopt;
    img.info_.name = std::move(name);
    // Everything read out of the live process has already had relocations applied,
    // so its absolute pointers are relative to the ACTUAL load address, not to the
    // optional header's ImageBase. Recording the real base is what makes the RTTI
    // and vftable walks correct on a relocated module.
    img.info_.load_base = remote_base;
    return img;
#else
    (void)process; (void)remote_base; (void)name;
    return std::nullopt;
#endif
}

const Section* Image::section_named(const std::string& n) const {
    for (const auto& s : sections_) if (s.name == n) return &s;
    return nullptr;
}

const Section* Image::section_of(uint32_t rva) const {
    for (const auto& s : sections_) {
        if (rva >= s.rva && rva - s.rva < s.span()) return &s;
    }
    return nullptr;
}

DataDir Image::directory(int index) const {
    if (index < 0 || static_cast<size_t>(index) >= dirs_.size()) return DataDir{};
    return dirs_[index];
}

std::vector<const Section*> Image::code_sections() const {
    std::vector<const Section*> out;
    for (const auto& s : sections_) {
        if (!s.has(kMemExecute)) continue;
        // A section with no file content reserves address space and holds no
        // code. The RAGE decoy section is exactly this shape; scanning or hashing
        // it would be both slow and meaningless.
        if (s.raw_size == 0 && s.span() > 0 && s.raw_ptr == 0) continue;
        out.push_back(&s);
    }
    return out;
}

std::vector<const Section*> Image::data_sections() const {
    std::vector<const Section*> out;
    for (const auto& s : sections_) {
        if (s.span() == 0) continue;
        if (s.has(kMemWrite) || (!s.has(kMemExecute) && s.raw_size > 0)) out.push_back(&s);
    }
    return out;
}

bool Image::is_code(uint32_t rva) const {
    for (const Section* s : code_sections()) {
        if (rva >= s->rva && rva - s->rva < s->span()) return true;
    }
    return false;
}

// ----------------------------------------------------------------- exports --

std::vector<Export> exports(const Image& img) {
    std::vector<Export> out;
    const DataDir dir = img.directory(kDirExport);
    if (!dir.rva || !img.in_range(dir.rva, sizeof(ExportDirectory))) return out;

    const auto* ed = reinterpret_cast<const ExportDirectory*>(img.at(dir.rva));
    if (ed->number_of_names == 0 || ed->number_of_names > (1u << 20)) return out;
    if (!ed->address_of_names || !ed->address_of_ordinals || !ed->address_of_functions) return out;
    if (!img.in_range(ed->address_of_names, ed->number_of_names * 4u)) return out;
    if (!img.in_range(ed->address_of_ordinals, ed->number_of_names * 2u)) return out;
    if (!img.in_range(ed->address_of_functions, ed->number_of_functions * 4u)) return out;

    for (uint32_t i = 0; i < ed->number_of_names; ++i) {
        const uint32_t name_rva = img.read_or<uint32_t>(ed->address_of_names + i * 4u, 0);
        const uint16_t ord      = img.read_or<uint16_t>(ed->address_of_ordinals + i * 2u, 0);
        if (name_rva >= img.size()) continue;
        // AddressOfFunctions is indexed by (ordinal - OrdinalBase), so the raw
        // table entry is at ord * 4; adding the base here would double-count it.
        const uint32_t fn_rva = img.read_or<uint32_t>(ed->address_of_functions + ord * 4u, 0);
        if (fn_rva == 0) continue;

        Export e;
        e.ordinal   = static_cast<uint32_t>(ed->ordinal_base) + ord;
        e.rva       = fn_rva;
        e.forwarded = (fn_rva >= dir.rva && fn_rva < dir.rva + dir.size);
        e.name      = cstr_at(img.at(name_rva), img.size() - name_rva, 1024);
        if (e.name.empty()) continue;
        out.push_back(std::move(e));
    }
    std::sort(out.begin(), out.end(),
              [](const Export& a, const Export& b) { return a.rva < b.rva; });
    return out;
}

std::optional<std::string> codeview_pdb_path(const Image& img) {
    const DataDir dir = img.directory(kDirDebug);
    if (!dir.rva || !img.in_range(dir.rva, sizeof(DebugDirectory))) return std::nullopt;

    for (uint32_t off = 0; off + sizeof(DebugDirectory) <= dir.size; off += sizeof(DebugDirectory)) {
        const auto* dbg = reinterpret_cast<const DebugDirectory*>(img.at(dir.rva + off));
        if (dbg->type != kDebugTypeCodeview) continue;
        if (dbg->size_of_data == 0 || dbg->address_of_raw_data >= img.size()) continue;
        if (!img.in_range(dbg->address_of_raw_data, dbg->size_of_data)) continue;
        if (img.read_or<uint32_t>(dbg->address_of_raw_data, 0) != kCodeviewRsds) continue;
        if (dbg->size_of_data <= 24) continue;

        const uint8_t* cv = img.at(dbg->address_of_raw_data);
        std::string path = cstr_at(cv + 24, dbg->size_of_data - 24, 4096);
        if (!path.empty()) return path;
    }
    return std::nullopt;
}

uint64_t code_hash(const Image& img) {
    const auto code = img.code_sections();
    if (code.empty()) return 0;

    // FNV-1a, 64-bit, over every executable section with file content. The
    // section RVA is mixed in so two builds cannot collide by layout alone.
    uint64_t h = 0xcbf29ce484222325ull;
    for (const Section* s : code) {
        for (int i = 0; i < 8; ++i) {
            h ^= static_cast<uint8_t>((s->rva >> (i * 8)) & 0xFF);
            h *= 0x100000001b3ull;
        }
        const uint32_t span = s->span();
        if (!img.in_range(s->rva, span)) return 0;
        const uint8_t* p = img.at(s->rva);
        for (uint32_t i = 0; i < span; ++i) {
            h ^= p[i];
            h *= 0x100000001b3ull;
        }
    }
    return h;
}

}  // namespace dmp::pe
