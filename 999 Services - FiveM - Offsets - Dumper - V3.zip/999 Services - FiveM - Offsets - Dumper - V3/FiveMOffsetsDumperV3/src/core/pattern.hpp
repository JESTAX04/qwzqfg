// language: C++, file: src/core/pattern.hpp, target: Windows 11, MSVC, x64
// Byte patterns with per-NIBBLE wildcards.
//
// A byte-level wildcard mask cannot represent the signature forms that actually
// appear in hand-written tables -- "4? 8B ?5", "48 8B ?5 ? ? ? ?" -- so each byte
// carries a 2-bit mask saying which of its nibbles are concrete. A lone '?' is a
// fully-wild byte; "4?" keeps the high nibble.
//
// Header-only and free of <windows.h> on purpose: this is the type a generated
// header or a runtime consumer needs, and it must not drag the PE parser along.
#pragma once
#include <cstdint>
#include <cstring>
#include <string>
#include <string_view>
#include <vector>

namespace dmp::pat {

inline constexpr uint8_t kMaskLow  = 0x01;  // low nibble is concrete
inline constexpr uint8_t kMaskHigh = 0x02;  // high nibble is concrete
inline constexpr uint8_t kMaskBoth = 0x03;

struct Pattern {
    std::vector<uint8_t> bytes;   // nibble values, meaningful only where masked
    std::vector<uint8_t> mask;    // per byte: which nibbles must match
    uint32_t             wildcards = 0;

    size_t length() const { return bytes.size(); }
    bool   empty()  const { return bytes.empty(); }

    std::string str() const;

    void append(uint8_t byte, uint8_t m);
    // Blank [begin, end). Each newly masked byte is counted once.
    void mask_range(uint32_t begin, uint32_t end);

    // First fully-concrete byte, for prescreening. Returns false when every byte
    // carries at least one wildcard nibble, in which case nothing can be screened.
    bool anchor(uint32_t& offset, uint8_t& value) const;

    // A second fully-concrete byte, used to widen the prescreen bucket. Returns
    // false when the pattern has no other concrete byte.
    bool second_anchor(uint32_t& offset, uint8_t& value) const;
};

Pattern parse(std::string_view text);
Pattern from_bytes(const uint8_t* data, size_t n);

// Compares `at` against the whole pattern. `at` must have length() readable bytes.
bool matches_at(const uint8_t* at, const Pattern& p);

// Scans a raw window and writes match OFFSETS into `out`, up to `max`.
// Returns how many were written. No allocation, so it is safe to call per frame.
size_t scan(const uint8_t* data, size_t size, const Pattern& p,
            uint32_t* out, size_t max);

// ------------------------------------------------------------------ inline --

inline std::string Pattern::str() const {
    static const char kHex[] = "0123456789ABCDEF";
    std::string out;
    out.reserve(bytes.size() * 3);
    for (size_t i = 0; i < bytes.size(); ++i) {
        if (i) out += ' ';
        out += (mask[i] & kMaskHigh) ? kHex[bytes[i] >> 4]     : '?';
        out += (mask[i] & kMaskLow)  ? kHex[bytes[i] & 0x0Fu] : '?';
    }
    return out;
}

inline void Pattern::append(uint8_t byte, uint8_t m) {
    bytes.push_back(byte);
    mask.push_back(m);
    if (m != kMaskBoth) ++wildcards;
}

inline void Pattern::mask_range(uint32_t begin, uint32_t end) {
    for (uint32_t i = begin; i < end && i < length(); ++i) {
        if (mask[i] != 0) { mask[i] = 0; ++wildcards; }
        bytes[i] = 0;
    }
}

inline bool Pattern::anchor(uint32_t& offset, uint8_t& value) const {
    for (size_t i = 0; i < mask.size(); ++i) {
        if (mask[i] == kMaskBoth) { offset = static_cast<uint32_t>(i); value = bytes[i]; return true; }
    }
    return false;
}

inline bool Pattern::second_anchor(uint32_t& offset, uint8_t& value) const {
    uint32_t first = 0;
    uint8_t  dummy = 0;
    if (!anchor(first, dummy)) return false;
    for (size_t i = first + 1; i < mask.size(); ++i) {
        if (mask[i] == kMaskBoth) { offset = static_cast<uint32_t>(i); value = bytes[i]; return true; }
    }
    return false;
}

inline int hex_digit(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

// Parsed token by token, NOT character by character.
//
// That distinction is the whole correctness of this function. Ignoring separators
// and counting nibbles positionally makes "? 48" collapse into the nibble pair
// "?4" followed by "8", so a lone '?' silently becomes "high nibble wildcard,
// low nibble 4". Every single-'?' entry in a hand-written table would then match
// the wrong bytes while still looking perfectly well-formed. Tokenising first is
// what lets '?', '??', '4?' and '?5' each mean what they say:
//
//   "?"   or "??"  -> a whole wildcard byte
//   "4?"           -> high nibble fixed at 4, low nibble free
//   "?5"           -> low nibble fixed at 5, high nibble free
//   "48"           -> the byte 0x48
//   "488B05"       -> three concrete bytes, since a token is read in pairs
inline Pattern parse(std::string_view text) {
    Pattern p;
    std::string token;
    token.reserve(16);

    auto flush = [&]() {
        if (token.empty()) return;
        size_t i = 0;
        while (i < token.size()) {
            if (token.size() - i == 1) {
                const char c = token[i++];
                if (c == '?') {
                    p.append(0, 0);
                } else {
                    const int d = hex_digit(c);
                    if (d >= 0) p.append(static_cast<uint8_t>(d), kMaskBoth);
                }
                continue;
            }
            const char hi = token[i];
            const char lo = token[i + 1];
            i += 2;

            const int h = (hi == '?') ? -1 : hex_digit(hi);
            const int l = (lo == '?') ? -1 : hex_digit(lo);
            if (h < 0 && l < 0) {
                p.append(0, 0);
                continue;
            }
            uint8_t byte = 0;
            uint8_t mask = 0;
            if (h >= 0) { byte |= static_cast<uint8_t>(h << 4); mask |= kMaskHigh; }
            if (l >= 0) { byte |= static_cast<uint8_t>(l);      mask |= kMaskLow; }
            p.append(byte, mask);
        }
        token.clear();
    };

    for (char c : text) {
        if (c == ' ' || c == '\t' || c == '-' || c == ',' || c == ':') {
            flush();
            continue;
        }
        token.push_back(c);
    }
    flush();
    return p;
}

inline Pattern from_bytes(const uint8_t* data, size_t n) {
    Pattern p;
    p.bytes.assign(data, data + n);
    p.mask.assign(n, kMaskBoth);
    return p;
}

inline bool matches_at(const uint8_t* at, const Pattern& p) {
    for (size_t i = 0; i < p.length(); ++i) {
        const uint8_t m = p.mask[i];
        // The mask bit is SET when the nibble is concrete, so the set case is the
        // one compared; a clear bit matches anything and is skipped.
        if ((m & kMaskHigh) && ((at[i] >> 4) != (p.bytes[i] >> 4))) return false;
        if ((m & kMaskLow)  && ((at[i] & 0x0Fu) != (p.bytes[i] & 0x0Fu))) return false;
    }
    return true;
}

inline size_t scan(const uint8_t* data, size_t size, const Pattern& p,
                   uint32_t* out, size_t max) {
    const size_t n = p.length();
    if (n == 0 || size < n || max == 0) return 0;

    uint32_t anchor_off = 0;
    uint8_t  anchor_val = 0;
    const bool have_anchor = p.anchor(anchor_off, anchor_val);

    size_t found = 0;
    const size_t last = size - n;
    size_t off = 0;
    while (off <= last) {
        if (have_anchor) {
            // Jump straight to the next position whose anchor byte could match.
            // This is what turns a per-byte branch into a memory-bandwidth-bound
            // scan, which matters when uniqueness tests run hundreds of times.
            const void* m = std::memchr(data + off + anchor_off, anchor_val,
                                        last - off + 1);
            if (!m) break;
            off = static_cast<size_t>(static_cast<const uint8_t*>(m) - data) - anchor_off;
        }
        if (matches_at(data + off, p)) {
            if (out) out[found] = static_cast<uint32_t>(off);
            if (++found == max) break;
        }
        ++off;
    }
    return found;
}

}  // namespace dmp::pat
