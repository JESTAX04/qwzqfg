// language: C++, file: src/core/image.hpp, target: Windows 11, MSVC, x64
// PE32+ image abstraction.
//
// Normalises the two sources this dumper reads -- a DLL on disk and a module
// already mapped into a live process -- into ONE mapped virtual image, so every
// later stage scans byte-identical memory regardless of where the bytes came from.
//
// The single most important thing this header exists to prevent: NEVER assume the
// code section is called ".text". FiveM's game process is built by RAGE, names its
// code ".zdata", puts runtime functions in ".rd_pef", and carries a ~100 MB decoy
// section with a zero raw size. A name-based assumption silently scans nothing.
#pragma once
#include <cstdint>
#include <cstring>
#include <filesystem>
#include <optional>
#include <string>
#include <vector>

namespace dmp::pe {

// Section characteristics.
inline constexpr uint32_t kCntCode    = 0x00000020u;
inline constexpr uint32_t kMemExecute = 0x20000000u;
inline constexpr uint32_t kMemRead    = 0x40000000u;
inline constexpr uint32_t kMemWrite   = 0x80000000u;

// Data-directory indices.
inline constexpr int kDirExport    = 0;
inline constexpr int kDirImport    = 1;
inline constexpr int kDirException = 3;  // .pdata
inline constexpr int kDirDebug     = 6;

inline constexpr uint16_t kDosSig       = 0x5A4D;    // 'MZ'
inline constexpr uint32_t kNtSig        = 0x00004550; // 'PE\0\0'
inline constexpr uint16_t kMachineAmd64 = 0x8664;
inline constexpr uint16_t kMagicPe32p   = 0x020B;
inline constexpr uint32_t kCodeviewRsds = 0x53445352; // 'SDSR' little-endian

// A hostile or truncated image must not be able to make the tool allocate wildly.
inline constexpr uint32_t kMaxImageBytes = 512u * 1024u * 1024u;

struct Section {
    std::string name;
    uint32_t    rva      = 0;
    uint32_t    vsize    = 0;
    uint32_t    raw_size = 0;
    uint32_t    raw_ptr  = 0;
    uint32_t    chars    = 0;

    bool has(uint32_t flag) const { return (chars & flag) != 0; }
    // VirtualSize is allowed to exceed raw data; the loader zero-fills the tail.
    uint32_t span() const { return vsize ? vsize : raw_size; }
};

struct DataDir { uint32_t rva = 0, size = 0; };

struct ModuleInfo {
    std::string name;
    // ImageBase as written in the optional header.
    uint64_t    preferred_base = 0;
    // The base every absolute pointer inside `data_` is relative to. For a file
    // this is preferred_base; for a live process it is the address the module was
    // actually mapped at, which ASLR almost always moves. RTTI and vftable walks
    // MUST use this field: subtracting preferred_base from a rel=0 pointer in a
    // relocated live image yields a garbage RVA, silently.
    uint64_t    load_base      = 0;
    uint32_t    size_of_image  = 0;
    uint32_t    timestamp      = 0;
    uint16_t    machine        = 0;
    uint32_t    entry          = 0;
};

class Image {
public:
    // Maps a PE file from disk into virtual layout.
    static std::optional<Image> from_file(const std::filesystem::path& path);

    // Reads a module already mapped in another process. `process` is a Win32
    // HANDLE passed as void* so this header stays free of <windows.h>.
    static std::optional<Image> from_process(void* process, uintptr_t remote_base,
                                             std::string name);

    const std::vector<uint8_t>&  bytes()    const { return data_; }
    const std::vector<Section>&  sections() const { return sections_; }
    const ModuleInfo&            info()     const { return info_; }

    uint32_t       size() const { return static_cast<uint32_t>(data_.size()); }
    const uint8_t* at(uint32_t rva) const { return data_.data() + rva; }

    bool in_range(uint32_t rva, uint32_t n = 1) const {
        return rva <= size() && n <= size() - rva;
    }

    const Section* section_named(const std::string& n) const;
    const Section* section_of(uint32_t rva) const;
    DataDir        directory(int index) const;

    // Executable sections, in image order, including any that share a region with
    // data. This is the scan surface for every pattern.
    std::vector<const Section*> code_sections() const;

    // Writable sections, used to bound pointer probes and RTTI lookups.
    std::vector<const Section*> data_sections() const;

    bool is_code(uint32_t rva) const;

    template <typename T> std::optional<T> read(uint32_t rva) const {
        if (!in_range(rva, sizeof(T))) return std::nullopt;
        T v{};
        std::memcpy(&v, data_.data() + rva, sizeof(T));
        return v;
    }
    template <typename T> T read_or(uint32_t rva, T fallback) const {
        return read<T>(rva).value_or(fallback);
    }

    // Zero-copy view of n bytes at rva, or nullptr when it would leave the image.
    const uint8_t* span(uint32_t rva, uint32_t n) const {
        return in_range(rva, n) ? data_.data() + rva : nullptr;
    }

private:
    std::vector<uint8_t> data_;
    std::vector<Section> sections_;
    std::vector<DataDir> dirs_;
    ModuleInfo           info_;

    bool parse_headers();
    bool build_from(const uint8_t* file_bytes, size_t file_size);
};

struct Export {
    uint32_t    ordinal   = 0;
    std::string name;
    uint32_t    rva       = 0;
    bool        forwarded = false;
};

std::vector<Export> exports(const Image& img);

// Debug-directory CodeView RSDS path, when the build shipped a PDB reference.
std::optional<std::string> codeview_pdb_path(const Image& img);

// FNV-1a over every executable section with file content. Two builds with the
// same hash share every code signature, so a consumer can short-circuit.
uint64_t code_hash(const Image& img);

}  // namespace dmp::pe
