// language: C++, file: src/core/rtti.cpp, target: Windows 11, MSVC, x64
#include "core/rtti.hpp"

#include <algorithm>
#include <cstring>

namespace dmp::rtti {
namespace {

constexpr uint32_t kColTypeDescriptor  = 12;  // pTypeDescriptor
constexpr uint32_t kColSelf            = 20;  // pSelf, the self-validating field
constexpr uint32_t kTypeDescNameOffset = 16;  // name[] follows the two pointers

// Precomputed executable ranges. Asking Image::is_code() per candidate would
// rebuild its section vector every call, and this walk makes that call millions of
// times.
struct CodeRanges {
    struct Range { uint32_t begin, end; };
    std::vector<Range> ranges;

    void build(const pe::Image& img) {
        for (const pe::Section* s : img.code_sections()) {
            const uint32_t span = s->span();
            if (span == 0) continue;
            ranges.push_back(Range{ s->rva, s->rva + span });
        }
        std::sort(ranges.begin(), ranges.end(),
                  [](const Range& a, const Range& b) { return a.begin < b.begin; });
    }

    bool contains(uint32_t rva) const {
        for (const Range& r : ranges) {
            if (rva >= r.begin && rva < r.end) return true;
        }
        return false;
    }
};

std::string cstr_at(const pe::Image& img, uint32_t rva, uint32_t cap) {
    if (rva >= img.size()) return {};
    const uint32_t avail = img.size() - rva;
    const uint32_t n = avail < cap ? avail : cap;
    const uint8_t* p = img.at(rva);
    uint32_t i = 0;
    while (i < n && p[i] != 0) {
        const uint8_t c = p[i];
        // A descriptor is printable ASCII; anything else means this is not a type
        // name and the chain resolved to noise.
        if (c < 0x20 || c > 0x7E) return {};
        ++i;
    }
    return std::string(reinterpret_cast<const char*>(p), i);
}

std::string class_of_col(const pe::Image& img, uint32_t col_rva) {
    const uint32_t td = img.read_or<uint32_t>(col_rva + kColTypeDescriptor, 0);
    if (td <= kTypeDescNameOffset) return {};
    if (td + kTypeDescNameOffset >= img.size()) return {};
    return cstr_at(img, td + kTypeDescNameOffset, 300);
}

}  // namespace

std::string short_class_name(const std::string& mangled) {
    // MSVC mangling: ".?AV<name>@@...", where the letter after "A" is V for class,
    // U for struct, T for union, W for enum. A namespace or nesting appends
    // "@...", so the readable name stops at the first '@'.
    if (mangled.size() < 6) return {};
    if (mangled[0] != '.' || mangled[1] != '?' || mangled[2] != 'A') return {};
    const char kind = mangled[3];
    if (kind != 'V' && kind != 'U' && kind != 'T' && kind != 'W') return {};

    const size_t end = mangled.find('@', 4);
    std::string name = (end == std::string::npos) ? mangled.substr(4)
                                                 : mangled.substr(4, end - 4);
    if (name.empty() || name.size() > 120) return {};
    return name;
}

std::vector<Vtable> enumerate(const pe::Image& img) {
    std::vector<Vtable> out;
    const uint64_t base = img.info().load_base;
    if (!base || img.size() == 0) return out;

    const uint64_t limit = base + img.size();
    CodeRanges code;
    code.build(img);

    for (const pe::Section& s : img.sections()) {
        const uint32_t span = s.span();
        if (span < 16 || !img.in_range(s.rva, span)) continue;
        const uint8_t* buf = img.at(s.rva);

        // slot[0] must point into code, and slot[-1] must be a COL whose pSelf
        // equals its own RVA. Both, or it is not a vftable.
        for (uint32_t off = 8; off + 8 <= span; off += 8) {
            uint64_t v = 0;
            std::memcpy(&v, buf + off, 8);
            if (v <= base || v >= limit) continue;

            const uint32_t fn_rva = static_cast<uint32_t>(v - base);
            if (!code.contains(fn_rva)) continue;

            uint64_t col = 0;
            std::memcpy(&col, buf + off - 8, 8);
            if (col < base || col >= limit) continue;

            const uint32_t col_rva = static_cast<uint32_t>(col - base);
            if (img.read_or<uint32_t>(col_rva + kColSelf, 0) != col_rva) continue;

            Vtable t;
            t.rva        = s.rva + off;
            t.col_rva    = col_rva;
            t.class_name = class_of_col(img, col_rva);
            t.short_name = short_class_name(t.class_name);
            out.push_back(std::move(t));
        }
    }

    std::sort(out.begin(), out.end(),
              [](const Vtable& a, const Vtable& b) { return a.rva < b.rva; });
    out.erase(std::unique(out.begin(), out.end(),
                          [](const Vtable& a, const Vtable& b) { return a.rva == b.rva; }),
              out.end());
    return out;
}

void recover(const pe::Image& img, const pd::Inventory& inv, Inventory& io,
             const Options& opt,
             const std::function<void(uint32_t, uint32_t)>& progress,
             const std::function<bool()>& cancelled) {
    const uint64_t base = img.info().load_base;
    if (!base || io.tables.empty()) return;

    const uint64_t limit = base + img.size();

    // Resolvable slot count per table, used only for ordering. Classes with more
    // virtual methods are the game's own objects rather than STL internals, and
    // they are worth spending the signature budget on first.
    auto slot_depth = [&](const Vtable& t) -> uint32_t {
        uint32_t n = 0;
        for (uint32_t slot = 0; slot < opt.max_slots_per_table; ++slot) {
            const uint32_t at = t.rva + slot * 8;
            if (!img.in_range(at, 8)) break;
            uint64_t v = 0;
            std::memcpy(&v, img.at(at), 8);
            if (v <= base || v >= limit) break;
            ++n;
        }
        return n;
    };

    std::vector<uint32_t> order(io.tables.size());
    for (uint32_t i = 0; i < order.size(); ++i) order[i] = i;
    std::stable_sort(order.begin(), order.end(), [&](uint32_t a, uint32_t b) {
        return slot_depth(io.tables[a]) > slot_depth(io.tables[b]);
    });

    uint32_t methods_done = 0;
    uint32_t tables_done  = 0;

    for (uint32_t oi = 0; oi < order.size(); ++oi) {
        if (tables_done >= opt.max_tables) break;
        if (methods_done >= opt.max_methods_total) break;
        if (cancelled && cancelled()) break;

        Vtable& t = io.tables[order[oi]];
        ++tables_done;

        for (uint32_t slot = 0; slot < opt.max_slots_per_table; ++slot) {
            const uint32_t at = t.rva + slot * 8;
            if (!img.in_range(at, 8)) break;

            uint64_t v = 0;
            std::memcpy(&v, img.at(at), 8);
            if (v <= base || v >= limit) break;      // end of the vftable

            const uint32_t fn_rva = static_cast<uint32_t>(v - base);
            if (!img.is_code(fn_rva)) break;

            // A slot that is not a .pdata function entry is a thunk, a pure-call
            // stub, or a pointer into a jump table. Recording it as a method would
            // emit a field list decoded from whatever bytes happen to live there.
            const pd::Function* fn = inv.find(fn_rva);
            if (!fn) continue;

            Method m;
            m.slot         = slot;
            m.rva          = fn_rva;
            m.size         = fn->size();
            m.has_function = true;

            bool spent = false;
            if (opt.signatures && methods_done < opt.max_methods_total) {
                m.sig = scan::sign_code(img, inv, fn_rva);
                m.has_signature = m.sig.ok();
                if (m.has_signature) {
                    ++io.signatures;
                    spent = true;
                }
            }
            if (opt.fields) {
                m.fields = dis::fields_of(img, fn_rva, fn->end);
                if (!m.fields.empty()) {
                    ++io.field_sets;
                    spent = true;
                }
            }
            if (spent) ++methods_done;

            t.methods.push_back(std::move(m));

            if (t.methods.size() >= opt.max_methods_per_table) break;
            if (methods_done >= opt.max_methods_total) break;
        }

        if (progress) progress(tables_done, opt.max_tables);
    }
    uint32_t named = 0;
    for (const Vtable& t : io.tables) if (t.named()) ++named;
    io.named = named;
}

}  // namespace dmp::rtti
