// language: C++, file: src/core/disasm.hpp, target: Windows 11, MSVC, x64
// A deliberately narrow x86-64 decoder: it answers exactly one question.
//
// Given a member function, what `this`-relative fields does it touch, and does it
// follow any of them one level deep? That is the shape a consumer needs to walk an
// object graph, and it is recoverable without a full disassembler because the
// pattern it looks for is always the same:
//
//     mov  rax, rcx              ; rcx is `this` under the MSVC x64 convention
//     mov  rdx, [rax + 0x18]     ; field 0x18
//     mov  r8,  [rdx + 0x38]     ; *(this + 0x18) + 0x38
//
// Anything outside the ModRM/RIP-relative families this understands stops the
// walk rather than desynchronising it. A decoder that guesses at lengths produces
// confident nonsense; one that stops produces less, and less is correct here.
#pragma once
#include "core/image.hpp"

#include <cstdint>
#include <vector>

namespace dmp::dis {

// x64 general-purpose register numbering, REX-extended: 0=rax 1=rcx 2=rdx 3=rbx
// 4=rsp 5=rbp 6=rsi 7=rdi, 8..15 = r8..r15.
inline constexpr int kThisReg = 1;  // rcx

struct FieldAccess {
    uint32_t field       = 0;    // offset from `this`
    uint32_t size        = 0;    // bytes touched: 1, 2, 4 or 8
    int32_t  deref_delta = -1;   // -1 = direct; >= 0 = *(this + field) + deref_delta
    bool     read        = false;
    bool     write       = false;
    bool     is_float    = false;
    uint32_t site_rva    = 0;    // where the instruction lives, for citation

    bool indirect() const { return deref_delta >= 0; }
};

// Decodes up to `max_insns` instructions starting at fn_rva and returns the merged
// field accesses. Duplicates on the same (field, deref_delta) pair are folded, with
// read/write flags OR-ed and the widest size kept.
std::vector<FieldAccess> fields_of(const pe::Image& img, uint32_t fn_rva,
                                   uint32_t fn_end, uint32_t max_insns = 128);

}  // namespace dmp::dis
