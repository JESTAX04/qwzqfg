// language: C++, file: src/core/resolve.cpp, target: Windows 11, MSVC, x64
#include "core/resolve.hpp"
#include "memory/memory.hpp"

namespace dmp::rv {

const char* kind_name(Kind k) {
    switch (k) {
    case Kind::Function:      return "function";
    case Kind::Instruction:   return "instruction";
    case Kind::GlobalPointer: return "global_pointer";
    case Kind::DataGlobal:    return "data_global";
    case Kind::Vtable:        return "vtable";
    case Kind::FieldOffset:   return "field_offset";
    case Kind::DerefChain:    return "deref_chain";
    case Kind::Unknown:       break;
    }
    return "unknown";
}

const char* status_name(Status s) {
    switch (s) {
    case Status::Ok:           return "ok";
    case Status::NotFound:     return "not_found";
    case Status::Ambiguous:    return "ambiguous";
    case Status::Unverified:   return "unverified";
    case Status::NotReadable:  return "not_readable";
    case Status::NotExecutable:return "not_executable";
    case Status::NullPointer:  return "null_pointer";
    case Status::Unpopulated:  return "unpopulated";
    case Status::DerefFailed:  return "deref_failed";
    case Status::OutsideImage: return "outside_image";
    case Status::Skipped:      break;
    }
    return "skipped";
}

uintptr_t resolve_rip(void* proc, uintptr_t instruction_address, int disp_offset,
                      int instruction_size, int32_t* out_disp) {
    if (!proc || !instruction_address) return 0;

    int32_t disp = 0;
    if (!mem::read_t<int32_t>(proc, instruction_address + disp_offset, disp)) return 0;
    if (out_disp) *out_disp = disp;

    // A displacement that drives the target below zero is corrupt, not a pointer
    // that happens to wrap; treating it as unsigned would fabricate an address.
    const int64_t target = static_cast<int64_t>(instruction_address)
                         + instruction_size + disp;
    if (target <= 0) return 0;
    return static_cast<uintptr_t>(target);
}

bool plausible_pointer(const proc::Snapshot& snap, uintptr_t address) {
    (void)snap;
    if (address < 0x10000) return false;                // null page and low garbage
    if (address > 0x00007FFFFFFFFFFFull) return false;  // non-canonical
    if (address & 0x7) return false;                    // x64 pointers are 8-aligned
    return true;
}

Verify verify_address(void* proc, const proc::Snapshot& snap, uintptr_t address, Kind kind) {
    Verify v;
    if (!proc || !address) { v.status = Status::NullPointer; return v; }

    const mem::Region r = mem::region_of(proc, address);
    v.readable   = r.readable();
    v.executable = r.executable();
    v.writable   = r.writable();
    v.in_image   = snap.valid && address >= snap.base
                && address < snap.base + snap.module_size;

    switch (kind) {
    case Kind::Function:
    case Kind::Instruction:
        // Executable and readable, and the first byte must actually read back.
        // A pattern that resolved into a discarded or guard page fails here
        // instead of producing an offset that crashes the consumer.
        if (!v.readable)   { v.status = Status::NotReadable;   return v; }
        if (!v.executable) { v.status = Status::NotExecutable; return v; }
        break;

    case Kind::GlobalPointer: {
        // The symbol is the address of a pointer, so the proof is that the
        // pointer itself reads back and lands somewhere mapped. Requiring only
        // "readable" would pass on a global that was never initialised.
        if (!v.readable) { v.status = Status::NotReadable; return v; }
        const uintptr_t target = mem::read_ptr(proc, address);
        v.probe = target;
        // Zero splits into two opposite conclusions. In writable memory the slot is
        // real and the game simply has not filled it yet. In read-only memory a
        // pointer variable cannot live there at all, so the signature landed on the
        // wrong site and the offset must not be trusted.
        if (!target) {
            v.status = v.writable ? Status::Unpopulated : Status::DerefFailed;
            return v;
        }
        if (!plausible_pointer(snap, target)) { v.status = Status::DerefFailed; return v; }
        if (!mem::is_readable(proc, target))  { v.status = Status::DerefFailed; return v; }
        break;
    }

    case Kind::DataGlobal:
        if (!v.readable) { v.status = Status::NotReadable; return v; }
        break;

    case Kind::Vtable: {
        // A vftable lives in read-only data and its first slot points at code.
        // Both halves are checked: an object's first qword being readable is not
        // evidence that it is a vftable.
        if (!v.readable) { v.status = Status::NotReadable; return v; }
        const uintptr_t first = mem::read_ptr(proc, address);
        v.probe = first;
        if (!first) { v.status = Status::NullPointer; return v; }
        if (!mem::is_executable(proc, first)) { v.status = Status::NotExecutable; return v; }
        break;
    }

    case Kind::FieldOffset:
    case Kind::DerefChain:
        // Not addresses at all; there is nothing to verify against a process.
        v.status = Status::Ok;
        return v;

    case Kind::Unknown:
        if (!v.readable) { v.status = Status::NotReadable; return v; }
        break;
    }

    v.status = Status::Ok;
    return v;
}

bool walk_chain(void* proc, uintptr_t base, const uint32_t* offsets, size_t count,
                uintptr_t& out) {
    uintptr_t addr = base;
    for (size_t i = 0; i < count; ++i) {
        if (!mem::read_t<uintptr_t>(proc, addr, addr)) return false;
        if (!addr) return false;
        addr += offsets[i];
    }
    out = addr;
    return true;
}

}  // namespace dmp::rv
