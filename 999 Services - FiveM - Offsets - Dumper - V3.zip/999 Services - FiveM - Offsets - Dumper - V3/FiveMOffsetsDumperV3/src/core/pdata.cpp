// language: C++, file: src/core/pdata.cpp, target: Windows 11, MSVC, x64
#include "core/pdata.hpp"

#include <algorithm>
#include <cstring>

namespace dmp::pd {
namespace {

// UNWIND_INFO layout:
//   +0 UBYTE Version : Flags   (bits 0-2 version, bit 2 CHAININFO, bits 4-7 handler)
//   +1 UBYTE SizeOfProlog
//   +2 UBYTE CountOfCodes
//   +3 UBYTE FrameRegister : FrameOffset
//   +4 UNWIND_CODE codes[CountOfCodes + (CountOfCodes & 1)]
void read_unwind(const pe::Image& img, uint32_t rva, Function& fn) {
    const uint8_t* p = img.span(rva, 4);
    if (!p) return;
    fn.version    = static_cast<uint8_t>(p[0] & 0x07u);
    fn.flags      = static_cast<uint8_t>(p[0] & 0xF0u);
    fn.prolog     = p[1];
    fn.code_count = p[2];
    fn.frame_reg  = p[3];
}

}  // namespace

const Function* Inventory::find(uint32_t rva) const {
    if (functions.empty()) return nullptr;
    auto it = std::upper_bound(functions.begin(), functions.end(), rva,
                               [](uint32_t v, const Function& f) { return v < f.begin; });
    if (it == functions.begin()) return nullptr;
    --it;
    return it->contains(rva) ? &*it : nullptr;
}

const Function* Inventory::enclosing(uint32_t rva) const {
    if (functions.empty()) return nullptr;
    auto it = std::upper_bound(functions.begin(), functions.end(), rva,
                               [](uint32_t v, const Function& f) { return v < f.begin; });
    if (it == functions.begin()) return &functions.front();
    --it;
    return &*it;
}

uint32_t Inventory::entry_of(uint32_t rva) const {
    const Function* f = enclosing(rva);
    if (!f || !f->contains(rva)) return 0;
    return f->begin;
}

std::vector<const Function*> Inventory::overlapping(uint32_t rva, uint32_t n) const {
    std::vector<const Function*> out;
    if (n == 0 || functions.empty()) return out;
    for (size_t i = 0; i < functions.size(); ++i) {
        const Function& f = functions[i];
        if (f.begin >= rva + n) break;
        if (f.end > rva) out.push_back(&f);
    }
    return out;
}

uint32_t Inventory::bytes_remaining(uint32_t rva) const {
    const Function* f = enclosing(rva);
    if (!f || rva < f->begin || rva >= f->end) return 0;
    return f->end - rva;
}

std::optional<Inventory> walk(const pe::Image& img) {
    const pe::DataDir dir = img.directory(pe::kDirException);
    if (!dir.rva || dir.size < 12) return std::nullopt;

    // The code section is whatever is executable, not necessarily ".text". FiveM's
    // game process is built by RAGE, calls its code ".zdata" and puts runtime
    // functions in ".rd_pef"; a name-based assumption yields nothing at all.
    const auto code = img.code_sections();
    if (code.empty()) return std::nullopt;

    uint32_t code_begin = 0xFFFFFFFFu, code_end = 0;
    for (const pe::Section* s : code) {
        const uint32_t span = s->span();
        if (s->rva < code_begin) code_begin = s->rva;
        if (s->rva + span > code_end) code_end = s->rva + span;
    }

    const uint32_t entries = dir.size / 12u;
    if (entries == 0 || entries > 4'000'000u) return std::nullopt;
    if (!img.in_range(dir.rva, entries * 12u)) return std::nullopt;

    Inventory inv;
    inv.code_begin = code_begin;
    inv.code_end   = code_end;
    inv.functions.reserve(entries);

    for (uint32_t i = 0; i < entries; ++i) {
        const uint8_t* p = img.at(dir.rva + i * 12u);
        Function fn;
        std::memcpy(&fn.begin,  p + 0, 4);
        std::memcpy(&fn.end,    p + 4, 4);
        std::memcpy(&fn.unwind, p + 8, 4);

        if (fn.begin == 0 && fn.end == 0) continue;      // zero-fill padding tail
        if (fn.begin >= fn.end) continue;                 // reverse-chained entries
        if (fn.end > img.size()) continue;
        if (!img.is_code(fn.begin) || !img.is_code(fn.end - 1)) continue;
        if (fn.end - fn.begin < 3) continue;              // thunks / leaf stubs

        read_unwind(img, fn.unwind, fn);  // defaults survive a malformed unwind blob
        inv.functions.push_back(fn);
    }
    if (inv.functions.empty()) return std::nullopt;

    std::sort(inv.functions.begin(), inv.functions.end(),
              [](const Function& a, const Function& b) { return a.begin < b.begin; });
    return inv;
}

}  // namespace dmp::pd
