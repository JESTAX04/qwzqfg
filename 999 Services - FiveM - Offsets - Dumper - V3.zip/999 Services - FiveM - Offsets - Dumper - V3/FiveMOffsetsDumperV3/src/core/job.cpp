// language: C++, file: src/core/job.cpp, target: Windows 11, MSVC, x64
#include "core/job.hpp"

#include "core/pdata.hpp"
#include "core/rtti.hpp"
#include "core/scanner.hpp"
#include "core/table.hpp"
#include "memory/memory.hpp"
#include "utils/utils.hpp"
#include "version.hpp"

#include <chrono>
#include <cstring>
#include <ctime>
#include <exception>
#include <iomanip>
#include <sstream>
#include <unordered_map>

namespace dmp::job {
namespace {

using steady = std::chrono::steady_clock;

uint64_t ms_since(steady::time_point t0) {
    return static_cast<uint64_t>(
        std::chrono::duration_cast<std::chrono::milliseconds>(steady::now() - t0).count());
}

std::string hex64(uint64_t v) {
    std::ostringstream ss;
    ss << "0x" << std::hex << std::uppercase << v;
    return ss.str();
}

std::string describe_code_sections(const pe::Image& img) {
    std::ostringstream ss;
    bool first = true;
    for (const pe::Section* s : img.code_sections()) {
        if (!first) ss << ", ";
        first = false;
        ss << s->name << "@0x" << std::hex << std::uppercase << s->rva
           << "+0x" << s->span();
    }
    if (first) ss << "<none>";
    return ss.str();
}

std::string utc_now() {
    std::time_t t = std::time(nullptr);
    std::tm g{};
    gmtime_s(&g, &t);
    char buf[32] = {};
    std::strftime(buf, sizeof(buf), "%Y-%m-%dT%H:%M:%SZ", &g);
    return buf;
}

// A target descriptor that works for both entry points. `live` is null for an
// offline run, which is what turns every process-touching stage off.
struct RunTarget {
    void*                live = nullptr;   // Win32 HANDLE as void*
    const proc::Snapshot* snap = nullptr;  // null when offline
};

std::string hex32(uint32_t v) {
    std::ostringstream ss;
    ss << "0x" << std::hex << std::uppercase << std::setw(8) << std::setfill('0') << v;
    return ss.str();
}

// Turns a match into the address the entry's Form says it yields. Shared by the
// pipeline and the audit so the two can never disagree about what a symbol means.
bool resolve_match(const pe::Image& img, const tbl::Entry& e, uint32_t match_rva,
                   uint32_t& target_rva) {
    uint32_t t_rva = 0;
    // The instruction the form resolves may sit inside the match rather than at its
    // start, so every displacement is read relative to that offset.
    const uint32_t insn = match_rva + static_cast<uint32_t>(e.insn_offset);
    switch (e.form) {
    case tbl::Form::RipRelative: {
        const int32_t disp = img.read_or<int32_t>(insn + 3, 0);
        const int64_t t = static_cast<int64_t>(insn) + 7 + disp;
        if (t <= 0 || t >= static_cast<int64_t>(img.size())) return false;
        t_rva = static_cast<uint32_t>(t);
        break;
    }
    case tbl::Form::Call: {
        const int32_t disp = img.read_or<int32_t>(insn + 1, 0);
        const int64_t t = static_cast<int64_t>(insn) + 5 + disp;
        if (t <= 0 || t >= static_cast<int64_t>(img.size())) return false;
        t_rva = static_cast<uint32_t>(t);
        break;
    }
    case tbl::Form::DispField: {
        // The disp32 IS the symbol: a field offset inside the object held in the
        // instruction's base register. Bounds-guarded so a drifted pattern cannot
        // publish an absurd "offset" from misread bytes; a real member offset is
        // small and positive.
        const int32_t disp = img.read_or<int32_t>(insn + 3, 0);
        if (disp <= 0 || disp > 0x100000) return false;
        t_rva = static_cast<uint32_t>(disp);
        break;
    }
    case tbl::Form::Direct:
        t_rva = insn;
        break;
    case tbl::Form::Export:
        // Nothing to resolve: the address came out of the export directory.
        return false;
    }

    if (e.target_delta != 0) {
        const int64_t t = static_cast<int64_t>(t_rva) + e.target_delta;
        if (t <= 0 || t >= static_cast<int64_t>(img.size())) return false;
        t_rva = static_cast<uint32_t>(t);
    }
    target_rva = t_rva;
    return true;
}

// What the resolved instruction actually is. This is the difference between a
// symbol a consumer dereferences and one it must not: `lea rcx,[rip+X]` hands over
// the address of X itself, while `mov rcx,[rip+X]` hands over the address of a
// pointer variable holding X. Reporting them identically is how a consumer ends up
// reading the first member of an object and calling it a pointer.
enum class RipShape { None, AddressOf, PointerLoad, Call };

RipShape rip_shape(const pe::Image& img, uint32_t match_rva) {
    const uint8_t* p = img.span(match_rva, 8);
    if (!p) return RipShape::None;
    uint32_t i = 0;
    while (i < 4 && p[i] >= 0x40 && p[i] <= 0x4F) ++i;   // REX prefixes
    if (i >= 8) return RipShape::None;
    switch (p[i]) {
    case 0x8D: return RipShape::AddressOf;
    case 0x8B: return RipShape::PointerLoad;
    case 0xE8: return RipShape::Call;
    default:   break;
    }
    return RipShape::None;
}

std::string describe_instruction(const pe::Image& img, uint32_t match_rva) {
    switch (rip_shape(img, match_rva)) {
    case RipShape::AddressOf:
        return "lea -- the operand is the address of the object itself; do not deref to reach it";
    case RipShape::PointerLoad:
        return "mov reg,[rip+disp] -- the operand is a pointer variable; deref once";
    case RipShape::Call:
        return "call rel32 -- the operand is the callee";
    default:
        break;
    }
    return {};
}

// The declared kind is what the table author intended; the operand instruction is
// what the bytes prove. For a RIP-relative data entry the two must agree, and when
// they do not the bytes win: dereferencing the address of an object reads its first
// member and calls it a pointer, which is exactly how a "null pointer" gets
// reported for an offset that is perfectly correct.
rv::Kind derive_kind(const pe::Image& img, const tbl::Entry& e, uint32_t match_rva) {
    if (e.form != tbl::Form::RipRelative) return e.kind;
    switch (rip_shape(img, match_rva + static_cast<uint32_t>(e.insn_offset))) {
    case RipShape::AddressOf:   return rv::Kind::DataGlobal;
    case RipShape::PointerLoad: return rv::Kind::GlobalPointer;
    default:                    break;
    }
    return e.kind;
}

}  // namespace

const char* stage_name(Stage s) {
    switch (s) {
    case Stage::Idle:       return "idle";
    case Stage::Attach:     return "attach";
    case Stage::ReadImage:  return "reading image";
    case Stage::ParsePdata: return "parsing .pdata";
    case Stage::Scan:       return "scanning";
    case Stage::Resolve:    return "resolving";
    case Stage::Verify:     return "verifying";
    case Stage::Rtti:       return "RTTI";
    case Stage::Export:     return "exporting";
    case Stage::Done:       return "done";
    case Stage::Failed:     return "failed";
    }
    return "?";
}

void Progress::say(const std::string& s) {
    std::lock_guard<std::mutex> lock(mtx_);
    message_ = s;
}

std::string Progress::text() {
    std::lock_guard<std::mutex> lock(mtx_);
    return message_;
}

namespace {

// The whole pipeline, over an image that is already in memory. Both public entry
// points funnel through here so there is exactly one implementation of the scan,
// the resolve, the RTTI pass and the export.
Outcome run_image(const pe::Image& image, const RunTarget& rt,
                  const Settings& settings, Progress& p) {
    Outcome out;
    const bool live = (rt.live != nullptr) && (rt.snap != nullptr);

    auto finish = [&](bool ok, const std::string& err) {
        out.success = ok;
        out.error   = err;
        p.running   = false;
        p.stage     = static_cast<int>(ok ? Stage::Done : Stage::Failed);
        if (!ok && !err.empty()) log::fail(err);
        return out;
    };

    const std::string module_name = live ? rt.snap->name : image.info().name;
    const uint32_t build = proc::build_from_name(module_name);

    // --------------------------------------------------------------- pdata --
    p.stage = static_cast<int>(Stage::ParsePdata);
    p.say("walking .pdata...");
    auto pdata = pd::walk(image);
    if (pdata) {
        log::ok(".pdata: " + std::to_string(pdata->size()) + " functions");
    } else {
        // Not fatal: the pattern scan and the RTTI enumeration both work without
        // it. Only signature synthesis and field recovery need function bounds.
        pdata = pd::Inventory{};
        log::warn(".pdata unavailable; signatures and field recovery will be skipped.");
    }

    // ---------------------------------------------------------------- scan --
    p.stage = static_cast<int>(Stage::Scan);

    // The table is chosen by module: the GTA globals live in the game process,
    // the Lua state lives in the scripting module.
    const tbl::TableRef table = tbl::table_for(module_name);
    if (table.entries == nullptr || table.count == 0) {
        return finish(false, "no signature table for " + module_name);
    }
    log::info("table: " + std::string(table.label) + ", "
              + std::to_string(table.count) + " symbol(s)");

    // The export directory is read once. An exported symbol needs no signature and
    // no hunt, which is exactly why the Lua anchor is an export.
    std::unordered_map<std::string, uint32_t> export_rvas;
    {
        const std::vector<pe::Export> ex = pe::exports(image);
        for (const pe::Export& e : ex) export_rvas.emplace(e.name, e.rva);
        if (!ex.empty()) {
            log::info("export directory: " + std::to_string(ex.size()) + " name(s)");
        }
    }

    p.say("scanning code sections...");
    std::vector<pat::Pattern> pats;
    pats.reserve(table.count);
    for (size_t i = 0; i < table.count; ++i) {
        // An Export entry carries a mangled name rather than bytes, so it is left
        // out of the scan and resolved from the directory instead. An empty
        // pattern is never bucketed, so it can never produce a spurious match.
        pats.push_back(table.entries[i].form == tbl::Form::Export
                     ? pat::Pattern{}
                     : pat::parse(table.entries[i].signature));
    }
    out.stats.patterns_total = static_cast<uint32_t>(table.count);

    const auto t_scan = steady::now();
    const std::vector<scan::Match> matches = scan::scan_all(image, pats, 8);
    out.stats.scan_ms = ms_since(t_scan);

    std::vector<std::vector<scan::Match>> by_pattern(pats.size());
    for (const scan::Match& m : matches) {
        if (m.pattern_index < by_pattern.size()) by_pattern[m.pattern_index].push_back(m);
    }
    log::ok("scan: " + std::to_string(matches.size()) + " hits in "
            + std::to_string(out.stats.scan_ms) + " ms");
    if (p.cancel) return finish(false, "cancelled.");

    if (settings.fallback_image_scan) {
        std::vector<pat::Pattern> missing;
        std::vector<uint32_t>     missing_index;
        for (uint32_t i = 0; i < pats.size(); ++i) {
            if (by_pattern[i].empty()) {
                missing.push_back(pats[i]);
                missing_index.push_back(i);
            }
        }
        if (!missing.empty()) {
            p.say("fallback scan outside code for " + std::to_string(missing.size())
                  + " pattern(s)...");
            const auto t_fb = steady::now();
            const std::vector<scan::Match> hits = scan::scan_all_image(image, missing, 2);
            for (const scan::Match& m : hits) {
                if (m.pattern_index >= missing_index.size()) continue;
                const uint32_t real = missing_index[m.pattern_index];
                if (by_pattern[real].size() >= 2) continue;
                by_pattern[real].push_back(m);
            }
            log::warn("fallback scan: " + std::to_string(hits.size())
                      + " hit(s) outside code in " + std::to_string(ms_since(t_fb))
                      + " ms; these are unverifiable.");
        }
    }

    // ------------------------------------------------------------- resolve --
    p.stage = static_cast<int>(Stage::Resolve);
    p.say("resolving addresses...");

    const uint64_t load_base = image.info().load_base;
    out::Bundle bundle;
    bundle.patterns_total = out.stats.patterns_total;
    bundle.scan_ms        = out.stats.scan_ms;
    bundle.prov.tool          = ver::kToolId;
    bundle.prov.generated_utc = utc_now();
    bundle.prov.module        = module_name;
    bundle.prov.build         = build;
    bundle.prov.load_base     = load_base;
    bundle.prov.module_size   = image.size();
    bundle.prov.pe_timestamp  = image.info().timestamp;
    bundle.prov.code_hash     = pe::code_hash(image);
    bundle.prov.code_sections = describe_code_sections(image);
    bundle.prov.live          = live;
    if (live) bundle.prov.image_path = rt.snap->image_path;

    out.stats.code_hash = bundle.prov.code_hash;
    out.stats.code_sections = static_cast<uint32_t>(image.code_sections().size());

    for (uint32_t i = 0; i < table.count; ++i) {
        const tbl::Entry& e = table.entries[i];

        rv::Result r;
        r.name           = e.name;
        r.kind           = e.kind;
        r.pattern        = (e.form == tbl::Form::Export)
                         ? std::string("export ") + e.signature
                         : pats[i].str();
        r.operand_offset = tbl::operand_offset_of(e.form, e.insn_offset);
        r.target_delta   = e.target_delta;

        // An export needs no scan: the loader already resolved it by name. This is
        // the anchor that costs nothing to carry across a patch.
        if (e.form == tbl::Form::Export) {
            const auto it = export_rvas.find(e.signature);
            if (it == export_rvas.end()) {
                r.verify.status = rv::Status::NotFound;
                log::warn(std::string(e.name) + ": export absent from this build");
                bundle.symbols.push_back(std::move(r));
                continue;
            }
            r.rva       = it->second;
            r.match_rva = r.rva;
            r.address   = load_base + r.rva;
            r.from_code = image.is_code(r.rva);
            ++out.stats.patterns_found;
            bundle.symbols.push_back(std::move(r));
            continue;
        }

        const std::vector<scan::Match>& hits = by_pattern[i];
        if (hits.empty()) {
            r.verify.status = rv::Status::NotFound;
            bundle.symbols.push_back(std::move(r));
            continue;
        }

        const scan::Match& m = hits.front();
        r.match_rva = m.rva;
        r.from_code = (m.section != nullptr) && m.section->has(pe::kMemExecute);
        // Let the operand instruction correct the declared kind before anything
        // validates the result against it.
        r.kind      = derive_kind(image, e, m.rva);

        // A second occurrence means the signature does not identify anything on its
        // own. Rather than take the first hit and hope, widen the pattern with the
        // bytes that follow the site until only one occurrence remains. Widening is
        // forward-only, so the match start stays put and operand_offset still
        // addresses the same displacement.
        if (hits.size() > 1) {
            const scan::Widened w = scan::stabilise(image, pats[i], hits.front().rva);
            if (w.unique) {
                pats[i]    = w.pattern;
                r.pattern  = pats[i].str();
                log::warn(std::string(e.name) + ": matched " + std::to_string(hits.size())
                          + " times; widened by " + std::to_string(w.extra)
                          + " byte(s) to a unique signature.");
            } else {
                r.verify.status = rv::Status::Ambiguous;
            }
        }

        uint32_t target_rva = 0;
        const bool resolved = resolve_match(image, e, m.rva, target_rva);

        if (!resolved) {
            if (r.verify.status != rv::Status::Ambiguous) {
                r.verify.status = rv::Status::OutsideImage;
            }
            bundle.symbols.push_back(std::move(r));
            continue;
        }

        r.rva     = target_rva;
        r.address = load_base + target_rva;
        ++out.stats.patterns_found;

        if (!r.from_code && r.verify.status != rv::Status::Ambiguous) {
            r.verify.status = rv::Status::Unverified;
        }
        bundle.symbols.push_back(std::move(r));
    }

    // How many places in code reference each data global. A global with zero
    // references on this build is one the game stopped using, which is worth
    // knowing before a consumer relies on it.
    for (rv::Result& r : bundle.symbols) {
        if (r.kind != rv::Kind::GlobalPointer && r.kind != rv::Kind::DataGlobal) continue;
        if (r.rva == 0) continue;
        uint32_t refs = 0;
        for (const pe::Section* s : image.code_sections()) {
            refs += static_cast<uint32_t>(
                scan::find_rip_refs(image, r.rva, s->rva, s->span()).size());
        }
        r.refs = refs;
    }

    // -------------------------------------------------------------- verify --
    if (settings.do_verify && live) {
        p.stage = static_cast<int>(Stage::Verify);
        p.say("verifying resolved addresses against the live target...");
        const auto t_verify = steady::now();
        p.total = static_cast<int>(bundle.symbols.size());
        p.done  = 0;

        for (rv::Result& r : bundle.symbols) {
            if (r.verify.status == rv::Status::NotFound ||
                r.verify.status == rv::Status::OutsideImage ||
                r.verify.status == rv::Status::Unverified) {
                ++p.done;
                continue;
            }
            const rv::Verify v = rv::verify_address(rt.live, *rt.snap, r.address, r.kind);
            if (r.verify.status == rv::Status::Ambiguous) {
                // An ambiguity note outranks a clean verification: the offset is
                // real, but the signature that produced it is not trustworthy.
                const rv::Status keep = r.verify.status;
                r.verify = v;
                if (v.status == rv::Status::Ok) r.verify.status = keep;
            } else {
                r.verify = v;
            }
            if (r.verify.status == rv::Status::Ok)             ++out.stats.verified;
            else if (r.verify.status == rv::Status::Ambiguous) ++out.stats.unverified;
            else if (r.verify.status == rv::Status::Unpopulated) ++out.stats.unpopulated;
            else                                              ++out.stats.failed;
            ++p.done;
        }
        out.stats.verify_ms = ms_since(t_verify);
        log::ok("verify: " + std::to_string(out.stats.verified) + " ok, "
                + std::to_string(out.stats.failed) + " failed, "
                + std::to_string(out.stats.unverified) + " ambiguous, "
                + std::to_string(out.stats.unpopulated) + " not yet populated");
    } else if (settings.do_verify && !live) {
        // Offline: there is nothing to read the addresses back from, so results
        // stay marked as resolved-but-unvalidated rather than being reported as
        // verified on the strength of arithmetic alone.
        for (rv::Result& r : bundle.symbols) {
            if (r.verify.status == rv::Status::NotFound ||
                r.verify.status == rv::Status::OutsideImage) continue;
            if (r.verify.status == rv::Status::Ambiguous) { ++out.stats.unverified; continue; }
            ++out.stats.verified;
        }
        log::warn("offline run: addresses resolved from the image but NOT validated "
                  "against a live process.");
    }
    if (p.cancel) return finish(false, "cancelled.");

    // ---------------------------------------------------------------- rtti --
    if (settings.do_rtti) {
        p.stage = static_cast<int>(Stage::Rtti);
        p.say("enumerating RTTI vftables...");
        const auto t_rtti = steady::now();

        bundle.rtti.tables = rtti::enumerate(image);
        bundle.rtti.enumerated = static_cast<uint32_t>(bundle.rtti.tables.size());
        uint32_t named = 0;
        for (const rtti::Vtable& t : bundle.rtti.tables) if (t.named()) ++named;
        bundle.rtti.named = named;
        log::ok("RTTI: " + std::to_string(bundle.rtti.enumerated) + " confirmed vftables, "
                + std::to_string(named) + " named");

        if (!pdata->empty()) {
            rtti::Options ro;
            ro.max_tables        = settings.rtti_max_tables;
            ro.max_methods_total = settings.rtti_max_methods;
            ro.signatures        = true;
            ro.fields            = true;

            p.total = static_cast<int>(ro.max_tables);
            p.done  = 0;
            rtti::recover(image, *pdata, bundle.rtti, ro,
                [&](uint32_t done, uint32_t total) {
                    p.done  = static_cast<int>(done);
                    p.total = static_cast<int>(total);
                    p.say("recovering methods: " + std::to_string(done) + "/"
                          + std::to_string(total) + " classes");
                },
                [&]() { return p.cancel.load(); });
        } else {
            log::warn("RTTI tables found but .pdata is unavailable; method signatures "
                      "and field chains need function bounds.");
        }

        out.stats.vftables        = bundle.rtti.enumerated;
        out.stats.vftables_named  = bundle.rtti.named;
        out.stats.rtti_signatures = bundle.rtti.signatures;
        out.stats.field_sets      = bundle.rtti.field_sets;
        out.stats.rtti_ms         = ms_since(t_rtti);
        log::ok("RTTI recovered in " + std::to_string(out.stats.rtti_ms) + " ms: "
                + std::to_string(bundle.rtti.signatures) + " signatures, "
                + std::to_string(bundle.rtti.field_sets) + " field sets");
    }
    if (p.cancel) return finish(false, "cancelled.");

    // -------------------------------------------------------------- export --
    p.stage = static_cast<int>(Stage::Export);
    p.say("writing exports...");
    const auto t_export = steady::now();

    out::WriteOptions wo;
    wo.out_dir      = settings.out_root;
    wo.write_json   = settings.export_json;
    wo.write_header = settings.export_header;
    wo.write_table  = settings.export_table;
    wo.write_report = settings.export_report;

    const out::Written written = out::write_all(bundle, wo);
    for (const std::string& e : written.errors) log::fail(e);
    out.stats.files_written = static_cast<uint32_t>(written.paths.size());
    out.stats.export_ms     = ms_since(t_export);
    out.out_dir             = out::module_dir(settings.out_root, module_name);

    for (const std::filesystem::path& path : written.paths) {
        log::ok("wrote " + path.string());
    }
    if (written.paths.empty()) {
        return finish(false, "nothing was written; check the output directory.");
    }

    return finish(true, {});
}

}  // namespace

Outcome run(proc::Target& target, const Settings& settings, Progress& p) {
    p.cancel  = false;
    p.running = true;

    // --------------------------------------------------------------- attach --
    p.stage = static_cast<int>(Stage::Attach);
    p.say("locating FiveM...");
    if (!target.attached() || !target.reattach_if_stale()) {
        p.running = false;
        p.stage   = static_cast<int>(Stage::Failed);
        const std::string err = "FiveM is not running (no grcWindow). Start the game first.";
        log::fail(err);
        Outcome out;
        out.error = err;
        return out;
    }
    target.refresh(0);
    const proc::Snapshot& snap = target.snapshot();
    if (!snap.valid || !snap.base) {
        p.running = false;
        p.stage   = static_cast<int>(Stage::Failed);
        const std::string err = "attached, but the main module could not be enumerated.";
        log::fail(err);
        Outcome out;
        out.error = err;
        return out;
    }
    log::ok("target: " + snap.name + " (pid " + std::to_string(snap.pid) + ")"
            + (proc::build_from_name(snap.name)
                   ? ", build " + std::to_string(proc::build_from_name(snap.name)) : "")
            + ", base " + hex64(snap.base));

    // ----------------------------------------------------------- read image --
    p.stage = static_cast<int>(Stage::ReadImage);
    p.say("reading " + hex64(snap.module_size) + " bytes of module image...");
    const auto t_read = steady::now();

    std::optional<pe::Image> image =
        pe::Image::from_process(target.handle(), snap.base, snap.name);
    if (!image || image->size() == 0) {
        p.running = false;
        p.stage   = static_cast<int>(Stage::Failed);
        const std::string err =
            "could not read the module image; the process may be protected.";
        log::fail(err);
        Outcome out;
        out.error = err;
        return out;
    }

    const auto code = image->code_sections();
    if (code.empty()) {
        p.running = false;
        p.stage   = static_cast<int>(Stage::Failed);
        const std::string err =
            "no executable section found. The image parse is wrong, or the module "
            "uses an unexpected layout.";
        log::fail(err);
        Outcome out;
        out.error = err;
        return out;
    }

    log::ok("image " + hex64(image->size()) + " read in "
            + std::to_string(ms_since(t_read)) + " ms");
    log::info("code sections: " + describe_code_sections(*image));

    RunTarget rt;
    rt.live = target.handle();
    rt.snap = &snap;

    Outcome out;
    try {
        out = run_image(*image, rt, settings, p);
    } catch (const std::exception& ex) {
        p.running = false;
        p.stage   = static_cast<int>(Stage::Failed);
        out.error = std::string("pipeline threw: ") + ex.what();
        log::fail(out.error);
    } catch (...) {
        p.running = false;
        p.stage   = static_cast<int>(Stage::Failed);
        out.error = "pipeline threw an unknown exception.";
        log::fail(out.error);
    }
    out.stats.read_ms = ms_since(t_read);
    return out;
}

Outcome run_offline(const std::filesystem::path& pe_path, const Settings& settings,
                    Progress& p) {
    p.cancel  = false;
    p.running = true;
    p.stage   = static_cast<int>(Stage::ReadImage);
    p.say("reading " + pe_path.string());

    Outcome out;
    auto image = pe::Image::from_file(pe_path);
    if (!image || image->size() == 0) {
        p.running = false;
        p.stage   = static_cast<int>(Stage::Failed);
        out.error = "not a readable PE32+ image: " + pe_path.string();
        log::fail(out.error);
        return out;
    }
    log::ok("image " + hex64(image->size()) + " mapped from disk: "
            + describe_code_sections(*image));

    // No process, so every verification stage turns itself off inside run_image.
    const RunTarget rt;
    try {
        out = run_image(*image, rt, settings, p);
    } catch (const std::exception& ex) {
        p.running = false;
        p.stage   = static_cast<int>(Stage::Failed);
        out.error = std::string("pipeline threw: ") + ex.what();
        log::fail(out.error);
    } catch (...) {
        p.running = false;
        p.stage   = static_cast<int>(Stage::Failed);
        out.error = "pipeline threw an unknown exception.";
        log::fail(out.error);
    }
    return out;
}

bool grep_file(const std::filesystem::path& pe_path, const std::string& signature,
               uint32_t limit, std::vector<GrepHit>& out, std::string& err) {
    out.clear();
    auto image = pe::Image::from_file(pe_path);
    if (!image || image->size() == 0) {
        err = "not a readable PE32+ image: " + pe_path.string();
        return false;
    }
    const pat::Pattern p = pat::parse(signature);
    if (p.empty()) {
        err = "signature parsed to nothing";
        return false;
    }

    // Routed through scan_all so this exercises the same bucket table the table
    // scan uses, rather than a private single-pattern loop that could hide a bug.
    const std::vector<pat::Pattern> pats{ p };
    const std::vector<scan::Match> hits = scan::scan_all(*image, pats, limit);

    for (const scan::Match& m : hits) {
        GrepHit h;
        h.rva        = m.rva;
        h.section    = m.section ? m.section->name : "<none>";
        h.executable = m.section != nullptr && m.section->has(pe::kMemExecute);
        out.push_back(std::move(h));
    }
    if (out.empty()) {
        // Worth distinguishing "present but outside code" from "absent": the first
        // is a signature that resolved to data, which is not a usable anchor.
        const std::vector<scan::Match> anywhere = scan::scan_all_image(*image, pats, limit);
        for (const scan::Match& m : anywhere) {
            GrepHit h;
            h.rva        = m.rva;
            h.section    = m.section ? m.section->name : "<none>";
            h.executable = false;
            out.push_back(std::move(h));
        }
        if (!out.empty()) err = "matched only outside executable memory";
    }
    return true;
}

// ---------------------------------------------------------------------- audit --

namespace {

// A verdict of "ok" is the only clean outcome; everything else is a symbol the
// table got wrong for this build and that a consumer would misread.
bool needs_attention(const AuditRow& r) { return r.verdict != "ok"; }

void audit_one(const pe::Image& image, void* live, const proc::Snapshot* snap,
               const tbl::Entry& e, const std::string& signature,
               uint32_t fuzzy_mismatch, AuditRow& row) {
    row.name = e.name;
    row.kind = rv::kind_name(e.kind);

    const pat::Pattern p = pat::parse(signature);
    if (p.empty()) {
        row.verdict = "bad_signature";
        row.detail  = "the signature does not parse";
        return;
    }

    const std::vector<scan::Match> hits = scan::scan_all(image, { p }, 32);
    row.match_count = static_cast<uint32_t>(hits.size());
    for (const scan::Match& m : hits) row.matches.push_back(m.rva);

    if (hits.empty()) {
        // The site is usually still there with a constant or two moved. Search by
        // tolerance rather than declaring the symbol lost.
        const std::vector<scan::FuzzyHit> near =
            scan::fuzzy_code(image, p, fuzzy_mismatch, 8);

        if (near.empty()) {
            row.verdict = "not_found";
            row.detail  = "no site within " + std::to_string(fuzzy_mismatch)
                        + " differing concrete byte(s); the code is gone or the "
                          "signature belongs to a different build";
            return;
        }

        const scan::FuzzyHit& best = near.front();
        row.verdict             = "repaired";
        row.rva                 = best.rva;
        row.proposed_mismatch   = best.mismatches;
        row.detail = "nearest site " + hex32(best.rva) + " differs in "
                   + std::to_string(best.mismatches) + "/"
                   + std::to_string(best.concrete) + " concrete byte(s)"
                   + (near.size() > 1 ? ", " + std::to_string(near.size() - 1)
                                        + " other near site(s)" : "");

        // Rebuild the signature from the bytes that are actually there, at the
        // original length so operand_offset keeps addressing the same byte, then
        // widen it: a repaired site is usually a common idiom, and a repaired
        // signature that matches eight places is no better than no signature.
        pat::Pattern fixed =
            scan::pattern_from_site(image, best.rva, static_cast<uint32_t>(p.length()));
        if (!fixed.empty()) {
            const scan::Widened w = scan::stabilise(image, fixed, best.rva);
            if (w.unique) {
                fixed = w.pattern;
                row.proposed_unique = true;
                row.detail += "; widened by " + std::to_string(w.extra) + " byte(s) to unique";
            } else {
                row.proposed_unique = scan::count_code(image, fixed, 2) == 1;
            }
            row.proposed = fixed.str();
        }
        row.operand_note = describe_instruction(image, best.rva);
        return;
    }

    if (hits.size() > 1) {
        const scan::Widened w = scan::stabilise(image, p, hits.front().rva);
        row.rva = hits.front().rva;
        if (w.unique) {
            row.verdict         = "ambiguous_widened";
            row.proposed        = w.pattern.str();
            row.proposed_unique = true;
            row.detail = "matched " + std::to_string(hits.size())
                       + " times; widened by " + std::to_string(w.extra)
                       + " byte(s) to a unique signature";
        } else {
            row.verdict = "ambiguous";
            row.detail  = "matched " + std::to_string(hits.size())
                        + " times and stayed ambiguous after widening by "
                        + std::to_string(w.extra) + " byte(s)";
        }
        if (e.form == tbl::Form::RipRelative || e.form == tbl::Form::Call) {
            row.operand_note = describe_instruction(image, hits.front().rva);
        }
        return;
    }

    uint32_t target = 0;
    if (!resolve_match(image, e, hits.front().rva, target)) {
        row.verdict = "outside_image";
        row.detail  = "the displacement points outside the image";
        return;
    }
    row.rva          = target;
    // The operand note describes what the RESOLVED OPERAND is, so it only means
    // something for a form that resolves one. For a patch site the address is the
    // instruction itself and "do not deref to reach it" is noise.
    if (e.form == tbl::Form::RipRelative || e.form == tbl::Form::Call) {
        row.operand_note =
            describe_instruction(image, hits.front().rva
                                 + static_cast<uint32_t>(e.insn_offset));
    }

    // Same correction the pipeline applies: the operand instruction decides whether
    // this is an object address or a pointer variable, and the audit has to agree
    // with the dump or it would report failures the dump does not have.
    const rv::Kind kind = derive_kind(image, e, hits.front().rva);
    row.kind = rv::kind_name(kind);

    if (!live || !snap) {
        row.verdict = "resolved";
        row.detail  = "resolved from the image; offline, so not validated";
        return;
    }

    const rv::Verify v =
        rv::verify_address(live, *snap, image.info().load_base + target, kind);
    row.verdict = rv::status_name(v.status);
    switch (v.status) {
    case rv::Status::Ok:
        row.detail = "verified against the live target";
        break;
    case rv::Status::Unpopulated: {
        // Say where the slot actually lives. A writable pointer variable in the
        // module's own data section is a real global that is simply still zero; the
        // reader can then decide whether the game has populated it yet or whether
        // the signature drifted onto a neighbouring slot.
        const pe::Section* sec = image.section_of(target);
        row.detail = std::string("the address reads and holds zero; the operand is a ")
                   + (sec ? sec->name : std::string("<unmapped>"))
                   + " global at " + hex32(target)
                   + ", so this is not a bad offset -- only an unfilled one";
        break;
    }
    case rv::Status::NullPointer:
        row.detail = "the resolved address itself is null";
        break;
    case rv::Status::NotReadable:
        row.detail = "the resolved page does not read back";
        break;
    case rv::Status::NotExecutable:
        row.detail = "resolved into non-executable memory for a code kind";
        break;
    case rv::Status::DerefFailed:
        row.detail = "the pointer read back lands on unmapped memory";
        if (!v.writable) {
            row.detail = "the operand holds zero and is NOT in writable memory, "
                         "so this is the wrong site rather than an unfilled global";
        }
        break;
    default:
        row.detail = rv::status_name(v.status);
        break;
    }
}

AuditResult audit_image(const pe::Image& image, void* live, const proc::Snapshot* snap,
                        const std::vector<std::string>& only, uint32_t fuzzy_mismatch,
                        bool include_clean) {
    AuditResult res;
    res.module      = live && snap ? snap->name : image.info().name;
    res.load_base   = image.info().load_base;
    res.module_size = image.size();
    res.build       = proc::build_from_name(res.module);

    auto wanted = [&](const char* name) {
        if (only.empty()) return true;
        for (const std::string& n : only) {
            if (n == name) return true;
        }
        return false;
    };

    for (size_t i = 0; i < tbl::kTableCount; ++i) {
        const tbl::Entry& e = tbl::kTable[i];
        if (!wanted(e.name)) continue;
        ++res.examined;

        AuditRow row;
        audit_one(image, live, snap, e, e.signature, fuzzy_mismatch, row);

        if (needs_attention(row)) {
            ++res.attention;
            res.rows.push_back(std::move(row));
        } else {
            ++res.clean;
            if (include_clean) res.rows.push_back(std::move(row));
        }
    }
    res.ok = true;
    return res;
}

}  // namespace

AuditResult audit_live(const std::vector<std::string>& only, uint32_t fuzzy_mismatch,
                       bool include_clean) {
    AuditResult res;
    proc::Target target;
    if (!target.attach()) {
        res.error = "FiveM is not running (no grcWindow). Start the game first.";
        return res;
    }
    target.refresh(0);
    const proc::Snapshot& snap = target.snapshot();
    if (!snap.valid) {
        res.error = "attached, but the main module could not be enumerated.";
        return res;
    }

    auto image = pe::Image::from_process(target.handle(), snap.base, snap.name);
    if (!image || image->size() == 0) {
        res.error = "could not read the module image.";
        return res;
    }
    return audit_image(*image, target.handle(), &snap, only, fuzzy_mismatch, include_clean);
}

AuditResult audit_file(const std::filesystem::path& pe_path,
                       const std::vector<std::string>& only, uint32_t fuzzy_mismatch,
                       bool include_clean) {
    AuditResult res;
    auto image = pe::Image::from_file(pe_path);
    if (!image || image->size() == 0) {
        res.error = "not a readable PE32+ image: " + pe_path.string();
        return res;
    }
    return audit_image(*image, nullptr, nullptr, only, fuzzy_mismatch, include_clean);
}

// --------------------------------------------------------------- exports -----

namespace {

bool iequals(const std::string& a, const std::string& b) {
    if (a.size() != b.size()) return false;
    for (size_t i = 0; i < a.size(); ++i) {
        char ca = a[i], cb = b[i];
        if (ca >= 'A' && ca <= 'Z') ca = static_cast<char>(ca + 32);
        if (cb >= 'A' && cb <= 'Z') cb = static_cast<char>(cb + 32);
        if (ca != cb) return false;
    }
    return true;
}

std::vector<ExportRow> to_export_rows(const std::vector<pe::Export>& ex,
                                      const pe::Image& image,
                                      const std::string& filter) {
    std::vector<ExportRow> out;
    for (const pe::Export& e : ex) {
        if (!filter.empty() && e.name.find(filter) == std::string::npos) continue;
        ExportRow r;
        r.name      = e.name;
        r.ordinal   = e.ordinal;
        r.rva       = e.rva;
        r.forwarded = e.forwarded;
        // Capture the prologue so a detour target can be inspected without going
        // anywhere near the process.
        if (!e.forwarded &&
            image.in_range(e.rva, static_cast<uint32_t>(r.head.size()))) {
            std::memcpy(r.head.data(), image.at(e.rva), r.head.size());
            r.head_valid = true;
        }
        out.push_back(std::move(r));
    }
    std::sort(out.begin(), out.end(),
              [](const ExportRow& a, const ExportRow& b) { return a.rva < b.rva; });
    return out;
}

const proc::Module* find_module(const proc::Snapshot& snap, const std::string& name) {
    for (const proc::Module& m : snap.modules) {
        if (iequals(m.name, name)) return &m;
    }
    return nullptr;
}

}  // namespace

std::vector<std::string> live_module_names() {
    std::vector<std::string> out;
    proc::Target target;
    if (!target.attach()) return out;
    target.refresh(0);
    const proc::Snapshot& snap = target.snapshot();
    for (const proc::Module& m : snap.modules) out.push_back(m.name);
    std::sort(out.begin(), out.end());
    return out;
}

std::vector<ExportRow> exports_of_file(const std::filesystem::path& pe_path,
                                       const std::string& filter, std::string& err) {
    auto image = pe::Image::from_file(pe_path);
    if (!image || image->size() == 0) {
        err = "not a readable PE32+ image: " + pe_path.string();
        return {};
    }
    return to_export_rows(pe::exports(*image), *image, filter);
}

std::vector<ExportRow> exports_of_live(const std::string& module,
                                       const std::string& filter, std::string& err) {
    proc::Target target;
    if (!target.attach()) {
        err = "FiveM is not running (no grcWindow). Start the game first.";
        return {};
    }
    target.refresh(0);
    const proc::Snapshot& snap = target.snapshot();
    if (!snap.valid) {
        err = "attached, but the module list could not be read.";
        return {};
    }
    const proc::Module* found = find_module(snap, module);
    if (!found) {
        err = "module not loaded: " + module;
        return {};
    }
    auto image = pe::Image::from_process(target.handle(), found->base, found->name);
    if (!image || image->size() == 0) {
        err = "could not read " + found->name;
        return {};
    }
    log::ok(found->name + " base " + hex64(found->base) + " size "
            + hex64(image->size()));
    return to_export_rows(pe::exports(*image), *image, filter);
}

Outcome run_module(const std::string& module_name, const Settings& settings,
                   Progress& p) {
    p.cancel  = false;
    p.running = true;
    p.stage   = static_cast<int>(Stage::Attach);
    p.say("locating FiveM...");

    Outcome out;
    auto fail = [&](const std::string& e) {
        p.running = false;
        p.stage   = static_cast<int>(Stage::Failed);
        out.success = false;
        out.error   = e;
        log::fail(e);
        return out;
    };

    proc::Target target;
    if (!target.attach()) {
        return fail("FiveM is not running (no grcWindow). Start the game first.");
    }
    target.refresh(0);
    const proc::Snapshot& snap = target.snapshot();
    if (!snap.valid) return fail("attached, but the module list could not be read.");

    const proc::Module* found = find_module(snap, module_name);
    if (!found) {
        std::string candidates;
        for (const proc::Module& m : snap.modules) {
            if (m.name.find("scripting") != std::string::npos) {
                candidates += (candidates.empty() ? "" : ", ") + m.name;
            }
        }
        return fail("module not loaded: " + module_name
                    + (candidates.empty() ? "" : "  (scripting modules: " + candidates + ")"));
    }

    p.stage = static_cast<int>(Stage::ReadImage);
    p.say("reading " + hex64(found->size) + " bytes of " + found->name + "...");
    const auto t_read = steady::now();

    auto image = pe::Image::from_process(target.handle(), found->base, found->name);
    if (!image || image->size() == 0) return fail("could not read " + found->name);
    log::ok(found->name + " base " + hex64(found->base) + " size "
            + hex64(image->size()) + " read in " + std::to_string(ms_since(t_read))
            + " ms");

    // Verification has to be bounded to THIS module, or every address would be
    // judged against the game process's image and reported as outside it.
    proc::Snapshot mod = snap;
    mod.name        = found->name;
    mod.base        = found->base;
    mod.module_size = found->size;

    RunTarget rt;
    rt.live = target.handle();
    rt.snap = &mod;

    try {
        out = run_image(*image, rt, settings, p);
    } catch (const std::exception& ex) {
        p.running = false;
        p.stage   = static_cast<int>(Stage::Failed);
        out.error = std::string("pipeline threw: ") + ex.what();
        log::fail(out.error);
    } catch (...) {
        p.running = false;
        p.stage   = static_cast<int>(Stage::Failed);
        out.error = "pipeline threw an unknown exception.";
        log::fail(out.error);
    }
    out.stats.read_ms = ms_since(t_read);
    return out;
}

std::vector<ProbeRow> probe_live(const std::vector<std::string>& only) {    std::vector<ProbeRow> out;

    proc::Target target;
    if (!target.attach()) {
        log::fail("FiveM is not running (no grcWindow).");
        return out;
    }
    target.refresh(0);
    const proc::Snapshot& snap = target.snapshot();
    if (!snap.valid) {
        log::fail("attached, but the module could not be enumerated.");
        return out;
    }

    auto image = pe::Image::from_process(target.handle(), snap.base, snap.name);
    if (!image || image->size() == 0) {
        log::fail("could not read the module image.");
        return out;
    }

    const uint64_t base = image->info().load_base;
    void* proc = target.handle();

    auto wanted = [&](const char* name) {
        if (only.empty()) return true;
        for (const std::string& n : only) {
            if (n == name) return true;
        }
        return false;
    };

    for (size_t i = 0; i < tbl::kTableCount; ++i) {
        const tbl::Entry& e = tbl::kTable[i];
        if (!wanted(e.name)) continue;

        const pat::Pattern p = pat::parse(e.signature);
        const std::vector<scan::Match> hits = scan::scan_all(*image, { p }, 4);
        if (hits.empty()) continue;

        uint32_t target_rva = 0;
        if (!resolve_match(*image, e, hits.front().rva, target_rva)) continue;

        const rv::Kind kind = derive_kind(*image, e, hits.front().rva);
        if (kind != rv::Kind::GlobalPointer) continue;   // no object to name

        ProbeRow row;
        row.name    = e.name;
        row.kind    = rv::kind_name(kind);
        row.rva     = target_rva;
        row.address = base + target_rva;

        row.object = mem::read_ptr(proc, row.address);
        if (!row.object) {
            row.note = "holds zero right now; nothing to name";
            out.push_back(std::move(row));
            continue;
        }
        if (!mem::is_readable(proc, row.object)) {
            row.note = "the pointer does not read back";
            out.push_back(std::move(row));
            continue;
        }

        // The object's first qword is its vtable, and the qword before that is the
        // Complete Object Locator, whose pSelf field must equal its own RVA. That
        // check is what makes the class name evidence rather than a guess.
        row.vtable = mem::read_ptr(proc, row.object);
        if (row.vtable < base || row.vtable >= base + image->size()) {
            row.note = "first qword is not a module pointer: this object has no "
                       "vtable, so RTTI cannot name it";
            out.push_back(std::move(row));
            continue;
        }
        row.vtable_rva = static_cast<uint32_t>(row.vtable - base);

        // The Complete Object Locator is the slot IMMEDIATELY BEFORE the vtable in
        // the module's read-only data -- not before the object on the heap. It is
        // read out of the mapped image rather than the process, because that is
        // where it actually lives.
        if (row.vtable_rva < 8) {
            row.note = "vtable sits too low in the image to have a locator";
            out.push_back(std::move(row));
            continue;
        }
        const uint64_t col_va = image->read_or<uint64_t>(row.vtable_rva - 8, 0);
        if (col_va < base || col_va >= base + image->size()) {
            row.note = "the slot before the vtable is not a locator: a RAGE manager "
                       "with RTTI stripped or no virtuals. The offset is still sound; "
                       "it simply cannot be named from RTTI.";
            out.push_back(std::move(row));
            continue;
        }
        const uint32_t col_rva = static_cast<uint32_t>(col_va - base);
        if (image->read_or<uint32_t>(col_rva + 20, 0) != col_rva) {
            row.note = "the locator's pSelf does not agree with its own address, so "
                       "this is not a confirmed polymorphic vtable";
            out.push_back(std::move(row));
            continue;
        }

        row.polymorphic = true;
        const uint32_t td = image->read_or<uint32_t>(col_rva + 12, 0);
        if (td > 16 && td + 16 < image->size()) {
            const uint32_t name_rva = td + 16;
            const uint32_t avail = image->size() - name_rva;
            const uint32_t cap = avail < 256 ? avail : 256;
            const uint8_t* np = image->at(name_rva);
            uint32_t n = 0;
            while (n < cap && np[n] >= 0x20 && np[n] <= 0x7E) ++n;
            row.class_name.assign(reinterpret_cast<const char*>(np), n);
        }
        out.push_back(std::move(row));
    }
    return out;
}

}  // namespace dmp::job
