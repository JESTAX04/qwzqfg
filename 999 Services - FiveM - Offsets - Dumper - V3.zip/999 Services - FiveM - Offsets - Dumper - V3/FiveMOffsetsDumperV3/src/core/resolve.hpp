// language: C++, file: src/core/resolve.hpp, target: Windows 11, MSVC, x64
// Turning a match into an address, and proving the address is real.
//
// A dumper that emits an unvalidated offset is worse than one that emits nothing:
// the number looks authoritative, it lands in a config, and the failure surfaces
// later as garbage reads or a ban. Every result that leaves this layer has been
// read back from the live target and had its page permissions checked against what
// its kind claims to be.
#pragma once
#include "core/image.hpp"
#include "process/process.hpp"

#include <cstdint>
#include <optional>
#include <string>

namespace dmp::rv {

// What a symbol's resolved RVA actually points at. This is the contract the old
// exporter never stated: "m_World" and "m_GiveWeapon" are not the same kind of
// number, and a consumer that dereferences one like the other reads garbage.
enum class Kind {
    Function,       // a function entry; call it
    Instruction,    // an address inside a function; patch it
    GlobalPointer,  // a global variable holding a pointer; deref to use
    DataGlobal,     // a global variable; use its address
    Vtable,         // a vftable; deref to the first virtual method
    FieldOffset,    // not an address: a byte offset inside an object
    DerefChain,     // not an address: (field offset, then deref, then offset)
    Unknown
};

const char* kind_name(Kind k);

enum class Status {
    Ok,
    NotFound,
    Ambiguous,      // the pattern matched more than once in code
    Unverified,     // found only outside executable memory
    NotReadable,
    NotExecutable,
    NullPointer,
    // The address itself is fine, but the pointer it holds is zero. That is not a
    // broken offset: it is a global the game has not populated yet -- a replay
    // interface before a session starts, an aim target with nothing in scope. It is
    // reported separately from a real failure so it never reads as a bad dump.
    Unpopulated,
    DerefFailed,
    OutsideImage,
    Skipped
};

const char* status_name(Status s);

struct Verify {
    Status    status     = Status::Skipped;
    bool      readable   = false;
    bool      executable = false;
    // A pointer global has to live in writable memory: the game writes it. An
    // operand that holds zero in a read-only section is not an unfilled global, it
    // is the wrong site, and the two conclusions are opposites.
    bool      writable   = false;
    bool      in_image    = false;
    uintptr_t probe      = 0;   // what the deref probe landed on, when one ran
};

// One resolved symbol, with everything a consumer needs to re-resolve it later
// rather than trusting a frozen number.
struct Result {
    std::string name;
    Kind        kind = Kind::Unknown;

    // Re-resolution recipe. `pattern` is the signature text; the two offsets say
    // how to turn a future match back into the target, exactly as described in
    // scanner.hpp. Emitting these is what makes the table survive a rebuild.
    std::string pattern;
    int32_t     operand_offset = -1;
    int32_t     target_delta   = 0;

    uint32_t  match_rva = 0;
    uint32_t  rva       = 0;
    uintptr_t address   = 0;
    bool      from_code = true;   // false => matched outside .text, unverifiable
    uint32_t  refs      = 0;      // code references found, for data globals

    Verify    verify;
};

// RIP-relative displacement decode against the live process. Returns the absolute
// target and writes the raw displacement to `out_disp` when non-null.
uintptr_t resolve_rip(void* proc, uintptr_t instruction_address, int disp_offset,
                      int instruction_size, int32_t* out_disp = nullptr);

// Checks a resolved absolute address against what its kind claims to be, by
// reading the target and querying its page permissions.
Verify verify_address(void* proc, const proc::Snapshot& snap, uintptr_t address, Kind kind);

// Walks a pointer chain, refusing to continue past an unreadable hop.
bool walk_chain(void* proc, uintptr_t base, const uint32_t* offsets, size_t count,
                uintptr_t& out);

// True when the address is page-aligned and inside the target's mapped range.
bool plausible_pointer(const proc::Snapshot& snap, uintptr_t address);

}  // namespace dmp::rv
