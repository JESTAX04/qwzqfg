// language: C++, file: src/core/rtti.hpp, target: Windows 11, MSVC, x64
// Recovering named classes, their vftables, and the fields their methods touch.
//
// A hardcoded signature table can only find what someone already reversed. RTTI is
// the part of a Microsoft binary that names its own classes, so turning it into a
// symbol table is what makes a dumper produce hundreds of entries instead of
// thirty -- and it is verifiable rather than heuristic:
//
//     Type Descriptor   = { void* vfTable; void* spare; char name[] }
//     Complete Locator  = { sig, offset, cdOffset, pTypeDesc, pClassDesc, pSelf }
//     vftable[-1]       = pointer to the Complete Locator
//
// A vftable is confirmed only when slot[-1] points at a COL and that COL's pSelf
// at +20 equals its own RVA. Both conditions, or the hit is discarded. That check
// is what stops a row of unrelated qwords from being reported as a class.
#pragma once
#include "core/disasm.hpp"
#include "core/image.hpp"
#include "core/pdata.hpp"
#include "core/scanner.hpp"

#include <cstdint>
#include <functional>
#include <string>
#include <vector>

namespace dmp::rtti {

struct Method {
    uint32_t slot  = 0;
    uint32_t rva   = 0;      // function entry
    uint32_t size  = 0;      // bytes, from .pdata
    bool     has_function = false;   // rva is a real .pdata function entry
    bool     has_signature = false;
    scan::Signature sig;
    std::vector<dis::FieldAccess> fields;
};

struct Vtable {
    uint32_t    rva        = 0;
    uint32_t    col_rva    = 0;
    std::string class_name;   // the raw ".?AVCFoo@@..." descriptor
    std::string short_name;   // "CFoo", demangled far enough to be readable
    std::vector<Method> methods;

    bool named() const { return !short_name.empty(); }
};

struct Options {
    uint32_t max_tables            = 48;
    uint32_t max_slots_per_table   = 48;
    uint32_t max_methods_per_table = 16;
    uint32_t max_methods_total     = 220;
    bool     signatures            = true;
    bool     fields                = true;
};

struct Inventory {
    std::vector<Vtable> tables;
    uint32_t enumerated = 0;   // confirmed vftables found, before any cap
    uint32_t named      = 0;
    uint32_t signatures = 0;
    uint32_t field_sets = 0;
};

// Every confirmed vftable in the image, with its class name when the RTTI chain
// resolves. This pass is cheap -- one linear walk of the data sections -- and is
// deliberately free of any cap, so the reported count is the true count.
std::vector<Vtable> enumerate(const pe::Image& img);

// Fills in signatures and field/deref chains for a bounded number of methods.
// Bounded on purpose: each signature costs a uniqueness proof over all of code,
// so this is the one stage whose runtime is worth putting a dial on.
// `cancelled` is polled between tables so a long recovery can be aborted.
void recover(const pe::Image& img, const pd::Inventory& inv, Inventory& io,
             const Options& opt,
             const std::function<void(uint32_t done, uint32_t total)>& progress = {},
             const std::function<bool()>& cancelled = {});

// ".?AVCFoo@Ns@@..." -> "CFoo". Returns empty for a descriptor that is not a
// mangled class or struct name.
std::string short_class_name(const std::string& mangled);

}  // namespace dmp::rtti
