// language: C++, file: src/core/pdata.hpp, target: Windows 11, MSVC, x64
// .pdata (PE exception directory) walk.
//
// On x64 every function that owns a stack frame gets a RUNTIME_FUNCTION entry, so
// one directory read yields an exact [begin, end) inventory of compiled code -- no
// symbols, no PDB, no guessing. It also yields UNWIND_INFO.SizeOfProlog, the
// authoritative prologue length, which is what tells a signature generator which
// leading bytes are compiler boilerplate rather than function identity.
#pragma once
#include "core/image.hpp"

#include <cstdint>
#include <optional>
#include <vector>

namespace dmp::pd {

struct Function {
    uint32_t begin      = 0;
    uint32_t end        = 0;
    uint32_t unwind     = 0;
    uint8_t  prolog     = 0;   // UNWIND_INFO.SizeOfProlog
    uint8_t  frame_reg  = 0;   // UNWIND_INFO.FrameRegister
    uint8_t  code_count = 0;   // UNWIND_INFO.CountOfCodes
    uint8_t  version    = 0;
    uint8_t  flags      = 0;

    uint32_t size() const { return end - begin; }
    bool contains(uint32_t rva) const { return rva >= begin && rva < end; }
    bool chained() const { return (flags & 0x04u) != 0; }  // UNW_FLAG_CHAININFO
};

class Inventory {
public:
    std::vector<Function> functions;
    uint32_t              code_begin = 0;
    uint32_t              code_end   = 0;

    size_t size()  const { return functions.size(); }
    bool   empty() const { return functions.empty(); }

    // Function whose [begin, end) strictly contains rva, or nullptr.
    const Function* find(uint32_t rva) const;
    // Nearest function starting at or below rva; never null on a non-empty list.
    const Function* enclosing(uint32_t rva) const;
    // Every function intersecting [rva, rva + n).
    std::vector<const Function*> overlapping(uint32_t rva, uint32_t n) const;

    // Bytes from rva to the end of its function. How far a forward window may run
    // before it walks off the end and starts reading the next function's bytes.
    uint32_t bytes_remaining(uint32_t rva) const;

    // RVA of the entry point at or before rva, i.e. the function rva is inside.
    // Returns 0 when rva is not inside any known function.
    uint32_t entry_of(uint32_t rva) const;
};

std::optional<Inventory> walk(const pe::Image& img);

}  // namespace dmp::pd
