// language: C++, file: src/core/scanner.cpp, target: Windows 11, MSVC, x64
#include "core/scanner.hpp"

#include <algorithm>
#include <cstring>

namespace dmp::scan {
namespace {

// A pattern reduced to "test this bucket when the byte at the anchor offset
// equals this value". One entry per pattern, so a position in the image only ever
// tests patterns that could actually start there.
struct Plan {
    uint32_t index      = 0;
    uint32_t anchor_off = 0;
    uint8_t  key        = 0;
};

struct PlanTable {
    std::vector<std::vector<Plan>> buckets;   // indexed by anchor byte value
    std::vector<uint32_t>          no_anchor; // patterns with no concrete byte
};

PlanTable build_plans(const std::vector<pat::Pattern>& pats) {
    PlanTable t;
    t.buckets.resize(256);
    for (uint32_t i = 0; i < pats.size(); ++i) {
        uint32_t off = 0;
        uint8_t  val = 0;
        if (pats[i].anchor(off, val)) {
            t.buckets[val].push_back(Plan{ i, off, val });
        } else if (!pats[i].empty()) {
            // A pattern made entirely of nibble-wildcards cannot be prescreened.
            // It is kept and tested at every position; a table full of such
            // patterns is a table that was written wrong, not a scanner problem.
            t.no_anchor.push_back(i);
        }
    }
    return t;
}

void scan_buffer(const uint8_t* buf, uint32_t span, uint32_t base_rva,
                 const pe::Section* section,
                 const std::vector<pat::Pattern>& pats,
                 const PlanTable& plans,
                 std::vector<Match>& out,
                 std::vector<uint32_t>& counts,
                 uint32_t max_per_pattern) {
    if (span == 0) return;

    for (uint32_t i = 0; i < span; ++i) {
        const auto& bucket = plans.buckets[buf[i]];
        for (const Plan& pl : bucket) {
            if (counts[pl.index] >= max_per_pattern) continue;
            if (i < pl.anchor_off) continue;
            const uint32_t pos = i - pl.anchor_off;
            const pat::Pattern& p = pats[pl.index];
            const uint32_t len = static_cast<uint32_t>(p.length());
            if (pos + len > span) continue;
            if (!pat::matches_at(buf + pos, p)) continue;

            out.push_back(Match{ pl.index, base_rva + pos, section });
            ++counts[pl.index];
        }

        for (uint32_t idx : plans.no_anchor) {
            if (counts[idx] >= max_per_pattern) continue;
            const pat::Pattern& p = pats[idx];
            const uint32_t len = static_cast<uint32_t>(p.length());
            if (i + len > span) continue;
            if (!pat::matches_at(buf + i, p)) continue;
            out.push_back(Match{ idx, base_rva + i, section });
            ++counts[idx];
        }
    }
}

uint32_t count_sections(const pe::Image& img, const std::vector<const pe::Section*>& secs,
                        const pat::Pattern& p, uint32_t cap) {
    if (cap == 0) return 0;
    uint32_t n = 0;
    std::vector<uint32_t> hits(cap);
    for (const pe::Section* s : secs) {
        const uint32_t span = s->span();
        if (span == 0 || !img.in_range(s->rva, span)) continue;
        const uint32_t want = cap - n;
        if (want == 0) break;
        n += static_cast<uint32_t>(pat::scan(img.at(s->rva), span, p, hits.data(), want));
    }
    return n;
}

// Masks the 4 displacement bytes of a rel32 whose target provably lands inside
// the image. Returns how many bytes were newly masked.
uint32_t mask_disp32(pat::Pattern& p, uint32_t at) {
    if (at + 4 > p.length()) return 0;
    const uint32_t before = p.wildcards;
    p.mask_range(at, at + 4);
    return p.wildcards - before;
}

}  // namespace

// ----------------------------------------------------------------- whole table --

std::vector<Match> scan_all(const pe::Image& img,
                            const std::vector<pat::Pattern>& pats,
                            uint32_t max_per_pattern) {
    std::vector<Match> out;
    if (pats.empty()) return out;

    const PlanTable plans = build_plans(pats);
    std::vector<uint32_t> counts(pats.size(), 0);

    for (const pe::Section* s : img.code_sections()) {
        const uint32_t span = s->span();
        if (span == 0 || !img.in_range(s->rva, span)) continue;
        scan_buffer(img.at(s->rva), span, s->rva, s, pats, plans, out, counts, max_per_pattern);
    }
    return out;
}

std::vector<Match> scan_all_image(const pe::Image& img,
                                  const std::vector<pat::Pattern>& pats,
                                  uint32_t max_per_pattern) {
    std::vector<Match> out;
    if (pats.empty()) return out;

    const PlanTable plans = build_plans(pats);
    std::vector<uint32_t> counts(pats.size(), 0);

    for (const pe::Section& s : img.sections()) {
        const uint32_t span = s.span();
        if (span == 0 || !img.in_range(s.rva, span)) continue;
        scan_buffer(img.at(s.rva), span, s.rva, &s, pats, plans, out, counts, max_per_pattern);
    }
    return out;
}

uint32_t count_code(const pe::Image& img, const pat::Pattern& p, uint32_t cap) {
    return count_sections(img, img.code_sections(), p, cap);
}

uint32_t count_image(const pe::Image& img, const pat::Pattern& p, uint32_t cap) {
    std::vector<const pe::Section*> all;
    all.reserve(img.sections().size());
    for (const pe::Section& s : img.sections()) all.push_back(&s);
    return count_sections(img, all, p, cap);
}

// --------------------------------------------------------------- rel32 sites --

std::optional<uint32_t> rip_target_rva(const pe::Image& img, uint32_t modrm_rva) {
    const uint8_t* p = img.span(modrm_rva, 5);
    if (!p) return std::nullopt;
    if (!is_rip_modrm(p[0])) return std::nullopt;

    const int64_t target = static_cast<int64_t>(modrm_rva) + 5 + disp32_at(p + 1);
    if (target < 0 || target >= static_cast<int64_t>(img.size())) return std::nullopt;
    return static_cast<uint32_t>(target);
}

std::vector<uint32_t> find_rip_refs(const pe::Image& img, uint32_t target_rva,
                                    uint32_t begin, uint32_t size) {
    std::vector<uint32_t> out;
    if (size < 5 || !img.in_range(begin, size)) return out;

    const uint8_t* buf = img.at(begin);
    for (uint32_t i = 0; i + 5 <= size; ++i) {
        if (!is_rip_modrm(buf[i])) continue;
        const int64_t target = static_cast<int64_t>(begin) + i + 5 + disp32_at(buf + i + 1);
        if (target == static_cast<int64_t>(target_rva)) out.push_back(begin + i);
    }
    return out;
}

std::vector<uint32_t> find_call_refs(const pe::Image& img, uint32_t target_rva,
                                     uint32_t begin, uint32_t size) {
    std::vector<uint32_t> out;
    if (size < 5 || !img.in_range(begin, size)) return out;

    const uint8_t* buf = img.at(begin);
    for (uint32_t i = 0; i + 5 <= size; ++i) {
        if (buf[i] != 0xE8) continue;
        const int64_t target = static_cast<int64_t>(begin) + i + 5 + disp32_at(buf + i + 1);
        if (target == static_cast<int64_t>(target_rva)) out.push_back(begin + i);
    }
    return out;
}

uint32_t mask_rel32_operands(const pe::Image& img, pat::Pattern& p, uint32_t pattern_rva) {
    uint32_t masked = 0;
    const uint32_t n = static_cast<uint32_t>(p.length());
    if (n < 5) return 0;

    for (uint32_t i = 0; i + 5 <= n; ++i) {
        if (p.mask[i] != pat::kMaskBoth) continue;
        const uint8_t b = p.bytes[i];

        // RIP-relative memory operand: ModRM with mod=00, rm=101.
        if (is_rip_modrm(b)) {
            if (rip_target_rva(img, pattern_rva + i)) {
                masked += mask_disp32(p, i + 1);
                continue;
            }
        }
        // E8 call rel32 / E9 jmp rel32.
        if (b == 0xE8 || b == 0xE9) {
            const int64_t target = static_cast<int64_t>(pattern_rva) + i + 5
                                 + disp32_at(img.at(pattern_rva + i + 1));
            if (target >= 0 && target < static_cast<int64_t>(img.size())) {
                masked += mask_disp32(p, i + 1);
            }
            continue;
        }
        // 0F 8x jcc rel32 -- six bytes, displacement at +2.
        if (b == 0x0F && i + 6 <= n && p.mask[i + 1] == pat::kMaskBoth &&
            p.bytes[i + 1] >= 0x80 && p.bytes[i + 1] <= 0x8F) {
            const int64_t target = static_cast<int64_t>(pattern_rva) + i + 6
                                 + disp32_at(img.at(pattern_rva + i + 2));
            if (target >= 0 && target < static_cast<int64_t>(img.size())) {
                masked += mask_disp32(p, i + 2);
            }
        }
    }
    return masked;
}

// ------------------------------------------------------------ repair tools --

Widened stabilise(const pe::Image& img, const pat::Pattern& p, uint32_t anchor_rva,
                  uint32_t max_extra) {
    Widened w;
    w.pattern = p;
    w.count   = count_code(img, p, 2);
    if (w.count <= 1) {
        w.unique = (w.count == 1);
        return w;
    }
    const uint32_t len = static_cast<uint32_t>(p.length());
    if (!img.in_range(anchor_rva, len)) return w;

    // Walk outward one byte at a time from the site that produced the pattern.
    // Extension is forward-only: the match start must not move, or operand_offset
    // would address the wrong displacement.
    for (uint32_t extra = 1; extra <= max_extra; ++extra) {
        const uint32_t at = anchor_rva + len + extra - 1;
        if (!img.in_range(at, 1)) break;

        pat::Pattern candidate = w.pattern;
        candidate.append(img.at(at)[0], pat::kMaskBoth);

        // The appended bytes can themselves contain a displacement, and a live
        // displacement is a byte string that changes on the next build. Masking it
        // keeps the widened pattern from being unique only by accident.
        mask_rel32_operands(img, candidate, anchor_rva);

        const uint32_t n = count_code(img, candidate, 2);
        w.pattern = std::move(candidate);
        w.extra   = extra;
        w.count   = n;
        if (n == 1) {
            w.unique = true;
            break;
        }
    }
    return w;
}

namespace {

// Shared body of the fuzzy searches. `secs` chooses the surface.
std::vector<FuzzyHit> fuzzy_over(const pe::Image& img,
                                 const std::vector<const pe::Section*>& secs,
                                 const pat::Pattern& p, uint32_t max_mismatch,
                                 uint32_t limit) {
    std::vector<FuzzyHit> out;
    if (p.empty() || limit == 0) return out;

    uint32_t anchor_off = 0;
    uint8_t  anchor_val = 0;
    if (!p.anchor(anchor_off, anchor_val)) return out;   // nothing to prescreen on

    // Positions that must actually be compared. Everything else is free.
    std::vector<uint32_t> concrete;
    concrete.reserve(p.length());
    for (uint32_t i = 0; i < p.length(); ++i) {
        if (p.mask[i] != 0) concrete.push_back(i);
    }
    if (concrete.empty()) return out;

    for (const pe::Section* s : secs) {
        const uint32_t span = s->span();
        if (span < p.length() || !img.in_range(s->rva, span)) continue;
        const uint8_t* buf = img.at(s->rva);
        const size_t   last = span - p.length();

        size_t i = anchor_off;
        while (i <= last + anchor_off && i < span) {
            const void* m = std::memchr(buf + i, anchor_val,
                                        (last + anchor_off) - i + 1);
            if (!m) break;
            i = static_cast<size_t>(static_cast<const uint8_t*>(m) - buf);
            if (i < anchor_off) { ++i; continue; }
            const size_t pos = i - anchor_off;
            if (pos > last) break;

            uint32_t bad = 0;
            for (uint32_t k : concrete) {
                const uint8_t mask = p.mask[k];
                const uint8_t b = buf[pos + k];
                if ((mask & pat::kMaskHigh) && ((b >> 4) != (p.bytes[k] >> 4))) ++bad;
                else if ((mask & pat::kMaskLow) && ((b & 0x0Fu) != (p.bytes[k] & 0x0Fu))) ++bad;
                if (bad > max_mismatch) break;
            }
            if (bad <= max_mismatch) {
                FuzzyHit h;
                h.rva        = s->rva + static_cast<uint32_t>(pos);
                h.mismatches = bad;
                h.concrete   = static_cast<uint32_t>(concrete.size());
                h.executable = s->has(pe::kMemExecute);
                out.push_back(h);
            }
            ++i;
        }
    }

    std::sort(out.begin(), out.end(), [](const FuzzyHit& a, const FuzzyHit& b) {
        if (a.mismatches != b.mismatches) return a.mismatches < b.mismatches;
        return a.rva < b.rva;
    });
    if (out.size() > limit) out.resize(limit);
    return out;
}

}  // namespace

std::vector<FuzzyHit> fuzzy_code(const pe::Image& img, const pat::Pattern& p,
                                 uint32_t max_mismatch, uint32_t limit) {
    return fuzzy_over(img, img.code_sections(), p, max_mismatch, limit);
}

std::vector<FuzzyHit> fuzzy_image(const pe::Image& img, const pat::Pattern& p,
                                  uint32_t max_mismatch, uint32_t limit) {
    std::vector<const pe::Section*> all;
    all.reserve(img.sections().size());
    for (const pe::Section& s : img.sections()) all.push_back(&s);
    return fuzzy_over(img, all, p, max_mismatch, limit);
}

pat::Pattern pattern_from_site(const pe::Image& img, uint32_t rva, uint32_t length) {
    if (length == 0 || !img.in_range(rva, length)) return pat::Pattern{};
    pat::Pattern p = pat::from_bytes(img.at(rva), length);
    mask_rel32_operands(img, p, rva);
    return p;
}

// ------------------------------------------------------------ signature build --

uint32_t shared_prefix_hits(const pe::Image& img, uint32_t fn_rva,
                            uint32_t off, uint32_t len) {
    if (len == 0 || !img.in_range(fn_rva + off, len)) return 0;
    const pat::Pattern p = pat::from_bytes(img.at(fn_rva + off), len);
    return count_code(img, p, 64);
}

Signature sign_code(const pe::Image& img, const pd::Inventory& inv,
                    uint32_t fn_rva, const SigOptions& opt) {
    Signature out;
    out.anchor_rva = fn_rva;
    out.quality    = Quality::Absent;

    const pd::Function* fn = inv.find(fn_rva);
    if (!fn) return out;
    if (!img.is_code(fn_rva)) return out;

    const uint32_t remaining = fn->end - fn_rva;

    // Shortest first, then widen. A tighter signature is cheaper to resolve and
    // less likely to be disturbed by an unrelated upstream change.
    const uint32_t lens[] = { opt.min_len, 16u, 20u, 24u, opt.max_len };

    // Offset 0 first: a unique signature that starts at the function entry is the
    // best possible answer and needs no boilerplate reasoning at all. Only when it
    // is ambiguous does the .pdata prolog length earn its keep.
    std::vector<uint32_t> skips;
    skips.push_back(0);
    if (fn->prolog > 0 && fn->prolog < remaining) {
        for (uint32_t s = fn->prolog; s <= opt.max_skip; s += 8) {
            if (s < remaining) skips.push_back(s);
        }
    }

    for (uint32_t skip : skips) {
        for (uint32_t len : lens) {
            if (len < opt.min_len || len > opt.max_len) continue;
            if (len > remaining || skip + len > remaining) continue;
            if (!img.in_range(fn_rva + skip, len)) continue;

            pat::Pattern p = pat::from_bytes(img.at(fn_rva + skip), len);
            const uint32_t masked = opt.mask_rel32
                                  ? mask_rel32_operands(img, p, fn_rva + skip) : 0;
            (void)masked;

            // Wildcarding a displacement can collapse a window into something that
            // matches everywhere, so the uniqueness proof has to run after masking.
            const uint32_t count = count_code(img, p, 2);
            if (count != 1) continue;

            out.pattern     = std::move(p);
            out.match_rva   = fn_rva + skip;
            out.match_count = 1;
            out.skipped     = skip;
            out.wildcards   = out.pattern.wildcards;
            out.quality     = Quality::Unique;
            // Direct form: the match address plus the skipped byte count is the
            // function entry, on every build, with no displacement to re-read.
            out.operand_offset = -1;
            out.target_delta   = static_cast<int32_t>(skip);
            return out;
        }
    }
    return out;
}

}  // namespace dmp::scan
