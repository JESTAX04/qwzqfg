// language: C++, file: src/core/dump.hpp, target: Windows 11, MSVC, x64
// Export writers.
//
// Four things this layer exists to guarantee, each of which the previous exporter
// got wrong:
//
//   1. Provenance. Every file starts with the module, its build tag, load base,
//      image size, PE timestamp, code-section hash and tool revision. An offset
//      table that cannot be tied to a build is a table nobody can trust later.
//
//   2. A stated contract. Each symbol carries its Kind, so a consumer knows
//      whether to call the address, dereference it, or treat it as a field offset.
//      Emitting "m_World" and "m_GiveWeapon" as identical integers is how a
//      consumer ends up dereferencing a patch site.
//
//   3. A re-resolution recipe. Each symbol also carries its pattern plus the
//      operand offset and target delta needed to turn a FUTURE match back into the
//      address, so the table survives a rebuild instead of freezing a number.
//
//   4. An honest failure list. Symbols that were not found, or that resolved but
//      failed validation, are written too, with their status. Dropping them makes
//      "not present on this build" indistinguishable from "removed from the table".
#pragma once
#include "core/resolve.hpp"
#include "core/rtti.hpp"

#include <cstdint>
#include <filesystem>
#include <string>
#include <vector>

namespace dmp::out {

struct Provenance {
    std::string tool;
    std::string generated_utc;
    std::string module;
    std::string image_path;
    uint32_t    build          = 0;
    uint64_t    load_base      = 0;
    uint32_t    module_size    = 0;
    uint64_t    code_hash      = 0;
    uint32_t    pe_timestamp   = 0;
    std::string code_sections;    // "zdata@0x1000+0x6000000, ..."
    bool        live           = true;
};

struct Bundle {
    Provenance              prov;
    std::vector<rv::Result> symbols;      // successes AND failures
    rtti::Inventory         rtti;
    uint32_t                patterns_total = 0;
    uint64_t                scan_ms        = 0;
};

struct WriteOptions {
    std::filesystem::path out_dir;        // created if missing
    bool write_json   = true;
    bool write_header = true;
    bool write_table  = true;
    bool write_report = true;
    bool include_rtti = true;
};

struct Written {
    std::vector<std::filesystem::path> paths;
    std::vector<std::string>           errors;
};

// Renders each artifact. Exposed so a caller can preview without touching disk.
std::string to_json(const Bundle& b);
std::string to_header(const Bundle& b);
std::string to_table(const Bundle& b);
std::string to_report(const Bundle& b);

Written write_all(const Bundle& b, const WriteOptions& opt);

// Directory layout: <out_dir>/<module name>/... so a dump of several modules
// cannot silently overwrite itself, which a flat CWD write does.
std::filesystem::path module_dir(const std::filesystem::path& root,
                                 const std::string& module_name);

// Turns a class name or symbol into a valid C++ identifier.
std::string sanitize_identifier(const std::string& raw);

}  // namespace dmp::out
