// language: C++, file: src/core/job.hpp, target: Windows 11, MSVC, x64
// The scan pipeline.
//
// Order matters here, and it is chosen to minimise how much the target process is
// touched. The module image is read ONCE into a local buffer; every signature, the
// .pdata walk, the RTTI enumeration and the field decoder then work entirely from
// that buffer. The live process is consulted only to verify the addresses that
// come out. The previous design issued one ReadProcessMemory per pattern and
// another per RIP resolution, which is both slower and a far louder access pattern.
#pragma once
#include "core/dump.hpp"
#include "process/process.hpp"

#include <array>
#include <atomic>
#include <cstdint>
#include <filesystem>
#include <mutex>
#include <string>

namespace dmp::job {

enum class Stage {
    Idle, Attach, ReadImage, ParsePdata, Scan, Resolve, Verify, Rtti, Export, Done, Failed
};

const char* stage_name(Stage s);

struct Settings {
    // Every one of these is wired to a control in the Settings tab; the previous
    // build's checkboxes wrote to function-local statics and changed nothing.
    bool export_json   = true;
    bool export_header = true;
    bool export_table  = true;
    bool export_report = true;
    bool do_verify     = true;
    bool do_rtti       = true;
    // Retry patterns that were not found in executable memory against the whole
    // image. Off by default: a hit outside code is not a function, and reporting
    // it as one produces a confident, wrong offset.
    bool fallback_image_scan = false;

    uint32_t    rtti_max_tables  = 48;
    uint32_t    rtti_max_methods = 240;
    std::filesystem::path out_root;
};

struct Progress {
    std::atomic<bool> running{ false };
    std::atomic<bool> cancel{ false };
    std::atomic<int>  stage{ 0 };
    std::atomic<int>  done{ 0 };
    std::atomic<int>  total{ 0 };

    void say(const std::string& s);
    std::string text();

    Stage current_stage() const { return static_cast<Stage>(stage.load()); }

private:
    std::mutex  mtx_;
    std::string message_;
};

struct Stats {
    uint64_t read_ms   = 0;
    uint64_t scan_ms   = 0;
    uint64_t verify_ms = 0;
    uint64_t rtti_ms   = 0;
    uint64_t export_ms = 0;

    uint32_t patterns_total   = 0;
    uint32_t patterns_found   = 0;
    uint32_t verified         = 0;
    uint32_t failed           = 0;
    uint32_t unverified       = 0;
    // Readable but holding zero. Not a failure: the offset is right, the game just
    // has not filled the slot yet.
    uint32_t unpopulated      = 0;
    uint32_t vftables         = 0;
    uint32_t vftables_named   = 0;
    uint32_t rtti_signatures  = 0;
    uint32_t field_sets       = 0;
    uint32_t files_written    = 0;
    uint32_t code_sections    = 0;
    uint64_t code_hash        = 0;
};

struct Outcome {
    bool                  success = false;
    std::string           error;
    Stats                 stats;
    std::filesystem::path out_dir;
};

// Blocking. Run this on a worker thread; it reports through `p` and honours
// `p.cancel` between stages and between RTTI tables.
Outcome run(proc::Target& target, const Settings& settings, Progress& p);

// Runs the same pipeline against a PE file already on disk. Nothing is attached,
// so result validation is skipped and the provenance records live=false. Useful
// for dumping a module you already have, and for diffing one build against the
// next without launching anything.
Outcome run_offline(const std::filesystem::path& pe_path, const Settings& settings,
                    Progress& p);

struct GrepHit {
    uint32_t    rva = 0;
    std::string section;
    bool        executable = false;
};

// Scans a PE on disk for one signature through the same single-pass bucketed
// engine the table scan uses. Without a running game this is how a signature gets
// proved to match exactly where it is expected to, and how many times.
bool grep_file(const std::filesystem::path& pe_path, const std::string& signature,
               uint32_t limit, std::vector<GrepHit>& out, std::string& err);

// ------------------------------------------------------------------- audit --

// One symbol the table could not cleanly resolve, with the evidence and -- where
// the image allows it -- a repaired signature taken from the live bytes.
struct AuditRow {
    std::string name;
    std::string kind;
    std::string verdict;        // clean | unpopulated | ambiguous | ambiguous_widened
                                // | not_found | repaired | not_readable | ...
    std::string detail;         // the evidence, in one line
    uint32_t    rva         = 0;
    uint32_t    match_count = 0;
    std::vector<uint32_t> matches;

    // A signature that resolves the symbol uniquely, rebuilt from the image:
    // widened when the original matched too often, replaced from the nearest
    // fuzzy site when it matched nothing at all.
    std::string proposed;
    bool        proposed_unique   = false;
    uint32_t    proposed_mismatch = 0;
    std::string operand_note;   // what the resolved instruction actually is
};

struct AuditResult {
    bool        ok = false;
    std::string error;
    std::string module;
    uint32_t    build      = 0;
    uint64_t    load_base  = 0;
    uint32_t    module_size = 0;
    uint32_t    examined   = 0;
    uint32_t    clean      = 0;
    // Counted separately from rows.size(), which also carries the clean rows when
    // include_clean is set. Reporting the two as one number made a fully clean
    // audit announce four problems.
    uint32_t    attention  = 0;
    std::vector<AuditRow> rows;   // only what needs attention, unless include_clean
};

// Reads the target once and explains every symbol the table fails to resolve
// cleanly. `only` restricts the run to named symbols; empty means all of them.
// `fuzzy_mismatch` is how far a not-found signature is allowed to have drifted.
AuditResult audit_live(const std::vector<std::string>& only, uint32_t fuzzy_mismatch,
                       bool include_clean);
AuditResult audit_file(const std::filesystem::path& pe_path,
                       const std::vector<std::string>& only, uint32_t fuzzy_mismatch,
                       bool include_clean);

// ------------------------------------------------------------------- probe --

// The strongest thing that can be said about a recovered global without playing
// the game: dereference it, take the object's vtable, validate that vtable through
// its Complete Object Locator, and read the class name straight out of the type
// descriptor. "Points somewhere mapped" becomes "points at a CWorld instance".
struct ProbeRow {
    std::string name;
    std::string kind;
    uint32_t    rva       = 0;
    uintptr_t   address   = 0;
    uintptr_t   object    = 0;
    uintptr_t   vtable    = 0;
    uint32_t    vtable_rva = 0;
    std::string class_name;
    bool        polymorphic = false;   // the vtable passed the self-validating check
    std::string note;
};

// Probes every global-pointer entry against the live target. Instructions and
// patch sites have no object to name, so they are reported with no class.
std::vector<ProbeRow> probe_live(const std::vector<std::string>& only);

// ----------------------------------------------------------------- exports ---
//
// An exported symbol is the most durable anchor a dumper can have: the loader
// relocates it by name, so it needs no signature and survives any patch that does
// not rename it. This is how the Lua state is pinned.
struct ExportRow {
    std::string name;
    uint32_t    ordinal   = 0;
    uint32_t    rva       = 0;
    bool        forwarded = false;
    // The first bytes at the export. A detour has to replace a whole number of
    // instructions at this address, so seeing them before anything is patched is the
    // difference between a trampoline that resumes aligned and one that corrupts the
    // function. Read-only; nothing is written.
    std::array<uint8_t, 16> head{};
    bool        head_valid = false;
};

std::vector<std::string> live_module_names();

std::vector<ExportRow> exports_of_file(const std::filesystem::path& pe_path,
                                       const std::string& filter, std::string& err);
std::vector<ExportRow> exports_of_live(const std::string& module,
                                       const std::string& filter, std::string& err);

// Dumps a loaded module other than the main executable. The Lua interpreter is a
// separate image, so it can only be reached this way.
Outcome run_module(const std::string& module_name, const Settings& settings, Progress& p);

}  // namespace dmp::job
