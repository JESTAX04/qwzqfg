// language: C++, file: src/utils/utils.hpp, target: Windows 11, MSVC, x64
// Thread-safe log sink.
//
// The failure this replaces is subtle and worth naming: the previous logger locked
// only around the vector push, then wrote to the console and called
// SetConsoleTextAttribute OUTSIDE the lock. With thirty scan threads logging at
// once that interleaves output and races a single process-wide console attribute.
// Here the lock covers the buffer, the console, and the file together, so one
// entry is one atomic line everywhere it appears.
#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace dmp::log {

enum class Level { Info, Ok, Warn, Fail };

struct Entry {
    std::string text;
    Level       level = Level::Info;
    uint64_t    seq   = 0;
};

void clear();
void write(Level level, const std::string& text);

inline void info(const std::string& t) { write(Level::Info, t); }
inline void ok(const std::string& t)   { write(Level::Ok, t); }
inline void warn(const std::string& t) { write(Level::Warn, t); }
inline void fail(const std::string& t) { write(Level::Fail, t); }

// Monotonic counter bumped on every mutation. The UI compares it against the last
// value it saw and skips the copy entirely when nothing changed, which is what
// keeps a per-frame log pane off the allocator.
uint64_t revision();

// Copy of the current buffer. Cheap to skip, safe to call while workers log.
std::vector<Entry> snapshot();

// Redirects the human-readable session log to a file next to the executable.
// Returns the path actually opened, or an empty string on failure.
std::string open_file_sink(const std::string& path);
void        close_file_sink();

}  // namespace dmp::log
