// language: C++, file: src/utils/utils.cpp, target: Windows 11, MSVC, x64
#include "utils/utils.hpp"

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>

#include <cstdio>
#include <ctime>
#include <fstream>
#include <mutex>

namespace dmp::log {
namespace {

std::mutex      g_mutex;
std::vector<Entry> g_entries;
uint64_t        g_seq = 0;
uint64_t        g_revision = 0;
std::ofstream   g_file;

const char* tag_of(Level l) {
    switch (l) {
    case Level::Info: return " INFO ";
    case Level::Ok:   return "  OK  ";
    case Level::Warn: return " WARN ";
    case Level::Fail: return " FAIL ";
    }
    return "  ??  ";
}

uint16_t color_of(Level l) {
    const WORD white = FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE;
    switch (l) {
    case Level::Info: return FOREGROUND_BLUE | FOREGROUND_INTENSITY;
    case Level::Ok:   return FOREGROUND_GREEN | FOREGROUND_INTENSITY;
    case Level::Warn: return FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_INTENSITY;
    case Level::Fail: return FOREGROUND_RED | FOREGROUND_INTENSITY;
    }
    return white | FOREGROUND_INTENSITY;
}

std::string timestamp() {
    std::time_t t = std::time(nullptr);
    std::tm lt{};
    localtime_s(&lt, &t);
    char buf[32] = {};
    std::strftime(buf, sizeof(buf), "%H:%M:%S", &lt);
    return buf;
}

}  // namespace

void clear() {
    std::lock_guard<std::mutex> lock(g_mutex);
    g_entries.clear();
    ++g_revision;
}

void write(Level level, const std::string& text) {
    // The whole body runs under one lock: buffer, console and file are updated
    // together, so interleaving between scan threads is impossible.
    std::lock_guard<std::mutex> lock(g_mutex);

    g_entries.push_back(Entry{ text, level, ++g_seq });
    ++g_revision;

    if (g_file.is_open()) {
        g_file << '[' << timestamp() << "] [" << tag_of(level) << "] " << text << '\n';
        g_file.flush();
    }

    // stdout is written unconditionally: the C runtime is what carries redirection,
    // and in the offline CLI path stdout is rebound to the borrowed console. Only
    // the colour calls need a real console handle, and they are skipped without one.
    const HANDLE h = GetStdHandle(STD_OUTPUT_HANDLE);
    const bool console = (h != nullptr) && (h != INVALID_HANDLE_VALUE);

    const WORD white  = FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE;
    const WORD bright = white | FOREGROUND_INTENSITY;

    if (console) SetConsoleTextAttribute(h, white);
    std::fputs("     [", stdout);
    if (console) SetConsoleTextAttribute(h, color_of(level));
    std::fputs(tag_of(level), stdout);
    if (console) SetConsoleTextAttribute(h, white);
    std::fputs("] ", stdout);
    if (console) SetConsoleTextAttribute(h, bright);
    std::fputs(text.c_str(), stdout);
    std::fputc('\n', stdout);
    if (console) SetConsoleTextAttribute(h, white);
    std::fflush(stdout);
}

uint64_t revision() {
    std::lock_guard<std::mutex> lock(g_mutex);
    return g_revision;
}

std::vector<Entry> snapshot() {
    std::lock_guard<std::mutex> lock(g_mutex);
    return g_entries;
}

std::string open_file_sink(const std::string& path) {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_file.is_open()) g_file.close();
    g_file.open(path, std::ios::out | std::ios::trunc);
    if (!g_file.is_open()) return {};
    return path;
}

void close_file_sink() {
    std::lock_guard<std::mutex> lock(g_mutex);
    if (g_file.is_open()) {
        g_file.flush();
        g_file.close();
    }
}

}  // namespace dmp::log
