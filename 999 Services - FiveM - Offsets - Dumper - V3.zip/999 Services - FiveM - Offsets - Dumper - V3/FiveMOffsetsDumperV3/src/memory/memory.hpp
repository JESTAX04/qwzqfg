// language: C++, file: src/memory/memory.hpp, target: Windows 11, MSVC, x64
// Raw remote-read primitives.
//
// This layer does exactly two things: read bytes out of another process, and ask
// the OS what a page is. It holds no opinion about what a result means -- that
// belongs to core/resolve.hpp -- so a failed read here is reported as a failure
// and never papered over with a zero.
//
// Handles travel as void* so this header never drags <windows.h> into a
// translation unit that does not want its min/max macros.
#pragma once
#include <cstddef>
#include <cstdint>
#include <string>

namespace dmp::mem {

struct Region {
    uintptr_t base    = 0;
    uintptr_t size    = 0;
    uint32_t  protect = 0;
    uint32_t  state   = 0;
    uint32_t  type    = 0;
    bool      valid   = false;

    bool committed() const;
    bool readable() const;
    bool writable() const;
    bool executable() const;
};

// Reads exactly n bytes. Returns false on a short read, so a partially readable
// page can never masquerade as a full value.
bool read(void* proc, uintptr_t address, void* out, size_t n);

template <typename T>
bool read_t(void* proc, uintptr_t address, T& out) {
    return read(proc, address, &out, sizeof(T));
}

uint64_t  read_u64(void* proc, uintptr_t address);
uint32_t  read_u32(void* proc, uintptr_t address);
uint16_t  read_u16(void* proc, uintptr_t address);
uint8_t   read_u8(void* proc, uintptr_t address);
uintptr_t read_ptr(void* proc, uintptr_t address);

// Reads a NUL-terminated ASCII string, capped. Returns empty when the first byte
// is unreadable.
std::string read_cstr(void* proc, uintptr_t address, size_t cap = 256);

// Page facts for the region containing `address`.
Region region_of(void* proc, uintptr_t address);
bool   is_committed(void* proc, uintptr_t address);
bool   is_readable(void* proc, uintptr_t address);
bool   is_executable(void* proc, uintptr_t address);
bool   is_writable(void* proc, uintptr_t address);

}  // namespace dmp::mem
