// language: C++, file: src/memory/memory.cpp, target: Windows 11, MSVC, x64
#include "memory/memory.hpp"

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>

namespace dmp::mem {

bool Region::committed() const { return valid && state == MEM_COMMIT; }

bool Region::readable() const {
    if (!committed()) return false;
    if (protect & (PAGE_GUARD | PAGE_NOACCESS)) return false;
    const uint32_t rw = PAGE_READONLY | PAGE_READWRITE | PAGE_WRITECOPY
                      | PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY;
    return (protect & rw) != 0;
}

bool Region::writable() const {
    if (!committed()) return false;
    if (protect & (PAGE_GUARD | PAGE_NOACCESS)) return false;
    const uint32_t w = PAGE_READWRITE | PAGE_WRITECOPY
                     | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY;
    return (protect & w) != 0;
}

bool Region::executable() const {
    if (!committed()) return false;
    if (protect & (PAGE_GUARD | PAGE_NOACCESS)) return false;
    const uint32_t x = PAGE_EXECUTE | PAGE_EXECUTE_READ
                     | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY;
    return (protect & x) != 0;
}

bool read(void* proc, uintptr_t address, void* out, size_t n) {
    if (!proc || address == 0 || n == 0 || !out) return false;
    SIZE_T got = 0;
    if (!ReadProcessMemory(proc, reinterpret_cast<LPCVOID>(address), out, n, &got)) {
        return false;
    }
    // A short read is a failure: callers use this to decide whether an address is
    // usable, and a partly-filled buffer would answer "usable" for a dead page.
    return got == n;
}

uint64_t read_u64(void* proc, uintptr_t address) {
    uint64_t v = 0;
    return read_t<uint64_t>(proc, address, v) ? v : 0;
}
uint32_t read_u32(void* proc, uintptr_t address) {
    uint32_t v = 0;
    return read_t<uint32_t>(proc, address, v) ? v : 0;
}
uint16_t read_u16(void* proc, uintptr_t address) {
    uint16_t v = 0;
    return read_t<uint16_t>(proc, address, v) ? v : 0;
}
uint8_t read_u8(void* proc, uintptr_t address) {
    uint8_t v = 0;
    return read_t<uint8_t>(proc, address, v) ? v : 0;
}
uintptr_t read_ptr(void* proc, uintptr_t address) {
    uintptr_t v = 0;
    return read_t<uintptr_t>(proc, address, v) ? v : 0;
}

std::string read_cstr(void* proc, uintptr_t address, size_t cap) {
    if (!proc || !address || cap == 0) return {};
    std::string out;
    out.reserve(64);
    char chunk[64];
    while (out.size() < cap) {
        const size_t want = (cap - out.size()) < sizeof(chunk) ? (cap - out.size())
                                                              : sizeof(chunk);
        SIZE_T got = 0;
        if (!ReadProcessMemory(proc, reinterpret_cast<LPCVOID>(address + out.size()),
                               chunk, want, &got) || got == 0) {
            break;
        }
        for (SIZE_T i = 0; i < got; ++i) {
            if (chunk[i] == '\0') return out;
            out.push_back(chunk[i]);
        }
    }
    return out;
}

Region region_of(void* proc, uintptr_t address) {
    Region r;
    if (!proc || !address) return r;

    MEMORY_BASIC_INFORMATION mbi{};
    if (VirtualQueryEx(proc, reinterpret_cast<LPCVOID>(address), &mbi, sizeof(mbi)) == 0) {
        return r;
    }
    r.valid   = true;
    r.base    = reinterpret_cast<uintptr_t>(mbi.BaseAddress);
    r.size    = static_cast<uintptr_t>(mbi.RegionSize);
    r.protect = mbi.Protect;
    r.state   = mbi.State;
    r.type    = mbi.Type;
    return r;
}

bool is_committed(void* proc, uintptr_t address) { return region_of(proc, address).committed(); }
bool is_readable(void* proc, uintptr_t address)  { return region_of(proc, address).readable(); }
bool is_executable(void* proc, uintptr_t address){ return region_of(proc, address).executable(); }
bool is_writable(void* proc, uintptr_t address)  { return region_of(proc, address).writable(); }

}  // namespace dmp::mem
