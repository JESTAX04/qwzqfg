// language: C++, file: src/main.cpp, target: Windows 11, MSVC, x64
// ImGui/DX11 shell over the scan pipeline.
//
// The UI thread never touches the target process while a scan is running: the
// worker owns the handle for the duration, and the Process Info pane renders the
// last cached snapshot instead of re-querying. That is what keeps a per-frame pane
// from turning into sixty EnumProcessModules calls a second against a live game.
#include <windows.h>
#include <windowsx.h>
#include <d3d11.h>
#include <shellapi.h>
#include <tchar.h>

#include <chrono>
#include <filesystem>
#include <optional>
#include <string>
#include <thread>
#include <vector>

#include "imgui.h"
#include "imgui_impl_dx11.h"
#include "imgui_impl_win32.h"

#include "core/job.hpp"
#include "core/table.hpp"
#include "process/process.hpp"
#include "utils/utils.hpp"
#include "version.hpp"

#pragma comment(lib, "d3d11.lib")
#pragma comment(lib, "d3dcompiler.lib")
#pragma comment(lib, "shell32.lib")

// The UI is the one translation unit that is not itself inside the engine's
// namespace, so the engine names are pulled in rather than spelled out at every
// call site.
using namespace dmp;

// ----------------------------------------------------------------- DX11 glue --

static ID3D11Device*           g_pd3dDevice        = nullptr;
static ID3D11DeviceContext*    g_pd3dDeviceContext = nullptr;
static IDXGISwapChain*         g_pSwapChain        = nullptr;
static UINT                    g_ResizeWidth = 0, g_ResizeHeight = 0;
static ID3D11RenderTargetView* g_mainRenderTargetView = nullptr;

static bool    CreateDeviceD3D(HWND hWnd);
static void    CleanupDeviceD3D();
static void    CreateRenderTarget();
static void    CleanupRenderTarget();
static LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND, UINT, WPARAM, LPARAM);

// --------------------------------------------------------------- app state ---

namespace {

struct AppState {
    proc::Target     target;
    job::Progress    progress;
    job::Settings    settings;
    std::thread      worker;
    std::optional<job::Outcome> outcome;

    int   active_tab = 0;
    float tab_alpha  = 1.0f;
    int   last_tab   = 0;
    float accent[3]  = { 0.51f, 0.20f, 1.00f };

    // Log pane: only re-copied when the sink actually changed.
    std::vector<log::Entry> logs;
    uint64_t    logs_revision = 0;

    std::filesystem::path exe_dir;
    std::string           log_path;

    bool quit = false;
};

AppState g;

std::filesystem::path executable_dir() {
    wchar_t buf[MAX_PATH] = {};
    const DWORD n = GetModuleFileNameW(nullptr, buf, MAX_PATH);
    if (n == 0) return std::filesystem::current_path();
    return std::filesystem::path(std::wstring(buf, n)).parent_path();
}

void start_scan() {
    if (g.progress.running) return;
    if (g.worker.joinable()) g.worker.join();

    g.outcome.reset();
    log::clear();
    g.progress.stage  = static_cast<int>(job::Stage::Attach);
    g.progress.done   = 0;
    g.progress.total  = 0;
    g.progress.cancel = false;
    g.progress.say("starting...");

    g.worker = std::thread([] {
        g.outcome = job::run(g.target, g.settings, g.progress);
        if (g.outcome->success) log::ok("dump complete.");
    });
}

void reap_worker() {
    if (g.worker.joinable() && !g.progress.running) g.worker.join();
}

void open_folder(const std::filesystem::path& path) {
    if (path.empty()) return;
    std::error_code ec;
    if (!std::filesystem::exists(path, ec)) std::filesystem::create_directories(path, ec);
    ShellExecuteW(nullptr, L"open", path.wstring().c_str(), nullptr, nullptr, SW_SHOWNORMAL);
}

void refresh_logs() {
    const uint64_t rev = log::revision();
    if (rev == g.logs_revision) return;
    g.logs_revision = rev;
    g.logs = log::snapshot();
}

ImVec4 level_color(log::Level l) {
    switch (l) {
    case log::Level::Info: return ImVec4(0.68f, 0.42f, 1.00f, 1.0f);
    case log::Level::Ok:   return ImVec4(0.34f, 0.86f, 0.42f, 1.0f);
    case log::Level::Warn: return ImVec4(0.95f, 0.75f, 0.28f, 1.0f);
    case log::Level::Fail: return ImVec4(0.94f, 0.32f, 0.32f, 1.0f);
    }
    return ImVec4(1, 1, 1, 1);
}

const char* level_tag(log::Level l) {
    switch (l) {
    case log::Level::Info: return "INFO";
    case log::Level::Ok:   return " OK ";
    case log::Level::Warn: return "WARN";
    case log::Level::Fail: return "FAIL";
    }
    return " ?? ";
}

// ------------------------------------------------------------------- theme ---

void apply_theme(ImGuiStyle& style) {
    style.WindowRounding    = 12.0f;
    style.ChildRounding     = 8.0f;
    style.FrameRounding     = 6.0f;
    style.PopupRounding     = 6.0f;
    style.ScrollbarRounding = 9.0f;
    style.GrabRounding      = 6.0f;
    style.TabRounding       = 6.0f;
    style.WindowBorderSize  = 0.0f;
    style.ChildBorderSize   = 1.0f;
    style.FrameBorderSize   = 0.0f;

    style.Colors[ImGuiCol_WindowBg]       = ImVec4(0.04f, 0.04f, 0.04f, 1.00f);
    style.Colors[ImGuiCol_TitleBg]        = ImVec4(0.00f, 0.00f, 0.00f, 1.00f);
    style.Colors[ImGuiCol_TitleBgActive]  = ImVec4(0.10f, 0.10f, 0.10f, 1.00f);
    style.Colors[ImGuiCol_Button]         = ImVec4(0.12f, 0.12f, 0.12f, 1.00f);
    style.Colors[ImGuiCol_ButtonHovered]  = ImVec4(0.24f, 0.24f, 0.24f, 1.00f);
    style.Colors[ImGuiCol_ButtonActive]   = ImVec4(g.accent[0], g.accent[1], g.accent[2], 1.00f);
    style.Colors[ImGuiCol_FrameBg]        = ImVec4(0.08f, 0.08f, 0.08f, 1.00f);
    style.Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.13f, 0.13f, 0.13f, 1.00f);
    style.Colors[ImGuiCol_FrameBgActive]  = ImVec4(0.16f, 0.16f, 0.16f, 1.00f);
    style.Colors[ImGuiCol_Text]           = ImVec4(0.95f, 0.95f, 0.95f, 1.00f);
    style.Colors[ImGuiCol_Separator]      = ImVec4(0.15f, 0.15f, 0.15f, 1.00f);
    style.Colors[ImGuiCol_Border]         = ImVec4(0.15f, 0.15f, 0.15f, 1.00f);
    style.Colors[ImGuiCol_HeaderActive]   = ImVec4(g.accent[0], g.accent[1], g.accent[2], 1.00f);
    style.Colors[ImGuiCol_HeaderHovered]  = ImVec4(g.accent[0] * 0.8f, g.accent[1] * 0.8f,
                                                  g.accent[2] * 0.8f, 1.00f);
}

// -------------------------------------------------------------------- tabs ---

void tab_scanner(const ImVec2& avail) {
    ImGui::Text("Pattern Scanner");
    ImGui::Separator();
    ImGui::Spacing();

    const bool busy = g.progress.running.load();

    if (!busy) {
        if (ImGui::Button("Start Dump", ImVec2(150, 40))) start_scan();
    } else {
        ImGui::BeginDisabled();
        ImGui::Button("Scanning...", ImVec2(150, 40));
        ImGui::EndDisabled();
    }

    ImGui::SameLine();
    if (busy) {
        if (ImGui::Button("Cancel", ImVec2(90, 40))) {
            g.progress.cancel = true;
            log::warn("cancel requested.");
        }
    } else {
        ImGui::BeginDisabled();
        ImGui::Button("Cancel", ImVec2(90, 40));
        ImGui::EndDisabled();
    }

    ImGui::SameLine();
    if (ImGui::Button("Open Output", ImVec2(120, 40))) open_folder(g.settings.out_root);

    ImGui::Spacing();

    const int   done = g.progress.done.load();
    const int   total = g.progress.total.load();
    const float frac = (total > 0) ? static_cast<float>(done) / static_cast<float>(total) : 0.0f;
    ImGui::ProgressBar(frac, ImVec2(avail.x - 20, 22));

    ImGui::TextColored(ImVec4(0.6f, 0.6f, 0.6f, 1.0f), "stage: %s   %s",
                       job::stage_name(g.progress.current_stage()),
                       g.progress.text().c_str());

    ImGui::Spacing();
    ImGui::Separator();
    ImGui::Text("Console Log:");
    ImGui::Spacing();

    const float log_h = (avail.y > 320.0f) ? avail.y - 210.0f : 160.0f;
    ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.03f, 0.03f, 0.03f, 1.0f));
    ImGui::BeginChild("LogScrollRegion", ImVec2(0, log_h), true,
                      ImGuiWindowFlags_AlwaysVerticalScrollbar);
    for (const log::Entry& e : g.logs) {
        ImGui::TextColored(level_color(e.level), "[%s] %s", level_tag(e.level), e.text.c_str());
    }
    if (ImGui::GetScrollY() >= ImGui::GetScrollMaxY()) ImGui::SetScrollHereY(1.0f);
    ImGui::EndChild();
    ImGui::PopStyleColor();

    if (g.outcome.has_value()) {
        const job::Outcome& o = *g.outcome;
        ImGui::Spacing();
        ImGui::Separator();
        if (o.success) {
            ImGui::TextColored(ImVec4(0.34f, 0.86f, 0.42f, 1.0f), "Dump complete");
        } else {
            ImGui::TextColored(ImVec4(0.94f, 0.32f, 0.32f, 1.0f), "Dump failed: %s",
                               o.error.c_str());
        }
        const job::Stats& s = o.stats;
        ImGui::Text("patterns %u/%u   verified %u   failed %u   ambiguous %u",
                    s.patterns_found, s.patterns_total, s.verified, s.failed, s.unverified);
        ImGui::Text("vftables %u (%u named)   signatures %u   field sets %u",
                    s.vftables, s.vftables_named, s.rtti_signatures, s.field_sets);
        ImGui::Text("code sections %u   code hash 0x%016llX",
                    s.code_sections, static_cast<unsigned long long>(s.code_hash));
        ImGui::Text("read %llu  scan %llu  verify %llu  rtti %llu  export %llu  (ms)",
                    static_cast<unsigned long long>(s.read_ms),
                    static_cast<unsigned long long>(s.scan_ms),
                    static_cast<unsigned long long>(s.verify_ms),
                    static_cast<unsigned long long>(s.rtti_ms),
                    static_cast<unsigned long long>(s.export_ms));
        ImGui::Text("files written: %u", s.files_written);
    }
}

void tab_process(const ImVec2& avail) {
    ImGui::Text("Target Process Information");
    ImGui::Separator();
    ImGui::Spacing();

    // Only the UI thread queries the target, and only when no scan is running, so
    // the worker's handle is never used concurrently.
    if (!g.progress.running && !g.worker.joinable()) {
        g.target.reattach_if_stale();
        g.target.refresh(1500);
    }
    const proc::Snapshot& snap = g.target.snapshot();

    if (!g.target.attached() || !snap.valid) {
        ImGui::Text("Status: ");
        ImGui::SameLine();
        ImGui::TextColored(ImVec4(0.94f, 0.32f, 0.32f, 1.0f), "Waiting for FiveM...");
        ImGui::Text("Launch FiveM, then press Refresh.");
        if (ImGui::Button("Refresh", ImVec2(120, 32))) g.target.refresh(0);
        return;
    }

    ImGui::Text("Status: ");
    ImGui::SameLine();
    ImGui::TextColored(ImVec4(0.34f, 0.86f, 0.42f, 1.0f), "Found (grcWindow)");

    ImGui::Text("Process ID:   %u", snap.pid);
    ImGui::Text("Executable:   %s", snap.name.c_str());
    const uint32_t build = proc::build_from_name(snap.name);
    ImGui::Text("Build:        %s", build ? std::to_string(build).c_str() : "unknown");
    ImGui::Text("Base Address: 0x%p", reinterpret_cast<void*>(snap.base));
    ImGui::Text("Module Size:  %lu bytes", static_cast<unsigned long>(snap.module_size));
    if (!snap.image_path.empty()) {
        ImGui::TextWrapped("Image Path:   %s", snap.image_path.c_str());
    }

    ImGui::Spacing();
    if (ImGui::Button("Refresh", ImVec2(120, 32))) g.target.refresh(0);
    ImGui::SameLine();
    ImGui::TextColored(ImVec4(0.6f, 0.6f, 0.6f, 1.0f),
                       "snapshot cached; re-read at most every 1.5s");

    ImGui::Spacing();
    ImGui::Separator();
    ImGui::Text("Loaded Modules (%zu):", snap.modules.size());
    const float list_h = (avail.y > 380.0f) ? avail.y - 240.0f : 140.0f;
    ImGui::BeginChild("ModulesList", ImVec2(0, list_h), true);
    for (const proc::Module& m : snap.modules) {
        ImGui::Text("%-34s | 0x%p | %lu", m.name.c_str(),
                    reinterpret_cast<void*>(m.base),
                    static_cast<unsigned long>(m.size));
    }
    ImGui::EndChild();
}

void tab_settings() {
    ImGui::Text("Dumper Settings");
    ImGui::Separator();
    ImGui::Spacing();

    ImGui::TextColored(ImVec4(0.6f, 0.6f, 0.6f, 1.0f), "Exports");
    ImGui::Checkbox("offsets.json", &g.settings.export_json);
    ImGui::Checkbox("offsets.hpp", &g.settings.export_header);
    ImGui::Checkbox("offsets.table", &g.settings.export_table);
    ImGui::Checkbox("report.md", &g.settings.export_report);

    ImGui::Spacing();
    ImGui::TextColored(ImVec4(0.6f, 0.6f, 0.6f, 1.0f), "Behaviour");
    ImGui::Checkbox("Validate results against the live target", &g.settings.do_verify);
    ImGui::Checkbox("Recover RTTI classes, signatures and fields", &g.settings.do_rtti);
    ImGui::Checkbox("Fallback scan outside code (unverifiable)",
                    &g.settings.fallback_image_scan);
    if (ImGui::IsItemHovered()) {
        ImGui::SetTooltip("A hit outside an executable section is not a function.\n"
                          "Results found this way are marked unverified.");
    }

    ImGui::Spacing();
    ImGui::TextColored(ImVec4(0.6f, 0.6f, 0.6f, 1.0f), "RTTI budget");
    int tables  = static_cast<int>(g.settings.rtti_max_tables);
    int methods = static_cast<int>(g.settings.rtti_max_methods);
    if (ImGui::SliderInt("Classes", &tables, 0, 256)) {
        g.settings.rtti_max_tables = static_cast<uint32_t>(tables);
    }
    if (ImGui::SliderInt("Methods (signature proofs)", &methods, 0, 1200)) {
        g.settings.rtti_max_methods = static_cast<uint32_t>(methods);
    }
    ImGui::TextColored(ImVec4(0.6f, 0.6f, 0.6f, 1.0f),
                       "each method costs a uniqueness proof over all code sections");

    ImGui::Spacing();
    ImGui::Separator();
    ImGui::TextColored(ImVec4(0.6f, 0.6f, 0.6f, 1.0f), "UI");
    if (ImGui::ColorEdit3("Accent Color", g.accent)) {
        ImGui::GetStyle().Colors[ImGuiCol_ButtonActive] =
            ImVec4(g.accent[0], g.accent[1], g.accent[2], 1.0f);
        ImGui::GetStyle().Colors[ImGuiCol_HeaderActive] =
            ImVec4(g.accent[0], g.accent[1], g.accent[2], 1.0f);
        ImGui::GetStyle().Colors[ImGuiCol_HeaderHovered] =
            ImVec4(g.accent[0] * 0.8f, g.accent[1] * 0.8f, g.accent[2] * 0.8f, 1.0f);
    }

    ImGui::Spacing();
    ImGui::Separator();
    ImGui::TextColored(ImVec4(0.6f, 0.6f, 0.6f, 1.0f), "Output directory");
    ImGui::TextWrapped("%s", g.settings.out_root.string().c_str());
    if (ImGui::Button("Open", ImVec2(100, 30))) open_folder(g.settings.out_root);
    ImGui::SameLine();
    if (ImGui::Button("Reveal session log", ImVec2(190, 30))) {
        open_folder(std::filesystem::path(g.log_path).parent_path());
    }

    ImGui::Spacing();
    ImGui::Separator();
    ImGui::TextColored(ImVec4(0.6f, 0.6f, 0.6f, 1.0f), "Signature table");
    ImGui::Text("%zu built-in patterns", dmp::tbl::kTableCount);
    ImGui::BeginChild("SigTable", ImVec2(0, 150), true);
    for (size_t i = 0; i < dmp::tbl::kTableCount; ++i) {
        const dmp::tbl::Entry& e = dmp::tbl::kTable[i];
        ImGui::Text("%-26s %-14s %s", e.name, dmp::rv::kind_name(e.kind), e.signature);
    }
    ImGui::EndChild();
}

void tab_about() {
    ImGui::Text("About %s", dmp::ver::kProduct);
    ImGui::Separator();
    ImGui::Spacing();

    ImGui::Text("%s", dmp::ver::kToolName);
    ImGui::TextColored(ImVec4(g.accent[0], g.accent[1], g.accent[2], 1.0f),
                       "version %s", dmp::ver::kVersion);
    ImGui::Spacing();
    ImGui::Text("Modernized and Optimized by:");
    ImGui::TextColored(ImVec4(g.accent[0], g.accent[1], g.accent[2], 1.0f), "%s",
                       dmp::ver::kAuthor);

    ImGui::Spacing();
    ImGui::Text("Discord: %s", dmp::ver::kDiscord);
    ImGui::Text("Website: %s", dmp::ver::kWebsite);
    ImGui::TextWrapped("Session log: %s", g.log_path.c_str());

    ImGui::Spacing();
    ImGui::Separator();
    ImGui::TextColored(ImVec4(0.6f, 0.6f, 0.6f, 1.0f), "Engine");
    ImGui::BulletText("single-pass bucketed scanner over every executable section");
    ImGui::BulletText(".pdata function inventory and prolog lengths");
    ImGui::BulletText("RTTI vftable recovery, gated on a self-validating locator");
    ImGui::BulletText("uniqueness-proven code signatures with rel32 wildcards");
    ImGui::BulletText("this-relative field and one-level deref recovery");
    ImGui::BulletText("live validation of every emitted address");

    ImGui::Spacing();
    ImGui::Separator();
    ImGui::TextColored(ImVec4(0.8f, 0.8f, 0.8f, 1.0f), "John 3:16");
    ImGui::TextWrapped("\"For God so loved the world, that he gave his only Son, that whoever "
                       "believes in him should not perish but have eternal life. Jesus Is King\"");
}

void render_tab_button(const char* label, int index) {
    const bool selected = (g.active_tab == index);
    if (selected) {
        ImGui::PushStyleColor(ImGuiCol_Header,
                              ImVec4(g.accent[0], g.accent[1], g.accent[2], 0.30f));
        ImGui::PushStyleColor(ImGuiCol_HeaderHovered,
                              ImVec4(g.accent[0], g.accent[1], g.accent[2], 0.40f));
        ImGui::PushStyleColor(ImGuiCol_Text,
                              ImVec4(g.accent[0], g.accent[1], g.accent[2], 1.0f));
    }
    if (ImGui::Selectable(label, selected, 0, ImVec2(0, 35)) && g.active_tab != index) {
        g.active_tab = index;
    }
    if (selected) ImGui::PopStyleColor(3);
}

// ------------------------------------------------------------- CLI / offline --

// A Windows-subsystem binary owns no console, so output from a terminal launch
// would go nowhere without borrowing the parent's. When stdout was already handed
// to us -- a redirect, or a pipe from a calling process -- that handle is left
// exactly as it is: rebinding to CONOUT$ here would silently discard the
// redirection and make every CLI run look like it produced no output.
void attach_parent_console() {
    const HANDLE existing = GetStdHandle(STD_OUTPUT_HANDLE);
    if (existing != nullptr && existing != INVALID_HANDLE_VALUE) return;
    if (!AttachConsole(ATTACH_PARENT_PROCESS)) return;
    FILE* f = nullptr;
    freopen_s(&f, "CONOUT$", "w", stdout);
    freopen_s(&f, "CONOUT$", "w", stderr);
}

void print_usage() {
    std::printf(
        "%s %s v%s\n\n"
        "  (no arguments)                 open the overlay\n"
        "  --dump-live [options]          dump the running FiveM game process\n"
        "  --dump-file <pe> [options]     dump an image already on disk, no process\n"
        "  --file <pe> --grep <sig>       scan one signature and report its hits\n"
        "  --selftest                     verify the signature parser and matching\n"
        "  --audit-live [options]         explain every symbol that fails on the live game\n"
        "  --audit-file <pe> [options]    the same audit against an image on disk\n"
        "  --probe-live [--only <name>]   name the class behind each resolved global\n"
        "  --modules-live                 list the game's loaded modules\n"
        "  --exports-live --module <name> [--filter s] [--limit n] [--bytes]\n"
        "                                 list a loaded module's exports (the durable\n"
        "                                 anchors -- this is how the Lua state is pinned)\n"
        "  --exports-file <pe> [--filter s]\n"
        "  --dump-module <name> [options] dump a loaded module other than the game exe\n\n"
        "audit options:\n"
        "  --only <name>      restrict to one symbol (repeatable)\n"
        "  --fuzzy <n>        how far a missing signature may have drifted (default 3)\n"
        "  --all              include symbols that resolved cleanly\n\n"
        "options:\n"
        "  --out <dir>        output root            (default: <exe>/out)\n"
        "  --no-rtti          skip RTTI recovery\n"
        "  --no-verify        skip validation\n"
        "  --fallback         also scan outside code (results marked unverified)\n"
        "  --rtti-tables <n>  class budget           (default 48)\n"
        "  --rtti-methods <n> signature budget       (default 240)\n"
        "  --limit <n>        max grep hits          (default 16)\n"
        "  --help             this text\n",
        dmp::ver::kProduct, dmp::ver::kToolName, dmp::ver::kVersion);
}

int run_selftest() {
    int failures = 0;
    auto check = [&](bool ok, const char* what) {
        std::printf("  [%s] %s\n", ok ? " ok " : "FAIL", what);
        if (!ok) ++failures;
    };

    // A lone '?', a bare '??', '4?' and '?5' all have to mean different things.
    // This is the assertion that catches the collapse of "? 48" into the nibble
    // pair "?4" followed by "8", which turns every single-'?' entry in a table
    // into a pattern that matches the wrong bytes while looking well-formed.
    check(pat::parse("48 8B 5C 24 ? 48").length() == 6, "lone '?' consumes exactly one byte");
    check(pat::parse("48 8B 5C 24 ? 48").wildcards == 1, "lone '?' yields exactly one wildcard");
    check(pat::parse("?").length() == 1 && pat::parse("?").wildcards == 1,
          "bare '?' is one wildcard byte");
    check(pat::parse("??").length() == 1 && pat::parse("??").wildcards == 1,
          "'??' is one wildcard byte");
    check(pat::parse("4?").length() == 1 && pat::parse("4?").mask[0] == pat::kMaskHigh,
          "'4?' fixes the high nibble only");
    check(pat::parse("?5").length() == 1 && pat::parse("?5").mask[0] == pat::kMaskLow,
          "'?5' fixes the low nibble only");
    check(pat::parse("488B05").length() == 3, "a run of hex splits into bytes");
    check(pat::parse("E8 ? ? ? ? 48 8B").length() == 7, "E8 + four wildcards + two bytes");

    const pat::Pattern sub = pat::parse("48 83 EC ?");
    const uint8_t a[4] = { 0x48, 0x83, 0xEC, 0x00 };
    const uint8_t b[4] = { 0x48, 0x83, 0xEC, 0xFF };
    const uint8_t c[4] = { 0x48, 0x83, 0xED, 0x00 };
    check(pat::matches_at(a, sub) && pat::matches_at(b, sub), "wildcard tail matches any byte");
    check(!pat::matches_at(c, sub), "concrete bytes still constrain");

    const pat::Pattern hi = pat::parse("4? 8B");
    const uint8_t h1[2] = { 0x4A, 0x8B };
    const uint8_t h2[2] = { 0x5A, 0x8B };
    check(pat::matches_at(h1, hi) && !pat::matches_at(h2, hi),
          "half-byte wildcard binds one nibble");

    // str() must reparse to an identical pattern, or an exported signature would
    // not mean the same thing as the one that produced the offset.
    const char* samples[] = {
        "48 8B 05 ? ? ? ? 33 D2",
        "4? 8B ?5",
        "E8 ? ? ? ? 48 83 C3 60",
        "? ? ? ?",
        "48 83 EC ?",
    };
    for (const char* s : samples) {
        const pat::Pattern once  = pat::parse(s);
        const pat::Pattern twice = pat::parse(once.str());
        check(once.bytes == twice.bytes && once.mask == twice.mask,
              "parse/str round-trip is stable");
    }

    // And the whole shipped table, since that is what actually gets exported.
    uint32_t bad_roundtrip = 0;
    uint32_t bad_length    = 0;
    for (size_t i = 0; i < tbl::kTableCount; ++i) {
        const pat::Pattern once  = pat::parse(tbl::kTable[i].signature);
        const pat::Pattern twice = pat::parse(once.str());
        if (once.bytes != twice.bytes || once.mask != twice.mask) ++bad_roundtrip;

        // Every entry in the table is written in spaced form, so the number of
        // whitespace-separated tokens must equal the number of pattern bytes.
        uint32_t tokens = 0;
        bool in_token = false;
        for (const char* q = tbl::kTable[i].signature; *q; ++q) {
            const bool sep = (*q == ' ');
            if (!sep && !in_token) { ++tokens; in_token = true; }
            else if (sep) in_token = false;
        }
        if (tokens != once.length()) ++bad_length;
    }
    check(bad_roundtrip == 0, "every built-in signature round-trips through str()");
    check(bad_length == 0, "every built-in signature tokenises to its byte count");

    std::printf("\n%s (%d failure(s))\n",
                failures ? "SELFTEST FAILED" : "selftest passed", failures);
    return failures ? 1 : 0;
}

int run_audit(const job::AuditResult& a, bool include_clean) {
    if (!a.ok) {
        std::printf("audit failed: %s\n", a.error.c_str());
        return 1;
    }
    std::printf("module %s\n", a.module.c_str());
    std::printf("  build       %u\n", a.build);
    std::printf("  load base   0x%016llX\n", static_cast<unsigned long long>(a.load_base));
    std::printf("  size        0x%08X\n", a.module_size);
    std::printf("  examined    %u\n", a.examined);
    std::printf("  clean       %u\n", a.clean);
    std::printf("  attention   %u\n\n", a.attention);

    if (a.attention == 0) {
        std::printf("every examined symbol resolved and verified.\n");
        return 0;
    }

    std::printf("%-26s %-20s %-12s %s\n", "SYMBOL", "VERDICT", "RVA", "DETAIL");
    std::printf("%s\n", std::string(110, '-').c_str());
    for (const job::AuditRow& r : a.rows) {
        if (!include_clean && r.verdict == "ok") continue;
        std::printf("%-26s %-20s 0x%08X   %s\n", r.name.c_str(), r.verdict.c_str(),
                    r.rva, r.detail.c_str());

        if (r.match_count > 1) {
            std::printf("%-26s %-20s            matches:", "", "");
            for (size_t i = 0; i < r.matches.size() && i < 8; ++i) {
                std::printf(" 0x%08X", r.matches[i]);
            }
            std::printf("%s\n", r.matches.size() > 8 ? " ..." : "");
        }
        if (!r.operand_note.empty()) {
            std::printf("%-26s %-20s            %s\n", "", "", r.operand_note.c_str());
        }
        if (!r.proposed.empty()) {
            std::printf("%-26s proposed signature%s:\n", "",
                        r.proposed_unique ? " (verified unique)" : " (NOT unique)");
            std::printf("      %s\n", r.proposed.c_str());
        }
    }
    return 0;
}

int run_probe(const std::vector<std::string>& only) {
    std::printf("reading the target image...\n\n");
    const std::vector<job::ProbeRow> rows = job::probe_live(only);
    if (rows.empty()) {
        std::printf("no global-pointer symbol resolved to a live object.\n");
        return 1;
    }
    std::printf("%-24s %-12s %-12s %-12s %s\n",
                "SYMBOL", "RVA", "OBJECT", "VTABLE", "CLASS");
    std::printf("%s\n", std::string(104, '-').c_str());
    for (const job::ProbeRow& r : rows) {
        std::printf("%-24s 0x%08X   0x%012llX 0x%012llX %s\n",
                    r.name.c_str(), r.rva,
                    static_cast<unsigned long long>(r.object),
                    static_cast<unsigned long long>(r.vtable),
                    r.class_name.empty() ? "-" : r.class_name.c_str());
        if (!r.note.empty()) {
            std::printf("%-24s %s\n", "", r.note.c_str());
        } else if (!r.class_name.empty()) {
            std::printf("%-24s %s via a self-validated locator at vtable rva 0x%08X\n",
                        "", r.polymorphic ? "polymorphic" : "unconfirmed",
                        r.vtable_rva);
        }
    }
    return 0;
}

std::string narrow(const std::wstring& w) {
    std::string s;
    s.reserve(w.size());
    for (wchar_t c : w) s.push_back(static_cast<char>(c));
    return s;
}

job::Settings parse_dump_options(const std::vector<std::wstring>& args, size_t start) {
    job::Settings s = g.settings;
    auto to_int = [](const std::wstring& w) -> int {
        try { return std::stoi(w); } catch (...) { return -1; }
    };
    for (size_t i = start; i < args.size(); ++i) {
        if (args[i] == L"--out" && i + 1 < args.size()) {
            s.out_root = args[++i];
        } else if (args[i] == L"--no-rtti") {
            s.do_rtti = false;
        } else if (args[i] == L"--no-verify") {
            s.do_verify = false;
        } else if (args[i] == L"--fallback") {
            s.fallback_image_scan = true;
        } else if (args[i] == L"--rtti-tables" && i + 1 < args.size()) {
            const int v = to_int(args[++i]);
            if (v >= 0) s.rtti_max_tables = static_cast<uint32_t>(v);
        } else if (args[i] == L"--rtti-methods" && i + 1 < args.size()) {
            const int v = to_int(args[++i]);
            if (v >= 0) s.rtti_max_methods = static_cast<uint32_t>(v);
        }
    }
    return s;
}

int run_exports(const std::vector<job::ExportRow>& rows, const std::string& title,
                uint32_t limit, bool show_bytes) {
    std::printf("%s\n", title.c_str());
    if (rows.empty()) {
        std::printf("no matching exports.\n");
        return 1;
    }
    std::printf("%zu export(s)\n\n", rows.size());
    std::printf("%-12s %-9s %s\n", "RVA", "ORDINAL", "NAME");
    std::printf("%s\n", std::string(96, '-').c_str());
    uint32_t shown = 0;
    for (const job::ExportRow& r : rows) {
        if (limit && shown >= limit) {
            std::printf("... %zu more\n", rows.size() - shown);
            break;
        }
        std::printf("0x%08X   %-9u %s%s\n", r.rva, r.ordinal, r.name.c_str(),
                    r.forwarded ? "   (forwarded)" : "");
        if (show_bytes && r.head_valid) {
            std::printf("%-12s %-9s ", "", "");
            for (size_t i = 0; i < r.head.size(); ++i) {
                std::printf("%02X ", r.head[i]);
            }
            std::printf("\n");
        }
        ++shown;
    }
    if (show_bytes) {
        std::printf("\nThe bytes above are what a detour would have to replace. A trampoline\n"
                    "must steal a WHOLE number of instructions or it resumes misaligned: five\n"
                    "bytes is safe only when those five bytes are one instruction.\n");
    }
    return 0;
}

int run_grep(const std::filesystem::path& pe_path, const std::string& signature,
             uint32_t limit) {    std::vector<job::GrepHit> hits;
    std::string err;
    if (!job::grep_file(pe_path, signature, limit, hits, err)) {
        std::printf("grep failed: %s\n", err.c_str());
        return 1;
    }
    if (!err.empty()) std::printf("note: %s\n", err.c_str());
    std::printf("%zu hit(s) for \"%s\" in %s\n", hits.size(), signature.c_str(),
                pe_path.filename().string().c_str());
    for (const job::GrepHit& h : hits) {
        std::printf("  rva 0x%08X  %-10s %s\n", h.rva, h.section.c_str(),
                    h.executable ? "" : "(NOT executable)");
    }
    return hits.empty() ? 1 : 0;
}

int run_cli(const std::vector<std::wstring>& args) {
    attach_parent_console();
    // A CLI run leaves a log too, so a batch dump over a folder of modules can be
    // audited afterwards without having watched the terminal.
    log::open_file_sink((g.exe_dir / "dumper-cli.log").string());

    if (args.empty() || args[0] == L"--help" || args[0] == L"-h") {
        print_usage();
        log::close_file_sink();
        return 0;
    }

    if (args[0] == L"--selftest") {
        const int rc = run_selftest();
        log::close_file_sink();
        return rc;
    }

    // ---- --modules-live ------------------------------------------------------
    if (args[0] == L"--modules-live") {
        const std::vector<std::string> names = job::live_module_names();
        if (names.empty()) {
            std::printf("FiveM is not running, or the module list could not be read.\n");
            log::close_file_sink();
            return 1;
        }
        std::printf("%zu loaded module(s)\n\n", names.size());
        for (const std::string& n : names) std::printf("%s\n", n.c_str());
        log::close_file_sink();
        return 0;
    }

    // ---- --exports-live / --exports-file ------------------------------------
    if (args[0] == L"--exports-live" || args[0] == L"--exports-file") {
        const bool live = (args[0] == L"--exports-live");
        std::string module;
        std::filesystem::path pe_path;
        std::string filter;
        uint32_t limit = 0;
        bool show_bytes = false;

        // Starts at 0: for --exports-file the switch itself is args[0], and
        // skipping it left the path unset and the command unusable.
        for (size_t i = 0; i < args.size(); ++i) {
            if (args[i] == L"--module" && i + 1 < args.size()) {
                module = narrow(args[++i]);
            } else if (args[i] == L"--exports-file" && i + 1 < args.size()) {
                pe_path = args[++i];
            } else if (args[i] == L"--filter" && i + 1 < args.size()) {
                filter = narrow(args[++i]);
            } else if (args[i] == L"--bytes") {
                show_bytes = true;
            } else if (args[i] == L"--limit" && i + 1 < args.size()) {
                try { limit = static_cast<uint32_t>(std::stoul(args[++i])); } catch (...) {}
            }
        }

        std::string err;
        std::vector<job::ExportRow> rows;
        std::string title;
        if (live) {
            if (module.empty()) {
                std::printf("--exports-live needs --module <name>\n");
                log::close_file_sink();
                return 2;
            }
            rows  = job::exports_of_live(module, filter, err);
            title = module + (filter.empty() ? " -- all exports"
                                             : " -- exports matching \"" + filter + "\"");
        } else {
            if (pe_path.empty()) {
                std::printf("--exports-file needs a path\n");
                log::close_file_sink();
                return 2;
            }
            rows  = job::exports_of_file(pe_path, filter, err);
            title = pe_path.filename().string()
                  + (filter.empty() ? " -- all exports"
                                    : " -- exports matching \"" + filter + "\"");
        }
        if (!err.empty()) std::printf("note: %s\n", err.c_str());
        const int rc = run_exports(rows, title, limit, show_bytes);
        log::close_file_sink();
        return rc;
    }

    // ---- --dump-module <name> -----------------------------------------------
    if (args[0] == L"--dump-module") {
        if (args.size() < 2) {
            std::printf("--dump-module needs a module name (see --modules-live)\n");
            log::close_file_sink();
            return 2;
        }
        const job::Settings s = parse_dump_options(args, 2);
        const job::Outcome out = job::run_module(narrow(args[1]), s, g.progress);
        const job::Stats& st = out.stats;
        std::printf("\n%s\n", out.success ? "dump complete" : "dump failed");
        if (!out.error.empty()) std::printf("error: %s\n", out.error.c_str());
        std::printf("  symbols    %u found / %u requested\n",
                    st.patterns_found, st.patterns_total);
        std::printf("  verified   %u ok, %u failed, %u unpopulated\n",
                    st.verified, st.failed, st.unpopulated);
        std::printf("  vftables   %u confirmed, %u named\n", st.vftables, st.vftables_named);
        std::printf("  output     %s\n", out.out_dir.string().c_str());
        log::close_file_sink();
        return out.success ? 0 : 1;
    }

    if (args[0] == L"--probe-live") {
        std::vector<std::string> only;
        for (size_t i = 1; i < args.size(); ++i) {
            if (args[i] == L"--only" && i + 1 < args.size()) {
                std::string s;
                for (wchar_t c : args[++i]) s.push_back(static_cast<char>(c));
                only.push_back(s);
            }
        }
        const int rc = run_probe(only);
        log::close_file_sink();
        return rc;
    }

    // ---- --audit-live / --audit-file ----------------------------------------
    const bool audit_live_mode = (args[0] == L"--audit-live");
    if (audit_live_mode || args[0] == L"--audit-file") {
        std::filesystem::path pe_path;
        std::vector<std::string> only;
        uint32_t fuzzy = 3;
        bool include_clean = false;

        auto narrow = [](const std::wstring& w) {
            std::string s;
            s.reserve(w.size());
            for (wchar_t c : w) s.push_back(static_cast<char>(c));
            return s;
        };

        for (size_t i = 0; i < args.size(); ++i) {
            if (args[i] == L"--audit-file" && i + 1 < args.size()) {
                pe_path = args[++i];
            } else if (args[i] == L"--only" && i + 1 < args.size()) {
                only.push_back(narrow(args[++i]));
            } else if (args[i] == L"--fuzzy" && i + 1 < args.size()) {
                try { fuzzy = static_cast<uint32_t>(std::stoul(args[++i])); } catch (...) {}
            } else if (args[i] == L"--all") {
                include_clean = true;
            }
        }

        std::printf("reading the target image...\n");
        const job::AuditResult a = audit_live_mode
                                 ? job::audit_live(only, fuzzy, include_clean)
                                 : job::audit_file(pe_path, only, fuzzy, include_clean);

        std::printf("\n");
        const int rc = run_audit(a, include_clean || a.ok == false);
        log::close_file_sink();
        return rc;
    }

    // ---- --file <pe> --grep <sig> -------------------------------------------
    if (args[0] == L"--file") {
        std::filesystem::path pe_path;
        std::wstring sig;
        uint32_t limit = 16;
        // Starts at 0: args[0] is "--file" itself, and skipping it left the path
        // unset no matter what followed.
        for (size_t i = 0; i < args.size(); ++i) {
            if (args[i] == L"--file" && i + 1 < args.size()) {
                pe_path = args[++i];
            } else if (args[i] == L"--grep" && i + 1 < args.size()) {
                sig = args[++i];
            } else if (args[i] == L"--limit" && i + 1 < args.size()) {
                try { limit = static_cast<uint32_t>(std::stoul(args[++i])); } catch (...) {}
            }
        }
        if (pe_path.empty() || sig.empty()) {
            std::printf("--file needs a path and --grep needs a signature\n");
            log::close_file_sink();
            return 2;
        }
        std::string narrow;
        narrow.reserve(sig.size());
        for (wchar_t c : sig) narrow.push_back(static_cast<char>(c));

        const int rc = run_grep(pe_path, narrow, limit);
        log::close_file_sink();
        return rc;
    }

    // ---- --dump-live ----------------------------------------------------------
    // Same pipeline as the overlay's scan button, driven from the command line:
    // attach to the running FiveM GTA process, read the image once, dump.
    if (args[0] == L"--dump-live") {
        job::Settings s = g.settings;

        auto to_int = [](const std::wstring& w) -> int {
            try { return std::stoi(w); } catch (...) { return -1; }
        };

        for (size_t i = 1; i < args.size(); ++i) {
            const std::wstring& a = args[i];
            if (a == L"--out" && i + 1 < args.size()) {
                s.out_root = args[++i];
            } else if (a == L"--no-rtti") {
                s.do_rtti = false;
            } else if (a == L"--no-verify") {
                s.do_verify = false;
            } else if (a == L"--fallback") {
                s.fallback_image_scan = true;
            } else if (a == L"--rtti-tables" && i + 1 < args.size()) {
                const int v = to_int(args[++i]);
                if (v >= 0) s.rtti_max_tables = static_cast<uint32_t>(v);
            } else if (a == L"--rtti-methods" && i + 1 < args.size()) {
                const int v = to_int(args[++i]);
                if (v >= 0) s.rtti_max_methods = static_cast<uint32_t>(v);
            } else {
                std::printf("ignoring unrecognised argument\n");
            }
        }

        if (!g.target.attach()) {
            std::printf("could not attach to the FiveM game process (is FiveM running?)\n");
            log::close_file_sink();
            return 1;
        }
        const auto& snap = g.target.snapshot();
        std::printf("attached %s pid %u base 0x%llX size 0x%X\n", snap.name.c_str(), snap.pid,
                    static_cast<unsigned long long>(snap.base), snap.module_size);

        const job::Outcome out = job::run(g.target, s, g.progress);
        const job::Stats& st = out.stats;

        std::printf("\n%s\n", out.success ? "dump complete" : "dump failed");
        if (!out.error.empty()) std::printf("error: %s\n", out.error.c_str());
        std::printf("  patterns   %u found / %u requested\n", st.patterns_found, st.patterns_total);
        std::printf("  vftables   %u confirmed, %u named\n", st.vftables, st.vftables_named);
        std::printf("  signatures %u unique, %u field sets\n", st.rtti_signatures, st.field_sets);
        std::printf("  timings    scan %llu ms, rtti %llu ms, export %llu ms\n",
                    static_cast<unsigned long long>(st.scan_ms),
                    static_cast<unsigned long long>(st.rtti_ms),
                    static_cast<unsigned long long>(st.export_ms));
        std::printf("  output     %s\n", out.out_dir.string().c_str());
        log::close_file_sink();
        return out.success ? 0 : 1;
    }

    if (args[0] != L"--dump-file") {
        std::printf("unrecognised argument; try --help\n");
        log::close_file_sink();
        return 2;
    }
    if (args.size() < 2) {
        std::printf("--dump-file needs a path\n");
        log::close_file_sink();
        return 2;
    }

    std::filesystem::path pe_path = args[1];
    job::Settings s = g.settings;

    auto to_int = [](const std::wstring& w) -> int {
        try { return std::stoi(w); } catch (...) { return -1; }
    };

    for (size_t i = 2; i < args.size(); ++i) {
        const std::wstring& a = args[i];
        if (a == L"--out" && i + 1 < args.size()) {
            s.out_root = args[++i];
        } else if (a == L"--no-rtti") {
            s.do_rtti = false;
        } else if (a == L"--no-verify") {
            s.do_verify = false;
        } else if (a == L"--fallback") {
            s.fallback_image_scan = true;
        } else if (a == L"--rtti-tables" && i + 1 < args.size()) {
            const int v = to_int(args[++i]);
            if (v >= 0) s.rtti_max_tables = static_cast<uint32_t>(v);
        } else if (a == L"--rtti-methods" && i + 1 < args.size()) {
            const int v = to_int(args[++i]);
            if (v >= 0) s.rtti_max_methods = static_cast<uint32_t>(v);
        } else {
            std::printf("ignoring unrecognised argument\n");
        }
    }

    const job::Outcome out = job::run_offline(pe_path, s, g.progress);
    const job::Stats& st = out.stats;

    std::printf("\n%s\n", out.success ? "dump complete" : "dump failed");
    if (!out.error.empty()) std::printf("error: %s\n", out.error.c_str());
    std::printf("  patterns   %u found / %u requested\n",
                st.patterns_found, st.patterns_total);
    std::printf("  vftables   %u confirmed, %u named\n", st.vftables, st.vftables_named);
    std::printf("  signatures %u unique, %u field sets\n",
                st.rtti_signatures, st.field_sets);
    std::printf("  code hash  0x%016llX over %u executable section(s)\n",
                static_cast<unsigned long long>(st.code_hash), st.code_sections);
    std::printf("  timings    scan %llu ms, rtti %llu ms, export %llu ms\n",
                static_cast<unsigned long long>(st.scan_ms),
                static_cast<unsigned long long>(st.rtti_ms),
                static_cast<unsigned long long>(st.export_ms));
    std::printf("  output     %s\n", out.out_dir.string().c_str());
    log::close_file_sink();
    return out.success ? 0 : 1;
}

}  // namespace

// ---------------------------------------------------------------- wWinMain ---

int APIENTRY wWinMain(HINSTANCE hInstance, HINSTANCE, PWSTR, int nCmdShow) {
    g.exe_dir = executable_dir();
    g.settings.out_root = g.exe_dir / "out";

    // Switch to the CLI before any window or D3D device exists, so the offline
    // path never flashes an overlay and never needs a desktop.
    {
        int argc = 0;
        LPWSTR* argv = CommandLineToArgvW(GetCommandLineW(), &argc);
        std::vector<std::wstring> args;
        if (argv) {
            for (int i = 1; i < argc; ++i) args.emplace_back(argv[i]);
            LocalFree(argv);
        }
        if (!args.empty()) return run_cli(args);
    }

    const std::string log_file = (g.exe_dir / "dumper.log").string();
    g.log_path = log::open_file_sink(log_file);
    if (g.log_path.empty()) g.log_path = "(could not open dumper.log)";

    WNDCLASSEXW wc = { sizeof(wc), CS_CLASSDC, WndProc, 0L, 0L, hInstance,
                       nullptr, nullptr, nullptr, nullptr,
                       L"FiveMOffsetsDumperV3", nullptr };
    ::RegisterClassExW(&wc);

    HWND hwnd = ::CreateWindowW(wc.lpszClassName,
                                L"FiveM Offset Dumper - By jxst_kifoxxxxe",
                                WS_POPUP, 120, 120, 980, 680,
                                nullptr, nullptr, wc.hInstance, nullptr);
    if (!hwnd) return 1;

    if (!CreateDeviceD3D(hwnd)) {
        CleanupDeviceD3D();
        ::UnregisterClassW(wc.lpszClassName, wc.hInstance);
        return 1;
    }

    ::ShowWindow(hwnd, nCmdShow);
    ::UpdateWindow(hwnd);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO();
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;
    io.IniFilename = nullptr;   // no stray imgui.ini written beside the exe

    ImGui::StyleColorsDark();
    apply_theme(ImGui::GetStyle());

    ImGui_ImplWin32_Init(hwnd);
    ImGui_ImplDX11_Init(g_pd3dDevice, g_pd3dDeviceContext);

    log::info(std::string(dmp::ver::kProduct) + " " + dmp::ver::kToolName + " v"
              + dmp::ver::kVersion);
    log::info("output root: " + g.settings.out_root.string());
    log::info("signature table: " + std::to_string(dmp::tbl::kTableCount) + " patterns");

    while (!g.quit) {
        MSG msg;
        while (::PeekMessage(&msg, nullptr, 0U, 0U, PM_REMOVE)) {
            ::TranslateMessage(&msg);
            ::DispatchMessage(&msg);
            if (msg.message == WM_QUIT) g.quit = true;
        }
        if (g.quit) break;

        if (g_ResizeWidth != 0 && g_ResizeHeight != 0) {
            CleanupRenderTarget();
            g_pSwapChain->ResizeBuffers(0, g_ResizeWidth, g_ResizeHeight,
                                        DXGI_FORMAT_UNKNOWN, 0);
            g_ResizeWidth = g_ResizeHeight = 0;
            CreateRenderTarget();
        }

        reap_worker();
        refresh_logs();

        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();

        ImGui::SetNextWindowPos(ImVec2(0, 0));
        ImGui::SetNextWindowSize(io.DisplaySize);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
        ImGui::Begin("Main Window", nullptr,
                     ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize |
                     ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoCollapse);
        ImGui::PopStyleVar();

        const float win_w = ImGui::GetWindowWidth();
        const float win_h = ImGui::GetWindowHeight();

        // ---- frameless top bar ------------------------------------------------
        ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.07f, 0.07f, 0.07f, 1.0f));
        ImGui::BeginChild("TopBar", ImVec2(win_w, 50), false);
        ImGui::SetCursorPos(ImVec2(0, 0));
        ImGui::InvisibleButton("##DragArea", ImVec2(win_w - 50, 50));

        ImGui::SetCursorPos(ImVec2(20, 16));
        ImGui::TextColored(ImVec4(1.0f, 1.0f, 1.0f, 1.0f), "%s", dmp::ver::kProduct);
        ImGui::SameLine();
        ImGui::TextColored(ImVec4(0.6f, 0.6f, 0.6f, 1.0f), "|");
        ImGui::SameLine();
        ImGui::Text("%s", dmp::ver::kTagline);

        ImGui::SetCursorPos(ImVec2(win_w - 40, 12));
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0, 0, 0, 0));
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.9f, 0.2f, 0.2f, 1.0f));
        ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.7f, 0.1f, 0.1f, 1.0f));
        if (ImGui::Button("X", ImVec2(25, 25))) {
            if (g.progress.running) g.progress.cancel = true;
            g.quit = true;
        }
        ImGui::PopStyleColor(3);
        ImGui::EndChild();
        ImGui::PopStyleColor();

        // ---- sidebar ---------------------------------------------------------
        ImGui::BeginChild("SideBar", ImVec2(170, win_h - 50), true);
        ImGui::Spacing();
        render_tab_button("  Scanner", 0);
        render_tab_button("  Process Info", 1);
        render_tab_button("  Settings", 2);
        render_tab_button("  About", 3);
        ImGui::EndChild();

        if (g.active_tab != g.last_tab) {
            g.tab_alpha = 0.0f;
            g.last_tab  = g.active_tab;
        }
        g.tab_alpha += (1.0f - g.tab_alpha) * (15.0f * io.DeltaTime);

        // ---- content ---------------------------------------------------------
        ImGui::SameLine();
        ImGui::PushStyleVar(ImGuiStyleVar_Alpha, g.tab_alpha);
        ImGui::BeginChild("ContentArea", ImVec2(win_w - 190, win_h - 70), false);
        ImGui::Spacing();
        const ImVec2 avail = ImGui::GetContentRegionAvail();

        switch (g.active_tab) {
        case 0:  tab_scanner(avail); break;
        case 1:  tab_process(avail); break;
        case 2:  tab_settings();     break;
        default: tab_about();        break;
        }

        ImGui::EndChild();
        ImGui::PopStyleVar();
        ImGui::End();

        ImGui::Render();
        const float clear[4] = { 0.04f, 0.04f, 0.04f, 1.0f };
        g_pd3dDeviceContext->OMSetRenderTargets(1, &g_mainRenderTargetView, nullptr);
        g_pd3dDeviceContext->ClearRenderTargetView(g_mainRenderTargetView, clear);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
        g_pSwapChain->Present(1, 0);
    }

    if (g.progress.running) g.progress.cancel = true;
    if (g.worker.joinable()) g.worker.join();

    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();

    log::close_file_sink();

    CleanupDeviceD3D();
    ::DestroyWindow(hwnd);
    ::UnregisterClassW(wc.lpszClassName, wc.hInstance);
    return 0;
}

// ---------------------------------------------------------------- DX11 impl --

static bool CreateDeviceD3D(HWND hWnd) {
    DXGI_SWAP_CHAIN_DESC sd;
    ZeroMemory(&sd, sizeof(sd));
    sd.BufferCount = 2;
    sd.BufferDesc.Width = 0;
    sd.BufferDesc.Height = 0;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferDesc.RefreshRate.Numerator = 60;
    sd.BufferDesc.RefreshRate.Denominator = 1;
    sd.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = hWnd;
    sd.SampleDesc.Count = 1;
    sd.SampleDesc.Quality = 0;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

    UINT flags = 0;
    D3D_FEATURE_LEVEL level;
    const D3D_FEATURE_LEVEL levels[2] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0 };
    HRESULT res = D3D11CreateDeviceAndSwapChain(
        nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, flags, levels, 2, D3D11_SDK_VERSION,
        &sd, &g_pSwapChain, &g_pd3dDevice, &level, &g_pd3dDeviceContext);
    if (res == DXGI_ERROR_UNSUPPORTED) {
        res = D3D11CreateDeviceAndSwapChain(
            nullptr, D3D_DRIVER_TYPE_WARP, nullptr, flags, levels, 2, D3D11_SDK_VERSION,
            &sd, &g_pSwapChain, &g_pd3dDevice, &level, &g_pd3dDeviceContext);
    }
    if (res != S_OK) return false;

    CreateRenderTarget();
    return true;
}

static void CleanupDeviceD3D() {
    CleanupRenderTarget();
    if (g_pSwapChain)        { g_pSwapChain->Release();        g_pSwapChain = nullptr; }
    if (g_pd3dDeviceContext) { g_pd3dDeviceContext->Release(); g_pd3dDeviceContext = nullptr; }
    if (g_pd3dDevice)        { g_pd3dDevice->Release();        g_pd3dDevice = nullptr; }
}

static void CreateRenderTarget() {
    ID3D11Texture2D* back = nullptr;
    if (SUCCEEDED(g_pSwapChain->GetBuffer(0, IID_PPV_ARGS(&back))) && back) {
        g_pd3dDevice->CreateRenderTargetView(back, nullptr, &g_mainRenderTargetView);
        back->Release();
    }
}

static void CleanupRenderTarget() {
    if (g_mainRenderTargetView) {
        g_mainRenderTargetView->Release();
        g_mainRenderTargetView = nullptr;
    }
}

static LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam)) return true;

    switch (msg) {
    case WM_NCHITTEST: {
        // Drag region measured from the live client rect, not a hardcoded 800: the
        // previous constant stopped matching the window the moment anything changed
        // its size, and the title bar silently stopped dragging.
        POINT pt = { GET_X_LPARAM(lParam), GET_Y_LPARAM(lParam) };
        ScreenToClient(hWnd, &pt);
        RECT rc{};
        GetClientRect(hWnd, &rc);
        if (pt.y >= 0 && pt.y < 50 && pt.x >= 0 && pt.x < (rc.right - 50)) return HTCAPTION;
        break;
    }
    case WM_SIZE:
        if (wParam == SIZE_MINIMIZED) return 0;
        g_ResizeWidth  = static_cast<UINT>(LOWORD(lParam));
        g_ResizeHeight = static_cast<UINT>(HIWORD(lParam));
        return 0;
    case WM_SYSCOMMAND:
        if ((wParam & 0xfff0) == SC_KEYMENU) return 0;
        break;
    case WM_DESTROY:
        ::PostQuitMessage(0);
        return 0;
    default:
        break;
    }
    return ::DefWindowProcW(hWnd, msg, wParam, lParam);
}
