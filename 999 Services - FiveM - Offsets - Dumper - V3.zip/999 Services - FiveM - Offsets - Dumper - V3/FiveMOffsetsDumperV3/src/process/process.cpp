// language: C++, file: src/process/process.cpp, target: Windows 11, MSVC, x64
#include "process/process.hpp"

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <psapi.h>

#include <chrono>
#include <cstdlib>

#pragma comment(lib, "Psapi.lib")

namespace dmp::proc {
namespace {

uint64_t now_ms() {
    using namespace std::chrono;
    return static_cast<uint64_t>(
        duration_cast<milliseconds>(steady_clock::now().time_since_epoch()).count());
}

}  // namespace

void* game_window() {
    return FindWindowA(kGameWindowClass, nullptr);
}

uint32_t window_pid(void* hwnd) {
    if (!hwnd) return 0;
    DWORD pid = 0;
    GetWindowThreadProcessId(static_cast<HWND>(hwnd), &pid);
    return pid;
}

uint32_t build_from_name(const std::string& module_name) {
    // FiveM names the game process "FiveM_b<build>_GTAProcess.exe". The build tag
    // is what a dumped offset table has to be keyed against, so it is parsed
    // rather than ignored.
    const size_t pos = module_name.find("_b");
    if (pos == std::string::npos) return 0;
    const char* p = module_name.c_str() + pos + 2;
    if (*p < '0' || *p > '9') return 0;
    return static_cast<uint32_t>(std::strtoul(p, nullptr, 10));
}

Target::~Target() { detach(); }

void* Target::open(uint32_t pid) {
    if (!pid) return nullptr;
    // PROCESS_QUERY_LIMITED_INFORMATION first: it succeeds across an integrity
    // boundary where PROCESS_QUERY_INFORMATION is denied, and VirtualQueryEx needs
    // no more than that. The wider right is only used when the narrow one fails.
    HANDLE h = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION | PROCESS_VM_READ, FALSE, pid);
    if (!h) h = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, pid);
    return h;
}

void Target::detach() {
    if (handle_) {
        CloseHandle(static_cast<HANDLE>(handle_));
        handle_ = nullptr;
    }
    pid_ = 0;
    snap_ = Snapshot{};
}

bool Target::attach() {
    detach();
    if (!game_window()) return false;
    const uint32_t pid = window_pid(game_window());
    if (!pid) return false;

    handle_ = open(pid);
    if (!handle_) return false;
    pid_ = pid;
    take_snapshot();
    return snap_.valid;
}

bool Target::reattach_if_stale() {
    if (!attached()) return attach();

    // The game can exit and restart under the same window class. A dead handle
    // still succeeds on GetExitCodeProcess, so that is the liveness probe.
    DWORD code = 0;
    if (!GetExitCodeProcess(static_cast<HANDLE>(handle_), &code) || code != STILL_ACTIVE) {
        return attach();
    }
    // Same window class, different pid: the game was restarted in place.
    const uint32_t live = window_pid(game_window());
    if (live && live != pid_) return attach();
    return true;
}

void Target::take_snapshot() {
    snap_ = Snapshot{};
    if (!handle_) return;

    snap_.pid      = pid_;
    snap_.valid    = true;
    snap_.taken_at_ms = now_ms();

    HMODULE modules[1024] = {};
    DWORD needed = 0;
    if (!EnumProcessModules(static_cast<HANDLE>(handle_), modules, sizeof(modules), &needed)) {
        snap_.valid = false;
        return;
    }
    const size_t count = needed / sizeof(HMODULE);
    snap_.modules.reserve(count);

    for (size_t i = 0; i < count; ++i) {
        char name[MAX_PATH] = {};
        if (GetModuleBaseNameA(static_cast<HANDLE>(handle_), modules[i], name, MAX_PATH) == 0) {
            continue;
        }
        MODULEINFO mi{};
        if (!GetModuleInformation(static_cast<HANDLE>(handle_), modules[i], &mi, sizeof(mi))) {
            continue;
        }
        Module m;
        m.name = name;
        m.base = reinterpret_cast<uintptr_t>(mi.lpBaseOfDll);
        m.size = mi.SizeOfImage;
        snap_.modules.push_back(std::move(m));
    }
    if (snap_.modules.empty()) {
        snap_.valid = false;
        return;
    }

    // modules[0] is the main executable by definition of EnumProcessModules.
    snap_.name        = snap_.modules.front().name;
    snap_.base        = snap_.modules.front().base;
    snap_.module_size = snap_.modules.front().size;

    char path[MAX_PATH] = {};
    if (GetModuleFileNameExA(static_cast<HANDLE>(handle_), modules[0], path, MAX_PATH)) {
        snap_.image_path = path;
    }
}

bool Target::refresh(uint32_t min_interval_ms) {
    if (!handle_) return false;
    if (snap_.valid && now_ms() - snap_.taken_at_ms < min_interval_ms) return false;
    take_snapshot();
    return true;
}

uintptr_t Target::address_of(uint32_t rva) const {
    if (!snap_.valid) return 0;
    if (rva >= snap_.module_size) return 0;
    return snap_.base + rva;
}

bool Target::in_image(uintptr_t address) const {
    if (!snap_.valid || !address) return false;
    return address >= snap_.base && address < snap_.base + snap_.module_size;
}

}  // namespace dmp::proc
