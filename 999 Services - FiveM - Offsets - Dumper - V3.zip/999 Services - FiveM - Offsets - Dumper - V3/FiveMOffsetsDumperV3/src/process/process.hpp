// language: C++, file: src/process/process.hpp, target: Windows 11, MSVC, x64
// Target discovery and process attachment.
//
// The snapshot is CACHED. Re-enumerating modules is the single most expensive
// thing this tool does to the target -- EnumProcessModules plus a
// GetModuleInformation call per module, on a process carrying a hundred of them --
// so doing it from a per-frame UI path would both stutter the overlay and produce
// a handle-and-query pattern that is trivially visible to anything watching the
// game process. refresh() re-reads it only when the interval has actually elapsed.
#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace dmp::proc {

struct Module {
    std::string name;
    uintptr_t   base = 0;
    uint32_t    size = 0;
};

struct Snapshot {
    bool                 valid       = false;
    uint32_t             pid         = 0;
    std::string          name;
    uintptr_t            base        = 0;
    uint32_t             module_size = 0;
    std::string          image_path;
    std::vector<Module>  modules;
    uint64_t             taken_at_ms = 0;
};

// The FiveM game window class. The GTA process -- not the launcher -- owns it.
inline constexpr const char* kGameWindowClass = "grcWindow";

// Handle to the game window, or nullptr when FiveM is not running.
void* game_window();
uint32_t window_pid(void* hwnd);

// "FiveM_b3751_GTAProcess.exe" -> 3751, or 0 when the name carries no build tag.
uint32_t build_from_name(const std::string& module_name);

class Target {
public:
    Target() = default;
    ~Target();
    Target(const Target&)            = delete;
    Target& operator=(const Target&) = delete;

    // Finds the window, opens the process with the narrowest rights that still
    // permit reading, and takes the first snapshot.
    bool attach();

    // Re-opens the process when the previous PID is gone. Cheap when the game is
    // already attached; used by the UI to recover after a restart.
    bool reattach_if_stale();

    void detach();
    bool attached() const { return handle_ != nullptr; }

    void* handle() const { return handle_; }
    uint32_t pid() const { return pid_; }

    // Cached snapshot. Never touches the target.
    const Snapshot& snapshot() const { return snap_; }

    // Re-enumerates modules when at least `min_interval_ms` has elapsed since the
    // last snapshot. Returns true when the snapshot was actually refreshed.
    bool refresh(uint32_t min_interval_ms = 1500);

    // Absolute address of an RVA inside the main module. 0 when out of range.
    uintptr_t address_of(uint32_t rva) const;

    // True when the address falls inside the main module image.
    bool in_image(uintptr_t address) const;

private:
    void*     handle_ = nullptr;
    uint32_t  pid_    = 0;
    Snapshot  snap_;

    void take_snapshot();
    static void* open(uint32_t pid);
};

}  // namespace dmp::proc
