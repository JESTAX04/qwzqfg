// language: C++, file: src/version.hpp, target: Windows 11, MSVC, x64
// Single source of truth for every version string the binary shows or writes.
// The product folder says V3, so the binary says V3; nothing carries a stale V2.
#pragma once

namespace dmp::ver {

inline constexpr const char* kProduct   = "999 SERVICES";
inline constexpr const char* kToolName  = "FiveM Advanced Offset Dumper";
inline constexpr const char* kVersion   = "3.0.0";
inline constexpr const char* kTagline   = "FiveM Advanced Offset Dumper v3";
inline constexpr const char* kAuthor    = "jxst_kifoxxxxe";
inline constexpr const char* kDiscord   = "https://discord.gg/REWDYEpa7f";
inline constexpr const char* kWebsite   = "https://999services01.mysellauth.com/";

// Stamped into every export so a dump can always be traced back to the tool
// revision that produced it.
inline constexpr const char* kToolId    = "999services-dumper/3.0.0";

inline constexpr const char* kWindowClass = "FiveMOffsetsDumperV3";
inline constexpr const char* kWindowTitle = "FiveM Offset Dumper - By jxst_kifoxxxxe";

}  // namespace dmp::ver
