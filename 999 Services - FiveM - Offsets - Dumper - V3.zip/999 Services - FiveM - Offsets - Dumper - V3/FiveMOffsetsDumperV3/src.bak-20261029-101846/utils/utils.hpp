#pragma once
#include <string>
#include <vector>
#include <mutex>

namespace logger {
    const int info = 0;
    const int success = 1;
    const int fail = 2;

    struct LogMessage {
        std::string text;
        int type;
    };

    void log(const std::string& message, int type = info);
    
    // GUI Log Buffer
    std::vector<LogMessage> get_logs();
    void clear_logs();
}
// Made By JxstKifoxxxxe Discord: https://discord.gg/REWDYEpa7f Website: https://999services01.mysellauth.com/
//     † John 3:16 "For God so loved the world, that he gave his only Son, that whoever believes in him should not perish but have eternal life. Jesus Is King † 
