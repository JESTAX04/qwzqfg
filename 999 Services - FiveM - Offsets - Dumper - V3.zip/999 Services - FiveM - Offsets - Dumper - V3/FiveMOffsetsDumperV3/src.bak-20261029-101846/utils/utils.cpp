#include "utils.hpp"
#include <windows.h>
#include <iostream>
#include <string>
#include <vector>
#include <mutex>

namespace logger {
    static std::vector<LogMessage> g_logs;
    static std::mutex g_logs_mutex;

    void set_console_color(WORD color) {
        HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
        SetConsoleTextAttribute(hConsole, color);
    }

    void log(const std::string& message, int type) {
        {
            std::lock_guard<std::mutex> lock(g_logs_mutex);
            g_logs.push_back({message, type});
        }

        HANDLE hConsole = GetStdHandle(STD_OUTPUT_HANDLE);
        if (hConsole == INVALID_HANDLE_VALUE || hConsole == NULL) {
            return; // No console available (e.g. subsystem Windows without console)
        }

        WORD white = FOREGROUND_RED | FOREGROUND_GREEN | FOREGROUND_BLUE;
        WORD bright_white = white | FOREGROUND_INTENSITY;
        WORD magenta_bright = FOREGROUND_BLUE | FOREGROUND_INTENSITY;
        WORD green_bright = FOREGROUND_GREEN | FOREGROUND_INTENSITY;
        WORD red_bright = FOREGROUND_RED | FOREGROUND_INTENSITY;

        const int padding = 5;
        std::cout << std::string(padding, ' ');

        set_console_color(white);
        std::cout << "[";

        switch (type) {
        case info:
            set_console_color(magenta_bright);
            std::cout << " INFO ";
            break;
        case success:
            set_console_color(green_bright);
            std::cout << "  OK  ";
            break;
        case fail:
            set_console_color(red_bright);
            std::cout << " FAIL ";
            break;
        default:
            set_console_color(bright_white);
            std::cout << "  ??  ";
            break;
        }

        set_console_color(white);
        std::cout << "] ";

        set_console_color(bright_white);
        std::cout << message << std::endl;

        set_console_color(white);
    }

    std::vector<LogMessage> get_logs() {
        std::lock_guard<std::mutex> lock(g_logs_mutex);
        return g_logs;
    }

    void clear_logs() {
        std::lock_guard<std::mutex> lock(g_logs_mutex);
        g_logs.clear();
    }
}
// Made By JxstKifoxxxxe Discord: https://discord.gg/REWDYEpa7f Website: https://999services01.mysellauth.com/
//     † John 3:16 "For God so loved the world, that he gave his only Son, that whoever believes in him should not perish but have eternal life. Jesus Is King † 
