#pragma once
#include <windows.h>
#include <cstdint>
#include <string>
#include <vector>

namespace memory {
    /**
     * @brief Scans for a byte pattern within a pre-read memory buffer.
     * @param buffer Pre-read memory buffer of the module.
     * @param base_address Starting address (module base).
     * @param pattern IDA-style byte pattern (e.g., "48 8B 05 ? ? ? ?").
     * @return Address of the match, or 0 if not found.
     */
    uintptr_t pattern_scan(const std::vector<uint8_t>& buffer, uintptr_t base_address, const std::string& pattern);

    /**
     * @brief Resolves a RIP-relative address (x64).
     *        Used for instructions like `lea rax, [rip + disp32]` or `call [rip + disp32]`.
     * @param process_handle       Handle to the target process.
     * @param instruction_address  Address of the instruction.
     * @param disp_offset          Offset of the displacement from the instruction start.
     * @param instruction_size     Total size of the instruction.
     * @return Resolved absolute address, or 0 on failure.
     */
    uintptr_t get_rip_relative_address(HANDLE process_handle, uintptr_t instruction_address, int disp_offset = 3, int instruction_size = 7);

    /**
     * @brief Reads a 64-bit pointer from the target process.
     * @param process_handle  Handle to the target process.
     * @param address         Address containing the pointer.
     * @return Value of the pointer, or 0 if read failed.
     */
    uintptr_t dereference_pointer(HANDLE process_handle, uintptr_t address);
}
// Made By JxstKifoxxxxe Discord: https://discord.gg/REWDYEpa7f Website: https://999services01.mysellauth.com/
//     † John 3:16 "For God so loved the world, that he gave his only Son, that whoever believes in him should not perish but have eternal life. Jesus Is King † 
