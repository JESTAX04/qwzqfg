#include "memory.hpp"
#include <windows.h>
#include <vector>
#include <string>
#include <sstream>
#include <cstdint>

struct WildcardByte {
    bool is_wildcard;
    uint8_t value;
    WildcardByte() : is_wildcard(true), value(0) {}
    WildcardByte(uint8_t v) : is_wildcard(false), value(v) {}
};

namespace memory {
    static std::vector<WildcardByte> build_signature(const std::string& input) {
        std::vector<WildcardByte> sig;
        sig.reserve(input.size() / 2); // Pre-allocate to prevent reallocation
        for (size_t i = 0; i < input.size(); ) {
            if (input[i] == ' ') {
                ++i;
                continue;
            }
            if (input[i] == '?') {
                sig.emplace_back();
                ++i;
                if (i < input.size() && input[i] == '?') {
                    ++i;
                }
            } else {
                if (i + 1 < input.size()) {
                    char high = input[i];
                    char low = input[i + 1];
                    auto hex_to_int = [](char c) -> uint8_t {
                        if (c >= '0' && c <= '9') return c - '0';
                        if (c >= 'a' && c <= 'f') return c - 'a' + 10;
                        if (c >= 'A' && c <= 'F') return c - 'A' + 10;
                        return 0;
                    };
                    uint8_t value = (hex_to_int(high) << 4) | hex_to_int(low);
                    sig.emplace_back(value);
                    i += 2;
                } else {
                    break;
                }
            }
        }
        return sig;
    }

    uintptr_t pattern_scan(const std::vector<uint8_t>& buffer, uintptr_t base_address, const std::string& pattern) {
        if (buffer.empty() || pattern.empty()) return 0;
        auto signature = build_signature(pattern);
        if (signature.empty()) return 0;

        const size_t sig_len = signature.size();
        const size_t buffer_size = buffer.size();
        if (buffer_size < sig_len) return 0;

        const size_t max_offset = buffer_size - sig_len;
        const uint8_t* scan_bytes = buffer.data();

        bool first_byte_is_wildcard = signature[0].is_wildcard;
        uint8_t first_byte = signature[0].value;

        for (size_t pos = 0; pos <= max_offset; ) {
            if (!first_byte_is_wildcard) {
                const void* match = memchr(scan_bytes + pos, first_byte, max_offset - pos + 1);
                if (!match) return 0;
                pos = static_cast<const uint8_t*>(match) - scan_bytes;
            }

            bool matched = true;
            for (size_t i = 1; i < sig_len; ++i) { // i = 1 because i = 0 is already matched if !first_byte_is_wildcard
                if (!signature[i].is_wildcard && signature[i].value != scan_bytes[pos + i]) {
                    matched = false;
                    break;
                }
            }

            if (matched) return base_address + pos;

            ++pos;
        }

        return 0;
    }

    uintptr_t get_rip_relative_address(HANDLE process_handle, uintptr_t instruction_address, int disp_offset, int instruction_size) {
        if (!process_handle || !instruction_address) return 0;
        int32_t offset = 0;
        SIZE_T bytes_read = 0;
        if (!ReadProcessMemory(process_handle, reinterpret_cast<LPCVOID>(instruction_address + disp_offset), &offset, sizeof(offset), &bytes_read) ||
            bytes_read != sizeof(offset)) return 0;

        return instruction_address + instruction_size + offset;
    }

    uintptr_t dereference_pointer(HANDLE process_handle, uintptr_t address) {
        if (!process_handle || !address) return 0;
        uintptr_t target = 0;
        SIZE_T bytes_read = 0;
        if (!ReadProcessMemory(process_handle, reinterpret_cast<LPCVOID>(address), &target, sizeof(target), &bytes_read) ||
            bytes_read != sizeof(target)) return 0;
            
        return target;
    }
}
// Made By JxstKifoxxxxe Discord: https://discord.gg/REWDYEpa7f Website: https://999services01.mysellauth.com/
//     † John 3:16 "For God so loved the world, that he gave his only Son, that whoever believes in him should not perish but have eternal life. Jesus Is King † 
