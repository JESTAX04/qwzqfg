#include <windows.h>
#include <windowsx.h>
#include <d3d11.h>
#include <tchar.h>
#include <iostream>
#include <thread>
#include <sstream>
#include <fstream>
#include <iomanip>
#include <vector>
#include <chrono>
#include <future>
#include <mutex>
#include <atomic>

#include "imgui.h"
#include "imgui_impl_win32.h"
#include "imgui_impl_dx11.h"

#include "process/process.hpp"
#include "memory/memory.hpp"
#include "utils/utils.hpp"

// Data for DX11
static ID3D11Device*            g_pd3dDevice = nullptr;
static ID3D11DeviceContext*     g_pd3dDeviceContext = nullptr;
static IDXGISwapChain*          g_pSwapChain = nullptr;
static bool                     g_SwapChainOccluded = false;
static UINT                     g_ResizeWidth = 0, g_ResizeHeight = 0;
static ID3D11RenderTargetView*  g_mainRenderTargetView = nullptr;

bool CreateDeviceD3D(HWND hWnd);
void CleanupDeviceD3D();
void CreateRenderTarget();
void CleanupRenderTarget();
LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

extern IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

enum class PatternType {
    RIP_RELATIVE,
    RIP_RELATIVE_CALL,
    INSTRUCTION
};

struct pattern_struct {
    const char* name;
    const char* signature;
    PatternType type;
    int extra_offset;
};

static pattern_struct patterns[] = {
    // Base Pointers
    {"m_World", "48 8B 05 ? ? ? ? 33 D2 48 8B 40 08 8A CA 48 85 C0 74 16 48 8B", PatternType::RIP_RELATIVE, 0},
    {"m_ReplayInterFace", "48 8D 0D ? ? ? ? 48 ? ? E8 ? ? ? ? 48 8D 0D ? ? ? ? 8A D8 E8 ? ? ? ? 84 DB 75 13 48 8D 0D ? ? ? ? 48 8B D7 E8 ? ? ? ? 84 C0 74 BC 8B 8F", PatternType::RIP_RELATIVE, 0},
    {"m_ViewPort", "48 8B 15 ? ? ? ? 48 8D 2D ? ? ? ? 48 8B CD", PatternType::RIP_RELATIVE, 0},
    {"m_BlipList", "4C 8D 05 ? ? ? ? 0F B7 C1", PatternType::RIP_RELATIVE, 0},
    {"m_CamGameplayDirector", "4C 8B 35 ? ? ? ? 33 FF 32 DB", PatternType::RIP_RELATIVE, 0},

    // Functions / Handlers / Kinematics
    {"m_ArmsKinematics", "E8 ? ? ? ? 48 83 C3 60 48 FF CF 75 E6 48 8B 5C 24", PatternType::RIP_RELATIVE_CALL, 0},
    {"m_LegsKinematics", "E8 ? ? ? ? 48 83 C3 60 48 FF CF 75 DF 48 8B 5C 24 ? 48 8B 6C 24 ? 48 8B 74 24", PatternType::RIP_RELATIVE_CALL, 0},
    {"m_GiveWeapon", "48 89 5c 24 ? 48 89 6c 24 ? 48 89 74 24 ? 57 48 83 ec ? 41 8b f0 8b fa 48 8b d9 e8", PatternType::INSTRUCTION, 0},

    // Patches / Modifiers
    {"m_SilentAim", "48 8D 45 ? F3 0F 10 00 F3 0F 10 48 ? F3 0F 11 45", PatternType::INSTRUCTION, 0},
    {"m_InfiniteAmmo0", "41 2B C9 3B C8 0F 4D C8", PatternType::INSTRUCTION, 0},
    {"m_InfiniteAmmo1", "41 2B D1 E8", PatternType::INSTRUCTION, 0},
    {"m_MagicBulletsPatch", "0F 29 4F ? 83 8F ? ? ? ? ? 48 8B 4F", PatternType::INSTRUCTION, 0},
    {"m_InfiniteCombatRoll", "89 81 ? ? ? ? 8B 87 ? ? ? ? F7 D0", PatternType::INSTRUCTION, 0},
    {"m_OffsetPool", "0F B7 CA 83 F9 07 7F 5E", PatternType::INSTRUCTION, 0},
    {"m_Speed", "0F 2F C2 77 ? F3 0F 10 83 ? ? ? ? 48 83 C4", PatternType::INSTRUCTION, 0},
    {"m_VehicleEngineHealth", "F3 0F 11 80 ? ? ? ? 48 8B 87 ? ? ? ? F3 0F 10 05", PatternType::INSTRUCTION, 0},
    {"m_Spread", "F3 41 0F 10 B0 ? ? ? ? 48 8B CA", PatternType::INSTRUCTION, 0},
    {"m_Recoil", "F3 0F 10 B0 ? ? ? ? 49 8B 87", PatternType::INSTRUCTION, 0},
    {"m_CObject", "4C 8B 41 ? 4D 85 C9", PatternType::INSTRUCTION, 0},
    {"m_CWeapon", "48 8B 8B ? ? ? ? 48 8B D7 E8 ? ? ? ? 48 8B 8B ? ? ? ? 48 8B D7 E8", PatternType::INSTRUCTION, 0},
    {"m_VehicleDriver", "4C 8B 94 C7 ? ? ? ? EB ? 4D 8B D6 41 8A 82", PatternType::INSTRUCTION, 0},
    {"m_NoRagDoll", "8B 81 ? ? ? ? 83 E0 ? C1 E0 ? 3D ? ? ? ? 0F 8F", PatternType::INSTRUCTION, 0},
    {"m_SeatBealt", "F6 81 ? ? ? ? ? 75 ? 8B 83", PatternType::INSTRUCTION, 0},
    {"m_VehicleDoorsLockState", "74 ? 83 B9 ? ? ? ? ? 75 ? 45 84 F6", PatternType::INSTRUCTION, 0},
    {"m_Handling", "48 8B 83 ? ? ? ? 8B D5 48 89 44 24 ? 4C 89 74 24", PatternType::INSTRUCTION, 0},

    // Legacy / Original
    {"bullet", "F3 41 0F 10 19 F3 41 0F 10 41 04", PatternType::INSTRUCTION, 0},
    {"aim_cped", "48 8D 0D ? ? ? ? E8 ? ? ? ? 48 8B 0D ? ? ? ? 48 85 C9 74 05 E8 ? ? ? ? 8A CB", PatternType::RIP_RELATIVE, 0},
    {"set_ped_in_to_vehicle", "48 8B C4 44 89 48 ? 44 89 40 ? 48 89 50 ? 48 89 48 ? 55 53 56 57 41 54 41 55 41 56 41 57 48 8D A8 ? ? ? ? 48 81 EC ? ? ? ? 83 BA", PatternType::INSTRUCTION, 0},
    {"c_sky_settings", "48 8D 0D ? ? ? ? E8 ? ? ? ? 83 25 ? ? ? ? 00 48 8D 0D ? ? ? ? F3", PatternType::RIP_RELATIVE, 0}
};

std::atomic<bool> g_is_scanning = false;
std::atomic<int> g_progress_found = 0;
std::atomic<int> g_progress_total = 0;

void perform_scan() {
    g_is_scanning = true;
    logger::clear_logs();
    logger::log("Awaiting for FiveM...", logger::info);

    HWND window_handle = nullptr;
    int wait_timer = 0;
    while (!(window_handle = FindWindowA("grcWindow", NULL))) {
        std::this_thread::sleep_for(std::chrono::seconds(1));
        wait_timer++;
        if (wait_timer > 30) {
            logger::log("FiveM not found within 30 seconds. Aborting.", logger::fail);
            g_is_scanning = false;
            return;
        }
    }

    DWORD pid;
    GetWindowThreadProcessId(window_handle, &pid);
    if (!pid) {
        g_is_scanning = false;
        return;
    }

    std::string process_name = process::get_name(pid);
    int build = 0;
    size_t b_pos = process_name.find("_b");

    if (b_pos != std::string::npos) {
        std::string build_str = process_name.substr(b_pos + 2);
        try {
            build = std::stoi(build_str);
            logger::log("FiveM found! (Build " + std::to_string(build) + ")", logger::success);
        } catch (...) {
            logger::log("FiveM found! (Build unknown)", logger::success);
        }
    } else {
        logger::log("FiveM found! (" + process_name + ")", logger::success);
    }

    HANDLE process_handle = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, pid);
    if (!process_handle) {
        logger::log("Failed to open process.", logger::fail);
        g_is_scanning = false;
        return;
    }

    uintptr_t base_address = process::get_base_address(pid);
    if (!base_address) {
        logger::log("Failed to get base address.", logger::fail);
        CloseHandle(process_handle);
        g_is_scanning = false;
        return;
    }
    
    DWORD module_size = process::get_module_size(pid);
    if (!module_size) {
        logger::log("Failed to get module size.", logger::fail);
        CloseHandle(process_handle);
        g_is_scanning = false;
        return;
    }

    logger::log("Caching game module in memory for optimized scanning...", logger::info);
    
    auto start_time = std::chrono::high_resolution_clock::now();
    
    std::vector<uint8_t> module_buffer(module_size, 0);
    uintptr_t current_address = base_address;
    MEMORY_BASIC_INFORMATION info;
    
    while (current_address < base_address + module_size && VirtualQueryEx(process_handle, reinterpret_cast<LPCVOID>(current_address), &info, sizeof(info))) {
        if (info.State == MEM_COMMIT && (info.Protect & PAGE_GUARD) == 0 && (info.Protect & PAGE_NOACCESS) == 0) {
            SIZE_T bytes_read = 0;
            uintptr_t offset = reinterpret_cast<uintptr_t>(info.BaseAddress) - base_address;
            SIZE_T read_size = info.RegionSize;
            if (offset + read_size > module_size) {
                read_size = module_size - offset;
            }
            if (read_size > 0) {
                ReadProcessMemory(process_handle, info.BaseAddress, module_buffer.data() + offset, read_size, &bytes_read);
            }
        }
        current_address = reinterpret_cast<uintptr_t>(info.BaseAddress) + info.RegionSize;
    }

    std::vector<std::pair<std::string, uintptr_t>> results;
    g_progress_found = 0;
    g_progress_total = sizeof(patterns) / sizeof(patterns[0]);

    std::vector<std::future<std::pair<std::string, uintptr_t>>> futures;
    std::mutex log_mutex;

    for (const auto& pattern : patterns) {
        futures.push_back(std::async(std::launch::async, [pattern, &module_buffer, base_address, process_handle, &log_mutex]() -> std::pair<std::string, uintptr_t> {
            uintptr_t instruction_address = memory::pattern_scan(module_buffer, base_address, pattern.signature);
            if (!instruction_address) {
                std::lock_guard<std::mutex> lock(log_mutex);
                logger::log(std::string(pattern.name) + " -> [NOT FOUND]", logger::fail);
                return {pattern.name, 0};
            }

            instruction_address += pattern.extra_offset;

            uintptr_t resolved_address = 0;
            switch (pattern.type) {
                case PatternType::RIP_RELATIVE:
                    resolved_address = memory::get_rip_relative_address(process_handle, instruction_address, 3, 7);
                    break;
                case PatternType::RIP_RELATIVE_CALL:
                    resolved_address = memory::get_rip_relative_address(process_handle, instruction_address, 1, 5);
                    break;
                case PatternType::INSTRUCTION:
                    resolved_address = instruction_address;
                    break;
            }

            if (!resolved_address) {
                std::lock_guard<std::mutex> lock(log_mutex);
                logger::log(std::string(pattern.name) + " -> [FAILED TO RESOLVE]", logger::fail);
                return {pattern.name, 0};
            }

            uintptr_t offset_fix = resolved_address - base_address;

            {
                std::lock_guard<std::mutex> lock(log_mutex);
                std::stringstream ss;
                ss << std::hex << std::uppercase << std::setfill('0') << std::setw(8) << offset_fix;
                logger::log(std::string(pattern.name) + " -> 0x" + ss.str(), logger::success);
                g_progress_found++;
            }
            
            return {pattern.name, offset_fix};
        }));
    }

    for (auto& fut : futures) {
        auto res = fut.get();
        if (res.second != 0) {
            results.push_back(res);
        }
    }

    auto end_time = std::chrono::high_resolution_clock::now();
    auto duration_ms = std::chrono::duration_cast<std::chrono::milliseconds>(end_time - start_time).count();

    logger::log("Scan Completed in " + std::to_string(duration_ms) + " ms", logger::info);
    logger::log("Found " + std::to_string(g_progress_found) + " / " + std::to_string(g_progress_total) + " patterns.", logger::info);

    // Dump to JSON file
    std::ofstream json_file("offsets.json");
    if (json_file.is_open()) {
        json_file << "{\n";
        for (size_t i = 0; i < results.size(); ++i) {
            json_file << "  \"" << results[i].first << "\": " << results[i].second;
            if (i < results.size() - 1) json_file << ",";
            json_file << "\n";
        }
        json_file << "}\n";
        json_file.close();
        logger::log("Exported -> offsets.json", logger::success);
    }

    // Dump to C++ Header file
    std::ofstream hpp_file("offsets.hpp");
    if (hpp_file.is_open()) {
        hpp_file << "#pragma once\n#include <cstdint>\n\nnamespace offsets {\n";
        for (const auto& result : results) {
            hpp_file << "    constexpr std::ptrdiff_t " << result.first << " = 0x" << std::hex << std::uppercase << result.second << ";\n";
        }
        hpp_file << "}\n";
        hpp_file.close();
        logger::log("Exported -> offsets.hpp", logger::success);
    }

    CloseHandle(process_handle);
    g_is_scanning = false;
}
int APIENTRY wWinMain(HINSTANCE hInstance, HINSTANCE hPrevInstance, PWSTR lpCmdLine, int nCmdShow) {
    WNDCLASSEXW wc = { sizeof(wc), CS_CLASSDC, WndProc, 0L, 0L, hInstance, nullptr, nullptr, nullptr, nullptr, L"FiveMOffsetsDumperV2", nullptr };
    ::RegisterClassExW(&wc);
    // WS_POPUP completely removes the ugly Windows Title Bar
    HWND hwnd = ::CreateWindowW(wc.lpszClassName, L"FiveM Offset Dumper - By jxst_kifoxxxxe", WS_POPUP, 100, 100, 800, 600, nullptr, nullptr, wc.hInstance, nullptr);

    if (!CreateDeviceD3D(hwnd)) {
        CleanupDeviceD3D();
        ::UnregisterClassW(wc.lpszClassName, wc.hInstance);
        return 1;
    }

    ::ShowWindow(hwnd, nCmdShow);
    ::UpdateWindow(hwnd);

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    ImGuiIO& io = ImGui::GetIO(); (void)io;
    io.ConfigFlags |= ImGuiConfigFlags_NavEnableKeyboard;

    // Deep Dark Theme / Black Theme setup
    ImGui::StyleColorsDark();
    ImGuiStyle& style = ImGui::GetStyle();
    
    // Rounding & Smoothness (Everything is now beautifully rounded)
    style.WindowRounding = 12.0f;
    style.ChildRounding = 8.0f;
    style.FrameRounding = 6.0f;
    style.PopupRounding = 6.0f;
    style.ScrollbarRounding = 9.0f;
    style.GrabRounding = 6.0f;
    style.TabRounding = 6.0f;
    
    style.WindowBorderSize = 0.0f; // Remove border for popup
    style.ChildBorderSize = 1.0f;
    style.FrameBorderSize = 0.0f;
    
    // Premium Colors
    static float accent_color[3] = { 0.5f, 0.2f, 1.0f };
    style.Colors[ImGuiCol_WindowBg] = ImVec4(0.04f, 0.04f, 0.04f, 1.00f);
    style.Colors[ImGuiCol_TitleBg] = ImVec4(0.00f, 0.00f, 0.00f, 1.00f);
    style.Colors[ImGuiCol_TitleBgActive] = ImVec4(0.10f, 0.10f, 0.10f, 1.00f);
    style.Colors[ImGuiCol_Button] = ImVec4(0.12f, 0.12f, 0.12f, 1.00f);
    style.Colors[ImGuiCol_ButtonHovered] = ImVec4(0.24f, 0.24f, 0.24f, 1.00f);
    style.Colors[ImGuiCol_ButtonActive] = ImVec4(0.35f, 0.35f, 0.35f, 1.00f);
    style.Colors[ImGuiCol_FrameBg] = ImVec4(0.08f, 0.08f, 0.08f, 1.00f);
    style.Colors[ImGuiCol_FrameBgHovered] = ImVec4(0.13f, 0.13f, 0.13f, 1.00f);
    style.Colors[ImGuiCol_FrameBgActive] = ImVec4(0.16f, 0.16f, 0.16f, 1.00f);
    style.Colors[ImGuiCol_Text] = ImVec4(0.95f, 0.95f, 0.95f, 1.00f);
    style.Colors[ImGuiCol_Separator] = ImVec4(0.15f, 0.15f, 0.15f, 1.00f);
    style.Colors[ImGuiCol_Border] = ImVec4(0.15f, 0.15f, 0.15f, 1.00f);

    ImGui_ImplWin32_Init(hwnd);
    ImGui_ImplDX11_Init(g_pd3dDevice, g_pd3dDeviceContext);

    bool done = false;
    
    static int active_tab = 0;
    static int last_tab = 0;
    static float tab_alpha = 1.0f;
        
    while (!done) {
        MSG msg;
        while (::PeekMessage(&msg, nullptr, 0U, 0U, PM_REMOVE)) {
            ::TranslateMessage(&msg);
            ::DispatchMessage(&msg);
            if (msg.message == WM_QUIT)
                done = true;
        }
        if (done)
            break;

        if (g_ResizeWidth != 0 && g_ResizeHeight != 0) {
            CleanupRenderTarget();
            g_pSwapChain->ResizeBuffers(0, g_ResizeWidth, g_ResizeHeight, DXGI_FORMAT_UNKNOWN, 0);
            g_ResizeWidth = g_ResizeHeight = 0;
            CreateRenderTarget();
        }

        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();

        // -------------------------
        // ImGui Menu Design (Cheat-style)
        // -------------------------
        ImGui::SetNextWindowPos(ImVec2(0, 0));
        ImGui::SetNextWindowSize(io.DisplaySize);
        ImGui::PushStyleVar(ImGuiStyleVar_WindowPadding, ImVec2(0, 0));
        ImGui::Begin("Main Window", nullptr, ImGuiWindowFlags_NoTitleBar | ImGuiWindowFlags_NoResize | ImGuiWindowFlags_NoMove | ImGuiWindowFlags_NoCollapse);
        ImGui::PopStyleVar();

        // Custom Frameless Top Bar
        ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.07f, 0.07f, 0.07f, 1.0f));
        ImGui::BeginChild("TopBar", ImVec2(ImGui::GetWindowWidth(), 50), false);
        
        // Invisible button spanning the top bar allowing native dragging!
        ImGui::SetCursorPos(ImVec2(0, 0));
        // We removed the ReleaseCapture logic here. Dragging is now handled safely by WM_NCHITTEST in WndProc!
        ImGui::InvisibleButton("##DragArea", ImVec2(ImGui::GetWindowWidth() - 50, 50));

        ImGui::SetCursorPos(ImVec2(20, 16));
        ImGui::PushFont(ImGui::GetIO().Fonts->Fonts[0]);
        ImGui::TextColored(ImVec4(1.0f, 1.0f, 1.0f, 1.0f), "999 SERVICES"); // White text
        ImGui::SameLine();
        ImGui::TextColored(ImVec4(0.6f, 0.6f, 0.6f, 1.0f), "|");
        ImGui::SameLine();
        ImGui::Text("FiveM Advanced Offset Dumper v2");
        ImGui::PopFont();
        
        // Custom Close button (X)
        ImGui::SetCursorPos(ImVec2(ImGui::GetWindowWidth() - 40, 12));
        ImGui::PushStyleColor(ImGuiCol_Button, ImVec4(0, 0, 0, 0));
        ImGui::PushStyleColor(ImGuiCol_ButtonHovered, ImVec4(0.9f, 0.2f, 0.2f, 1.0f)); // Red on hover
        ImGui::PushStyleColor(ImGuiCol_ButtonActive, ImVec4(0.7f, 0.1f, 0.1f, 1.0f));
        if (ImGui::Button("X", ImVec2(25, 25))) {
            done = true;
        }
        ImGui::PopStyleColor(3);

        ImGui::EndChild();
        ImGui::PopStyleColor();

        // Sidebar / Tabs
        ImGui::BeginChild("SideBar", ImVec2(160, ImGui::GetWindowHeight() - 50), true);
        ImGui::Spacing();
        
        auto render_tab = [&](const char* label, int index) {
            bool selected = (active_tab == index);
            
            // Custom smooth styling for selected tab
            if (selected) {
                ImGui::PushStyleColor(ImGuiCol_Header, ImVec4(accent_color[0], accent_color[1], accent_color[2], 0.3f));
                ImGui::PushStyleColor(ImGuiCol_HeaderHovered, ImVec4(accent_color[0], accent_color[1], accent_color[2], 0.4f));
                ImGui::PushStyleColor(ImGuiCol_Text, ImVec4(accent_color[0], accent_color[1], accent_color[2], 1.0f));
            }
            
            if (ImGui::Selectable(label, selected, 0, ImVec2(0, 35))) {
                if (active_tab != index) {
                    active_tab = index;
                }
            }
            
            if (selected) {
                ImGui::PopStyleColor(3);
            }
        };

        render_tab("  Scanner", 0);
        render_tab("  Process Info", 1);
        render_tab("  Settings", 2);
        render_tab("  About", 3);
        ImGui::EndChild();
        
        // Smooth tab alpha transition logic
        if (active_tab != last_tab) {
            tab_alpha = 0.0f; // Reset alpha to fade-in
            last_tab = active_tab;
        }
        tab_alpha += (1.0f - tab_alpha) * (15.0f * io.DeltaTime); // Smooth lerp logic
        
        // Main Content Area
        ImGui::SameLine();
        ImGui::PushStyleVar(ImGuiStyleVar_Alpha, tab_alpha);
        ImGui::BeginChild("ContentArea", ImVec2(ImGui::GetWindowWidth() - 180, ImGui::GetWindowHeight() - 70), false);
        ImGui::Spacing();

        if (active_tab == 0) {
            // Scanner Tab
            ImGui::Text("Pattern Scanner");
            ImGui::Separator();
            ImGui::Spacing();

            if (!g_is_scanning) {
                if (ImGui::Button("Start Dump", ImVec2(150, 40))) {
                    g_is_scanning = true;
                    std::thread(perform_scan).detach();
                }
            } else {
                ImGui::BeginDisabled();
                ImGui::Button("Scanning...", ImVec2(150, 40));
                ImGui::EndDisabled();
                
                float progress = (g_progress_total == 0) ? 0.0f : (float)g_progress_found / (float)g_progress_total;
                ImGui::SameLine();
                ImGui::ProgressBar(progress, ImVec2(ImGui::GetContentRegionAvail().x - 20, 40));
            }

            ImGui::Spacing();
            ImGui::Separator();
            ImGui::Text("Console Log:");
            ImGui::Spacing();
            
            ImGui::PushStyleColor(ImGuiCol_ChildBg, ImVec4(0.03f, 0.03f, 0.03f, 1.0f));
            ImGui::BeginChild("LogScrollRegion", ImVec2(0, 0), true, ImGuiWindowFlags_AlwaysVerticalScrollbar);
            std::vector<logger::LogMessage> logs = logger::get_logs();
            for (const auto& logMsg : logs) {
                ImVec4 color = ImVec4(1.0f, 1.0f, 1.0f, 1.0f);
                if (logMsg.type == logger::info) color = ImVec4(0.7f, 0.3f, 1.0f, 1.0f); // Purple info
                else if (logMsg.type == logger::success) color = ImVec4(0.2f, 0.9f, 0.2f, 1.0f); // Green
                else if (logMsg.type == logger::fail) color = ImVec4(0.9f, 0.2f, 0.2f, 1.0f); // Red
                
                ImGui::TextColored(color, "[%s] %s", 
                    (logMsg.type == logger::info) ? "INFO" : (logMsg.type == logger::success) ? " OK " : "FAIL", 
                    logMsg.text.c_str());
            }
            if (ImGui::GetScrollY() >= ImGui::GetScrollMaxY())
                ImGui::SetScrollHereY(1.0f);
            ImGui::EndChild();
            ImGui::PopStyleColor();

        } else if (active_tab == 1) {
            // Process Info Tab
            ImGui::Text("Target Process Information");
            ImGui::Separator();
            ImGui::Spacing();

            HWND window_handle = FindWindowA("grcWindow", NULL);
            if (window_handle) {
                DWORD pid;
                GetWindowThreadProcessId(window_handle, &pid);
                ImGui::Text("Status: ");
                ImGui::SameLine();
                ImGui::TextColored(ImVec4(0.2f, 0.9f, 0.2f, 1.0f), "Found (grcWindow)");
                
                ImGui::Text("Process ID: %lu", pid);
                std::string process_name = process::get_name(pid);
                ImGui::Text("Executable: %s", process_name.c_str());
                ImGui::Text("Base Address: 0x%p", (void*)process::get_base_address(pid));
                ImGui::Text("Module Size: %lu bytes", process::get_module_size(pid));

                ImGui::Spacing();
                ImGui::Separator();
                ImGui::Text("Loaded Modules (First 20):");
                ImGui::BeginChild("ModulesList", ImVec2(0, 0), true);
                auto modules = process::get_modules(pid);
                int count = 0;
                for (const auto& mod : modules) {
                    ImGui::Text("%-30s | Base: 0x%p | Size: %lu", mod.name.c_str(), (void*)mod.base_address, mod.size);
                    if (++count >= 20) break;
                }
                ImGui::EndChild();

            } else {
                ImGui::Text("Status: ");
                ImGui::SameLine();
                ImGui::TextColored(ImVec4(0.9f, 0.2f, 0.2f, 1.0f), "Waiting for FiveM...");
                ImGui::Text("Please launch FiveM before viewing process info.");
            }

        } else if (active_tab == 2) {
            // Settings Tab
            ImGui::Text("Dumper Settings");
            ImGui::Separator();
            ImGui::Spacing();

            static bool export_json = true;
            static bool export_hpp = true;
            ImGui::Checkbox("Export offsets.json", &export_json);
            ImGui::Checkbox("Export offsets.hpp", &export_hpp);
            
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::Text("UI Settings");
            
            if (ImGui::ColorEdit3("Accent Color", accent_color)) {
                style.Colors[ImGuiCol_ButtonActive] = ImVec4(accent_color[0], accent_color[1], accent_color[2], 1.0f);
                style.Colors[ImGuiCol_HeaderActive] = ImVec4(accent_color[0], accent_color[1], accent_color[2], 1.0f);
                style.Colors[ImGuiCol_HeaderHovered] = ImVec4(accent_color[0] * 0.8f, accent_color[1] * 0.8f, accent_color[2] * 0.8f, 1.0f);
            }

        } else if (active_tab == 3) {
            // About Tab
            ImGui::Text("About 999 Services Dumper");
            ImGui::Separator();
            ImGui::Spacing();

            ImGui::Text("Modernized and Optimized by:");
            ImGui::TextColored(ImVec4(accent_color[0], accent_color[1], accent_color[2], 1.0f), "jxst_kifoxxxxe");
            
            ImGui::Spacing();
            ImGui::Text("Discord: https://discord.gg/REWDYEpa7f");
            ImGui::Text("Website: https://999services01.mysellauth.com/");
            
            ImGui::Spacing();
            ImGui::Separator();
            ImGui::TextColored(ImVec4(0.8f, 0.8f, 0.8f, 1.0f), "John 3:16");
            ImGui::TextWrapped("\"For God so loved the world, that he gave his only Son, that whoever believes in him should not perish but have eternal life. Jesus Is King\"");
        }

        ImGui::EndChild();
        ImGui::PopStyleVar(); // pop alpha
        ImGui::End();

        // -------------------------

        ImGui::Render();
        // Match the background clear color to ImGui's WindowBg so there's no sharp corner discrepancy
        const float clear_color_with_alpha[4] = { 0.04f, 0.04f, 0.04f, 1.0f };
        g_pd3dDeviceContext->OMSetRenderTargets(1, &g_mainRenderTargetView, nullptr);
        g_pd3dDeviceContext->ClearRenderTargetView(g_mainRenderTargetView, clear_color_with_alpha);
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());

        g_pSwapChain->Present(1, 0); // Present with vsync
    }

    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();

    CleanupDeviceD3D();
    ::DestroyWindow(hwnd);
    ::UnregisterClassW(wc.lpszClassName, wc.hInstance);

    return 0;
}

bool CreateDeviceD3D(HWND hWnd) {
    DXGI_SWAP_CHAIN_DESC sd;
    ZeroMemory(&sd, sizeof(sd));
    sd.BufferCount = 2;
    sd.BufferDesc.Width = 0;
    sd.BufferDesc.Height = 0;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferDesc.RefreshRate.Numerator = 60;
    sd.BufferDesc.RefreshRate.Denominator = 1;
    sd.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = hWnd;
    sd.SampleDesc.Count = 1;
    sd.SampleDesc.Quality = 0;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;

    UINT createDeviceFlags = 0;
    D3D_FEATURE_LEVEL featureLevel;
    const D3D_FEATURE_LEVEL featureLevelArray[2] = { D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_0, };
    HRESULT res = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, createDeviceFlags, featureLevelArray, 2, D3D11_SDK_VERSION, &sd, &g_pSwapChain, &g_pd3dDevice, &featureLevel, &g_pd3dDeviceContext);
    if (res == DXGI_ERROR_UNSUPPORTED)
        res = D3D11CreateDeviceAndSwapChain(nullptr, D3D_DRIVER_TYPE_WARP, nullptr, createDeviceFlags, featureLevelArray, 2, D3D11_SDK_VERSION, &sd, &g_pSwapChain, &g_pd3dDevice, &featureLevel, &g_pd3dDeviceContext);
    if (res != S_OK)
        return false;

    CreateRenderTarget();
    return true;
}

void CleanupDeviceD3D() {
    CleanupRenderTarget();
    if (g_pSwapChain) { g_pSwapChain->Release(); g_pSwapChain = nullptr; }
    if (g_pd3dDeviceContext) { g_pd3dDeviceContext->Release(); g_pd3dDeviceContext = nullptr; }
    if (g_pd3dDevice) { g_pd3dDevice->Release(); g_pd3dDevice = nullptr; }
}

void CreateRenderTarget() {
    ID3D11Texture2D* pBackBuffer;
    g_pSwapChain->GetBuffer(0, IID_PPV_ARGS(&pBackBuffer));
    g_pd3dDevice->CreateRenderTargetView(pBackBuffer, nullptr, &g_mainRenderTargetView);
    pBackBuffer->Release();
}

void CleanupRenderTarget() {
    if (g_mainRenderTargetView) { g_mainRenderTargetView->Release(); g_mainRenderTargetView = nullptr; }
}

LRESULT WINAPI WndProc(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam) {
    if (ImGui_ImplWin32_WndProcHandler(hWnd, msg, wParam, lParam))
        return true;

    switch (msg) {
    case WM_NCHITTEST: {
        POINT pt;
        pt.x = GET_X_LPARAM(lParam);
        pt.y = GET_Y_LPARAM(lParam);
        ScreenToClient(hWnd, &pt);
        // Top bar is 50px tall, but we exclude the rightmost 50px for the close button
        if (pt.y >= 0 && pt.y < 50 && pt.x >= 0 && pt.x < 800 - 50) {
            return HTCAPTION; // Tells OS to drag the window from this area natively
        }
        break;
    }
    case WM_SIZE:
        if (wParam == SIZE_MINIMIZED)
            return 0;
        g_ResizeWidth = (UINT)LOWORD(lParam); // Queue resize
        g_ResizeHeight = (UINT)HIWORD(lParam);
        return 0;
    case WM_SYSCOMMAND:
        if ((wParam & 0xfff0) == SC_KEYMENU)
            return 0;
        break;
    case WM_DESTROY:
        ::PostQuitMessage(0);
        return 0;
    }
    return ::DefWindowProcW(hWnd, msg, wParam, lParam);
}
