#pragma once
#include <windows.h>
#include <string>
#include <cstdint>
#include <vector>

namespace process {
    /**
     * @brief Retrieves the base address of the main module in the specified process.
     * @param pid Process ID.
     * @return Base address of the primary module (usually the executable), or 0 on failure.
     */
    uintptr_t get_base_address(DWORD pid);

    /**
     * @brief Retrieves the size of the main module in the specified process.
     * @param pid Process ID.
     * @return Size of the module in bytes, or 0 on failure.
     */
    DWORD get_module_size(DWORD pid);

    /**
     * @brief Gets the name of the main executable module for the given process.
     * @param pid Process ID.
     * @return Name of the executable (e.g., "game.exe"), or empty string if failed.
     */
    std::string get_name(DWORD pid);

    struct ModuleInfo {
        std::string name;
        uintptr_t base_address;
        DWORD size;
    };

    /**
     * @brief Gets all modules loaded in the process.
     */
    std::vector<ModuleInfo> get_modules(DWORD pid);
}
// Made By JxstKifoxxxxe Discord: https://discord.gg/REWDYEpa7f Website: https://999services01.mysellauth.com/
//     † John 3:16 "For God so loved the world, that he gave his only Son, that whoever believes in him should not perish but have eternal life. Jesus Is King † 
