#include "process.hpp"
#include <TlHelp32.h>
#include <Psapi.h>

#pragma comment(lib, "Psapi.lib")

namespace process {
    static HANDLE open_process_handle(DWORD pid) {
        return OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, pid);
    }

    static bool enum_modules(HANDLE hProc, HMODULE* modules, DWORD max_bytes, DWORD* bytes_needed) {
        return EnumProcessModules(hProc, modules, max_bytes, bytes_needed) != 0;
    }

    static bool get_module_name(HANDLE hProc, HMODULE hMod, char* buffer, DWORD buffer_size) {
        return GetModuleBaseNameA(hProc, hMod, buffer, buffer_size) > 0;
    }

    uintptr_t get_base_address(DWORD pid) {
        HANDLE hProc = open_process_handle(pid);
        if (!hProc) return 0;

        HMODULE modules[1024];
        DWORD needed = 0;

        if (enum_modules(hProc, modules, sizeof(modules), &needed) && needed >= sizeof(HMODULE)) {
            CloseHandle(hProc);
            return reinterpret_cast<uintptr_t>(modules[0]);
        }

        CloseHandle(hProc);
        return 0;
    }

    DWORD get_module_size(DWORD pid) {
        HANDLE hProc = open_process_handle(pid);
        if (!hProc) return 0;

        HMODULE first_module = nullptr;
        DWORD needed = 0;

        if (enum_modules(hProc, &first_module, sizeof(first_module), &needed)) {
            MODULEINFO modInfo = {0};
            if (GetModuleInformation(hProc, first_module, &modInfo, sizeof(MODULEINFO))) {
                CloseHandle(hProc);
                return modInfo.SizeOfImage;
            }
        }

        CloseHandle(hProc);
        return 0;
    }

    std::string get_name(DWORD pid) {
        HANDLE hProc = open_process_handle(pid);
        if (!hProc) return {};

        HMODULE first_module = nullptr;
        DWORD needed = 0;
        char name_buffer[MAX_PATH] = { 0 };

        if (enum_modules(hProc, &first_module, sizeof(first_module), &needed)) {
            get_module_name(hProc, first_module, name_buffer, sizeof(name_buffer));
        }

        CloseHandle(hProc);
        return std::string(name_buffer);
    }

    std::vector<ModuleInfo> get_modules(DWORD pid) {
        std::vector<ModuleInfo> result;
        HANDLE hProc = open_process_handle(pid);
        if (!hProc) return result;

        HMODULE modules[1024];
        DWORD needed = 0;

        if (enum_modules(hProc, modules, sizeof(modules), &needed)) {
            int count = needed / sizeof(HMODULE);
            for (int i = 0; i < count; i++) {
                char name_buffer[MAX_PATH] = { 0 };
                if (get_module_name(hProc, modules[i], name_buffer, sizeof(name_buffer))) {
                    MODULEINFO modInfo = { 0 };
                    if (GetModuleInformation(hProc, modules[i], &modInfo, sizeof(MODULEINFO))) {
                        result.push_back({ std::string(name_buffer), reinterpret_cast<uintptr_t>(modInfo.lpBaseOfDll), modInfo.SizeOfImage });
                    }
                }
            }
        }

        CloseHandle(hProc);
        return result;
    }
}
// Made By JxstKifoxxxxe Discord: https://discord.gg/REWDYEpa7f Website: https://999services01.mysellauth.com/
//     † John 3:16 "For God so loved the world, that he gave his only Son, that whoever believes in him should not perish but have eternal life. Jesus Is King † 
