#pragma once
#include <windows.h>
#include <iostream>
#include <vector>

class function_hook {
public:
    function_hook(void* target, void* hook) : target_function(target), hook_function(hook), is_hooked(false) {
        original_bytes = new unsigned char[14];
    }

    ~function_hook() {
        if (is_hooked) {
            remove_hook();
        }
        delete[] original_bytes;
    }

    bool install_hook() {
        if (is_hooked) return false;

        DWORD old_protect;
        if (!VirtualProtect(target_function, 14, PAGE_EXECUTE_READWRITE, &old_protect)) {
            std::cerr << "virtualprotect failed: " << GetLastError() << std::endl;
            return false;
        }

        memcpy(original_bytes, target_function, 14);

        *(unsigned char*)target_function = 0x48;
        *((unsigned char*)target_function + 1) = 0xB8;
        *(int64_t*)((unsigned char*)target_function + 2) = (int64_t)hook_function;
        *((unsigned char*)target_function + 10) = 0xFF;
        *((unsigned char*)target_function + 11) = 0xE0;

        if (!VirtualProtect(target_function, 14, old_protect, &old_protect)) {
            std::cerr << "virtualprotect restore failed: " << GetLastError() << std::endl;
            return false;
        }

        is_hooked = true;
        return true;
    }

    void remove_hook() {
        if (!is_hooked) return;

        DWORD old_protect;
        if (VirtualProtect(target_function, 14, PAGE_EXECUTE_READWRITE, &old_protect)) {
            memcpy(target_function, original_bytes, 14);
            if (!VirtualProtect(target_function, 14, old_protect, &old_protect)) {
                MessageBoxA(0, "Failed to restore memory protection", "", MB_OK);
            }
        }
        else {
            MessageBoxA(0, "Failed to restore memory protection 2", "", MB_OK);
        }

        is_hooked = false;
    }

    template<typename FuncType, typename... Args>
    auto call_original(FuncType original_func, Args... args) -> decltype(original_func(args...)) {
        remove_hook();
        auto result = original_func(args...);
        install_hook();
        return result;
    }

private:
    void* target_function;
    void* hook_function;
    unsigned char* original_bytes;
    bool is_hooked;
};

