#include "Resources.h"
#include "Memory.h"
#include <iostream>
#include <fstream>
#include <string>
#include <regex>
#include <mutex>
#include <windows.h>
#include "./Cheat/addr/address.h"
#include "./Main/encrypt/skStr.h"
#include "./Main/Scanner.h"
uint64_t ResourceHandle = (uint64_t)GetModuleHandleA(sk("citizen-resources-core.dll"));
uintptr_t Resources::BaseAddr, Resources::ResourceListEntry, Resources::ResourceScanAddress;
int Resources::chosenResource = -1;
typedef uint64_t(*TerminateResource_t)(uintptr_t pResourcePointer);
TerminateResource_t TerminateResource = nullptr;
uintptr_t fetchPath(uintptr_t address) {
    __try {
        return *(uintptr_t*)(address);
    }
    __except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ? EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        return NULL;
    }
}

char fetchChar(uintptr_t address) {
    __try {
        return *reinterpret_cast<char*>(address);
    }
    __except (GetExceptionCode() == EXCEPTION_ACCESS_VIOLATION ? EXCEPTION_EXECUTE_HANDLER : EXCEPTION_CONTINUE_SEARCH) {
        return NULL;
    }
}
std::string extractString(uintptr_t Addr) {
    const int maxLength = 256;
    char buffer[maxLength] = { 0 };
    int readCount = 0;

    MEMORY_BASIC_INFORMATION mbi;
    if (VirtualQuery(reinterpret_cast<LPCVOID>(Addr), &mbi, sizeof(mbi)) == 0) {
        return "[ERROR]";
    }

    while (readCount < maxLength - 1) {
        char ch = fetchChar(Addr + readCount);
        if (ch == NULL) break;

        buffer[readCount] = ch;
        if (ch == '\0') break;
        readCount++;
    }

    return std::string(buffer);
}

bool offsetsInitialized = false;
bool terminationOffsetsInitialized = false;

void Resources::terminate(uintptr_t ResourcePointer) {
    if (!terminationOffsetsInitialized) {
        TerminateResource = reinterpret_cast<TerminateResource_t>(Scanner::Get()->Scan("citizen-resources-core.dll", "48 83 EC ? C7 81", NULL, NULL));
    }

    HANDLE threadHandle = CreateRemoteThread(GetCurrentProcess(), NULL, 0, (LPTHREAD_START_ROUTINE)TerminateResource, (LPVOID)ResourcePointer, 0, NULL);
    CloseHandle(threadHandle);
}

void Resources::refresh() {
    if (!offsetsInitialized) {

        ResourceScanAddress = Scanner::Get()->Scan("citizen-resources-core.dll", "48 8B 05 ? ? ? ? 48 8D 14 F0", NULL, NULL);
        ResourceListEntry = *(uintptr_t*)(ResourceScanAddress + *(int*)(ResourceScanAddress + 3) + 7);
        offsetsInitialized = true;
    }

    size_t currentListSize = ResourceList.size();
    size_t currentIndex = 0;

    for (size_t i = 0; i < 500; i++) {
        uintptr_t resourcePointer = *(uintptr_t*)(ResourceListEntry + (i * 8U));

        if (!resourcePointer) continue;

        uintptr_t pathPointer = fetchPath(resourcePointer + 0xF0);
        if (!pathPointer) continue;

        std::string fullPath = extractString(pathPointer);
        if (fullPath.empty() || fullPath.find("resources:/") == std::string::npos) continue;

        std::string resourceName = fullPath.substr(11, fullPath.length() - 12);
        uint32_t resourceState = *(uint32_t*)(resourcePointer + 0x118);
        if (resourceState < eResourceState::Uninitialized || resourceState > eResourceState::Stopping) continue;

        resourceStruct resourceEntry;
        resourceEntry.Pointer = resourcePointer;
        resourceEntry.Path = fullPath;
        resourceEntry.Name = resourceName;
        resourceEntry.State = static_cast<eResourceState>(resourceState);

        if (currentIndex < currentListSize) {
            ResourceList[currentIndex] = resourceEntry;
        }
        else {
            ResourceList.push_back(resourceEntry);
        }

        currentIndex++;
    }

    if (currentIndex < currentListSize) ResourceList.resize(currentIndex);
}
