#pragma once

#include "../../../Main/includes/includes.h"

class Core
{
public:
    static Core* Get() {
        if (m_pSingleton == nullptr)
            m_pSingleton = new Core;
        return m_pSingleton;
    }

    static Core* m_pSingleton;

    std::vector<std::string> Friend;

    ImVec2 W2S(Vector3 pos);

    Vector3 BoneVec(const uint64_t ped, int boneid);
    DWORD64 GetCamera();

    float Pythag(const ImVec2& a, const ImVec2& b);
    uint8_t get_owner_id(uint64_t net_object);
    bool set_network_id_can_migrate(uint64_t net_object, bool toggle);
    bool set_network_id_exists_on_all_machines(uint64_t net_object, bool toggle);
    bool network_request_control_of_network_id(uint64_t net_object, uint64_t local_net_object);
    void network_request_control_of_entity(uint64_t entity, uint64_t localplayer);

};


