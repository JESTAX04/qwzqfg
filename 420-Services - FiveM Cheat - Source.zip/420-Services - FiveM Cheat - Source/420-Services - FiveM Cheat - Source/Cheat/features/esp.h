﻿#pragma once
#include "../../Main/includes/includes.h"

class Visuals
{
public:
    void Initialize();
	const char* m_get_weapon_name(DWORD hash)
	{
		const char* dagger = ("dagger");
		const char* bat = ("bat");
		const char* bottle = ("bottle");
		const char* crowbar = ("crow bar");
		const char* unarmed = ("unarmed");
		const char* flashlight = ("flash light");
		const char* golfclub = ("golf club");
		const char* hammer = ("hammer");
		const char* hatchet = ("hatchet");
		const char* knuckle = ("knuckle");
		const char* knife = ("knife");
		const char* machete = ("machete");
		const char* switchblade = ("switch blade");
		const char* nightstick = ("night stick");
		const char* wrench = ("wrench");
		const char* battleaxe = ("battle axe");
		const char* poolcue = ("pool cue");
		const char* pistol = ("pistol");
		const char* pistolmk2 = ("pistol mk2");
		const char* combatpistol = ("combat pistol");
		const char* appistol = ("ap pistol");
		const char* stungun = ("stungun");
		const char* pistol50 = ("pistol 50");
		const char* snspistol = ("sns pistol");
		const char* snspistolmk2 = ("sns pistol mk2");
		const char* heavypistol = ("heavy pistol");
		const char* vintagepistol = ("vintage pistol");
		const char* flaregun = ("flare gun");
		const char* marksmanpistol = ("marksman pistol");
		const char* revolver = ("revolver");
		const char* revolvermk2 = ("revolver mk2");
		static auto doubleaction = ("double action");
		static auto microsmg = ("micro smg");
		static auto smg = ("smg");
		static auto tacticalrifle = ("tactical rifle");
		static auto smgmk2 = ("smg mk2");
		static auto assaultsmg = ("assault smg");
		static auto combatpdw = ("combat pdw");
		static auto machinepistol = ("machine pistol");
		static auto minismg = ("mini smg");
		static auto pumpshotgun = ("pump shotgun");
		static auto pumpshotgun_mk2 = ("pump shotgun mk2");
		static auto sawnoffshotgun = ("sawnoff shotgun");
		static auto assaultshotgun = ("assault shotgun");
		static auto bullpupshotgun = ("bullpup shotgun");
		static auto musket = ("musket");
		static auto heavyshotgun = ("heavy shotgun");
		static auto dbshotgun = ("db shotgun");
		static auto autoshotgun = ("auto shotgun");
		static auto assaultrifle = ("assault rifle");
		static auto assaultrifle_mk2 = ("assault rifle mk2");
		static auto carbinerifle = ("carbine rifle");
		static auto carbinerifle_mk2 = ("carbine rifle mk2");
		static auto advancedrifle = ("advanced rifle");
		static auto specialcarbine = ("special carbine");
		static auto specialcarbine_mk2 = ("special carbine mk2");
		static auto bullpuprifle = ("bullpup rifle");
		static auto bullpuprifle_mk2 = ("bullpup rifle mk2");
		static auto compactrifle = ("compact rifle");
		static auto machine_gun = ("machine gun");
		static auto combatmg = ("combat mg");
		static auto combatmg_mk2 = ("combat mg mk2");
		static auto gusenberg = ("gusenberg");
		static auto sniperrifle = ("sniper rifle");
		static auto heavysniper = ("awp");
		static auto heavysniper_mk2 = ("awp mk2");
		static auto marksmanrifle = ("marksman rifle");
		static auto marksmanrifle_mk2 = ("marksman rifle mk2");
		static auto rpg = ("rpg");
		static auto grenadelauncher = ("grenade launcher");
		static auto grenadelauncher_smoke = ("grenade launcher smoke");
		static auto minigun = ("minigun");
		static auto firework = ("firework");
		static auto railgun = ("railgun");
		static auto hominglauncher = ("homing launcher");
		static auto compactlauncher = ("compact launcher");
		static auto grenade = ("grenade");
		static auto bzgas = ("bzgas");
		static auto smokegrenade = ("smoke grenade");
		static auto flare = ("flare");
		static auto molotov = ("molotov");
		static auto stickybomb = ("sticky bomb");
		static auto proxmine = ("prox mine");
		static auto snowball = ("snowball");
		static auto pipebomb = ("pipe bomb");
		static auto ball = ("ball");
		static auto petrolcan = ("petrol can");
		static auto fireextinguisher = ("fire extinguisher");
		static auto parachute = ("parachute");

		static auto weapon_militaryrifle = ("military rifle");
		static auto weapon_heavyrifle = ("heavy rifle");
		static auto weapon_tacticalrifle = ("tactical rifle");

		static auto weapon_precisionrifle = ("precision rifle");

		static auto weapon_emplauncher = ("compact emp launcher");
		static auto weapon_rayminigun = ("ray minigun");

		switch (hash) {
		case 0xD1D5F52B:
			return tacticalrifle;
			break;
		case 0x92A27487:
			return dagger;
			break;
		case 0x958A4A8F:
			return bat;
			break;
		case 0xF9E6AA4B:
			return bottle;
			break;
		case 0x84BD7BFD:
			return crowbar;
			break;
		case 0xA2719263:
			return unarmed;
			break;
		case 0x8BB05FD7:
			return flashlight;
			break;
		case 0x440E4788:
			return golfclub;
			break;
		case 0x4E875F73:
			return hammer;
			break;
		case 0xF9DCBF2D:
			return hatchet;
			break;
		case 0xD8DF3C3C:
			return knuckle;
			break;
		case 0x99B507EA:
			return knife;
			break;
		case 0xDD5DF8D9:
			return machete;
			break;
		case 0xDFE37640:
			return switchblade;
			break;
		case 0x678B81B1:
			return nightstick;
			break;
		case 0x19044EE0:
			return wrench;
			break;
		case 0xCD274149:
			return battleaxe;
			break;
		case 0x94117305:
			return poolcue;
			break;
		case 0x1B06D571:
			return pistol;
			break;
		case 0xBFE256D4:
			return pistolmk2;
			break;
		case 0x5EF9FEC4:
			return combatpistol;
			break;
		case 0x22D8FE39:
			return appistol;
			break;
		case 0x3656C8C1:
			return stungun;
			break;
		case 0x99AEEB3B:
			return pistol50;
			break;
		case 0xBFD21232:
			return snspistol;
			break;
		case 0x88374054:
			return snspistolmk2;
			break;
		case 0xD205520E:
			return heavypistol;
			break;
		case 0x83839C4:
			return vintagepistol;
			break;
		case 0x47757124:
			return flaregun;
			break;
		case 0xDC4DB296:
			return marksmanpistol;
			break;
		case 0xC1B3C3D1:
			return revolver;
			break;
		case 0xCB96392F:
			return revolvermk2;
			break;
		case 0x97EA20B8:
			return doubleaction;
			break;
		case 0x13532244:
			return microsmg;
			break;
		case 0x2BE6766B:
			return smg;
			break;
		case 0x78A97CD0:
			return smgmk2;
			break;
		case 0xEFE7E2DF:
			return assaultsmg;
			break;
		case 0xA3D4D34:
			return combatpdw;
			break;
		case 0xDB1AA450:
			return machinepistol;
			break;
		case 0xBD248B55:
			return minismg;
			break;
		case 0x1D073A89:
			return pumpshotgun;
			break;
		case 0x555AF99A:
			return pumpshotgun_mk2;
			break;
		case 0x7846A318:
			return sawnoffshotgun;
			break;
		case 0xE284C527:
			return assaultshotgun;
			break;
		case 0x9D61E50F:
			return bullpupshotgun;
			break;
		case 0xA89CB99E:
			return musket;
			break;
		case 0x3AABBBAA:
			return heavyshotgun;
			break;
		case 0xEF951FBB:
			return dbshotgun;
			break;
		case 0x12E82D3D:
			return autoshotgun;
			break;
		case 0xBFEFFF6D:
			return assaultrifle;
			break;
		case 0x394F415C:
			return assaultrifle_mk2;
			break;
		case 0x83BF0278:
			return carbinerifle;
			break;
		case 0xFAD1F1C9:
			return carbinerifle_mk2;
			break;
		case 0xAF113F99:
			return advancedrifle;
			break;
		case 0xC0A3098D:
			return specialcarbine;
			break;
		case 0x969C3D67:
			return specialcarbine_mk2;
			break;
		case 0x7F229F94:
			return bullpuprifle;
			break;
		case 0x84D6FAFD:
			return bullpuprifle_mk2;
			break;
		case 0x624FE830:
			return compactrifle;
			break;
		case 0x9D07F764:
			return machine_gun;
			break;
		case 0x7FD62962:
			return combatmg;
			break;
		case 0xDBBD7280:
			return combatmg_mk2;
			break;
		case 0x61012683:
			return gusenberg;
			break;
		case 0x5FC3C11:
			return sniperrifle;
			break;
		case 0xC472FE2:
			return heavysniper;
			break;
		case 0xA914799:
			return heavysniper_mk2;
			break;
		case 0xC734385A:
			return marksmanrifle;
			break;
		case 0x6A6C02E0:
			return marksmanrifle_mk2;
			break;
		case 0xB1CA77B1:
			return rpg;
			break;
		case 0xA284510B:
			return grenadelauncher;
			break;
		case 0x4DD2DC56:
			return grenadelauncher_smoke;
			break;
		case 0x42BF8A85:
			return minigun;
			break;
		case 0x7F7497E5:
			return firework;
			break;
		case 0x6D544C99:
			return railgun;
			break;
		case 0x63AB0442:
			return hominglauncher;
			break;
		case 0x781FE4A:
			return compactlauncher;
			break;
		case 0x93E220BD:
			return grenade;
			break;
		case 0xA0973D5E:
			return bzgas;
			break;
		case 0xFDBC8A50:
			return smokegrenade;
			break;
		case 0x497FACC3:
			return flare;
			break;
		case 0x24B17070:
			return molotov;
			break;
		case 0x2C3731D9:
			return stickybomb;
			break;
		case 0xAB564B93:
			return proxmine;
			break;
		case 0x787F0BB:
			return snowball;
			break;
		case 0xBA45E8B8:
			return pipebomb;
			break;
		case 0x23C9F95C:
			return ball;
			break;
		case 0x34A67B97:
			return petrolcan;
			break;
		case 0x60EC506:
			return fireextinguisher;
			break;
		case 0xFBAB5776:
			return parachute;
			break;
			return weapon_militaryrifle;
			break;
		case 0xC78D71B4:
			return weapon_heavyrifle;
			break;
		case 0x6E7DDDEC:
			return weapon_precisionrifle;
			break;
		case 0xDB26713A:
			return weapon_emplauncher;
			break;
		case 0xB62D1F67:
			return weapon_rayminigun;
			break;
		default:
			return unarmed;
			break;
		}
	}
};
