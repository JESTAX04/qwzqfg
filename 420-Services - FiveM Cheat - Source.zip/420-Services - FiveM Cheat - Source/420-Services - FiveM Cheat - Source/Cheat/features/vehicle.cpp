#include "vehicle.h"
#include "../addr/address.h"

static inline void sanitize_plate(char* plate) {
    
    int w = 0;
    for (int i = 0; plate[i] && w < 8; ++i) {
        char c = plate[i];
        if (c >= 'a' && c <= 'z') c = char(c - 32);
        
        if ((c >= 'A' && c <= 'Z') || (c >= '0' && c <= '9') || c == ' ') {
            plate[w++] = c;
        }
    }
    plate[w] = '\0';
}

void Vehicle::Initialize()
{
    uint64_t pedfactory = *(uint64_t*)(Address::Get()->m_sPedFactory);

    if (!pedfactory) return;

    uint64_t localplayer = *(uint64_t*)(pedfactory + 0x8);

    if (!localplayer) return;

    uint64_t nav = *(uint64_t*)(localplayer + 0x30);

    if (!nav) return;

    uint64_t vehicle_manager = *(uint64_t*)(localplayer + Address::Get()->m_pVehMgr);

    if (!vehicle_manager) return;

    uint64_t handlingdata = *(uint64_t*)(vehicle_manager + Address::Get()->m_pHandlingData);

   
    if (globals.vehicle.shift_boost)
    {
        if (GetAsyncKeyState(VK_SHIFT) & 0x8000) {

            *(float*)(handlingdata + 0x4C) = (float)globals.vehicle.shift_boost_value;
        }
        else
        {
            *(float*)(handlingdata + 0x4C) = 1;
        }
    }
    if (globals.vehicle.repair)
    {
        
        if (MemoryAddress::repair_vehicle)
        {
            MemoryAddress::repair_vehicle(vehicle_manager);
            if (MemoryAddress::pointer_to_handle) {
                int vehHandle = MemoryAddress::pointer_to_handle((intptr_t)vehicle_manager);
                MemoryAddress::repair_vehicle((uint64_t)vehHandle);
            }
        }
        
        if (Address::Get()->m_pEnghealth)
        {
            *(float*)(vehicle_manager + Address::Get()->m_pEnghealth) = 1000.0f;
        }
        if (Address::Get()->m_pDoorstatus)
        {
            *(uint32_t*)(vehicle_manager + Address::Get()->m_pDoorstatus) = 0u;
        }
        
        *(bool*)(vehicle_manager + 0x189) = true; 
        
        if (MemoryAddress::Set_forward_speed)
        {
            MemoryAddress::Set_forward_speed(vehicle_manager, 0.0f);
        }
        globals.vehicle.repair = false;
    }
    if (globals.vehicle.set_plate)
    {
        globals.vehicle.set_plate = false;
        sanitize_plate(globals.vehicle.plate_text);
        if (MemoryAddress::set_plate)
        {
            int vehHandle = MemoryAddress::pointer_to_handle((intptr_t)vehicle_manager);
            MemoryAddress::set_plate((uint64_t)vehHandle, globals.vehicle.plate_text);
            
            if (MemoryAddress::Set_forward_speed)
                MemoryAddress::Set_forward_speed(vehicle_manager, 0.0f);
        }
    }
    if (globals.vehicle.apply_color_change) {
        uint64_t vehicle_mods = *(uint64_t*)(vehicle_manager + 0x0048);
        uint64_t vehicle_mods_visual = *(uint64_t*)(vehicle_mods + 0x0020);

        *(BYTE*)(vehicle_mods_visual + 0x00A6) = globals.vehicle.primary_vehicle_color.Value.x * 255;
        *(BYTE*)(vehicle_mods_visual + 0x00A5) = globals.vehicle.primary_vehicle_color.Value.y * 255;
        *(BYTE*)(vehicle_mods_visual + 0x00A4) = globals.vehicle.primary_vehicle_color.Value.z * 255;
        *(BYTE*)(vehicle_mods_visual + 0x00A7) = globals.vehicle.primary_vehicle_color.Value.w * 255;

        *(BYTE*)(vehicle_mods_visual + 0x00AA) = globals.vehicle.secondary_vehicle_color.Value.x * 255;
        *(BYTE*)(vehicle_mods_visual + 0x00A9) = globals.vehicle.secondary_vehicle_color.Value.y * 255;
        *(BYTE*)(vehicle_mods_visual + 0x00A8) = globals.vehicle.secondary_vehicle_color.Value.z * 255;
        *(BYTE*)(vehicle_mods_visual + 0x00AB) = globals.vehicle.secondary_vehicle_color.Value.w * 255;

        globals.vehicle.apply_color_change = false;
    }
    if (globals.vehicle.modify_gravity)
    {
        *(float*)(vehicle_manager + Address::Get()->m_pGravity) = (float)globals.vehicle.gravity_value;
    }
    if (globals.vehicle.rocket_boost) {
        uint64_t model_info = *(uint64_t*)(vehicle_manager + 0x20);
        if (!model_info) return;
        *(uint16_t*)(model_info + 0x058B) = 0100;
    }
    if (globals.vehicle.godmode)
    {
        *(bool*)(vehicle_manager + 0x189) = true;
    }
    else
    {
        *(bool*)(vehicle_manager + 0x189) = false;
    }
    
}