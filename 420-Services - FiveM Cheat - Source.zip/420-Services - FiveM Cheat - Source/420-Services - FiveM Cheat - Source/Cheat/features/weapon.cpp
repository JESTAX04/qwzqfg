#include "weapon.h"

static inline bool EnableNoReload(uint64_t weapon_info, bool enable)
{
    if (!weapon_info) return false;
    __try {
        
        *(float*)(weapon_info + Address::Get()->m_pReloadMult) = enable ? 100.0f : 1.0f;
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}

static inline void SetAmmo(uint64_t pedPtr, int ammo)
{
    if (!pedPtr) return;
    
    if (MemoryAddress::SetPedAmmo_addr) {
        __try {
            using SetPedAmmo_t = void(*)(uint64_t,int);
            ((SetPedAmmo_t)MemoryAddress::SetPedAmmo_addr)(pedPtr, ammo);
            return;
        } __except (EXCEPTION_EXECUTE_HANDLER) {}
    }
    
    __try {
        uint64_t inventory = *(uint64_t*)(pedPtr + Address::Get()->m_pWeaponManager - 0x8);
        if (inventory) {
            *(int*)(inventory + 0x18) = ammo;
            *(int*)(inventory + 0x1C) = ammo;
        }
    } __except (EXCEPTION_EXECUTE_HANDLER) {}
}
void GiveWeapon(__int64 ped, __int64 weaponhash) {
	if (MemoryAddress::add_weapon == NULL) return;

	uint64_t world = *(uint64_t*)(Address::Get()->m_sPedFactory);
	uint64_t localplayer = *(uint64_t*)(world + 0x8);
	
	if (localplayer)
	{
		uint64_t inventory = *(uint64_t*)(ped + Address::Get()->m_pWeaponManager - 0x8);
		if (inventory)
		{
			MemoryAddress::add_weapon(inventory, weaponhash);
			if (globals.weapon.spawn_ammo_count > 0) {
				SetAmmo(ped, globals.weapon.spawn_ammo_count);
			}
		}
	}

   

}
void Weapon::Initialize()
{

	if (globals.weapon.weapon_spawn) {
		uint64_t pedfactory = *(uint64_t*)(Address::Get()->m_sPedFactory);

		if (!pedfactory) return;

		__int64 localplayer = *(__int64*)(pedfactory + 0x8);

		if (!localplayer) return;
		switch (globals.weapon.weapon_spawn_index)
		{
		case 0: GiveWeapon(localplayer, 0x92A27487); break;
		case 1: GiveWeapon(localplayer, 0x958A4A8F); break;
		case 2: GiveWeapon(localplayer, 0x99B507EA); break;
		case 3: GiveWeapon(localplayer, 0xDD5DF8D9); break;

		case 4: GiveWeapon(localplayer, 0x1B06D571); break;
		case 5: GiveWeapon(localplayer, 0xBFE256D4); break;
		case 6: GiveWeapon(localplayer, 0x5EF9FEC4); break;
		case 7: GiveWeapon(localplayer, 0x22D8FE39); break;

		case 8: GiveWeapon(localplayer, 0x3656C8C1); break;
		case 9: GiveWeapon(localplayer, 0x99AEEB3B); break;
		case 10: GiveWeapon(localplayer, 0xBFD21232); break;
		case 11: GiveWeapon(localplayer, 0x88374054); break;
		case 12: GiveWeapon(localplayer, 0xD205520E); break;
		case 13: GiveWeapon(localplayer, 0x83839C4); break;
		case 14: GiveWeapon(localplayer, 0x47757124); break;
		case 15: GiveWeapon(localplayer, 0xDC4DB296); break;
		case 16: GiveWeapon(localplayer, 0xC1B3C3D1); break;
		case 17: GiveWeapon(localplayer, 0xCB96392F); break;
		case 18: GiveWeapon(localplayer, 0x97EA20B8); break;
		case 19: GiveWeapon(localplayer, 0x13532244); break;
		case 20: GiveWeapon(localplayer, 0x2BE6766B); break;
		case 21: GiveWeapon(localplayer, 0x78A97CD0); break;

		case 22: GiveWeapon(localplayer, 0xEFE7E2DF); break;
		case 23: GiveWeapon(localplayer, 0xA3D4D34); break;
		case 24: GiveWeapon(localplayer, 0xDB1AA450); break;
		case 25: GiveWeapon(localplayer, 0xBD248B55); break;
		case 26: GiveWeapon(localplayer, 0x1D073A89); break;
		case 27: GiveWeapon(localplayer, 0x555AF99A); break;
		case 28: GiveWeapon(localplayer, 0x7846A318); break;
		case 29: GiveWeapon(localplayer, 0xE284C527); break;
		case 30: GiveWeapon(localplayer, 0x9D61E50F); break;
		case 31: GiveWeapon(localplayer, 0xA89CB99E); break;
		case 32: GiveWeapon(localplayer, 0x3AABBBAA); break;
		case 33: GiveWeapon(localplayer, 0xEF951FBB); break;
		case 34: GiveWeapon(localplayer, 0x12E82D3D); break;
		case 35: GiveWeapon(localplayer, 0xBFEFFF6D); break;
		case 36: GiveWeapon(localplayer, 0x394F415C); break;
		case 37: GiveWeapon(localplayer, 0x83BF0278); break;
		case 38: GiveWeapon(localplayer, 0xFAD1F1C9); break;
		case 39: GiveWeapon(localplayer, 0xAF113F99); break;
		case 40: GiveWeapon(localplayer, 0xC0A3098D); break;
		case 41: GiveWeapon(localplayer, 0x969C3D67); break;
		case 42: GiveWeapon(localplayer, 0x7F229F94); break;
		case 43: GiveWeapon(localplayer, 0x84D6FAFD); break;
		case 44: GiveWeapon(localplayer, 0x624FE830); break;
		case 45: GiveWeapon(localplayer, 0x9D07F764); break;
		case 46: GiveWeapon(localplayer, 0x7FD62962); break;
		case 47: GiveWeapon(localplayer, 0xDBBD7280); break;
		case 48: GiveWeapon(localplayer, 0x61012683); break;

		case 49: GiveWeapon(localplayer, 0x5FC3C11); break;
		case 50: GiveWeapon(localplayer, 0xC472FE2); break;
		case 51: GiveWeapon(localplayer, 0xA914799); break;
		case 52: GiveWeapon(localplayer, 0xC734385A); break;
		case 53: GiveWeapon(localplayer, 0x6A6C02E0); break;
		case 54: GiveWeapon(localplayer, 0xB1CA77B1); break;
		case 55: GiveWeapon(localplayer, 0xA284510B); break;
		case 56: GiveWeapon(localplayer, 0x42BF8A85); break;
		case 57: GiveWeapon(localplayer, 0x7F7497E5); break;
		case 58: GiveWeapon(localplayer, 0x6D544C99); break;

		case 59: GiveWeapon(localplayer, 0x63AB0442); break;
		case 60: GiveWeapon(localplayer, 0x781FE4A); break;
		case 61: GiveWeapon(localplayer, 0x93E220BD); break;
		case 62: GiveWeapon(localplayer, 0xA0973D5E); break;
		case 63: GiveWeapon(localplayer, 0xFDBC8A50); break;
		case 64: GiveWeapon(localplayer, 0x497FACC3); break;
		case 65: GiveWeapon(localplayer, 0x24B17070); break;
		case 66: GiveWeapon(localplayer, 0x2C3731D9); break;
		case 67: GiveWeapon(localplayer, 0xAB564B93); break;
		case 68: GiveWeapon(localplayer, 0x787F0BB); break;

		case 69: GiveWeapon(localplayer, 0xBA45E8B8); break;
		case 70: GiveWeapon(localplayer, 0x23C9F95C); break;

		case 71: GiveWeapon(localplayer, 0x34A67B97); break;
		case 72: GiveWeapon(localplayer, 0x60EC506); break;
		case 73: GiveWeapon(localplayer, 0xFBAB5776); break;

		}
		globals.weapon.weapon_spawn = false;
	}
	if (globals.weapon.weapon_enabled) {
		uint64_t pedfactory = *(uint64_t*)(Address::Get()->m_sPedFactory);

		if (!pedfactory) return;

		uint64_t localplayer = *(uint64_t*)(pedfactory + 0x8);

		if (!localplayer) return;

		uint64_t nav = *(uint64_t*)(localplayer + 0x30);

		if (!nav) return;

		uint64_t weapon_mgr = *(uint64_t*)(localplayer + Address::Get()->m_pWeaponManager);

		if (!weapon_mgr) return;

		uint64_t weapon_info = *(uint64_t*)(weapon_mgr + 0x20);

		if (!weapon_info) return;

		uint64_t playerinfo = *(uint64_t*)(localplayer + Address::Get()->m_pPlayerInfo);
		if (!playerinfo) return;
		
		if (globals.weapon.no_recoil) {
			*(float*)(weapon_info + Address::Get()->m_pRecoil) = 0;
		}

		if (globals.weapon.tp_to_bullet)
		{
			Vector3 impact_coord = *(Vector3*)(weapon_mgr + 0x1B0);
			if (GetAsyncKeyState(VK_LBUTTON) & 0x8000)
			{
				if (impact_coord.is_zero()) return;
				*(Vector3*)(localplayer + 0x90) = Vector3(impact_coord.x, impact_coord.y, impact_coord.z);
				*(Vector3*)(nav + 0x50) = Vector3(impact_coord.x, impact_coord.y, impact_coord.z);
			}
		}
		static Vector3 impact_coord_saved;
		static bool shot_fired;
		if (globals.weapon.bullet_traces)
		{
			if (GetAsyncKeyState(VK_LBUTTON) & 0x8000)
			{
				Vector3 last_impact_coord = *(Vector3*)(weapon_mgr + 0x1B0);
				if (last_impact_coord.x != 0.0f || last_impact_coord.y != 0.0f || last_impact_coord.z != 0.0f)
				{
					impact_coord_saved = last_impact_coord;
					shot_fired = true;
				}
			}
			if (shot_fired)
			{
				ImVec2 start_pos = Core::Get()->W2S(*(Vector3*)(localplayer + 0x90));
				ImVec2 end_pos = Core::Get()->W2S(impact_coord_saved);
				Graphics::Get()->DrawLine(start_pos, end_pos, globals.weapon.bullet_traces_col, 1.0f);
			}
		}
		if (globals.weapon.no_spread) {
			*(float*)(weapon_info + Address::Get()->m_pSpread) = 0;
		}

		if (globals.weapon.no_reload) {
			EnableNoReload(weapon_info, true);
		} else {
			EnableNoReload(weapon_info, false);
		}

		if (globals.weapon.damage_boost) {
			*(float*)(weapon_info + 0xB0) = globals.weapon.weapon_damage;
		}

		if (globals.weapon.range_multiplier) {
			*(float*)(weapon_info + Address::Get()->m_pRange) = globals.weapon.weapon_range;
		}

		
		uint64_t inv = 0;
		__try { inv = *(uint64_t*)(localplayer + Address::Get()->m_pWeaponManager - 0x8); } __except(EXCEPTION_EXECUTE_HANDLER) { inv = 0; }
		if (inv) {
			bool lockAmmo = (globals.weapon.freeze_ammo || globals.weapon.infinite_ammo);
			__try {
				BYTE v = *(BYTE*)(inv + 0x78);
				if (lockAmmo) v |= 2; else v &= ~2;
				*(BYTE*)(inv + 0x78) = v;
			} __except(EXCEPTION_EXECUTE_HANDLER) {}
		}

		if (globals.weapon.explosiveammo)
		{
			*(uint32_t*)(playerinfo + Address::Get()->m_pFrameFlags) = 1 << 11;
		}
		if (globals.weapon.fire_ammo)
		{
			*(uint32_t*)(playerinfo + Address::Get()->m_pFrameFlags) = 1 << 12;
		}

	}

}