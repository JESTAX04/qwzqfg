﻿#pragma once

#include "../../Main/includes/includes.h"


struct TeleportLocation {
    const char* name;
    float x, y, z;
};


extern const TeleportLocation g_TeleportLocations[];
extern const int g_TeleportLocationsCount;


Vector3 GetWaypointCoords();


void ReviveLocalPlayer();


void SafeWriteVec3(uint64_t address, const Vector3& v);

class Self {
public:
    void Initialize();
    void Freecam();

private:
    bool wasnoclip = false;
};

