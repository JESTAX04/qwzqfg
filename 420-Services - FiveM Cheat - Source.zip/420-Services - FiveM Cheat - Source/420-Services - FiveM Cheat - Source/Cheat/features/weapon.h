#pragma once
#include "../../Main/includes/includes.h"

class Weapon
{
public:
    void Initialize();
};
