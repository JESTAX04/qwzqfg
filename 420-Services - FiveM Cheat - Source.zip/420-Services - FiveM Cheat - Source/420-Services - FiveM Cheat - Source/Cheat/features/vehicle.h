#pragma once
#include "../../Main/includes/includes.h"

class Vehicle
{
public:
    void Initialize();

};
