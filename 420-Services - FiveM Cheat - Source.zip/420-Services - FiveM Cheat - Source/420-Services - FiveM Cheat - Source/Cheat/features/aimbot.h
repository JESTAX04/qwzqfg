#pragma once

#include "../../Main/includes/includes.h"

class Aimbot {
public:
    void SetAngles(Vector3 targetpoint);
    void SetAnglesInstant(Vector3 targetpoint);
    void Initialize();
    uint64_t GetEntity();
    Vector3 GetHitbox(uint64_t entity);
};