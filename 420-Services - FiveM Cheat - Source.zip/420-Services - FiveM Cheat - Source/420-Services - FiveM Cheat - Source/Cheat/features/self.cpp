#include "self.h"
#include "../gta/core/core.h"
#include <mutex>
#include <cmath>
#include "../../Main/includes/globals.h"
#include "../addr/address.h"

#include "../../hook.hpp"


const TeleportLocation g_TeleportLocations[] = {
	
	{ "Strip Club DJ Booth",        126.135f,   -1278.583f,  29.270f },
	{ "Blaine County Savings Bank", -109.299f,   6464.035f,  31.627f },
	{ "Police Station",             436.491f,   -982.172f,  30.699f },
	{ "Humane Labs Entrance",      3619.749f,   2742.740f,  28.690f },
	{ "Burnt FIB Building",        160.868f,    -745.831f, 250.063f },
	{ "North Yankton Bank",       5309.519f,  -5212.375f,  83.522f },
	{ "10 Car Garage Back Room",   223.193f,    -967.322f,  99.000f },
	{ "Humane Labs Tunnel",       3525.495f,   3705.301f,  20.992f },
	{ "Ammunation Office",         12.494f,   -1110.130f,  29.797f },
	{ "Ammunation Gun Range",      22.153f,   -1072.854f,  29.797f },
	{ "Trevor's Meth Lab",        1391.773f,   3608.716f,  38.942f },

	
	{ "Pacific Standard Bank Vault",  255.851f,  217.030f, 101.683f },
	{ "Lester's House",             1273.898f, -1719.304f,  54.771f },
	{ "Floyd's Apartment",         -1150.703f, -1520.713f,  10.633f },
	{ "FIB Top Floor",               135.733f,  -749.216f, 258.152f },
	{ "IAA Office",                  117.220f,  -620.938f, 206.047f },

	
	{ "Fort Zancudo ATC Entrance",  -2344.373f,  3267.498f,  32.811f },
	{ "Fort Zancudo ATC Top Floor", -2358.132f,  3249.754f, 101.451f },
	{ "Damaged Hospital",            356.822f,   -590.151f,  43.315f },
	{ "Slaughterhouse",             -80.557f,   6220.006f,  31.090f },
	{ "County Coroner/Morgue",      243.351f,  -1376.014f,  39.534f },
	{ "Torture Room",               136.515f,  -2203.149f,   7.309f },
	{ "O'Neil Ranch",              2441.216f,  4968.585f,  51.707f },

	
	{ "Main LS Customs",            -365.425f,  -131.809f,  37.873f },
	{ "Yacht",                     -2023.661f, -1038.038f,   5.577f },
	{ "Carrier (MP Only)",          3069.330f, -4704.220f,  15.043f },
	{ "Fort Zancudo UFO",           2052.000f,  3237.000f, 1456.973f },
	{ "Very High Up",              -129.964f,  8130.873f, 6705.307f },
	{ "IAA Roof",                   134.085f,   -637.859f, 262.851f },
	{ "FIB Roof",                   150.126f,   -754.591f, 262.865f },
	{ "Maze Bank Roof",             -75.015f,   -818.215f, 326.176f },
	{ "Top of Mt. Chilliad",        450.718f,   5566.614f, 806.183f },
	{ "Most Northerly Point",        24.775f,   7644.102f,  19.055f },
	{ "Vinewood Bowl Stage",        686.245f,   577.950f, 130.461f },
	{ "Sisyphus Theater Stage",     205.316f,  1167.378f, 227.005f },
	{ "Director Mod Trailer",       -20.004f,    -10.889f, 500.602f },
	{ "Galileo Observatory Roof",  -438.804f,  1076.097f, 352.411f },
	{ "Kortz Center",             -2243.810f,   264.048f, 174.615f },
	{ "Chumash Historic Pier",    -3426.683f,   967.738f,   8.347f },
	{ "Paleto Bay Pier",          -275.522f,  6635.835f,   7.425f },
	{ "God's Thumb",             -1006.402f,  6272.383f,   1.503f },
	{ "Calafia Train Bridge",     -517.869f,  4425.284f,  89.795f },
	{ "Altruist Cult Camp",      -1170.841f,  4926.646f, 224.295f },
	{ "Maze Bank Arena Roof",    -324.300f,  -1968.545f,  67.002f },
	{ "Marlowe Vineyards",       -1868.971f,  2095.674f, 139.115f },
	{ "Hippy Camp",              2476.712f,  3789.645f,  41.226f },
	{ "Devin Weston's House",   -2639.872f,  1866.812f, 160.135f },
	{ "Abandon Mine",           -595.342f,  2086.008f, 131.412f },
	{ "Weed Farm",             2208.777f,  5578.235f,  53.735f },
	{ "Stab City",              126.975f,  3714.419f,  46.827f },
	{ "Airplane Graveyard Tail",2395.096f,  3049.616f,  60.053f },
	{ "Satellite Dish Antenna",2034.988f,  2953.105f,  74.602f },
	{ "Satellite Dishes",      2062.123f,  2942.055f,  47.431f },
	{ "Windmill Top",          2026.677f,  1842.684f, 133.313f },
	{ "Sandy Shores Crane",    1051.209f,  2280.452f,  89.727f },
	{ "Rebel Radio",            736.153f,  2583.143f,  79.634f },
	{ "Quarry",               2954.196f,  2783.410f,  41.004f },
	{ "Power Station Chimney",2732.931f,  1577.540f,  83.671f },
	{ "Merryweather Dock",      486.417f, -3339.692f,   6.070f },
	{ "Cargo Ship",             899.678f, -2882.191f,  19.013f },
	{ "Del Perro Pier",       -1850.127f,-1231.751f,  13.017f },
	{ "Play Boy Mansion",     -1475.234f,  167.088f,  55.841f },
	{ "Jolene Ghost",         3059.620f,  5564.246f, 197.091f },
	{ "NOOSE Headquarters",   2535.243f,  -383.799f,  92.993f },
	{ "Snowman",              971.245f, -1620.993f,  30.111f },
	{ "Oriental Theater",     293.089f,   180.466f, 104.301f },
	{ "Beach Skatepark",     -1374.881f,-1398.835f,   6.141f },
	{ "Underpass Skatepark",  718.341f,-1218.714f,  26.014f },
	{ "Casino",               924.369f,    47.037f,  81.093f },
	{ "University of San Andreas", -1696.866f, 142.747f, 64.372f },
	{ "La Puerta Freeway Bridge", -543.932f, -2225.543f, 122.366f },
	{ "Land Act Dam",        1660.369f,   -12.013f, 170.020f },
	{ "Mount Gordo",        2877.633f,  5911.078f, 369.624f },
	{ "Little Seoul",       -889.655f,  -853.499f,  20.566f },
	{ "Epsilon Building",   -695.025f,    82.955f,  55.855f },
	{ "The Richman Hotel", -1330.911f,   340.871f,  64.078f },
	{ "Vinewood Sign",       711.362f,  1198.134f, 348.526f },
	{ "LS Golf Club",      -1336.715f,    59.051f,  55.246f },
	{ "Chicken",            -31.010f,  6316.830f,  40.083f },
	{ "Little Portola",    -635.463f,  -242.402f,  38.175f },
	{ "Pacific Bluffs CC", -3022.222f,    39.968f,  13.611f },
	{ "Vinewood Cemetery",-1659993.000f, -128.399f,  59.954f },
	{ "Paleto Forest Chimney",-549.467f, 5308.221f, 114.146f },
	{ "Mirror Park",       1070.206f,  -711.958f,  58.483f },
	{ "Rocket",            1608.698f,  6438.096f,  37.637f },
	{ "El Gordo Lighthouse",3430.155f, 5174.196f,  41.280f },
	{ "Mile High Club",    -144.274f,  -946.813f, 269.135f },

	
	{ "Clubhouse 1",       1107.040f, -3157.399f, -37.519f },
	{ "Clubhouse 2",        998.481f, -3164.711f, -38.907f },
	{ "Warehouse 1",       1009.500f, -3196.600f, -38.997f },
	{ "Warehouse 2",       1051.491f, -3196.536f, -39.148f },
	{ "Warehouse 3",       1093.600f, -3196.600f, -38.998f },
	{ "Warehouse 4",       1121.897f, -3195.338f, -40.403f },
	{ "Warehouse 5",       1165.000f, -3196.600f, -39.013f },
	{ "Warehouse Small",   1094.988f, -3101.776f, -39.004f },
	{ "Warehouse Medium",  1056.486f, -3105.724f, -39.004f },
	{ "Warehouse Large",   1006.967f, -3102.079f, -39.004f },
	{ "Car Garage (IMP)",   994.593f, -3002.594f, -39.647f },

	
	{ "Carwash",             55.700f,  -1391.300f,  30.500f },
	{ "Garage in La Mesa",  970.275f, -1826.570f,  31.115f },
	{ "Red Hill Valley Church",-282.464f, 2835.840f,  55.914f },
	{ "Lost's Trailer Park",  49.494f,  3744.472f,  46.386f },
	{ "Lost Clubhouse",     984.155f,   -95.366f,  74.500f },
	{ "Pillbox Hospital",   307.168f,  -590.807f,  43.280f },
	{ "PDM (Car Dealer)",   -54.300f, -1109.377f,  26.436f },
	{ "Remove Zancudo Gates",-1599.950f, 2807.050f, 17.204f },
	{ "Ferris Wheel",     -1645.550f, -1113.040f, 12.650f },
	{ "Casino Penthouse",  968.156f,    0.306f, 111.292f },
	{ "Golf Flags",      -1032.000f,   -84.000f,  44.000f },
	{ "Racetrack",        1978.000f,  3111.000f,  46.000f },

	
	{ "2 Car Garage",      173.290f, -1003.600f, -99.657f },
	{ "6 Car Garage",      197.815f, -1002.293f, -99.657f },
	{ "10 Car Garage",     229.956f,  -981.793f, -99.661f },

	
	{ "Low End Apartment", 261.459f,  -998.820f, -99.009f },
	{ "4 Integrity Apt 28", -18.079f,  -583.673f,  79.466f },
	{ "4 Integrity Apt 30", -35.313f,  -580.420f,  88.712f },
	{ "Del Perro Apt 4",  -1468.140f,  -541.815f,  73.444f },
	{ "Del Perro Apt 7",  -1477.140f,  -538.750f,  55.526f },
	{ "Richard Majestic Apt 2", -915.811f, -379.432f, 113.675f },
	{ "Tinsel Apt 42",    -614.860f,    40.678f,  97.600f },
	{ "Eclipse Apt 3",    -773.407f,   341.766f, 211.397f },
	{ "3655 Wild Oats Dr", -169.286f,   486.494f, 137.444f },
	{ "2044 North Conker", 340.941f,   437.180f, 149.393f },
	{ "2045 North Conker", 373.023f,   416.105f, 145.701f },
	{ "2862 Hillcrest",   -676.127f,   588.612f, 145.170f },
	{ "2868 Hillcrest",   -763.107f,   615.906f, 144.140f },
	{ "2874 Hillcrest",   -857.798f,   682.563f, 152.653f },
	{ "2677 Whispymound",  120.500f,   549.952f, 184.097f },
	{ "2133 Mad Wayne",   -1288.000f,   440.748f,  97.695f },

	
	{ "Bunker Interior",   899.552f, -3246.038f, -98.049f },
	{ "CharCreator",       402.516f, -1002.847f, -99.259f },
	{ "Mission Carpark",   405.923f,  -954.115f, -99.663f },
	{ "Solomon's Office", -1005.840f,  -478.920f,  50.027f },
	{ "Psychiatrist Office",-1908.024f, -573.424f,  19.097f },
	{ "Omega's Garage",   2331.344f,  2574.073f,  46.681f },
	{ "Movie Theatre",    -1427.299f, -245.101f,  16.804f },
	{ "Motel",            152.261f,  -1004.471f, -98.999f },
	{ "Madrazos Ranch",   1399.996f,  1147.235f, 115.321f },
	{ "Life Invader Office",-1044.193f,-236.954f,  37.965f },
	{ "FBI Floor 47",      134.584f,  -766.486f, 234.152f },
	{ "FBI Floor 49",      134.635f,  -765.831f, 242.152f },
};

const int g_TeleportLocationsCount = sizeof(g_TeleportLocations) / sizeof(TeleportLocation);


Vector3 g_noclip_target_pos = Vector3(0.f, 0.f, 0.f);
bool g_noclip_request = false;


static Vector3 g_spectate_origin = Vector3(0.f, 0.f, 0.f);
static bool g_spectate_has_origin = false;


static inline bool Safe_SetEntityCoordsNoOffset(uint64_t entity, float x, float y, float z, bool alive, bool deadFlag, bool ragdollFlag, bool clearArea)
{
    if (!MemoryAddress::SetEntityCoordsNoOffset) return false;
    __try {
        MemoryAddress::SetEntityCoordsNoOffset(entity, x, y, z, alive, deadFlag, ragdollFlag, clearArea);
        return true;
    }
    __except (EXCEPTION_EXECUTE_HANDLER) {
        MemoryAddress::SetEntityCoordsNoOffset = nullptr;
        return false;
    }
}


void SafeWriteVec3(uint64_t address, const Vector3& v)
{
    if (!address) return;
    __try {
        *(Vector3*)(address) = v;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        
    }
}


static inline bool IsValidEntityPtr(uint64_t entity)
{
    if (!entity) return false;
    __try {
        (void)*(uint64_t*)(entity + 0x20); 
        (void)*(float*)(entity + 0x90);    
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}


static inline bool SafeReadVec3(uint64_t address, Vector3& out)
{
    if (!address) return false;
    __try {
        out = *(Vector3*)(address);
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
}


Vector3 GetWaypointCoords()
{
    Vector3 coords = Vector3(0.0f, 0.0f, 0.0f);
    if (MemoryAddress::WayPointRead == 0) return coords;
    __try {
        float x = *(float*)(MemoryAddress::WayPointRead + 0x0);
        float y = *(float*)(MemoryAddress::WayPointRead + 0x4);
        
        if (fabsf(x) < 0.001f && fabsf(y) < 0.001f) return coords;
        
        uint64_t pedfactory = *(uint64_t*)(Address::Get()->m_sPedFactory);
        uint64_t localplayer = pedfactory ? *(uint64_t*)(pedfactory + 0x8) : 0;
        float z = 0.0f;
        if (localplayer) {
            __try { z = *(float*)(localplayer + 0x98); }
            __except (EXCEPTION_EXECUTE_HANDLER) { z = 0.0f; }
        }
        coords = Vector3(x, y, z);
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        
    }
    return coords;
}

void ReviveLocalPlayer()
{
    uint64_t pedfactory = *(uint64_t*)(Address::Get()->m_sPedFactory);
    uint64_t localplayer = pedfactory ? *(uint64_t*)(pedfactory + 0x8) : 0;
    if (!localplayer) return;
    
    __try {
        float maxH = 200.0f;
        *(float*)(localplayer + 0x280) = maxH;
    } __except (EXCEPTION_EXECUTE_HANDLER) {}
    
    __try {
        float x = *(float*)(localplayer + 0x90);
        float y = *(float*)(localplayer + 0x94);
        float z = *(float*)(localplayer + 0x98);
        Safe_SetEntityCoordsNoOffset(localplayer, x, y, z + 0.15f, true, false, false, true);
    } __except (EXCEPTION_EXECUTE_HANDLER) {}
    
    if (MemoryAddress::ClearPedBlood_addr) {
        __try {
            using ClearPedBlood_t = void(*)(uint64_t);
            ((ClearPedBlood_t)MemoryAddress::ClearPedBlood_addr)(localplayer);
        } __except (EXCEPTION_EXECUTE_HANDLER) {}
    }
}


bool ExecuteWaypointLua(Vector3& outCoords)
{
    
    
    return false;
}
























void Self::Initialize() {
    uint64_t pedfactory = *(uint64_t*)(Address::Get()->m_sPedFactory);

    if (!pedfactory) return;

    uint64_t localplayer = *(uint64_t*)(pedfactory + 0x8);

    if (!localplayer) return;

    
    if (GetAsyncKeyState(globals.self.hotkey_noclip.key) & 1) {
        globals.self.noclip = !globals.self.noclip;
    }

    
    if (GetAsyncKeyState(globals.self.freecam_key.key) & 1) {
        globals.self.freecam = !globals.self.freecam;
    }

    
    if (globals.self.invisible_key.key && (GetAsyncKeyState(globals.self.invisible_key.key) & 1)) {
        globals.self.Invisible = !globals.self.Invisible;
    }
    
    if (globals.self.revive_key.key && (GetAsyncKeyState(globals.self.revive_key.key) & 1)) {
        
        
        globals.self.revive_request = true;
    }
    
    if (globals.self.desync_key.key && (GetAsyncKeyState(globals.self.desync_key.key) & 1)) {
        globals.self.desync = !globals.self.desync;
    }

    uint64_t nav = *(uint64_t*)(localplayer + 0x30);

    if (globals.self.nocol && nav) {
        DWORD64 addr1 = (DWORD64)nav;
        if (addr1) {
            DWORD64 addr2 = *(DWORD64*)(addr1 + 0x10);
            if (addr2) {
                DWORD64 addr3 = *(DWORD64*)(addr2 + 0x20);
                if (addr3) {
                    DWORD64 addr4 = *(DWORD64*)(addr3 + 0x70);
                    if (addr4) {
                        DWORD64 addr5 = *(DWORD64*)(addr4 + 0x0);
                        if (addr5) {
                            *(float*)(addr5 + 0x2C) = -1.0f;
                        }
                    }
                }
            }
        }
    }

    
    if (globals.self.super_jump) {
        uint64_t playerinfo = *(uint64_t*)(localplayer + Address::Get()->m_pPlayerInfo);
        if (playerinfo) {
            *(uint32_t*)(playerinfo + Address::Get()->m_pFrameFlags) = 1 << 14;
        }
    }

    if (globals.self.beast_jump) {
        uint64_t playerinfo = *(uint64_t*)(localplayer + Address::Get()->m_pPlayerInfo);
        if (playerinfo) {
            *(uint32_t*)(playerinfo + Address::Get()->m_pFrameFlags) = 1 << 28;
        }
    }

    if (globals.self.godmode)
    {
        *(BYTE*)(localplayer + 0x189) = 1;
    }
    else
    {
        *(BYTE*)(localplayer + 0x189) = 0;
    }

    
    if (globals.self.Invisible) {
        
        uint64_t playerinfo__inv = *(uint64_t*)(localplayer + Address::Get()->m_pPlayerInfo);
        if (playerinfo__inv) {
            uint32_t* cfg = (uint32_t*)(playerinfo__inv + Address::Get()->m_pConfigFlags);
            if (cfg) {
                *cfg |= (1u << 2);
            }
        }
        
        __try {
            uint64_t model_info = *(uint64_t*)(localplayer + 0x20);
            if (model_info) *(float*)(model_info + 0x2C) = 0.f;
        } __except(EXCEPTION_EXECUTE_HANDLER) {}
        
        __try {
            uint64_t veh = *(uint64_t*)(localplayer + Address::Get()->m_pVehMgr);
            if (veh) {
                uint64_t vmi = *(uint64_t*)(veh + 0x20);
                if (vmi) *(float*)(vmi + 0x2C) = 0.f;
            }
        } __except(EXCEPTION_EXECUTE_HANDLER) {}
    } else {
        
        uint64_t playerinfo__inv = *(uint64_t*)(localplayer + Address::Get()->m_pPlayerInfo);
        if (playerinfo__inv) {
            uint32_t* cfg = (uint32_t*)(playerinfo__inv + Address::Get()->m_pConfigFlags);
            if (cfg) {
                *cfg &= ~(1u << 2);
            }
        }
        __try {
            uint64_t model_info = *(uint64_t*)(localplayer + 0x20);
            if (model_info) *(float*)(model_info + 0x2C) = 1.f;
        } __except(EXCEPTION_EXECUTE_HANDLER) {}
        __try {
            uint64_t veh = *(uint64_t*)(localplayer + Address::Get()->m_pVehMgr);
            if (veh) {
                uint64_t vmi = *(uint64_t*)(veh + 0x20);
                if (vmi) *(float*)(vmi + 0x2C) = 1.f;
            }
        } __except(EXCEPTION_EXECUTE_HANDLER) {}
    }

    
    if (globals.self.revive_request) {
        
        
        __try {
            float* health = (float*)(localplayer + 0x280);
            if (health && *health < 200.0f) {
                *health = 200.0f;
            }
        } __except(EXCEPTION_EXECUTE_HANDLER) {}
        globals.self.revive_request = false;
    }

    
    if (globals.self.desync) {
        if (Address::Get()->m_pVelocity) {
            SafeWriteVec3(localplayer + Address::Get()->m_pVelocity, Vector3(0.f, 0.f, 0.f));
        }
        uint64_t playerinfo__ds = *(uint64_t*)(localplayer + Address::Get()->m_pPlayerInfo);
        if (playerinfo__ds) {
            uint32_t* cfg = (uint32_t*)(playerinfo__ds + Address::Get()->m_pConfigFlags);
            if (cfg) {
                *cfg |= (1u << 5); 
            }
        }
    } else {
        uint64_t playerinfo__ds = *(uint64_t*)(localplayer + Address::Get()->m_pPlayerInfo);
        if (playerinfo__ds) {
            uint32_t* cfg = (uint32_t*)(playerinfo__ds + Address::Get()->m_pConfigFlags);
            if (cfg) {
                *cfg &= ~(1u << 5);
            }
        }
    }
    if (globals.self.semigodmode)
    {
        auto maxhealth = *(float*)(localplayer + 0x280);
        if (maxhealth < 200)
        {
            *(float*)(localplayer + 0x280) = 200;
        }
    }
    if (globals.self.custom_altitude)
    {
        DWORD64 cam = Core::Get()->GetCamera();
        if (cam)
        {
            uint64_t cam_data = *(uint64_t*)(cam + 0x10);
            if (*(float*)(cam_data + 0x88) != globals.self.custom_altitude_value)
                *(float*)(cam_data + 0x88) = globals.self.custom_altitude_value;
        }
    }
    if (globals.self.custom_fov)
    {
        DWORD64 cam = Core::Get()->GetCamera();
        if (cam)
        {
            uint64_t cam_data = *(uint64_t*)(cam + 0x10);
            *(float*)(cam_data + 0x30) = globals.self.custom_fov_value;
        }
    }




     
    if (globals.self.noclip) {
        DWORD64 cambase = Core::Get()->GetCamera();
        if (cambase) {
            
            Vector3 ActualPos = *(Vector3*)(localplayer + 0x90);
            
            
            uint64_t vehicle_manager = *(uint64_t*)(localplayer + Address::Get()->m_pVehMgr);
            if (vehicle_manager) {
                return; 
            }
            
            
            float health = *(float*)(localplayer + 0x280);
            if (health < 100) {
                return; 
            }
            
            
            float noclip_speed_multiplier = 0.1f; 
            if (GetAsyncKeyState(VK_LSHIFT) & 0x8000) {
                noclip_speed_multiplier = 1.0f; 
            }
            
            
            uint64_t nav_nc = *(uint64_t*)(localplayer + 0x30);
            if (nav_nc) {
                *(float*)(nav_nc + 0x30) = 1; 
            }
            
            
            Vector3 TPSangles = *(Vector3*)(cambase + 0x3D0);
            if (TPSangles.is_zero()) {
                TPSangles = *(Vector3*)(cambase + 0x40);
            }
            
            Vector3 newpos = ActualPos;
            float speed_step = globals.self.noclip_speed * noclip_speed_multiplier * 0.1f;
            
            
            if (GetAsyncKeyState(0x57) & 0x8000) { 
                newpos.x += (TPSangles.x * speed_step);
                newpos.y += (TPSangles.y * speed_step);
                newpos.z += (TPSangles.z * speed_step);
            }
            if (GetAsyncKeyState(0x53) & 0x8000) { 
                newpos.x -= (TPSangles.x * speed_step);
                newpos.y -= (TPSangles.y * speed_step);
                newpos.z -= (TPSangles.z * speed_step);
            }
            if (GetAsyncKeyState(0x41) & 0x8000) { 
                newpos.x -= (TPSangles.y * speed_step);
                newpos.y += (TPSangles.x * speed_step);
            }
            if (GetAsyncKeyState(0x44) & 0x8000) { 
                newpos.x += (TPSangles.y * speed_step);
                newpos.y -= (TPSangles.x * speed_step);
            }
            if (GetAsyncKeyState(VK_SPACE) & 0x8000) { 
                newpos.z += speed_step;
            }
            if (GetAsyncKeyState(VK_CONTROL) & 0x8000) { 
                newpos.z -= speed_step;
            }
            
            
            float lerpAmount = 0.5f;
            Vector3 finalPos = ActualPos + ((newpos - ActualPos) * lerpAmount);
            
            
            SafeWriteVec3(localplayer + 0x90, finalPos);
            SafeWriteVec3(localplayer + 0x320, finalPos); 
            
            if (nav_nc) {
                SafeWriteVec3(nav_nc + 0x50, finalPos);
            }
            
            
            if (Address::Get()->m_pVelocity) {
                SafeWriteVec3(localplayer + Address::Get()->m_pVelocity, Vector3(0.f, 0.f, 0.f));
            }
            
            
            uint64_t model_info = *(uint64_t*)(localplayer + 0x20);
            if (model_info) {
                *(float*)(model_info + 0x2C) = 0.f; 
            }
            
            
            SafeWriteVec3(cambase + 0x60, finalPos);
            
            
            static int control_refresh = 0;
            if ((++control_refresh % 15) == 0) {
                Core::Get()->network_request_control_of_entity(localplayer, localplayer);
            }
            
            
            __try {
                uint8_t* ped_task = (uint8_t*)(localplayer + Address::Get()->m_pPedTask);
                if (ped_task) {
                    *ped_task |= (1 << 7);
                }
            } __except(EXCEPTION_EXECUTE_HANDLER) {}
            
            
            __try {
                uint64_t playerinfo = *(uint64_t*)(localplayer + Address::Get()->m_pPlayerInfo);
                if (playerinfo) {
                    uint32_t* frame_flags = (uint32_t*)(playerinfo + Address::Get()->m_pFrameFlags);
                    if (frame_flags) {
                        *frame_flags |= (1 << 9);
                    }
                }
            } __except(EXCEPTION_EXECUTE_HANDLER) {}
            
            
            g_noclip_target_pos = finalPos;
        }
        
        if (!wasnoclip) {
            
            uint64_t model_info = *(uint64_t*)(localplayer + 0x20);
            if (model_info) {
                *(float*)(model_info + 0x2C) = 0.f;
            }
            
            
            uint64_t playerinfo = *(uint64_t*)(localplayer + Address::Get()->m_pPlayerInfo);
            if (playerinfo) {
                uint32_t* cfg = (uint32_t*)(playerinfo + Address::Get()->m_pConfigFlags);
                if (cfg) {
                    *cfg |= (1u << 0) | (1u << 1) | (1u << 3); 
                }
            }
            
            
            globals.self.freecam = false;
            wasnoclip = true;
        }
    }
    else if (wasnoclip) {
        __try {
            uint64_t model_info_restore = *(uint64_t*)(localplayer + 0x20);
            if (model_info_restore) *(float*)(model_info_restore + 0x2C) = 1.f;
        } __except(EXCEPTION_EXECUTE_HANDLER) {}
        
        __try {
            uint64_t veh_restore = *(uint64_t*)(localplayer + Address::Get()->m_pVehMgr);
            if (veh_restore) {
                uint64_t vmi = *(uint64_t*)(veh_restore + 0x20);
                if (vmi) *(float*)(vmi + 0x2C) = 1.f;
            }
        } __except(EXCEPTION_EXECUTE_HANDLER) {}
        
        __try {
            uint8_t* ped_task = (uint8_t*)(localplayer + Address::Get()->m_pPedTask);
            if (ped_task) {
                *ped_task &= ~(1 << 7);
            }
        } __except(EXCEPTION_EXECUTE_HANDLER) {}
        
        uint64_t playerinfo = *(uint64_t*)(localplayer + Address::Get()->m_pPlayerInfo);
        if (playerinfo) {
            uint32_t* cfg = (uint32_t*)(playerinfo + Address::Get()->m_pConfigFlags);
            if (cfg) {
                *cfg &= ~((1u << 0) | (1u << 1) | (1u << 3));
            }
            
            __try {
                uint32_t* frame_flags = (uint32_t*)(playerinfo + Address::Get()->m_pFrameFlags);
                if (frame_flags) {
                    *frame_flags &= ~(1 << 9);
                }
            } __except(EXCEPTION_EXECUTE_HANDLER) {}
        }
        
        __try {
            uint64_t nav_nc = *(uint64_t*)(localplayer + 0x30);
            if (nav_nc) {
                uint64_t a1 = nav_nc;
                uint64_t a2 = *(uint64_t*)(a1 + 0x10);
                if (a2) {
                    uint64_t a3 = *(uint64_t*)(a2 + 0x20);
                    if (a3) {
                        uint64_t a4 = *(uint64_t*)(a3 + 0x70);
                        if (a4) {
                            uint64_t a5 = *(uint64_t*)(a4 + 0x0);
                            if (a5) *(float*)(a5 + 0x2C) = 1.0f;
                        }
                    }
                }
            }
        } __except(EXCEPTION_EXECUTE_HANDLER) {}
        wasnoclip = false;
    }
}
enum e_types : uint32_t { PED = 0, VEHICLE = 1, NONE = 2 };
struct m_freecam_target {
	Vector3 v_origin{};
	Vector2 v_s_origin{};
	uint32_t m_type{ NONE };
	float m_pixel_distance{ 0.0f };
	float m_distance{ 0.0f };
	uint64_t m_pointer{ 0 };
	int m_network_id{ -1 };
};
m_freecam_target freecam_target{};
static bool was_on = false;
static int iteration_count = 0;
static bool un_nop_needed = true;


static Vector3 last_freecam_position;
void Self::Freecam() {

    auto last_key_press_time = std::chrono::steady_clock::now();

    uint64_t pedfactory = *(uint64_t*)(Address::Get()->m_sPedFactory);
    uint64_t localplayer = *(uint64_t*)(pedfactory + 0x8);
    if (!localplayer) return;

    uint64_t base = *(uint64_t*)(__readgsqword(0x60) + 0x10);
    if (Address::Get()->freecam_nop == 0) {
        Address::Get()->freecam_nop = Scanner::Get()->Scan(NULL, "f3 0f 11 47 ? f3 0f 10 44 24 ? f3 0f 11 4f ? f3 0f 10 4c 24 ? f3 0f 11 47 ? f3 0f 11 4f ? e8", NULL, NULL) - base;
    }

    uint64_t offset_nop = Address::Get()->freecam_nop;
    BYTE nop_array[5] = { 0x90, 0x90, 0x90, 0x90, 0x90 };
    BYTE un_nop_array_x[5] = { 0xF3, 0x0F, 0x11, 0x47, 0x60 };
    BYTE un_nop_array_y[5] = { 0xF3, 0x0F, 0x11, 0x4F, 0x64 };
    BYTE un_nop_array_z[5] = { 0xF3, 0x0F, 0x11, 0x47, 0x68 };

    uintptr_t model_info = *(uintptr_t*)(localplayer + 0x20);
    freecam_target.m_type = NONE;

    c_key freecam_key = globals.self.freecam_key;;

    if (globals.self.freecam) {

        if (model_info) *(float*)(model_info + 0x2C) = 0.f;
        float m_closest_distance = FLT_MAX;

        auto current_time = std::chrono::steady_clock::now();
        auto time_since_last_press = std::chrono::duration_cast<std::chrono::milliseconds>(current_time - last_key_press_time).count();

        static bool last_spectate = false;
        if (globals.self.spectate && !last_spectate) {
            
            if (*(Vector3*)(localplayer + 0x90) != Vector3(0.f,0.f,0.f)) {
                g_spectate_origin = *(Vector3*)(localplayer + 0x90);
                g_spectate_has_origin = true;
            }
        }
        if (!globals.self.spectate && last_spectate) {
            
            g_spectate_has_origin = false;
        }
        last_spectate = globals.self.spectate;

        
        if (globals.self.spectate && g_spectate_has_origin) {
            *(Vector3*)(localplayer + 0x90) = g_spectate_origin;
            *(Vector3*)(localplayer + 0x320) = g_spectate_origin; 
            
        }

        
        DWORD64 cambase = Core::Get()->GetCamera();
        if (globals.self.spectate && globals.self.spectate_target) {
            
            Vector3 head_pos = Core::Get()->BoneVec(globals.self.spectate_target, 128);
            if (head_pos.is_zero(1e-5f)) {
                Vector3 base_pos = *(Vector3*)(globals.self.spectate_target + 0x90);
                head_pos = base_pos + Vector3(0.f, 0.f, 1.0f);
            }
            Vector3 desired_cam = head_pos + Vector3(0.f, 0.f, 0.35f);

            
            Vector3 cam_pos = *(Vector3*)(cambase + 0x60);
            float lerp = 0.35f;
            Vector3 new_cam_pos{
                cam_pos.x + (desired_cam.x - cam_pos.x) * lerp,
                cam_pos.y + (desired_cam.y - cam_pos.y) * lerp,
                cam_pos.z + (desired_cam.z - cam_pos.z) * lerp
            };

            *(Vector3*)(cambase + 0x60) = new_cam_pos;
            

            
        } else {
        


        if (GetAsyncKeyState(0x45)) {
            last_key_press_time = current_time;
            switch (freecam_target.m_type) {
            case VEHICLE:
                Core::Get()->network_request_control_of_entity(freecam_target.m_pointer, localplayer);

                uint64_t vehicle_manager = *(uint64_t*)(freecam_target.m_pointer + Address::Get()->m_pVehMgr);

                break;
            }
        }

        if (GetAsyncKeyState(0x48)) {
            last_key_press_time = current_time;
            switch (freecam_target.m_type) {
            case VEHICLE:
                break;
            }
        }


        if (iteration_count % 1000 == 0) {
            BYTE current_nop_x[5];
            BYTE current_nop_y[5];
            BYTE current_nop_z[5];
            memcpy(current_nop_x, (void*)(base + offset_nop), 5);
            memcpy(current_nop_y, (void*)(base + offset_nop + 0xB), 5);
            memcpy(current_nop_z, (void*)(base + offset_nop + 0x16), 5);

            un_nop_needed = !(memcmp(current_nop_x, un_nop_array_x, 5) == 0 &&
                memcmp(current_nop_y, un_nop_array_y, 5) == 0 &&
                memcmp(current_nop_z, un_nop_array_z, 5) == 0);
        }

        if (un_nop_needed) {
            memcpy((void*)(base + offset_nop), nop_array, 5);
            memcpy((void*)(base + offset_nop + 0xB), nop_array, 5);
            memcpy((void*)(base + offset_nop + 0x16), nop_array, 5);
        }

        cambase = Core::Get()->GetCamera();

        Vector3 new_pos = *(Vector3*)(cambase + 0x60);
        Vector3 cameradirection = *(Vector3*)(cambase + 0x03D0);
        Vector3 angles = *(Vector3*)(cambase + 0x3D0);

        if (angles.is_zero()) {
            angles = *(Vector3*)(cambase + 0x40);
        }

        
        
        float speed_step = (float)globals.self.freecam_speed; 
        float cam_speed = (speed_step * speed_step) * 0.02f; 

        if (GetAsyncKeyState(0x57)) {
            new_pos.y += angles.y * cam_speed;
            new_pos.x += angles.x * cam_speed;
            new_pos.z += angles.z * cam_speed;
        }

        if (GetAsyncKeyState(0x53)) {
            new_pos.y -= angles.y * cam_speed;
            new_pos.x -= angles.x * cam_speed;
            new_pos.z -= angles.z * cam_speed;
        }

        if (GetAsyncKeyState(0x41)) {
            new_pos.y += angles.x * cam_speed;
            new_pos.x -= angles.y * cam_speed;
        }

        if (GetAsyncKeyState(0x44)) {
            new_pos.y -= angles.x * cam_speed;
            new_pos.x += angles.y * cam_speed;
        }

        *(Vector3*)(cambase + 0x60) = new_pos;
        
        last_freecam_position = new_pos;
        
        if (!globals.self.spectate) *(Vector3*)(localplayer + 0x320) = new_pos;

        }
        

        
         
    }
    else {
        
        if (was_on && globals.self.freecam_teleport_on_disable) {
            
            Vector3 target = last_freecam_position;
            if (!(target.x == 0.f && target.y == 0.f && target.z == 0.f)) {
                float tx = target.x;
                float ty = target.y;
                float tz = target.z + 0.35f; 
                if (!Safe_SetEntityCoordsNoOffset(localplayer, tx, ty, tz, true, false, false, true)) {
                    
                    SafeWriteVec3(localplayer + 0x90, Vector3(tx, ty, tz));
                    SafeWriteVec3(localplayer + 0x320, Vector3(tx, ty, tz));
                    uint64_t navptr = 0; __try { navptr = *(uint64_t*)(localplayer + 0x30); } __except(EXCEPTION_EXECUTE_HANDLER) { navptr = 0; }
                    if (navptr) SafeWriteVec3(navptr + 0x50, Vector3(tx, ty, tz));
                }
                
                if (Address::Get()->m_pVelocity) {
                    SafeWriteVec3(localplayer + Address::Get()->m_pVelocity, Vector3(0.f, 0.f, 0.f));
                }
            }
        }
        if (model_info) *(float*)(model_info + 0x2C) = 1.f;

        if (un_nop_needed) {
            memcpy((void*)(base + offset_nop), un_nop_array_x, 5);
            memcpy((void*)(base + offset_nop + 0xB), un_nop_array_y, 5);
            memcpy((void*)(base + offset_nop + 0x16), un_nop_array_z, 5);
        }
    }




    iteration_count++;
    
    was_on = globals.self.freecam;
}

