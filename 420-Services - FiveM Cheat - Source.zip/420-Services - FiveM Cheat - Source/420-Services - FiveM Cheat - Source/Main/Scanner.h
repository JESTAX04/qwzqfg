#pragma once

#include "includes/includes.h"
#define BaseAddShift 0x13000

class Scanner
{
public:
    static Scanner* Get() {
        static Scanner* m_pSingleton = nullptr;
        if (m_pSingleton == nullptr)
            m_pSingleton = new Scanner;
        return m_pSingleton;
    }

    uint64_t resolverelativeaddress(uint64_t Address, int InstructionLength) {
        if (!Address) return 0;
        DWORD Offset = *(DWORD*)(Address + (InstructionLength - 4));
        return Address + InstructionLength + Offset;
    }

    uint64_t ReturnScan(uint64_t pModuleBaseAddress, const char* sSignature, size_t nSelectResultIndex)
    {
        static auto patternToByte = [](const char* pattern) {
            auto bytes = std::vector<int>{};
            const auto start = const_cast<char*>(pattern);
            const auto end = const_cast<char*>(pattern) + strlen(pattern);

            for (auto current = start; current < end; ++current) {
                if (*current == '?') {
                    ++current;
                    if (*current == '?')
                        ++current;
                    bytes.push_back(-1);
                }
                else
                    bytes.push_back(strtoul((const char*)current, &current, 16));
            }
            return bytes;
            };

        const auto dosHeader = (PIMAGE_DOS_HEADER)pModuleBaseAddress;
        const auto ntHeaders = (PIMAGE_NT_HEADERS)((std::uint8_t*)pModuleBaseAddress + dosHeader->e_lfanew);

        const auto sizeOfImage = ntHeaders->OptionalHeader.SizeOfImage;
        auto patternBytes = patternToByte(sSignature);
        const auto scanBytes = (uint8_t*)(pModuleBaseAddress);

        const auto size = patternBytes.size();
        const auto data = patternBytes.data();

        MEMORY_BASIC_INFORMATION mbi;
        size_t nFoundResults = 0;
        uint8_t* currentAddr = (uint8_t*)(pModuleBaseAddress);
        uint8_t* endAddr = currentAddr + ((PIMAGE_NT_HEADERS)((std::uint8_t*)pModuleBaseAddress + ((PIMAGE_DOS_HEADER)pModuleBaseAddress)->e_lfanew))->OptionalHeader.SizeOfImage;

        while (currentAddr < endAddr) {
            if (!VirtualQueryEx((HANDLE)-1, currentAddr, &mbi, sizeof(mbi))) {
                break;
            }

            if (mbi.Protect != PAGE_NOACCESS && !(mbi.Protect & PAGE_GUARD)) {
                const auto scanBytes = (uint8_t*)(mbi.BaseAddress);
                const auto regionSize = mbi.RegionSize;

                for (size_t i = 0; i < regionSize - size; ++i) {
                    bool found = true;

                    for (size_t j = 0; j < size; ++j) {
                        if (scanBytes[i + j] != data[j] && data[j] != -1) {
                            found = false;
                            break;
                        }
                    }

                    if (found) {
                        if (nSelectResultIndex != 0) {
                            if (nFoundResults < nSelectResultIndex) {
                                nFoundResults++;
                                found = false;
                            }
                            else {
                                DWORD oldProtection;
                                VirtualProtectEx((HANDLE)-1, (LPVOID)&currentAddr[i], size, PAGE_EXECUTE_READWRITE, &oldProtection);
                                uint64_t result = (uint64_t)(&currentAddr[i]);
                                VirtualProtectEx((HANDLE)-1, (LPVOID)&currentAddr[i], size, oldProtection, &oldProtection);
                                return result;
                            }
                        }
                        else {
                            DWORD oldProtection;
                            VirtualProtectEx((HANDLE)-1, (LPVOID)&currentAddr[i], size, PAGE_EXECUTE_READWRITE, &oldProtection);
                            uint64_t result = (uint64_t)(&currentAddr[i]);
                            VirtualProtectEx((HANDLE)-1, (LPVOID)&currentAddr[i], size, oldProtection, &oldProtection);
                            return result;
                        }
                    }
                }
            }

            currentAddr = (uint8_t*)(mbi.BaseAddress) + mbi.RegionSize;
        }

        return NULL;
    }

    uint64_t Scan(const char* szModuleName, const char* sSignature, size_t nSelectResultIndex, int InstructionLength) {
        auto ret = ReturnScan((uint64_t)GetModuleHandleA(szModuleName), sSignature, nSelectResultIndex);
        if (InstructionLength != 0) {
            ret = resolverelativeaddress(ret, InstructionLength);
        }




        return ret;
    }

    uintptr_t resolvePtr(const char* szModuleName, int64_t targetValue, BYTE compareByte) {
        uintptr_t baseaddy = (uintptr_t)GetModuleHandleA(szModuleName);
        const auto dosHeader = (PIMAGE_DOS_HEADER)baseaddy;
        const auto ntHeaders = (PIMAGE_NT_HEADERS)((std::uint8_t*)baseaddy + dosHeader->e_lfanew);
        const auto sizeOfImage = ntHeaders->OptionalHeader.SizeOfImage;

        int64_t currentAddress = baseaddy + BaseAddShift;

        while (currentAddress < baseaddy + sizeOfImage) {
            auto cp = *(int64_t*)currentAddress;
            if (cp == targetValue) {
                if (*(BYTE*)cp == compareByte)
                    return currentAddress;
            }
            currentAddress++;
        }

        return NULL;
    }
};