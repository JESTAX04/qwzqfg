













#pragma once




































































/*
#define IM_VEC2_CLASS_EXTRA                                                     \
        constexpr ImVec2(const MyVec2& f) : x(f.x), y(f.y) {}                   \
        operator MyVec2() const { return MyVec2(x,y); }

#define IM_VEC4_CLASS_EXTRA                                                     \
        constexpr ImVec4(const MyVec4& f) : x(f.x), y(f.y), z(f.z), w(f.w) {}   \
        operator MyVec4() const { return MyVec4(x,y,z,w); }
*/






















/*
namespace ImGui
{
    void MyFunction(const char* name, const MyMatrix44& v);
}
*/

#define IMGUI_ENABLE_FREETYPE

inline const char* KEY_NAMES[] = {
    "NONE",
    "M1",
    "M2",
    "CN",
    "M3",
    "M4",
    "M5",
    "NONE",
    "BACK",
    "TAB",
    "NONE",
    "NONE",
    "BACK",
    "ENT",
    "NONE",
    "NONE",
    "SHIFT",
    "CTRL",
    "ALT",
    "PAUSE",
    "CAPS",
    "KAN",
    "NONE",
    "JUN",
    "FIN",
    "KAN",
    "NONE",
    "ESC",
    "CON",
    "NCO",
    "ACC",
    "MAD",
    "SPACE",
    "PGU",
    "PGD",
    "END",
    "HOME",
    "LEFT",
    "UP",
    "RIGH",
    "DOWN",
    "SEL",
    "PRINT",
    "EXE",
    "PRINT",
    "INS",
    "DEL",
    "HEL",
    "0",
    "1",
    "2",
    "3",
    "4",
    "5",
    "6",
    "7",
    "8",
    "9",
    "???",
    "NONE",
    "NONE",
    "NONE",
    "NONE",
    "NONE",
    "NONE",
    "A",
    "B",
    "C",
    "D",
    "E",
    "F",
    "G",
    "H",
    "I",
    "J",
    "K",
    "L",
    "M",
    "N",
    "O",
    "P",
    "Q",
    "R",
    "S",
    "T",
    "U",
    "V",
    "W",
    "X",
    "Y",
    "Z",
    "WIN",
    "WIN",
    "APP",
    "NONE",
    "SLE",
    "NUM0",
    "NUM1",
    "NUM2",
    "NUM3",
    "NUM4",
    "NUM5",
    "NUM6",
    "NUM7",
    "NUM8",
    "NUM9",
    "*",
    "+",
    "|",
    "-",
    ".",
    "/",
    "F1",
    "F2",
    "F3",
    "F4",
    "F5",
    "F6",
    "F7",
    "F8",
    "F9",
    "F10",
    "F11",
    "F12",
    "F13",
    "F14",
    "F15",
    "F16",
    "F17",
    "F18",
    "F19",
    "F20",
    "F21",
    "F22",
    "F23",
    "F24",
    "NONE",
    "NONE",
    "NONE",
    "NONE",
    "NONE",
    "NONE",
    "NONE",
    "NONE",
    "NUMLOCK",
    "SCR",
    "=",
    "MAS",
    "TOY",
    "OYA",
    "OYA",
    "NONE",
    "NONE",
    "NONE",
    "NONE",
    "NONE",
    "NONE",
    "NONE",
    "NONE",
    "NONE",
    "SHIFT",
    "SHIFT",
    "CTRL",
    "CTRL",
    "ALT",
    "ALT"
};

class c_key {
public:
    int key = 0;
    int mode = 0;
};