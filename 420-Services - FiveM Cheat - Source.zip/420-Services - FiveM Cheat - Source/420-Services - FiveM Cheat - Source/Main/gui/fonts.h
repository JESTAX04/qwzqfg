#pragma once
#include "font.h"

class c_font {
private:
	unsigned char* data;
	size_t data_size;
	std::unordered_map< float, ImFont* > fonts;
public:
	std::vector< float > should_init = { };

	void init( float sz ) {
		auto config = ImFontConfig( );
		config.FontDataOwnedByAtlas = false;

		fonts.insert( { sz, ImGui::GetIO( ).Fonts->AddFontFromMemoryTTF( data, data_size, sz, &config, ImGui::GetIO( ).Fonts->GetGlyphRangesCyrillic( ) ) } );
	}

	ImFont* get( float sz ) {
		auto it = fonts.find( sz );

		if ( it == fonts.end( ) ) {
			if ( std::find( should_init.begin( ), should_init.end( ), sz ) == should_init.end( ) )
				should_init.emplace_back( sz );

			return nullptr;
		}

		return it->second;
	}

	void set_data( unsigned char* bytes, size_t size ) {
		delete[] data;

        data = new unsigned char[size];
        std::memcpy(data, bytes, size);

        data_size = size;
	}
};