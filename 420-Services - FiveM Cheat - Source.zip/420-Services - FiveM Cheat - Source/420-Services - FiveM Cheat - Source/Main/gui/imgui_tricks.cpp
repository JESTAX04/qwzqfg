#include "imgui_tricks.hpp"

namespace ImTricks {
	namespace NotifyManager {

		std::vector<NotifyStruct> notifies;

		void AddNotify(const char* message, NotifyState state, notify_pos pos) {
			notifies.push_back({ message, state, GetTickCount64() + 6000, pos });
		}

		void HandleNotifies(ImDrawList* draw) {

			if (notifies.empty())
				return;

			const auto ScreenSize = ImGui::GetIO().DisplaySize;
			ImVec2 tl_pos{ 20, 20 };
			ImVec2 tr_pos{ ScreenSize.x - 20, 20 };
			ImVec2 br_pos{ ScreenSize.x - 20, ScreenSize.y - 20 };
			ImVec2 bl_pos{ 20, ScreenSize.y - 20 };

			auto DrawNotify = [&draw, &tl_pos, &tr_pos, &br_pos, &bl_pos](NotifyStruct notify) {
				float alpha = ( ( 6000 - ( notify.time - GetTickCount64( ) ) ) * 6 ) / 6000.f < 4.f ? ( ( 6000 - ( notify.time - GetTickCount64( ) ) ) * 6 ) / 2000.f : ( ( notify.time - GetTickCount64( ) ) * 6 ) / 2000.f;

				const char* messages[] = {
					"SUCCESS",
					"ERROR",
					"INFO"
				};

				ImColor colors[] = {
					{ 194, 130, 55, int( 255 * ImClamp( alpha, 0.f, 1.f ) ) },
					{ 194, 55, 55, int( 255 * ImClamp( alpha, 0.f, 1.f ) ) },
					{ 55, 86, 194, int( 255 * ImClamp( alpha, 0.f, 1.f ) ) },
				};

				ImVec2 size{ 300, 37 + ImGui::CalcTextSize( messages[notify.state] ).y + ImGui::CalcTextSize( notify.message ).y };

				ImVec2 pos[] = {
					tl_pos,
					{ tr_pos.x - size.x, tr_pos.y },
					br_pos - size, 
					{ bl_pos.x, bl_pos.y - size.y }
				};

				ImVec2 start_pos = pos[notify.pos];
				ImVec2 end_pos = start_pos + size;

				draw->AddRectFilled( start_pos, end_pos, ImGui::GetColorU32( ImGuiCol_FrameBg, ImClamp( alpha, 0.f, 1.f ) ) );
				draw->AddRectFilled( start_pos, { start_pos.x + 1, end_pos.y }, colors[notify.state] );

				draw->AddText( start_pos + ImVec2{ 16, 14 }, ImGui::GetColorU32( ImGuiCol_Text, ImClamp( alpha, 0.f, 1.f ) ), messages[notify.state] );
				draw->AddText( start_pos + ImVec2{ 16, end_pos.y - start_pos.y - 14 - ImGui::CalcTextSize( notify.message ).y }, ImGui::GetColorU32( ImGuiCol_TextDisabled, ImClamp( alpha, 0.f, 1.f ) ), notify.message );

				if ( notify.pos == notify_tl ) tl_pos.y += 10.f + 37 + ImGui::CalcTextSize( messages[notify.state] ).y + ImGui::CalcTextSize( notify.message ).y;
				if ( notify.pos == notify_tr ) tr_pos.y += 10.f + 37 + ImGui::CalcTextSize( messages[notify.state] ).y + ImGui::CalcTextSize( notify.message ).y;
				if ( notify.pos == notify_br ) br_pos.y -= 10.f + 37 + ImGui::CalcTextSize( messages[notify.state] ).y + ImGui::CalcTextSize( notify.message ).y;
				if ( notify.pos == notify_bl ) bl_pos.y -= 10.f + 37 + ImGui::CalcTextSize( messages[notify.state] ).y + ImGui::CalcTextSize( notify.message ).y;
			};

			for (int i = 0; i < notifies.size(); i++)
			{
				auto current_notify = notifies.at(i);
				if (current_notify.time < GetTickCount64())
				{
					notifies.erase(notifies.begin() + i);
					continue;
				}
				DrawNotify(current_notify);            
			}
		}
	}

	namespace Widgets {
		void ColorEdit3(const char* label, ImColor& color, ImGuiColorEditFlags flags) {
			float col[3] = { color.Value.x, color.Value.y, color.Value.z };

			if (ImGui::ColorEdit3(label, col, flags))
				color = ImColor(col[0], col[1], col[2]);
		}

		void ColorEdit4(const char* label, ImColor& color, ImGuiColorEditFlags flags) {
			float col[4] = { color.Value.x, color.Value.y, color.Value.z , color.Value.w };

			if (ImGui::ColorEdit4(label, col, flags))
				color = ImColor(col[0], col[1], col[2], col[3]);
		}

		void ColorEdit3(const char* label, ImTrickyColor& color, ImGuiColorEditFlags flags) {
			float col[3] = { color[0], color[1], color[2] };

			if (ImGui::ColorEdit3(label, col, flags))
				color = ImTrickyColor(col[0], col[1], col[2]);
		}

		void ColorEdit4(const char* label, ImTrickyColor& color, ImGuiColorEditFlags flags) {
			float col[4] = { color[0], color[1], color[2] , color[3] };

			if (ImGui::ColorEdit4(label, col, flags))
				color = ImTrickyColor(col[0], col[1], col[2], col[3]);
		}
	}

	namespace DrawList {
		/*
		// The original author of the code is nathanvoglsam
		// https://github.com/nathanvoglsam
		*/
		void AddConvexPolyFilledGradient(ImDrawList* draw, const ImVec2* points, const ImTrickyColor* col, const int points_count)
		{
			const ImVec2 uv = draw->_Data->TexUvWhitePixel;

			if (draw->Flags & ImDrawListFlags_AntiAliasedFill)
			{
				
				const float AA_SIZE = 1.0f;
				const int idx_count = (points_count - 2) * 3 + points_count * 6;
				const int vtx_count = (points_count * 2);
				draw->PrimReserve(idx_count, vtx_count);

				
				unsigned int vtx_inner_idx = draw->_VtxCurrentIdx;
				unsigned int vtx_outer_idx = draw->_VtxCurrentIdx + 1;
				for (int i = 2; i < points_count; i++)
				{
					draw->_IdxWritePtr[0] = (ImDrawIdx)(vtx_inner_idx); draw->_IdxWritePtr[1] = (ImDrawIdx)(vtx_inner_idx + ((i - 1) << 1)); draw->_IdxWritePtr[2] = (ImDrawIdx)(vtx_inner_idx + (i << 1));
					draw->_IdxWritePtr += 3;
				}

				
				ImVec2* temp_normals = (ImVec2*)alloca(points_count * sizeof(ImVec2));
				for (int i0 = points_count - 1, i1 = 0; i1 < points_count; i0 = i1++)
				{
					const ImVec2& p0 = points[i0];
					const ImVec2& p1 = points[i1];
					ImVec2 diff = p1 - p0;
					diff *= ImInvLength(diff, 1.0f);
					temp_normals[i0].x = diff.y;
					temp_normals[i0].y = -diff.x;
				}

				for (int i0 = points_count - 1, i1 = 0; i1 < points_count; i0 = i1++)
				{
					
					const ImVec2& n0 = temp_normals[i0];
					const ImVec2& n1 = temp_normals[i1];
					ImVec2 dm = (n0 + n1) * 0.5f;
					float dmr2 = dm.x * dm.x + dm.y * dm.y;
					if (dmr2 > 0.000001f)
					{
						float scale = 1.0f / dmr2;
						if (scale > 100.0f) scale = 100.0f;
						dm *= scale;
					}
					dm *= AA_SIZE * 0.5f;

					
					draw->_VtxWritePtr[0].pos = (points[i1] - dm); draw->_VtxWritePtr[0].uv = uv; draw->_VtxWritePtr[0].col = col[i1];        
					draw->_VtxWritePtr[1].pos = (points[i1] + dm); draw->_VtxWritePtr[1].uv = uv; draw->_VtxWritePtr[1].col = col[i1] & ~IM_COL32_A_MASK;  
					draw->_VtxWritePtr += 2;

					
					draw->_IdxWritePtr[0] = (ImDrawIdx)(vtx_inner_idx + (i1 << 1)); draw->_IdxWritePtr[1] = (ImDrawIdx)(vtx_inner_idx + (i0 << 1)); draw->_IdxWritePtr[2] = (ImDrawIdx)(vtx_outer_idx + (i0 << 1));
					draw->_IdxWritePtr[3] = (ImDrawIdx)(vtx_outer_idx + (i0 << 1)); draw->_IdxWritePtr[4] = (ImDrawIdx)(vtx_outer_idx + (i1 << 1)); draw->_IdxWritePtr[5] = (ImDrawIdx)(vtx_inner_idx + (i1 << 1));
					draw->_IdxWritePtr += 6;
				}
				draw->_VtxCurrentIdx += (ImDrawIdx)vtx_count;
			}
			else
			{
				
				const int idx_count = (points_count - 2) * 3;
				const int vtx_count = points_count;
				draw->PrimReserve(idx_count, vtx_count);
				for (int i = 0; i < vtx_count; i++)
				{
					draw->_VtxWritePtr[0].pos = points[i]; draw->_VtxWritePtr[0].uv = uv; draw->_VtxWritePtr[0].col = col[i];
					draw->_VtxWritePtr++;
				}
				for (int i = 2; i < points_count; i++)
				{
					draw->_IdxWritePtr[0] = (ImDrawIdx)(draw->_VtxCurrentIdx); draw->_IdxWritePtr[1] = (ImDrawIdx)(draw->_VtxCurrentIdx + i - 1); draw->_IdxWritePtr[2] = (ImDrawIdx)(draw->_VtxCurrentIdx + i);
					draw->_IdxWritePtr += 3;
				}
				draw->_VtxCurrentIdx += (ImDrawIdx)vtx_count;
			}
		}

		/*
		// The original author of the code is nathanvoglsam
		// https://github.com/nathanvoglsam
		*/
		void AddTriangleFilledMultiColor(ImDrawList* draw, const ImVec2& a, const ImVec2& b, const ImVec2& c, ImTrickyColor col_a, ImTrickyColor col_b, ImTrickyColor col_c)
		{
			ImVec2 verts[] = { a, b, c };
			ImTrickyColor colors[] = { col_a, col_b, col_c };
			AddConvexPolyFilledGradient(draw, verts, colors, 3);
		}

		void AddConvexPolyFilledMultiColor(ImDrawList* draw, const ImVec2* verts, ImTrickyColor* colors, int points)
		{
			AddConvexPolyFilledGradient(draw, verts, colors, points);
		}
	}

}
