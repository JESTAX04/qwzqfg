#pragma once

#include "includes/includes.h"

class Graphics {
public:
	static Graphics* Get() {
		static Graphics* s_pSingleton = nullptr;
        if (s_pSingleton == nullptr)
            s_pSingleton = new Graphics;
        return s_pSingleton;
	}
    void DrawCornerBox(float x, float y, float w, float h, float thickness, float coverage, ImColor col)
    {
        DrawLine({ x, y }, { x + (w * coverage), y }, col, thickness);
        DrawLine({ x, y }, { x, y + (h * coverage / 2) }, col, thickness);

        DrawLine({ x, y + h }, { x + (w * coverage), y + h }, col, thickness);
        DrawLine({ x, y + h }, { x, (y + h) - (h * coverage / 2) }, col, thickness);

        DrawLine({ x + w, y }, { (x + w) - (w * coverage), y }, col, thickness);
        DrawLine({ x + w, y }, { x + w, y + (h * coverage / 2) }, col, thickness);

        DrawLine({ x + w, y + h }, { (x + w) - (w * coverage), y + h }, col, thickness);
        DrawLine({ x + w, y + h }, { x + w, (y + h) - (h * coverage / 2) }, col, thickness);
    }
    void DrawTextA(ImFont* pFont, const std::string& text, const ImVec2& pos, float size, ImU32 color, bool center, ImU32 outlineColor = ImColor(0, 0, 0)) {
        std::stringstream stream(text);
        std::string line;

        float y = 0.0f;
        int index = 0;
        const float outlineOffset = 1.0f;

        while (std::getline(stream, line)) {
            ImVec2 textSize = pFont->CalcTextSizeA(size, FLT_MAX, 0.0f, line.c_str());

            ImVec2 textPos = pos;
            if (center) {
                textPos.x -= textSize.x / 2.0f;
            }

            ImVec2 currentPos = ImVec2(textPos.x, textPos.y + textSize.y * index);

            ImGui::GetBackgroundDrawList()->AddText(pFont, size, ImVec2(currentPos.x - outlineOffset, currentPos.y), outlineColor, line.c_str());
            ImGui::GetBackgroundDrawList()->AddText(pFont, size, ImVec2(currentPos.x + outlineOffset, currentPos.y), outlineColor, line.c_str());
            ImGui::GetBackgroundDrawList()->AddText(pFont, size, ImVec2(currentPos.x, currentPos.y - outlineOffset), outlineColor, line.c_str());
            ImGui::GetBackgroundDrawList()->AddText(pFont, size, ImVec2(currentPos.x, currentPos.y + outlineOffset), outlineColor, line.c_str());

            ImGui::GetBackgroundDrawList()->AddText(pFont, size, currentPos, color, line.c_str());

            y = pos.y + textSize.y * (index + 1);
            index++;
        }
    }
    void FillRect(float x, float y, float w, float h, ImColor color, float rounding = 0.0f) {
        if (IsOnScreen({ x, y })) {
            ImGui::GetBackgroundDrawList()->AddRectFilled(ImVec2(x, y), ImVec2(x + w, y + h), color, rounding);
        }
    }
    void DrawBorder(float x, float y, float w, float h, float thickness, ImColor BorderColor) {
        FillRect(x, y, w, thickness, BorderColor);

        FillRect(x, y, thickness, h, BorderColor);

        FillRect((x + w), y, thickness, h, BorderColor);

        FillRect(x, y + h, w + thickness, thickness, BorderColor);
    }

    void DrawLine(ImVec2 dst, ImVec2 src, ImColor col, float thickness) {
        if (this->IsOnScreen(dst) && this->IsOnScreen(src)) {
            ImGui::GetBackgroundDrawList()->AddLine(src, dst, col, thickness);
        }
    }
    bool IsOnScreen(ImVec2 pos) {
        if (pos.x < 0.1f || pos.y < 0.1 || pos.x > ImGui::GetIO().DisplaySize.x || pos.y > ImGui::GetIO().DisplaySize.y) {
            return false;
        }
        else {
            return true;
        }
    }
};