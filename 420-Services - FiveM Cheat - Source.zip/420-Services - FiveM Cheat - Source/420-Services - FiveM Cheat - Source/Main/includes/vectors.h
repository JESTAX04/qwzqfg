template <typename T>
union vector3
{
	T data[3];
	struct
	{
		T x, y, z;
	};

	constexpr vector3(T x, T y, T z) noexcept : x(x),
		y(y),
		z(z)
	{
	}

	constexpr vector3() noexcept : x(),
		y(),
		z()
	{
	}

	constexpr vector3 operator+(const vector3& rhs) const
	{
		return vector3(x + rhs.x, y + rhs.y, z + rhs.z);
	}

	constexpr vector3 operator-(const vector3& rhs) const
	{
		return vector3(x - rhs.x, y - rhs.y, z - rhs.z);
	}

	constexpr vector3 operator*(const vector3& rhs) const
	{
		return vector3(x * rhs.x, y * rhs.y, z * rhs.z);
	}

	constexpr vector3 operator/(const vector3& rhs) const
	{
		return vector3(x / rhs.x, y / rhs.y, z / rhs.z);
	}

	constexpr vector3 operator+(const float& rhs) const
	{
		return vector3(x + rhs, y + rhs, z + rhs);
	}

	constexpr vector3 operator-(const float& rhs) const
	{
		return vector3(x - rhs, y - rhs, z - rhs);
	}

	constexpr vector3 operator*(const float& rhs) const
	{
		return vector3(x * rhs, y * rhs, z * rhs);
	}

	constexpr vector3 operator/(const float& rhs) const
	{
		return vector3(x / rhs, y / rhs, z / rhs);
	}

	constexpr bool operator==(const vector3& rhs) const
	{
		return x == rhs.x && y == rhs.y && z == rhs.z;
	}

	constexpr vector3& operator+=(const vector3& rhs)
	{
		return *this = *this + rhs;
	}

	constexpr vector3& operator-=(const vector3& rhs)
	{
		return *this = *this - rhs;
	}

	constexpr vector3& operator*=(const vector3& rhs)
	{
		return *this = *this * rhs;
	}

	constexpr vector3& operator/=(const vector3& rhs)
	{
		return *this = *this / rhs;
	}

	constexpr vector3& operator+=(const float& rhs)
	{
		return *this = *this + rhs;
	}

	constexpr vector3& operator-=(const float& rhs)
	{
		return *this = *this - rhs;
	}

	constexpr vector3& operator*=(const float& rhs)
	{
		return *this = *this * rhs;
	}

	constexpr vector3& operator/=(const float& rhs)
	{
		return *this = *this / rhs;
	}

	constexpr T length() const
	{
		return sqrt(x * x + y * y + z * z);
	}

	constexpr T magnitude() const
	{
		return length();
	}

	constexpr vector3 normalize() const
	{
		T len = length();
		if (len)
		{
			return *this * (1 / len);
		}

		return *this;
	}

	constexpr vector3 multiply(const vector3 rhs) const
	{
		return vector3(x * rhs.x, y * rhs.y, z * rhs.z);
	}

	constexpr vector3 invert() const
	{
		return *this * -1;
	}

	
	constexpr vector3 cross_product(const vector3& rhs) const
	{
		return vector3(y * rhs.z - z * rhs.y, z * rhs.x - x * rhs.z, x * rhs.y - y * rhs.x);
	}

	constexpr float dot_product(const vector3& rhs) const
	{
		return x * rhs.x + y * rhs.y + z * rhs.z;
	}

	constexpr float distance(const vector3& rhs) const
	{
		return (*this - rhs).length();
	}
	bool is_zero(float epsilon = 1e-6) const {
		return std::fabs(x) < epsilon && std::fabs(y) < epsilon && std::fabs(z) < epsilon;
	}
};
typedef vector3<float> Vector3;

struct Matrix4x4 {
	float m[4][4];

	Matrix4x4() {
		for (int i = 0; i < 4; ++i)
			for (int j = 0; j < 4; ++j)
				m[i][j] = 0.0f;
	}
};

struct PVector3
{
public:
	PVector3() = default;

	PVector3(float x, float y, float z) :
		x(x), y(y), z(z)
	{
	}
public:
	float x{};
private:
	char m_padding1[0x04]{};
public:
	float y{};
private:
	char m_padding2[0x04]{};
public:
	float z{};
private:
	char m_padding3[0x04]{};
};

class Vector2 final {
public:
	float x;
	float y;

	Vector2(const float x, const float y) : x(x), y(y) {}
	constexpr Vector2() : x(0.0f), y(0.0f) {};
};