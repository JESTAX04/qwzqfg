#pragma once
#include <Windows.h>
#include <d3d11.h>
#include <regex>
#include <dxgi.h>
#include <functional>
#include <winternl.h>
#include <d3d9.h>
#include <d3dx9.h>
#include <DirectXMath.h>
#include <dwmapi.h>
#include <vector>
#include <random>
#include <chrono>
#include "../gui/imgui/imgui.h"
#include "../gui/imgui/imgui_impl_win32.h"
#include "../gui/imgui/imgui_impl_dx11.h"
#include "../gui/gui.h"

#include "globals.h"
#include "vectors.h"

#include "../Scanner.h"
#include "../Graphics.h"

#include "../encrypt/skStr.h"

#include "../../Cheat/Cheat.h"

#include "../../Cheat/addr/address.h"

#include "../../Cheat/gta/core/core.h"

#include "../../Cheat/features/aimbot.h"

#include "../../Cheat/features/esp.h"

#include "../../Cheat/features/self.h"

#include "../../Cheat/features/vehicle.h"

#include "../../Cheat/features/weapon.h"

typedef HRESULT(__stdcall* Present) (IDXGISwapChain* pSwapChain, UINT SyncInterval, UINT Flags);

inline Present oPresent;

inline HWND window = NULL;
inline ID3D11Device* pDevice = NULL;
inline ID3D11DeviceContext* pContext = NULL;
inline ID3D11RenderTargetView* mainRenderTargetView;

extern LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

#define IMGUI_DEFINE_MATH_OPERATORS


inline ImFont* g_TitleFont = nullptr;
inline ImFont* g_SubTitleFont = nullptr;


inline int g_last_present_fps = 0;