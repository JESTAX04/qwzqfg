#include "fiber.hpp"
#include "tick.hpp"
#include <memory.h>
#include "Main/includes/globals.h"



#include "enums.hpp"
#include "hashes.hpp"
#include "Cheat/addr/address.h"
#include "Cheat/gta/core/core.h"



static const ControllerInputs controls[] = { ControllerInputs::INPUT_LOOK_LR, ControllerInputs::INPUT_LOOK_UD, ControllerInputs::INPUT_LOOK_UP_ONLY, ControllerInputs::INPUT_LOOK_DOWN_ONLY, ControllerInputs::INPUT_LOOK_LEFT_ONLY, ControllerInputs::INPUT_LOOK_RIGHT_ONLY, ControllerInputs::INPUT_LOOK_LEFT, ControllerInputs::INPUT_LOOK_RIGHT, ControllerInputs::INPUT_LOOK_UP, ControllerInputs::INPUT_LOOK_DOWN };



bool IsModelRequest = false;
static int s_modelWaitTicks = 0;


void on_Tls_Thread() {
	if (globals.vehicle.spawn_vehicle) {
		uint64_t pedfactory = *(uint64_t*)(Address::Get()->m_sPedFactory);
		if (!pedfactory) return;

		uint64_t localplayer = *(uint64_t*)(pedfactory + 0x8);
		if (!localplayer) return;

		Vector3 endpos = *(Vector3*)(localplayer + 0x90);
		auto vehiculeHash = globals.vehicle.spawn_vehicle_hash;

		if (!IsModelRequest) {
			
			if (MemoryAddress::is_model_in_cd_image) {
				(VOID)MemoryAddress::is_model_in_cd_image(vehiculeHash);
			}
			if (MemoryAddress::request_model) MemoryAddress::request_model(vehiculeHash);
			IsModelRequest = true;
			s_modelWaitTicks = 0;
		}
		else
		{
			bool loaded = MemoryAddress::has_model_loaded ? (MemoryAddress::has_model_loaded(vehiculeHash) != 0) : false;
			if (loaded || s_modelWaitTicks > 500) { 
				
				DWORD64 cam = Core::Get()->GetCamera();
				Vector3 forward = cam ? *(Vector3*)(cam + 0x3D0) : Vector3(0.f,1.f,0.f);
				if (forward.is_zero()) forward = cam ? *(Vector3*)(cam + 0x40) : Vector3(0.f,1.f,0.f);
				if (!forward.is_zero()) forward = forward.normalize();
				Vector3 spawn = endpos;
				spawn.x += forward.x * 4.0f; spawn.y += forward.y * 4.0f; spawn.z += 1.2f;
				float heading = (!forward.is_zero()) ? atan2f(forward.x, forward.y) * 57.2957795f : 0.0f;
				PVector3 spawn_coords = PVector3(spawn.x, spawn.y, spawn.z);
				if (MemoryAddress::create_vehicle) {
					
					uint64_t veh_ptr = MemoryAddress::create_vehicle(vehiculeHash, spawn_coords, heading, true, true);
					if (!veh_ptr) {
						veh_ptr = MemoryAddress::create_vehicle(vehiculeHash, spawn_coords, heading, false, false);
					}
				}
				if (MemoryAddress::set_model_no_longer_needed) MemoryAddress::set_model_no_longer_needed(vehiculeHash);
				IsModelRequest = false;
				s_modelWaitTicks = 0;

				globals.vehicle.spawn_vehicle = false;
			}
			else {
				
				s_modelWaitTicks++;
			}
		}

	
	}



	tick::pNativeInvoker.on_tick();

	Fiber::Instance().GameFiber->wait(1);
}

void Fiber::Call()
{
	
	
	this->GameFiber = std::make_unique<fiber::GameFiber_Task>(nullptr, on_Tls_Thread);
}

