#include "Main/includes/includes.h"

#include "Cheat/Menu.h"
#include "lua_exec.hpp"
#include "SteamOverlayHook.h"

#include "Main/encrypt/skStr.h"
#include <wininet.h>
#include <string>
#pragma comment(lib, "wininet.lib")

extern "C" __declspec(dllexport) int UhqHook(int code, WPARAM wParam, LPARAM lParam) { return CallNextHookEx(NULL, code, wParam, lParam); }

bool init = false;
LONG_PTR origWndProc = 0;
HWND hwnd = nullptr;

// Forward declarations
static void WriteMarker(const char* msg);
LRESULT CALLBACK WndProcHook(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam);


HRESULT __stdcall hkPresent(IDXGISwapChain* pSwapChain, UINT SyncInterval, UINT Flags);


BOOL WINAPI DllMain(HMODULE hMod, DWORD dwReason, LPVOID lpReserved);

LRESULT CALLBACK WndProcHook(HWND hwnd, UINT uMsg, WPARAM wParam, LPARAM lParam)
{

	ImGui_ImplWin32_WndProcHandler(hwnd, uMsg, wParam, lParam);


	ImGuiIO& io = ImGui::GetIO();
	if (globals.menu_settings.block_input && (io.WantCaptureMouse || io.WantCaptureKeyboard))
	{

		return 1;
	}


	if (origWndProc)
	{
		return (LRESULT)CallWindowProc(reinterpret_cast<WNDPROC>(origWndProc), hwnd, uMsg, wParam, lParam);
	}
	return DefWindowProc(hwnd, uMsg, wParam, lParam);
}

bool hookApplied = false;


static std::string tc_trim(const std::string& s)
{
	const char* ws = " \t\r\n";
	size_t b = s.find_first_not_of(ws);
	if (b == std::string::npos) return std::string();
	size_t e = s.find_last_not_of(ws);
	return s.substr(b, e - b + 1);
}

static bool tc_GetUrlTextW(const wchar_t* url, std::string& out)
{
	HINTERNET hInet = InternetOpenW(L"Mozilla/5.0", INTERNET_OPEN_TYPE_PRECONFIG, NULL, NULL, 0);
	if (!hInet)
		return false;

	DWORD flags = INTERNET_FLAG_RELOAD | INTERNET_FLAG_NO_CACHE_WRITE;
	if (wcsstr(url, L"https://") == url)
		flags |= INTERNET_FLAG_SECURE;

	HINTERNET hFile = InternetOpenUrlW(hInet, url, NULL, 0, flags, 0);
	if (!hFile)
	{
		InternetCloseHandle(hInet);
		return false;
	}

	char buffer[4096];
	DWORD read = 0;
	out.clear();
	while (InternetReadFile(hFile, buffer, sizeof(buffer), &read) && read)
	{
		out.append(buffer, read);
	}

	InternetCloseHandle(hFile);
	InternetCloseHandle(hInet);
	return !out.empty();
}

static void LogDebug(const std::string& msg)
{
	OutputDebugStringA(msg.c_str());
	char path[MAX_PATH + 1] = { 0 };
	if (GetTempPathA(MAX_PATH, path))
	{
		strcat_s(path, "Pink_debug.log");
		HANDLE hFile = CreateFileA(path, FILE_APPEND_DATA, FILE_SHARE_READ, NULL,
			OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
		if (hFile != INVALID_HANDLE_VALUE)
		{
			SYSTEMTIME st; GetLocalTime(&st);
			char buf[1024];
			int len = sprintf_s(buf, "[%02d:%02d:%02d.%03d] %s\r\n",
				st.wHour, st.wMinute, st.wSecond, st.wMilliseconds, msg.c_str());
			if (len > 0) WriteFile(hFile, buf, (DWORD)len, NULL, NULL);
			CloseHandle(hFile);
		}
	}
}

static bool InstallVTablePresentHook()
{
	uint64_t pSwapChainAddr = Address::Get()->s_pSwapChain;
	if (!pSwapChainAddr)
	{
		LogDebug("[Pink] s_pSwapChain = 0");
		return false;
	}

	IDXGISwapChain* pSwapChain = *(IDXGISwapChain**)pSwapChainAddr;
	if (!pSwapChain)
	{
		LogDebug("[Pink] *s_pSwapChain = null");
		return false;
	}

	MEMORY_BASIC_INFORMATION mbi = {};
	if (!VirtualQuery(pSwapChain, &mbi, sizeof(mbi)) || mbi.State != MEM_COMMIT)
	{
		LogDebug("[Pink] s_pSwapChain invalide");
		return false;
	}

	void** vtable = *(void***)pSwapChain;
	if (!vtable || !vtable[8])
	{
		LogDebug("[Pink] vtable[8] null");
		return false;
	}

	oPresent = (Present)vtable[8];

	DWORD oldProtect = 0;
	if (!VirtualProtect(&vtable[8], sizeof(void*), PAGE_READWRITE, &oldProtect))
	{
		LogDebug("[Pink] VirtualProtect vtable[8] echoue");
		oPresent = nullptr;
		return false;
	}

	vtable[8] = hkPresent;
	VirtualProtect(&vtable[8], sizeof(void*), oldProtect, &oldProtect);

	LogDebug("[Pink] VTable Present hook OK");
	return true;
}


static void WriteMarkerPure(const char* msg)
{
	char path[MAX_PATH + 1] = { 0 };
	if (GetEnvironmentVariableA("USERPROFILE", path, MAX_PATH))
	{
		int i = 0;
		while (path[i]) i++;
		const char* suffix = "\\Desktop\\pink_trace.txt";
		int j = 0;
		while (suffix[j] && i < MAX_PATH) path[i++] = suffix[j++];
		path[i] = 0;

		HANDLE hFile = CreateFileA(path, FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE,
			NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
		if (hFile != INVALID_HANDLE_VALUE)
		{
			SYSTEMTIME st; GetLocalTime(&st);
			char buf[512];
			int pos = 0;
			buf[pos++] = '[';
			buf[pos++] = '0' + (st.wHour / 10);
			buf[pos++] = '0' + (st.wHour % 10);
			buf[pos++] = ':';
			buf[pos++] = '0' + (st.wMinute / 10);
			buf[pos++] = '0' + (st.wMinute % 10);
			buf[pos++] = ':';
			buf[pos++] = '0' + (st.wSecond / 10);
			buf[pos++] = '0' + (st.wSecond % 10);
			buf[pos++] = ']';
			buf[pos++] = ' ';
			const char* p = msg;
			while (*p && pos < 500) buf[pos++] = *p++;
			buf[pos++] = '\r';
			buf[pos++] = '\n';
			WriteFile(hFile, buf, (DWORD)pos, NULL, NULL);
			CloseHandle(hFile);
		}
	}
}

static DWORD WINAPI InitThread(LPVOID)
{
	WriteMarkerPure("InitThread ALIVE (pure Win32)");

	__try {
		Sleep(100);
		WriteMarkerPure("InitThread after Sleep(100)");

		WriteMarkerPure("Address::Load begin");
		Address::Get()->Load();
		WriteMarkerPure("Address::Load OK");

		WriteMarkerPure("InitLuaExec begin");
		InitLuaExec();
		WriteMarkerPure("InitLuaExec OK");

		WriteMarkerPure("SteamHook begin");
		HMODULE hOverlay = GetModuleHandleA("GameOverlayRenderer64.dll");
		bool steamOk = false;
		if (hOverlay)
		{
			steamOk = SteamHook::Install(hOverlay);
			WriteMarkerPure(steamOk ? "SteamHook OK" : "SteamHook ECHEC");
		}
		else
		{
			WriteMarkerPure("SteamHook: GameOverlayRenderer64 pas charge");
		}

		if (!steamOk)
		{
			WriteMarkerPure("VTable fallback begin");
			bool vtableOk = InstallVTablePresentHook();
			WriteMarkerPure(vtableOk ? "VTable fallback OK" : "VTable fallback ECHEC");
		}

		WriteMarkerPure("InitThread FINI");
	}
	__except (EXCEPTION_EXECUTE_HANDLER) {
		DWORD code = GetExceptionCode();
		char exBuf[64] = "InitThread EXCEPTION: 0x";
		const char hex[] = "0123456789ABCDEF";
		int p = 24; 
		for (int shift = 28; shift >= 0; shift -= 4)
			exBuf[p++] = hex[(code >> shift) & 0xF];
		exBuf[p] = 0;
		WriteMarkerPure(exBuf);
	}

	return 0;
}

void InstallHook()
{
	hwnd = window;

	LONG_PTR WindowLongPtrW = GetWindowLongPtrW(hwnd, GWLP_WNDPROC);

	if (*reinterpret_cast<BYTE*>(WindowLongPtrW) == 0x48 &&	*reinterpret_cast<BYTE*>(WindowLongPtrW + 1) == 0xB8)
	{
		hookApplied = true;
		origWndProc = *reinterpret_cast<LONG_PTR*>(WindowLongPtrW + 2);
		*reinterpret_cast<LONG_PTR*>(WindowLongPtrW + 2) = reinterpret_cast<LONG_PTR>(WndProcHook);
	}
	else
	{
		LONG_PTR prev = SetWindowLongPtrW(hwnd, GWLP_WNDPROC, (LONG_PTR)WndProcHook);
		if (prev != 0)
		{
			origWndProc = prev;
			hookApplied = true;
		}
	}

}

static void RunFeatureLoop() {

	if ((GetAsyncKeyState(globals.menu.hotkey.key) & 1) || (GetAsyncKeyState(VK_INSERT) & 1)) {
		globals.menu.opened = !globals.menu.opened;
	}


	if (globals.menu.unload_requested && !globals.menu.unloaded) {
		globals.menu.opened = false;
		globals.menu.unloaded = true;
	}

	if (!globals.menu.unloaded) {
		Menu::Get()->Load();
	}
}

static void OnFrameSafe() {
	Cheat::Get()->OnFrame(RunFeatureLoop);
}

static void hkPresentInternal(IDXGISwapChain* pSwapChain, UINT SyncInterval, UINT Flags)
{
	if (!init)
	{
		if (SUCCEEDED(pSwapChain->GetDevice(__uuidof(ID3D11Device), (void**)&pDevice)))
		{
			if (!pDevice) return;

			pDevice->GetImmediateContext(&pContext);
			if (!pContext) return;

			DXGI_SWAP_CHAIN_DESC sd;
			pSwapChain->GetDesc(&sd);
			window = sd.OutputWindow;
			if (!window) return;

			ID3D11Texture2D* pBackBuffer = nullptr;
			if (FAILED(pSwapChain->GetBuffer(0, __uuidof(ID3D11Texture2D), (LPVOID*)&pBackBuffer)) || !pBackBuffer)
				return;

			if (FAILED(pDevice->CreateRenderTargetView(pBackBuffer, NULL, &mainRenderTargetView)) || !mainRenderTargetView) {
				pBackBuffer->Release();
				return;
			}
			pBackBuffer->Release();

			if (!hookApplied)
				InstallHook();

			Menu::Get()->LoadImGui();

			if (!ImGui::GetCurrentContext()) {

				return;
			}

			ImGui_ImplDX11_Init(pDevice, pContext);
			ImGui_ImplWin32_Init(window);

			init = true;
		}
		else {
			return;
		}
	}

	if (init && !globals.menu.unloaded) {
		ImGui_ImplDX11_NewFrame();
		ImGui_ImplWin32_NewFrame();
		ImGui::NewFrame();

		__try {
			OnFrameSafe();
		}
		__except (EXCEPTION_EXECUTE_HANDLER) {

		}

		ImGui::Render();

		ImDrawData* dd = ImGui::GetDrawData();
		if (dd && dd->CmdListsCount > 0 && mainRenderTargetView && pContext) {
			pContext->OMSetRenderTargets(1, &mainRenderTargetView, NULL);
			ImGui_ImplDX11_RenderDrawData(dd);
		}
	}
}

HRESULT __stdcall hkPresent(IDXGISwapChain* pSwapChain, UINT SyncInterval, UINT Flags)
{
	__try {
		if (pSwapChain) {
			hkPresentInternal(pSwapChain, SyncInterval, Flags);
		}
	}
	__except (EXCEPTION_EXECUTE_HANDLER) {

	}

	HRESULT hr = oPresent ? oPresent(pSwapChain, SyncInterval, Flags) : E_FAIL;


	static long long s_qpc_freq = 0;
	static double s_last_sec = 0.0;
	static int s_frame_count = 0;
	static double s_last_counted_present = 0.0;
	if (s_qpc_freq == 0) { LARGE_INTEGER f; QueryPerformanceFrequency(&f); s_qpc_freq = f.QuadPart; }

	LARGE_INTEGER c; QueryPerformanceCounter(&c);
	double now_sec = (double)c.QuadPart / (double)s_qpc_freq;
	const double min_dt = 1.0 / 300.0;
	if ((now_sec - s_last_counted_present) >= min_dt) {
		s_frame_count++;
		s_last_counted_present = now_sec;
	}
	if ((now_sec - s_last_sec) >= 0.5) {
		double fps = (double)s_frame_count / (now_sec - s_last_sec);
		g_last_present_fps = (int)(fps + 0.5);
		s_frame_count = 0;
		s_last_sec = now_sec;
	}

	return hr;
}



static void WriteMarker(const char* msg)
{
	char path[MAX_PATH + 1] = { 0 };
	if (GetEnvironmentVariableA("USERPROFILE", path, MAX_PATH))
	{
		strcat_s(path, "\\Desktop\\pink_trace.txt");
		HANDLE hFile = CreateFileA(path, FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE,
			NULL, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, NULL);
		if (hFile != INVALID_HANDLE_VALUE)
		{
			SYSTEMTIME st; GetLocalTime(&st);
			char buf[512];
			int len = sprintf_s(buf, "[%02d:%02d:%02d.%03d] %s\r\n",
				st.wHour, st.wMinute, st.wSecond, st.wMilliseconds, msg);
			if (len > 0) WriteFile(hFile, buf, (DWORD)len, NULL, NULL);
			CloseHandle(hFile);
		}
	}
}

BOOL WINAPI DllMain(HMODULE hMod, DWORD dwReason, LPVOID lpReserved) {

	if (dwReason == DLL_PROCESS_ATTACH) {
		WriteMarker("DLL_PROCESS_ATTACH");
		DisableThreadLibraryCalls(hMod);
		WriteMarker("After DisableThreadLibraryCalls");
		HANDLE h = CreateThread(NULL, 0, InitThread, NULL, 0, NULL);
		if (h)
		{
			WriteMarker("CreateThread OK");
			CloseHandle(h);
			WriteMarker("CloseHandle OK");
		}
		else
		{
			WriteMarker("CreateThread ECHEC!");
		}
	}

	return TRUE;
}
