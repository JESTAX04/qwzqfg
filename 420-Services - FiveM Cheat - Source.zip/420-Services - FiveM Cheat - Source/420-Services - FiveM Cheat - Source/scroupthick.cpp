#include "scroupthick.hpp"

#include "thread.hpp"
#include "fiber.hpp"
#include "Cheat/addr/address.h"

using script_thread_tick_t = uintptr_t(*)(game_thread* thread, int ops_to_execute);
script_thread_tick_t ptr_gta_script_thread_tick = 0;
script_thread_tick_t original_native_thread = nullptr;

uintptr_t hooked_native_thread(game_thread* this_ptr, int ops_to_execute) {
	Thread::Instance().CallT(this_ptr, ops_to_execute);


	
	
	return original_native_thread(this_ptr, ops_to_execute);
}
void Hooks::Thread(UINT64 scrMeta) {

	Fiber::Instance().Call();
	BYTE scrIndex;


	if (true)
		scrIndex = 64 + 8 * 3;

	
	
	ptr_gta_script_thread_tick = (script_thread_tick_t)(scrMeta + scrIndex);
	
	original_native_thread = (script_thread_tick_t)(*(uint64_t*)ptr_gta_script_thread_tick);
	
	*(intptr_t*)ptr_gta_script_thread_tick = (intptr_t)&hooked_native_thread;
	
}
void Hooks::Initialize(UINT64 scrMeta) {
	

	this->Thread(scrMeta);

}