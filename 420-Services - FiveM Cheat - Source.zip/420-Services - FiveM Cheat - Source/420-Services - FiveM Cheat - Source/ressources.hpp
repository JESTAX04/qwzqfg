#pragma once



#include <functional>
#include <memory>
#include <atomic>
#include <type_traits>





class Resource
{
private:
	char pad_0x0000[0xC0];
};


std::vector<Resource*> FetchAllResources() {
	std::vector<Resource*> ResourcesList;

	auto GetAllResources = reinterpret_cast<std::vector<Resource*>*>(reinterpret_cast<uintptr_t>(GetModuleHandleA("citizen-resources-core.dll")) + 0xB26E0);
	if (GetAllResources) {
		for (Resource* resource : *GetAllResources) {
			if (resource) {
				ResourcesList.push_back(resource);
			}
		}
	}

	return ResourcesList;
}

enum ResourceState : uint32_t {
	Uninitialized,
	Stopped,
	Starting,
	Started,
	Stopping
};


using GetNameFunc = const std::string& (*)(Resource*);

using GetPathFunc = const std::string& (*)(Resource*);

using GetStateFunc = ResourceState(*)(Resource*);

using StopResourceFunc = void(*)(Resource*);





template <typename T, typename... Args>
void appendToOutput(std::ostringstream& oss, T first, Args... rest) {
	oss << std::quoted(first); 
	if constexpr (sizeof...(rest) > 0) {
		oss << ", ";
		appendToOutput(oss, rest...);
	}
}

