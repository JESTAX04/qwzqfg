#include "thread.hpp"
#include "fiber.hpp"
#include "Cheat/addr/address.h"

void Thread::CallT(game_thread* this_ptr, int ops_to_execute) {
	

	if (this_ptr->m_context.m_script_hash == STARTUP || this_ptr->m_context.m_script_hash == MAIN_PERSISTENT || this_ptr->m_context.m_script_hash == 0x3) 
	{
		
		

		auto& thread = game_thread::GetActiveThread(Address::Get()->activeThreadTlsOffset);
		
		auto orig_thread = thread;

		thread = this_ptr;


		Fiber::Instance().GameFiber->on_tick();

		thread = orig_thread;
	}

}