#pragma once
#include "Includes.h"
class Resources
{
public:
	static enum eResourceState : uint32_t {
		Uninitialized,
		Stopped,
		Starting,
		Started,
		Stopping
	};
	static struct resourceStruct {
		uintptr_t Pointer = 0;
		std::string Path;
		std::string Name;
		eResourceState State = eResourceState::Uninitialized;
	};
	static int chosenResource;
	static inline std::vector<resourceStruct> ResourceList;
	static void refresh();
	static void terminate(uintptr_t Resourceptr);
private:

	static uintptr_t BaseAddr;
	static uintptr_t BaseAddySiz;
	static uintptr_t ResourceListEntry;
	static uintptr_t ResourceScanAddress;
	static uintptr_t SRSAddr;
};
