#pragma once
#include <Windows.h>
#include <cstdint>
#include <vector>
#include <string>
#include <cstring>
#include "MinHook.h"



extern HRESULT __stdcall hkPresent(IDXGISwapChain* pSwapChain, UINT SyncInterval, UINT Flags);



namespace SteamHook {


static constexpr const char* PATTERN_DX11_PRESENT =
	"48 89 5C 24 ? 48 89 6C 24 ? 56 57 41 54 41 56 41 57 48 83 EC ? 41 8B E8";

static constexpr const char* PATTERN_D3D9_PRESENT =
	"48 89 5C 24 08 48 89 6C 24 10 48 89 74 24 18 57 48 83 EC 30 48 8B 05";

static std::vector<int> PatternToBytes(const char* pattern)
{
	std::vector<int> bytes;
	const char* p = pattern;

	while (*p)
	{
		if (*p == ' ' || *p == '\t') { ++p; continue; }

		if (*p == '?')
		{
			bytes.push_back(-1);
			++p;
			if (*p == '?') ++p;
		}
		else if (std::isxdigit(static_cast<unsigned char>(*p)))
		{
			bytes.push_back(static_cast<int>(std::strtol(p, const_cast<char**>(&p), 16)));
		}
		else
		{
			++p;  // skip unexpected chars
		}
	}

	return bytes;
}

static uintptr_t FindPattern(HMODULE hMod, const char* pattern)
{
	auto bytes = PatternToBytes(pattern);
	if (bytes.empty())
		return 0;

	const uintptr_t base = reinterpret_cast<uintptr_t>(hMod);

	const auto* dos  = reinterpret_cast<const IMAGE_DOS_HEADER*>(base);
	const auto* nt   = reinterpret_cast<const IMAGE_NT_HEADERS*>(base + dos->e_lfanew);
	const size_t size = nt->OptionalHeader.SizeOfImage;

	if (size < bytes.size())
		return 0;

	for (size_t i = 0; i < size - bytes.size(); ++i)
	{
		bool found = true;
		for (size_t j = 0; j < bytes.size(); ++j)
		{
			if (bytes[j] != -1 &&
				reinterpret_cast<const uint8_t*>(base)[i + j] != static_cast<uint8_t>(bytes[j]))
			{
				found = false;
				break;
			}
		}
		if (found)
			return base + i;
	}

	return 0;
}

static bool Install(HMODULE hOverlay)
{
	if (!hOverlay)
		return false;

	uintptr_t presentAddr = FindPattern(hOverlay, PATTERN_DX11_PRESENT);

	if (!presentAddr)
		presentAddr = FindPattern(hOverlay, PATTERN_D3D9_PRESENT);

	if (!presentAddr)
		return false;   

	{
		MEMORY_BASIC_INFORMATION mbi = {};
		if (!VirtualQuery(reinterpret_cast<LPCVOID>(presentAddr), &mbi, sizeof(mbi)))
			return false;
		DWORD execMask = PAGE_EXECUTE | PAGE_EXECUTE_READ |
		                 PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY;
		if (!(mbi.Protect & execMask))
			return false;   
	}

	MH_STATUS st;
	st = MH_Initialize();
	if (st != MH_OK && st != MH_ERROR_ALREADY_INITIALIZED)
		return false;


	st = MH_CreateHook(reinterpret_cast<LPVOID>(presentAddr),
	                   reinterpret_cast<LPVOID>(hkPresent),
	                   reinterpret_cast<LPVOID*>(&oPresent));
	if (st != MH_OK)
		return false;

	st = MH_EnableHook(reinterpret_cast<LPVOID>(presentAddr));
	if (st != MH_OK)
		return false;

	return true;  // hook actif ✓
}

} // namespace SteamHook
