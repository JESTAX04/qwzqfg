// language: C++, target: Windows 11, MSVC (x64)
// Injector. Manual-maps fvem_core.dll into FiveM's client process without
// LoadLibrary and without registering a PEB loader entry. Builds an indirect
// syscall table from a clean ntdll copy and passes it to the mapped DLL.
//
// Syscall service numbers (SSN) are per Windows build â€” re-derive on patch:
//   NtAllocateVirtualMemory, NtProtectVirtualMemory, NtCreateThreadEx,
//   NtQuerySystemInformation, NtOpenProcess, NtReadVirtualMemory,
//   NtWriteVirtualMemory, NtClose, NtSetInformationThread.
#include <windows.h>
#include <tlhelp32.h>
#include <psapi.h>
#include <cstdio>
#include <cstdint>
#include <cstring>
#include <vector>
#include <string>

#pragma comment(lib, "psapi.lib")

// Console output. Two rules here, both from MEMORY_ONLY_PLAN.md:
//   1. No CRT stdio. fputws(stdout) drags the entire CRT file layer into the
//      image (CreateFileW / WriteFile / SetFilePointerEx / SetEndOfFile), which
//      makes the shipped binary ABLE to write a file even though we never do.
//      WriteConsoleW talks to the console object directly. Under FVEM_LOG
//      (Debug only) the stdio path is kept so redirected/piped output still
//      works - a dev convenience that must not exist in a shipped image.
//   2. The %TEMP% file sink stays FVEM_LOG-gated: a plaintext log with mapped
//      base addresses in it is post-hoc evidence and must not exist on a run.
static void tee(const wchar_t* fmt, ...) {
    wchar_t buf[512];
    va_list ap;
    va_start(ap, fmt);
    vswprintf_s(buf, 512, fmt, ap);
    va_end(ap);

    HANDLE out = GetStdHandle(STD_OUTPUT_HANDLE);
    DWORD wrote = 0;
    if (!out || out == INVALID_HANDLE_VALUE ||
        !WriteConsoleW(out, buf, (DWORD)wcslen(buf), &wrote, nullptr)) {
#ifdef FVEM_LOG
        fputws(buf, stdout);
#endif
    }

#ifdef FVEM_LOG
    wchar_t dir[MAX_PATH];
    if (GetTempPathW(MAX_PATH, dir)) {
        wchar_t path[MAX_PATH];
        swprintf_s(path, L"%sfvem_injector.log", dir);
        FILE* f = nullptr;
        if (_wfopen_s(&f, path, L"a") == 0 && f) {
            fputws(buf, f);
            fclose(f);
        }
    }
#endif
}

#include "../common/pe.h"
#include "../common/syscalls.h"
#include "../common/obf.h"
#include "../core/generated/payload_blob.h"

using namespace gfx;
using gfx::sys::SyscallTable;

// Payload integrity. Plain FNV-1a over the decrypted image - not a security
// hash, a build-consistency check (see tools/payload_pack). Replaces the old
// read_file(), which was the injector's only reason to touch the volume.
static uint64_t fnv1a(const uint8_t* p, size_t n) {
    uint64_t h = 1469598103934665603ull;
    for (size_t i = 0; i < n; ++i) { h ^= p[i]; h *= 1099511628211ull; }
    return h;
}

// Resolve the syscall SSN for a given ntdll export by counting the bytes until
// the "mov eax, imm32" (B8) that precedes the syscall stub's jmp.
static uint32_t ssn_from_export(void* ntdll_base, const char* name) {
    void* fn = pe::find_export(ntdll_base, name);
    if (!fn) return 0;
    auto* bytes = static_cast<uint8_t*>(fn);
    // Stub layout (typical): mov r10, rcx (4C 8B D1) ; mov eax, imm32 (B8 xx xx xx xx) ; jmp/syscall
    for (int i = 0; i < 32; i++) {
        if (bytes[i] == 0xB8) {
            return *reinterpret_cast<uint32_t*>(bytes + i + 1);
        }
    }
    return 0;
}

// Find the syscall gadget (syscall; ret) inside the loaded ntdll so indirect
// jumps return through a legitimate ntdll address.
static void* find_syscall_gadget(uintptr_t ntdll_base) {
    auto* dos = reinterpret_cast<IMAGE_DOS_HEADER*>(ntdll_base);
    auto* h = reinterpret_cast<IMAGE_NT_HEADERS64*>(ntdll_base + dos->e_lfanew);
    auto* sec = IMAGE_FIRST_SECTION(h);
    for (int i = 0; i < h->FileHeader.NumberOfSections; i++, sec++) {
        if (!(sec->Characteristics & IMAGE_SCN_MEM_EXECUTE)) continue;
        auto* begin = reinterpret_cast<uint8_t*>(ntdll_base + sec->VirtualAddress);
        auto* end = begin + sec->Misc.VirtualSize - 2;
        for (auto* p = begin; p < end; p++) {
            if (p[0] == 0x0F && p[1] == 0x05 && p[2] == 0xC3) { // syscall; ret
                return p;
            }
        }
    }
    return nullptr;
}

// Enable SeDebugPrivilege so we can open processes owned by other accounts or
// running elevated. Returns false if the token isn't privileged enough (e.g.
// we're not elevated at all and the target is).
static bool enable_debug_privilege() {
    HANDLE token = nullptr;
    if (!OpenProcessToken(GetCurrentProcess(),
                          TOKEN_ADJUST_PRIVILEGES | TOKEN_QUERY, &token))
        return false;
    TOKEN_PRIVILEGES tp{};
    tp.PrivilegeCount = 1;
    tp.Privileges[0].Attributes = SE_PRIVILEGE_ENABLED;
    if (!LookupPrivilegeValueW(nullptr, L"SeDebugPrivilege", &tp.Privileges[0].Luid)) {
        CloseHandle(token);
        return false;
    }
    bool ok = AdjustTokenPrivileges(token, FALSE, &tp, 0, nullptr, nullptr) != 0;
    DWORD err = GetLastError();
    CloseHandle(token);
    return ok && err == ERROR_SUCCESS;
}

// Is this process already running elevated?
static bool is_elevated() {
    HANDLE token = nullptr;
    if (!OpenProcessToken(GetCurrentProcess(), TOKEN_QUERY, &token)) return false;
    TOKEN_ELEVATION elev{};
    DWORD sz = 0;
    bool ok = GetTokenInformation(token, TokenElevation, &elev, sizeof(elev), &sz) != 0;
    CloseHandle(token);
    return ok && elev.TokenIsElevated != 0;
}

// Relaunching ourselves elevated via UAC (ShellExecuteW "runas" on our own
// path) is deliberately GONE. It re-executes this image from disk, which is a
// file-system event we control and can simply not have; it also puts a UAC
// prompt on screen at the exact moment of injection, which is a louder tell
// than running unelevated. Elevation is now a precondition the operator
// arranges (elevated terminal), not something the injector arranges for
// itself. See MEMORY_ONLY_PLAN.md M3.

int wmain(int argc, wchar_t** argv) {
    tee(L"[fvem] FiveM executor injector\n");
    tee(L"[fvem] injector build %hs %hs\n", __DATE__, __TIME__);

    if (!enable_debug_privilege()) {
        tee(L"[fvem] no SeDebugPrivilege (token elevated=%d) - an elevated "
            L"FiveM client will fail to open.\n", is_elevated() ? 1 : 0);
        tee(L"[fvem] launch this injector from an elevated terminal if the "
            L"client is elevated; it will not re-exec itself.\n");
        // Continues unelevated: a non-elevated client still opens fine.
    }

#ifdef FVEM_DEV_TOOLS
    // --dump <pid> <outfile>: read the target's game-code module image from
    // MEMORY (FiveM encrypts adhesive.dll on disk; only the loaded image is
    // plaintext) and write it to outfile for offline signature scanning.
    // DEV ONLY - gated out of every shipped build: a raw module-image writer is
    // a disk-write primitive, and the memory-only posture (MEMORY_ONLY_PLAN.md)
    // forbids the shipped injector from being able to write one at all.
    if (argc >= 2 && _wcsicmp(argv[1], L"--dump") == 0) {
        DWORD pid = (DWORD)wcstoul(argv[2], nullptr, 10);
        if (pid == 0) { tee(L"[fvem] --dump needs a pid\n"); return 1; }
        const wchar_t* out = argc >= 4 ? argv[3] : L"game_module.bin";
        HANDLE proc = OpenProcess(PROCESS_QUERY_INFORMATION | PROCESS_VM_READ, FALSE, pid);
        if (!proc) { tee(L"[fvem] cannot open pid %lu (err %lu)\n", pid, GetLastError()); return 2; }
        // Walk the target's PEB loader list (same walk the DLL uses) and pick
        // the largest module by SizeOfImage â€” that is the game code module.
        uintptr_t best_base = 0, best_size = 0;
        wchar_t best_name[MAX_PATH]{};
        {
            uintptr_t peb = 0;
            // PEB via NtQueryInformationProcess is overkill; the loader list
            // walk needs the target PEB which for a same-integrity-level x64
            // process we can read through ProcessBasicInformation.
            typedef LONG(NTAPI* _NtQIP)(HANDLE, int, void*, ULONG, ULONG*);
            auto pNt = reinterpret_cast<_NtQIP>(GetProcAddress(
                GetModuleHandleW(L"ntdll.dll"), "NtQueryInformationProcess"));
            PROCESS_BASIC_INFORMATION pbi{};
            if (pNt && pNt(proc, 0, &pbi, sizeof(pbi), nullptr) == 0 && pbi.PebBaseAddress) {
                uintptr_t ldr = 0;
                SIZE_T rd = 0;
                if (ReadProcessMemory(proc, (BYTE*)pbi.PebBaseAddress + 0x18, &ldr, 8, &rd)) {
                    uintptr_t head = ldr + 0x10;
                    uintptr_t cur = 0;
                    if (ReadProcessMemory(proc, (void*)head, &cur, 8, &rd)) {
                        while (cur && cur != head) {
                            uintptr_t dll = 0;
                            if (!ReadProcessMemory(proc, (void*)(cur + 0x30), &dll, 8, &rd)) break;
                            if (dll) {
                                // read SizeOfImage from NT headers of the module
                                uintptr_t dos = dll;
                                uint32_t e_lfanew = 0;
                                if (ReadProcessMemory(proc, (void*)(dos + 0x3C), &e_lfanew, 4, &rd)) {
                                    uintptr_t nt = dos + e_lfanew;
                                    uint32_t size_of_image = 0;
                                    // NT headers64: Signature(4) + FileHeader(20) + OptionalHeader.SizeOfImage at 0x50
                                    if (ReadProcessMemory(proc, (void*)(nt + 0x50), &size_of_image, 4, &rd) &&
                                        size_of_image > best_size) {
                                        best_size = size_of_image;
                                        best_base = dll;
                                        wchar_t name[64]{};
                                        if (ReadProcessMemory(proc, (void*)(cur + 0x48), name, 64, &rd))
                                            wcscpy_s(best_name, name);
                                    }
                                }
                            }
                            if (!ReadProcessMemory(proc, (void*)cur, &cur, 8, &rd)) break;
                        }
                    }
                }
            }
        }
        if (!best_base) { tee(L"[fvem] no modules found in target\n"); CloseHandle(proc); return 3; }
        tee(L"[fvem] game module %ls base=0x%llX size=0x%llX\n", best_name,
            (unsigned long long)best_base, (unsigned long long)best_size);
        // Read the image SECTION BY SECTION from the live headers (a single
        // giant ReadProcessMemory can fail on a sparse/guard page). Sections
        // map to the same RVA layout as the on-disk file.
        std::vector<uint8_t> img(best_size);
        SIZE_T got = 0;
        {
            uintptr_t base = best_base;
            uintptr_t dos = base;
            uint32_t e_lfanew = 0;
            SIZE_T rd = 0;
            ReadProcessMemory(proc, (void*)(dos + 0x3C), &e_lfanew, 4, &rd);
            uintptr_t nt = dos + e_lfanew;
            uint16_t nsections = 0;
            ReadProcessMemory(proc, (void*)(nt + 0x6), &nsections, 2, &rd);
            // IMAGE_FIRST_SECTION = nt + 0x18 (OptionalHeader) + sizeof(IMAGE_OPTIONAL_HEADER64)
            uintptr_t first_sec = nt + 0x18 + 240;
            // headers first
            uint32_t header_bytes = 0;
            ReadProcessMemory(proc, (void*)(nt + 0x54), &header_bytes, 4, &rd);
            if (header_bytes > 0x10000) header_bytes = 0x10000;
            if (ReadProcessMemory(proc, (void*)base, img.data(), header_bytes, &rd)) got += rd;
            for (int i = 0; i < nsections && i < 96; i++) {
                uintptr_t sh = first_sec + (uintptr_t)i * 40;
                uint32_t va = 0, raw_size = 0, raw_ptr = 0;
                ReadProcessMemory(proc, (void*)(sh + 0xC), &va, 4, &rd);
                ReadProcessMemory(proc, (void*)(sh + 0x10), &raw_size, 4, &rd);
                ReadProcessMemory(proc, (void*)(sh + 0x14), &raw_ptr, 4, &rd);
                if (raw_size == 0 || raw_ptr >= best_size) continue;
                SIZE_T n = (raw_size < best_size - raw_ptr) ? raw_size : (best_size - raw_ptr);
                SIZE_T r = 0;
                if (ReadProcessMemory(proc, (void*)(base + va), img.data() + raw_ptr, n, &r))
                    got += r;
            }
        }
        CloseHandle(proc);
        if (got == 0) { tee(L"[fvem] read failed\n"); return 4; }
        FILE* f = nullptr;
        if (_wfopen_s(&f, out, L"wb") != 0 || !f) { tee(L"[fvem] cannot write %ls\n", out); return 5; }
        fwrite(img.data(), 1, got, f);
        fclose(f);
        tee(L"[fvem] dumped %zu bytes to %ls\n", got, out);
        return 0;
    }
#endif // FVEM_DEV_TOOLS

    // resolve target pid: argv[1] = pid or process name
    DWORD pid = 0;
    if (argc >= 2) {
        pid = (DWORD)wcstoul(argv[1], nullptr, 10);
        if (pid == 0) {
            // try name match
            HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
            PROCESSENTRY32W pe32{ sizeof(pe32) };
            if (Process32FirstW(snap, &pe32)) {
                do {
                    if (!_wcsicmp(pe32.szExeFile, argv[1])) { pid = pe32.th32ProcessID; break; }
                } while (Process32NextW(snap, &pe32));
            }
            CloseHandle(snap);
        }
    }

    // zero-arg convenience: auto-attach to the running FiveM game process.
    // FiveM spawns several GTAProcess entries (launcher stubs + the real game
    // under cache\subprocess\), so prefer the one whose image path contains
    // "subprocess" â€” that is the actual client.
    if (pid == 0) {
        HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPPROCESS, 0);
        PROCESSENTRY32W pe32{ sizeof(pe32) };
        DWORD fallback = 0;
        if (Process32FirstW(snap, &pe32)) {
            do {
                wchar_t* name = pe32.szExeFile;
                if (_wcsnicmp(name, L"FiveM_", 6) || !wcsstr(name, L"GTAProcess.exe"))
                    continue;

                // Skip launcher stubs: FiveM spawns near-empty GTAProcess
                // entries; the real client has a multi-GB working set. 64 MB
                // is far below any live client, above any stub.
                HANDLE h = OpenProcess(PROCESS_QUERY_LIMITED_INFORMATION, FALSE, pe32.th32ProcessID);
                if (h) {
                    PROCESS_MEMORY_COUNTERS pmc{};
                    if (GetProcessMemoryInfo(h, &pmc, sizeof(pmc)) && pmc.WorkingSetSize) {
                        if (pmc.WorkingSetSize < 64ull * 1024 * 1024) { CloseHandle(h); continue; }
                    }
                    if (!fallback) fallback = pe32.th32ProcessID;

                    // Prefer the subprocess copy (the actual client).
                    wchar_t path[MAX_PATH]{};
                    DWORD len = MAX_PATH;
                    if (QueryFullProcessImageNameW(h, 0, path, &len) &&
                        wcsstr(path, L"subprocess")) {
                        pid = pe32.th32ProcessID;
                        CloseHandle(h);
                        break;
                    }
                    CloseHandle(h);
                }
            } while (Process32NextW(snap, &pe32));
        }
        CloseHandle(snap);
        if (!pid) pid = fallback;
        if (pid) tee(L"[fvem] auto-attached to pid %lu\n", pid);
    }

    if (pid == 0) {
        tee(L"[fvem] no FiveM process found; usage: fvem_injector <pid|process-name>\n");
        return 1;
    }

    // --- Armed-client guard (successor to the fixed-base MZ sentinel) ---
    // The mapped DLL creates-and-holds a PID-SCOPED mutex (name embeds the
    // game's pid) for the game's lifetime. A prior injector run that armed
    // THIS game leaves the object alive; seeing it already exist means a
    // second fvem would stack a second Present/WndProc hook chain into the
    // same client (double menu-toggle + two ImGui contexts per frame -> D3D
    // corruption -> crash). Refuse; the user relaunches THAT game to arm
    // fresh. An armed CRASHED-but-undead client (FiveM holds the process
    // through crashometry upload) no longer blocks a fresh game - the names
    // differ by pid. Replaces the old EnumProcesses + "read MZ at
    // 0x180000000" sweep; the base is randomized and the header erased.
    HANDLE arm = nullptr;
    {
        wchar_t mname[80]{};
        gfx::obf::arm_mutex_name(mname, 80, pid);
        arm = CreateMutexW(nullptr, FALSE, mname);
        if (arm && GetLastError() == ERROR_ALREADY_EXISTS) {
            tee(L"[fvem] that game (pid %lu) is already armed - relaunch it "
                L"(fresh process) before injecting again. Skipping.\n", pid);
            return 0;
        }
        // RELEASE THE PROBE HANDLE NOW, before mapping. The mapped DLL boots
        // on the trampoline thread within microseconds and CreateMutexW's the
        // SAME name as its long-term hold. While this injector lives, its
        // probe handle keeps the object alive - the DLL would then read
        // ERROR_ALREADY_EXISTS from ITS OWN INJECTOR and (with the double-arm
        // abort in entry.cpp) refuse to boot. Every injection would abort.
        // Closing here makes "already exists" mean exactly one thing: a real
        // prior fvem hold inside the game.
        if (arm) { CloseHandle(arm); arm = nullptr; }
    }

    // =========================================================================
    // Build the indirect-syscall table FIRST, then arm it locally so the
    // injector's OWN cross-process calls (open/alloc/write/thread) go through
    // the ntdll syscall gadget instead of the exported Win32 wrappers. Those
    // exports (VirtualAllocEx, WriteProcessMemory, CreateRemoteThread, even the
    // OpenProcess â†’ NtOpenProcess transition) are exactly what userland EDR
    // inline-hooks and the Kernel-Process ETW provider watch. Using the gate
    // here means the injection API set never surfaces a hooked call site with
    // our return address on it. The same {ssn,gadget} pairs are handed to the
    // mapped DLL too (ntdll shares a base across processes for a session, so
    // the absolute gadget is valid in both).
    // =========================================================================
    // The SSNs and the syscall gadget come from the ALREADY-MAPPED local ntdll
    // (below). The old on-disk "clean copy" read filled ntdll_raw and never
    // used it again - a pure disk touch with no consumer. Deleted: this binary
    // now reads nothing from the volume. If a pristine image is ever needed
    // (an EDR inline-hooked the loader's view), map the \KnownDlls\ntdll.dll
    // section a second time rather than reopening the file - see
    // MEMORY_ONLY_PLAN.md M1.3.
    uintptr_t local_ntdll = reinterpret_cast<uintptr_t>(GetModuleHandleW(L"ntdll.dll"));

    SyscallTable table{};
    table.allocate_virtual_memory.ssn = ssn_from_export((void*)local_ntdll, "NtAllocateVirtualMemory");
    table.protect_virtual_memory.ssn  = ssn_from_export((void*)local_ntdll, "NtProtectVirtualMemory");
    table.create_thread_ex.ssn        = ssn_from_export((void*)local_ntdll, "NtCreateThreadEx");
    table.open_process.ssn            = ssn_from_export((void*)local_ntdll, "NtOpenProcess");
    table.read_virtual_memory.ssn     = ssn_from_export((void*)local_ntdll, "NtReadVirtualMemory");
    table.write_virtual_memory.ssn    = ssn_from_export((void*)local_ntdll, "NtWriteVirtualMemory");
    table.close.ssn                   = ssn_from_export((void*)local_ntdll, "NtClose");
    table.set_information_thread.ssn  = ssn_from_export((void*)local_ntdll, "NtSetInformationThread");
    table.query_system_info.ssn       = ssn_from_export((void*)local_ntdll, "NtQuerySystemInformation");

    void* gadget = find_syscall_gadget(local_ntdll);
    if (!gadget) {
        tee(L"[fvem] no syscall gadget â€” install ntdll may be thunked\n");
        return 5;
    }
    tee(L"[fvem] syscall table: alloc=%u protect=%u createthread=%u openproc=%u "
        L"read=%u write=%u close=%u hide=%u query=%u gadget=%p\n",
        table.allocate_virtual_memory.ssn, table.protect_virtual_memory.ssn,
        table.create_thread_ex.ssn, table.open_process.ssn,
        table.read_virtual_memory.ssn, table.write_virtual_memory.ssn,
        table.close.ssn, table.set_information_thread.ssn,
        table.query_system_info.ssn, gadget);
    table.allocate_virtual_memory.gadget = gadget;
    table.protect_virtual_memory.gadget  = gadget;
    table.create_thread_ex.gadget        = gadget;
    table.open_process.gadget            = gadget;
    table.read_virtual_memory.gadget     = gadget;
    table.write_virtual_memory.gadget    = gadget;
    table.close.gadget                   = gadget;
    table.set_information_thread.gadget  = gadget;
    table.query_system_info.gadget       = gadget;

    // Arm the gate in this process. After this, sys::open_process/allocate/
    // write_mem/read_mem/protect/create_thread all dispatch indirectly.
    sys::set_table(&table);

    // --- Open the target through the gate (NtOpenProcess, not OpenProcess) ---
    const uint32_t want_access =
        PROCESS_CREATE_THREAD | PROCESS_QUERY_INFORMATION | PROCESS_VM_READ |
        PROCESS_VM_WRITE | PROCESS_VM_OPERATION;
    HANDLE proc = nullptr;
    NTSTATUS opst = sys::open_process(want_access, false, pid, reinterpret_cast<void**>(&proc));
    if (opst != 0 || !proc) {
        // Fallback to the Win32 path (elevated / handle-policy differences). Only
        // reached when the indirect open failed, so the common path stays clean.
        DWORD err = (DWORD)opst;
        proc = OpenProcess(want_access, FALSE, pid);
        if (!proc) {
            err = GetLastError();
            tee(L"[fvem] failed to open process %lu (ntst=0x%08lX win32err %lu)\n",
                pid, (unsigned long)opst, err);
            if (err == ERROR_ACCESS_DENIED) {
                tee(L"[fvem] ACCESS_DENIED - run this injector elevated (as admin) if FiveM is elevated, "
                        L"or the game process is protected\n");
            }
            return 2;
        }
    }

    // --- Payload: decrypted out of our own image. Never a file. -------------
    // fvem.dll is not read from the volume at any point in this process. The
    // packer (tools/payload_pack, build-time) baked the encrypted image into
    // this binary and it is XOR-decoded into private heap here, so there is no
    // fvem.dll on the machine for anything to find, copy or scan. This is the
    // payload half of MEMORY_ONLY_PLAN.md M1.
    std::vector<uint8_t> dll(payload::kSize);
    for (size_t i = 0; i < payload::kSize; ++i)
        dll[i] = fvem_payload_start[i] ^ payload::kKey[i & 31];

    // Self-check before a single byte reaches the target: fails on a stale blob
    // packed against a different source tree, or a corrupted image.
    if (fnv1a(dll.data(), dll.size()) != payload::kPlainHash) {
        tee(L"[fvem] payload self-check FAILED (blob corrupt or stale)\n");
        return 3;
    }
    tee(L"[fvem] payload %u bytes, decoded in memory (no payload file)\n",
        (unsigned)payload::kSize);

    // Echo the DLL's own embedded build stamp ("Mon DD YYYY HH:MM:SS", __DATE__
    // and __TIME__ adjacent in .rdata). A stale DLL loaded from disk beside the
    // injector was the #1 "I injected the fix but saw the old bug" cause; there
    // is no file to go stale any more, but the stamp still pins which build is
    // inside this exe, which is what a launch needs to be self-diagnosing.
    {
        const std::string txt(reinterpret_cast<const char*>(dll.data()), dll.size());
        static const char* mon[] = {"Jan","Feb","Mar","Apr","May","Jun",
                                    "Jul","Aug","Sep","Oct","Nov","Dec"};
        std::string stamp;
        for (size_t p = 0; p + 25 < txt.size(); ++p) {
            bool ok = false;
            for (const char* m : mon)
                if (txt.compare(p, 3, m) == 0) { ok = true; break; }
            if (!ok || txt[p + 3] != ' ') continue;
            int dd = 0;
            size_t k = p + 4;
            while (k < txt.size() && txt[k] == ' ') ++k;
            while (k < txt.size() && txt[k] >= '0' && txt[k] <= '9')
                dd = dd * 10 + (txt[k++] - '0');
            if (dd < 1 || dd > 31 || k >= txt.size() || txt[k] != ' ') continue;
            if (txt.compare(k + 1, 4, "2026") != 0 &&
                txt.compare(k + 1, 4, "2025") != 0) continue;
            k += 5;
            if (k >= txt.size() || txt[k] != ' ') continue;
            int h, mi, s;
            if (sscanf_s(txt.c_str() + k + 1, "%d:%d:%d", &h, &mi, &s) != 3 ||
                h > 23 || mi > 59 || s > 59) continue;
            char b[40];
            sprintf_s(b, "%s %02d %s %02d:%02d:%02d",
                      txt.substr(p, 3).c_str(), dd, txt.substr(k + 1, 4).c_str(), h, mi, s);
            std::string ts(b);
            if (stamp.empty() || ts > stamp) stamp = ts;   // latest build wins
        }
        tee(L"[fvem] payload stamp: %hs\n", stamp.empty() ? "(unparsed)" : stamp.c_str());
    }

    // (Double-injection is already handled above by the session arm-mutex probe;
    //  the base is randomized, so a fixed-base MZ re-check would be meaningless.)

    // Allocate the table in the target process so the mapped DLL can read it.
    void* table_remote = nullptr;
    {
        SIZE_T sz = sizeof(table);
        if (sys::allocate(proc, &table_remote, &sz, PAGE_READWRITE,
                          MEM_COMMIT | MEM_RESERVE) != 0 || !table_remote) {
            tee(L"[fvem] failed to stage syscall table in target\n");
            return 6;
        }
        SIZE_T wr = 0;
        if (sys::write_mem(proc, table_remote, &table, sizeof(table), &wr) != 0) {
            tee(L"[fvem] failed to write syscall table\n");
            return 6;
        }
    }

    // --- Manual map the DLL into the TARGET process (pe.cpp routes through the
    //     gate; it commits per-section so the image is never a whole RWX blob) ---
    gfx::pe::MappedImage img;
    if (!pe::map_in_target(proc, dll, img)) {
        tee(L"[fvem] manual map into target failed\n");
        return 7;
    }

    // The image is in the target now, so our plaintext working copy is dead
    // weight - wipe it rather than leave a pageable copy of the payload in this
    // process (MEMORY_ONLY_PLAN.md M3.1 covers the page-file side).
    SecureZeroMemory(dll.data(), dll.size());
    dll.clear();
    dll.shrink_to_fit();

    // Pass the table pointer + target pid + the boot-trampoline coordinates to
    // the DLL entry (reserved -> BootCtx). The tramp coordinate is passed so the
    // DLL can NtFree it the moment the boot thread is clear of it: a private
    // executable page with no backing file object is the single loudest
    // memory-scan signature a manual map leaves, and leaving it resident is
    // unacceptable. Keep BootCtx layout byte-identical to the one in entry.cpp.
    struct BootCtx { SyscallTable* table; DWORD pid; void* tramp; SIZE_T tramp_size; };

    uint8_t code[42]{};
    code[0] = 0x48; code[1] = 0xB9; // mov rcx, imm64 (hModule)
    uintptr_t v = reinterpret_cast<uintptr_t>(img.base);
    memcpy(code + 2, &v, 8);
    code[10] = 0x48; code[11] = 0xBA; // mov rdx, imm64 (DLL_PROCESS_ATTACH=1)
    v = 1;
    memcpy(code + 12, &v, 8);
    code[20] = 0x49; code[21] = 0xB8; // mov r8, imm64 (reserved = BootCtx*) â€” filled after ctx alloc
    BootCtx ctx{ reinterpret_cast<SyscallTable*>(table_remote), pid, nullptr, 0 };
    v = reinterpret_cast<uintptr_t>(&ctx);  // placeholder; real pointer written below
    memcpy(code + 22, &v, 8);
    code[30] = 0x48; code[31] = 0xB8; // mov rax, imm64 (entry)
    v = reinterpret_cast<uintptr_t>(img.entry);
    memcpy(code + 32, &v, 8);
    code[40] = 0xFF; code[41] = 0xE0; // jmp rax

    // Stage the BootCtx in the target and patch the trampoline's r8 with its
    // real address (the local &ctx is not valid in the target).
    void* ctx_remote = nullptr;
    {
        SIZE_T sz = sizeof(ctx);
        if (sys::allocate(proc, &ctx_remote, &sz, PAGE_READWRITE,
                          MEM_COMMIT | MEM_RESERVE) != 0 || !ctx_remote) {
            tee(L"[fvem] boot ctx alloc failed\n");
            return 7;
        }
    }
    ctx.tramp = nullptr; // set once the tramp is allocated (below); written to remote now, rewritten after
    {
        SIZE_T wr = 0;
        sys::write_mem(proc, ctx_remote, &ctx, sizeof(ctx), &wr);
    }
    // r8 of the trampoline = ctx_remote.
    {
        uintptr_t cr = reinterpret_cast<uintptr_t>(ctx_remote);
        memcpy(code + 22, &cr, 8);
    }

    // Boot trampoline: commit RW, write the stub, then flip to RX. It is never
    // RWX, and the DLL frees it during boot (see entry.cpp), so no file-less
    // executable page survives into gameplay.
    void* tramp = nullptr;
    SIZE_T tramp_sz = sizeof(code);
    if (sys::allocate(proc, &tramp, &tramp_sz, PAGE_READWRITE,
                      MEM_COMMIT | MEM_RESERVE) != 0 || !tramp) {
        tee(L"[fvem] trampoline alloc failed\n");
        return 7;
    }
    tramp_sz = sizeof(code);
    {
        SIZE_T wrote = 0;
        if (sys::write_mem(proc, tramp, code, sizeof(code), &wrote) != 0) {
            tee(L"[fvem] trampoline write failed\n");
            return 7;
        }
    }
    {
        void* p = tramp; SIZE_T s = sizeof(code); uint32_t old = 0;
        sys::protect(proc, &p, &s, PAGE_EXECUTE_READ, &old);
    }
    // Record the tramp in the remote BootCtx so the DLL can free it.
    ctx.tramp = tramp;
    ctx.tramp_size = sizeof(code);
    {
        SIZE_T wr = 0;
        sys::write_mem(proc, ctx_remote, &ctx, sizeof(ctx), &wr);
    }

    // Start the remote thread through the gate â€” NtCreateThreadEx via the
    // indirect gadget, not the export. The DLL self-arranges its evasion from
    // here; the injector stays clean.
    HANDLE hLoad = nullptr;
    NTSTATUS st = sys::create_thread(proc, &hLoad, THREAD_ALL_ACCESS, nullptr,
                                     0 /* CreateFlags */, tramp, nullptr, /*suspended*/ false);
    if (st != 0 || !hLoad) {
        tee(L"[fvem] remote thread failed (0x%08lX)\n", (unsigned long)st);
        return 8;
    }

    tee(L"[fvem] mapped @ %p, thread %p running\n", img.base, hLoad);
    WaitForSingleObject(hLoad, 3500);
    CloseHandle(proc);
    tee(L"[fvem] done\n");
    return 0;
}