param([string]$DumpPath)
# Minimal minidump stream-dir parser (PDMD header).
$fs = [System.IO.File]::OpenRead($DumpPath)
$br = New-Object System.IO.BinaryReader($fs)
try {
    $sig = $br.ReadUInt32()
    $ver = $br.ReadUInt32()
    $nstreams = $br.ReadUInt32()
    $ts = $br.ReadUInt32()
    $sdir = $br.ReadUInt32()
    "sig=0x$('{0:X8}' -f $sig) streams=$nstreams sdir=0x$('{0:X}' -f $sdir)"
    for ($i = 0; $i -lt $nstreams; $i++) {
        $fs.Position = $sdir + $i * 12
        $type = $br.ReadUInt32()
        $dsz = $br.ReadUInt32()
        $dof = $br.ReadUInt32()
        if ($type -eq 6) {
            "EXCEPTION stream size=$dsz at=0x$('{0:X}' -f $dof)"
            $save = $fs.Position
            $fs.Position = $dof
            $code = $br.ReadUInt32()
            $flags = $br.ReadUInt32()
            $np = $br.ReadUInt32()
            $addr = $br.ReadUInt64()
            $tid = $br.ReadUInt32()
            "  code=0x$('{0:X8}' -f $code) flags=0x$('{0:X8}' -f $flags) np=$np addr=0x$('{0:X}' -f $addr) thread=$tid"
            for ($p = 0; $p -lt $np; $p++) {
                $pv = $br.ReadUInt64()
                "  param$p = 0x$('{0:X}' -f $pv)"
            }
            # AMD64 CONTEXT is stream 7; exception stream often embeds one after params.
            $fs.Position = $save
        } elseif ($type -eq 7) {
            "AMD64 CONTEXT stream size=$dsz at=0x$('{0:X}' -f $dof)"
            $save = $fs.Position
            $fs.Position = $dof
            $ctx = New-Object byte[] $dsz
            [void]$fs.Read($ctx, 0, $dsz)
            $rip = [BitConverter]::ToUInt64($ctx, 0xF8)
            $rsp = [BitConverter]::ToUInt64($ctx, 0x98)
            $rax = [BitConverter]::ToUInt64($ctx, 0x78)
            "  RIP=0x$('{0:X}' -f $rip) RSP=0x$('{0:X}' -f $rsp) RAX=0x$('{0:X}' -f $rax)"
            $fs.Position = $save
        } elseif ($type -eq 1) { # module list
            "MODULE stream size=$dsz at=0x$('{0:X}' -f $dof)"
        }
    }
} finally {
    $br.Dispose()
    $fs.Dispose()
}
