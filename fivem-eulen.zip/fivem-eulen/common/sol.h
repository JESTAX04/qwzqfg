// language: C++, target: Windows 11, MSVC (x64)
// sol2 lazy-initialization unit. Keeps the heavy sol2 header out of the PCH
// so other TUs compile fast and don't drag Lua's C++ template soup.
#pragma once
#include <sol/sol.hpp>

namespace gfx {

// Provide the sol2 state holder. The actual lua_State* comes from core/lua_state.cpp
// after we pattern-scan the game's live state (or create a fresh one when we own
// the process). `view` is a heap view over a foreign (game) state; `state` is
// only owned when `own` is true.
struct LuaRuntime {
    sol::state*       state = nullptr; // owned iff own == true
    sol::state_view*  view  = nullptr; // view over the game's state (not owned)
    bool              own   = false;

    LuaRuntime() = default;
    // Construct a view over an externally-owned lua_State* (FiveM's).
    explicit LuaRuntime(void* L)
        : view(new sol::state_view(reinterpret_cast<lua_State*>(L))) {}
    ~LuaRuntime() {
        delete view;
        if (own) delete state;
    }
    LuaRuntime(const LuaRuntime&) = delete;
    LuaRuntime& operator=(const LuaRuntime&) = delete;
};

// Helper: run a lua chunk on whichever state is active, returning error text.
const char* run_lua(LuaRuntime& rt, const char* script, size_t len);

} // namespace gfx
