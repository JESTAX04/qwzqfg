// language: C++, target: Windows 11, MSVC (x64)
// Manual mapper core. Maps a raw PE without LoadLibrary, without a PEB entry,
// relocates against the actual base, and fixes the import table via the target
// process's loaded modules (resolve through in-memory headers, not the loader list).
#include "pe.h"
#include "syscalls.h"
#include "../core/log.h"
#include <cstring>
#include <algorithm>
#include <cwchar>

namespace gfx::pe {

// Append a diagnostics line to %TEMP%\fvem_injector.log (the injector's tee
// target), so resolution failures are visible even from a hidden elevated run.
// Compiled out of Release: the plaintext log is post-hoc evidence and must not
// exist on a shipped run.
static void diag(const char* fmt, ...) {
#ifdef FVEM_LOG
    char buf[384];
    va_list ap;
    va_start(ap, fmt);
    vsprintf_s(buf, sizeof(buf), fmt, ap);
    va_end(ap);
    wchar_t dir[MAX_PATH];
    if (GetTempPathW(MAX_PATH, dir)) {
        wchar_t path[MAX_PATH];
        swprintf_s(path, MAX_PATH, L"%sfvem_injector.log", dir);
        FILE* f = nullptr;
        if (_wfopen_s(&f, path, L"a") == 0 && f) {
            fputs(buf, f);
            fputc('\n', f);
            fclose(f);
        }
    }
#else
    (void)fmt;
#endif
}

static IMAGE_NT_HEADERS64* nt(void* base) {
    auto* dos = static_cast<IMAGE_DOS_HEADER*>(base);
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return nullptr;
    auto* h = reinterpret_cast<IMAGE_NT_HEADERS64*>(
        reinterpret_cast<uintptr_t>(base) + dos->e_lfanew);
    if (h->Signature != IMAGE_NT_SIGNATURE) return nullptr;
    return h;
}

void* rva_to_ptr(void* base, uint32_t rva) {
    return reinterpret_cast<void*>(reinterpret_cast<uintptr_t>(base) + rva);
}

// Convert an RVA to a raw FILE offset using the section table (RVA != file
// offset when SectionAlignment > FileAlignment).
static uintptr_t rva_to_raw(const std::vector<uint8_t>& raw,
                            const IMAGE_NT_HEADERS64* h, uint32_t rva) {
    if (rva < h->OptionalHeader.SizeOfHeaders) return rva;
    auto* sec = IMAGE_FIRST_SECTION(h);
    for (int i = 0; i < h->FileHeader.NumberOfSections; i++, sec++) {
        uint32_t vsz = std::max(sec->Misc.VirtualSize, sec->SizeOfRawData);
        if (rva >= sec->VirtualAddress && rva < sec->VirtualAddress + vsz) {
            uintptr_t off = sec->PointerToRawData + (rva - sec->VirtualAddress);
            if (off < raw.size()) return off;
        }
    }
    return 0;
}

// Local (raw-file) pointer for an RVA.
static void* rva_raw_ptr(const std::vector<uint8_t>& raw, const IMAGE_NT_HEADERS64* h, uint32_t rva) {
    return const_cast<uint8_t*>(raw.data()) + rva_to_raw(raw, h, rva);
}

void* find_export(void* base, const char* name) {
    auto* h = nt(base);
    if (!h) return nullptr;
    auto& dd = h->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT];
    if (!dd.VirtualAddress) return nullptr;
    auto* exp = static_cast<IMAGE_EXPORT_DIRECTORY*>(rva_to_ptr(base, dd.VirtualAddress));
    auto* names = static_cast<uint32_t*>(rva_to_ptr(base, exp->AddressOfNames));
    auto* ords  = static_cast<uint16_t*>(rva_to_ptr(base, exp->AddressOfNameOrdinals));
    auto* funcs = static_cast<uint32_t*>(rva_to_ptr(base, exp->AddressOfFunctions));
    for (uint32_t i = 0; i < exp->NumberOfNames; i++) {
        const char* n = static_cast<const char*>(rva_to_ptr(base, names[i]));
        if (!strcmp(n, name)) return rva_to_ptr(base, funcs[ords[i]]);
    }
    return nullptr;
}

uintptr_t module_base_from_ptr(void* ptr_inside) {
    uintptr_t p = reinterpret_cast<uintptr_t>(ptr_inside) & ~0xFFFFull; // 64K align
    for (int i = 0; i < 16384; i++, p -= 0x10000) {
        __try {
            auto* dos = reinterpret_cast<IMAGE_DOS_HEADER*>(p);
            if (dos->e_magic == IMAGE_DOS_SIGNATURE) {
                auto* h = reinterpret_cast<IMAGE_NT_HEADERS64*>(p + dos->e_lfanew);
                if (h->Signature == IMAGE_NT_SIGNATURE) return p;
            }
        } __except (probe_filter(GetExceptionCode(), GetExceptionInformation())) {}
    }
    return 0;
}

void* find_export_from_loaded(uintptr_t base, const char* name) {
    return find_export(reinterpret_cast<void*>(base), name);
}

bool manual_map(const std::vector<uint8_t>& raw, MappedImage& out) {
    if (raw.size() < sizeof(IMAGE_DOS_HEADER)) return false;
    auto* dos = reinterpret_cast<const IMAGE_DOS_HEADER*>(raw.data());
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return false;
    auto* h = reinterpret_cast<const IMAGE_NT_HEADERS64*>(
        raw.data() + dos->e_lfanew);
    if (h->Signature != IMAGE_NT_SIGNATURE) return false;

    const size_t image_bytes = h->OptionalHeader.SizeOfImage;
    // Commit RW (never RWX): fixups run while the pages are writable, then
    // finalize_image_protections() drops each section to its real RX/RW/RO so no
    // executable-and-writable region ever exists in the mapped image.
    void* mem = VirtualAlloc(
        reinterpret_cast<void*>(h->OptionalHeader.ImageBase),
        image_bytes, MEM_RESERVE | MEM_COMMIT, PAGE_READWRITE);
    if (!mem) mem = VirtualAlloc(nullptr, image_bytes, MEM_RESERVE | MEM_COMMIT,
                                 PAGE_READWRITE);
    if (!mem) return false;

    const size_t header_bytes = h->OptionalHeader.SizeOfHeaders;
    memcpy(mem, raw.data(), std::min(header_bytes, raw.size()));

    auto* sec = IMAGE_FIRST_SECTION(h);
    for (int i = 0; i < h->FileHeader.NumberOfSections; i++, sec++) {
        if (sec->SizeOfRawData == 0) continue;
        void* dst = rva_to_ptr(mem, sec->VirtualAddress);
        memcpy(dst, raw.data() + sec->PointerToRawData, sec->SizeOfRawData);
    }

    // Relocations against actual base.
    const auto delta = reinterpret_cast<uintptr_t>(mem) - h->OptionalHeader.ImageBase;
    if (delta != 0) {
        auto& rdd = h->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC];
        if (rdd.VirtualAddress) {
            auto* reloc = static_cast<IMAGE_BASE_RELOCATION*>(
                rva_to_ptr(mem, rdd.VirtualAddress));
            const uint8_t* end = reinterpret_cast<const uint8_t*>(reloc) + rdd.Size;
            while (reinterpret_cast<uintptr_t>(reloc) < reinterpret_cast<uintptr_t>(end)
                   && reloc->VirtualAddress) {
                const size_t count = (reloc->SizeOfBlock - sizeof(IMAGE_BASE_RELOCATION)) / 2;
                auto* entries = reinterpret_cast<uint16_t*>(reloc + 1);
                for (size_t j = 0; j < count; j++) {
                    const uint16_t e = entries[j];
                    if ((e >> 12) == IMAGE_REL_BASED_DIR64) {
                        auto* p = static_cast<uint64_t*>(
                            rva_to_ptr(mem, reloc->VirtualAddress + (e & 0xFFF)));
                        *p += delta;
                    }
                }
                reloc = reinterpret_cast<IMAGE_BASE_RELOCATION*>(
                    reinterpret_cast<uint8_t*>(reloc) + reloc->SizeOfBlock);
            }
        }
    }

    // Imports: fix IAT by resolving against loaded modules via in-memory headers.
    auto& idd = h->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
    if (idd.VirtualAddress) {
        auto* desc = static_cast<IMAGE_IMPORT_DESCRIPTOR*>(rva_to_ptr(mem, idd.VirtualAddress));
        while (desc->Name) {
            const char* modname = static_cast<const char*>(rva_to_ptr(mem, desc->Name));
            HMODULE hmod = GetModuleHandleA(modname);
            if (hmod) {
                uintptr_t base = reinterpret_cast<uintptr_t>(hmod);
                auto* thunk = static_cast<uintptr_t*>(rva_to_ptr(mem, desc->FirstThunk));
                auto* orig  = desc->OriginalFirstThunk
                    ? static_cast<uintptr_t*>(rva_to_ptr(mem, desc->OriginalFirstThunk))
                    : thunk;
                for (size_t i = 0; orig[i]; i++) {
                    uintptr_t val = orig[i];
                    if (val & 0x8000000000000000ull) {
                        thunk[i] = base + static_cast<uint32_t>(val & 0xFFFF);
                    } else {
                        auto* by_name = static_cast<IMAGE_IMPORT_BY_NAME*>(
                            rva_to_ptr(mem, static_cast<uint32_t>(val)));
                        thunk[i] = reinterpret_cast<uintptr_t>(
                            find_export_from_loaded(base, by_name->Name));
                    }
                }
            }
            desc++;
        }
    }

    out.base = mem;
    out.entry = rva_to_ptr(mem, h->OptionalHeader.AddressOfEntryPoint);
    out.image_size = image_bytes;

    // Drop every region to its final protection (headers RO, code RX, data RW/RO).
    {
        DWORD oldp = 0;
        VirtualProtect(mem, h->OptionalHeader.SizeOfHeaders, PAGE_READONLY, &oldp);
        auto* s = IMAGE_FIRST_SECTION(h);
        for (int i = 0; i < h->FileHeader.NumberOfSections; i++, s++) {
            if (s->Misc.VirtualSize == 0) continue;
            DWORD prot;
            if (s->Characteristics & IMAGE_SCN_MEM_EXECUTE) prot = PAGE_EXECUTE_READ;
            else if (s->Characteristics & IMAGE_SCN_MEM_WRITE) prot = PAGE_READWRITE;
            else prot = PAGE_READONLY;
            DWORD o = 0;
            VirtualProtect(rva_to_ptr(mem, s->VirtualAddress), s->Misc.VirtualSize, prot, &o);
        }
    }
    return true;
}

// Read a pointer-sized value from the target.
static bool read_remote(HANDLE proc, uintptr_t addr, uintptr_t& out) {
    SIZE_T rd = 0;
    return ReadProcessMemory(proc, reinterpret_cast<void*>(addr), &out,
                             sizeof(out), &rd) != 0 && rd == sizeof(out);
}

// Read a UNICODE_STRING (DllBase walk uses FullDllName at +0x48).
static bool read_remote_name(HANDLE proc, uintptr_t addr, wchar_t* out, size_t cap) {
    uint16_t len = 0;
    SIZE_T rd = 0;
    if (!ReadProcessMemory(proc, reinterpret_cast<void*>(addr), &len,
                           sizeof(len), &rd) || rd != sizeof(len)) return false;
    if (len > 512) len = 512;
    uintptr_t buf = 0;
    if (!read_remote(proc, addr + 8, buf) || !buf) return false;
    size_t chars = len / sizeof(wchar_t);
    if (chars >= cap) chars = cap - 1;
    if (!ReadProcessMemory(proc, reinterpret_cast<void*>(buf), out,
                           chars * sizeof(wchar_t), &rd)) return false;
    out[chars] = 0;
    return true;
}

// Find a loaded module's base in the TARGET by walking its PEB loader list.
static uintptr_t remote_module_base(HANDLE proc, const wchar_t* want) {
    // PEB via NtQueryInformationProcess(ProcessBasicInformation).
    typedef LONG(NTAPI* _NtQIP)(HANDLE, ULONG, void*, ULONG, ULONG*);
    auto pNtQIP = reinterpret_cast<_NtQIP>(
        GetProcAddress(GetModuleHandleW(L"ntdll.dll"), "NtQueryInformationProcess"));
    if (!pNtQIP) return 0;
    struct PBI { void* ExitStatus; void* PebBaseAddress; void* AffinityMask;
                 LONG BasePriority; ULONG_PTR UniqueProcessId; ULONG_PTR InheritedFromUniqueProcessId; };
    PBI pbi{};
    if (pNtQIP(proc, 0 /*ProcessBasicInformation*/, &pbi, sizeof(pbi), nullptr) != 0)
        return 0;
    if (!pbi.PebBaseAddress) return 0;

    uintptr_t peb = reinterpret_cast<uintptr_t>(pbi.PebBaseAddress);
    uintptr_t ldr = 0;
    if (!read_remote(proc, peb + 0x18, ldr) || !ldr) return 0;
    uintptr_t head = ldr + 0x10; // InLoadOrderModuleList
    uintptr_t cur = 0;
    if (!read_remote(proc, head, cur) || !cur) return 0;

    int guard = 0;
    while (cur && cur != head && guard++ < 1024) {
        uintptr_t dll = 0;
        if (read_remote(proc, cur + 0x30, dll) && dll) { // DllBase
            wchar_t name[260]{};
            if (read_remote_name(proc, cur + 0x48, name, 260)) { // FullDllName
                const wchar_t* slash = wcsrchr(name, L'\\');
                const wchar_t* base_name = slash ? slash + 1 : name;
                if (_wcsicmp(base_name, want) == 0) return dll;
            }
        }
        if (!read_remote(proc, cur, cur)) break; // Flink
    }
    return 0;
}

// Resolve one imported function in the target: find the module there, then
// read its export table from the LOCAL loaded copy (same image file â†’ same
// RVAs) and return module_base + RVA.
// (inline logic lives in map_in_target; kept here for readability)

// Resolve ONE import to a target-space address, following forwarder chains
// ("KERNELBASE.GetTempPathW" â†’ resolve KERNELBASE's export in the target).
// Returns 0 on unresolvable.
static uintptr_t resolve_import_rec(HANDLE proc, const char* mod, const char* name, int depth);

// Normalize a module name to "<name>.dll": append .dll only when the name
// does not already end in ".dll" (case-insensitive). The old check tested
// only the last character, so "d3d11.dll" became "d3d11.dll.dll" and the
// target PEB walk never matched, leaving the import unresolved.
static void normalize_mod_name(const char* mod, wchar_t* wmod, size_t cap) {
    size_t wn = 0;
    for (; mod[wn] && wn < cap - 8; wn++) wmod[wn] = static_cast<wchar_t>(mod[wn]);
    if (wn >= 4 &&
        (wmod[wn-4] == L'.' || wmod[wn-4] == L'.') &&
        (wmod[wn-3] == L'd' || wmod[wn-3] == L'D') &&
        (wmod[wn-2] == L'l' || wmod[wn-2] == L'L') &&
        (wmod[wn-1] == L'l' || wmod[wn-1] == L'L')) {
        wmod[wn] = 0;
        return;
    }
    wmod[wn++] = L'.'; wmod[wn++] = L'd'; wmod[wn++] = L'l'; wmod[wn++] = L'l';
    wmod[wn] = 0;
}

// Import by ordinal: index the module's export table directly (ordinal -
// OrdinalBase), then run the same forwarder check.
static uintptr_t resolve_import_ordinal(HANDLE proc, const char* mod, uint16_t ordinal) {
    if (!mod) return 0;

    wchar_t wmod[128];
    normalize_mod_name(mod, wmod, 128);

    uintptr_t tmod = remote_module_base(proc, wmod);
    if (!tmod) {
        HMODULE local = GetModuleHandleA(mod);
        if (!local) return 0;
        tmod = reinterpret_cast<uintptr_t>(local);
    }

    HMODULE local = GetModuleHandleA(mod);
    bool local_loaded = false;
    if (!local) { local = LoadLibraryA(mod); local_loaded = (local != nullptr); }
    if (!local) return 0;
    uintptr_t lb = reinterpret_cast<uintptr_t>(local);

    auto* h = nt(reinterpret_cast<void*>(lb));
    auto& dd = h->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT];
    uint32_t rva = 0;
    uint32_t dir_va = 0, dir_sz = 0;
    if (dd.VirtualAddress && dd.Size) {
        dir_va = dd.VirtualAddress; dir_sz = dd.Size;
        auto* exp = static_cast<IMAGE_EXPORT_DIRECTORY*>(
            rva_to_ptr(reinterpret_cast<void*>(lb), dd.VirtualAddress));
        uint32_t idx = static_cast<uint32_t>(ordinal) - exp->Base;
        if (idx < exp->NumberOfFunctions) {
            auto* funcs = static_cast<uint32_t*>(
                rva_to_ptr(reinterpret_cast<void*>(lb), exp->AddressOfFunctions));
            rva = funcs[idx];
        }
    }

    if (local_loaded) FreeLibrary(local);
    if (!rva) return 0;

    // Forwarder? RVA into the export directory â†’ string "MODULE.NAME".
    if (rva >= dir_va && rva < dir_va + dir_sz) {
        const char* fwd = reinterpret_cast<const char*>(lb + rva);
        const char* dot = strchr(fwd, '.');
        if (dot && (dot - fwd) < 64 && strlen(dot + 1) < 128) {
            char fmod[64]{}, fname[128]{};
            memcpy(fmod, fwd, static_cast<size_t>(dot - fwd));
            strcpy_s(fname, dot + 1);
            return resolve_import_rec(proc, fmod, fname, 0);
        }
        return 0;
    }
    return tmod + rva;
}

static uintptr_t resolve_import_rec(HANDLE proc, const char* mod, const char* name, int depth) {
    if (depth > 6 || !mod || !name) return 0;

    // Target module base (PEB walk) with .dll normalization for forwarders.
    wchar_t wmod[128];
    normalize_mod_name(mod, wmod, 128);

    uintptr_t tmod = remote_module_base(proc, wmod);
    if (!tmod) {
        // Fall back to the local base (system DLLs share a base per boot).
        HMODULE local = GetModuleHandleA(mod);
        if (!local) {
            diag("[fvem] resolver: '%s' remote=0 local=0", mod);
            return 0;
        }
        tmod = reinterpret_cast<uintptr_t>(local);
    }

    // Local copy of the same module â†’ same export table.
    HMODULE local = GetModuleHandleA(mod);
    bool local_loaded = false;
    if (!local) { local = LoadLibraryA(mod); local_loaded = (local != nullptr); }
    if (!local) return 0;
    uintptr_t lb = reinterpret_cast<uintptr_t>(local);

    uintptr_t local_export = reinterpret_cast<uintptr_t>(
        find_export_from_loaded(lb, name));
    if (!local_export) {
        if (local_loaded) FreeLibrary(local);
        return 0;
    }
    uintptr_t rva = local_export - lb;

    // Forwarder? The export slot points INTO the module's own export
    // directory â€” the entry holds a string "MODULE.NAME" instead of code.
    bool forwarded = false;
    {
        auto* h = nt(reinterpret_cast<void*>(lb));
        auto& dd = h->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXPORT];
        if (dd.VirtualAddress && dd.Size &&
            rva >= dd.VirtualAddress && rva < dd.VirtualAddress + dd.Size)
            forwarded = true;
    }

    if (forwarded) {
        // Parse "MODULE.FUNCTION" from the forwarder string.
        const char* fwd = reinterpret_cast<const char*>(local_export);
        const char* dot = strchr(fwd, '.');
        uintptr_t out = 0;
        if (dot && (dot - fwd) < 64 && strlen(dot + 1) < 128) {
            char fmod[64]{}, fname[128]{};
            memcpy(fmod, fwd, static_cast<size_t>(dot - fwd));
            strcpy_s(fname, dot + 1);
            out = resolve_import_rec(proc, fmod, fname, depth + 1);
        }
        if (local_loaded) FreeLibrary(local);
        return out;
    }

    if (local_loaded) FreeLibrary(local);
    return tmod + rva;
}

bool map_in_target(HANDLE proc, const std::vector<uint8_t>& raw, MappedImage& out) {
    if (raw.size() < sizeof(IMAGE_DOS_HEADER)) return false;
    auto* dos = reinterpret_cast<const IMAGE_DOS_HEADER*>(raw.data());
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return false;
    auto* h = reinterpret_cast<const IMAGE_NT_HEADERS64*>(raw.data() + dos->e_lfanew);
    if (h->Signature != IMAGE_NT_SIGNATURE) return false;

    const size_t image_bytes = h->OptionalHeader.SizeOfImage;
    // Commit RW through the indirect gate (never RWX). Fixups happen while the
    // region is writable; finalize_image_protections below drops it to the
    // per-section RX/RW/RO before the injector ever starts a thread here, so a
    // scanner sampling this window cannot catch a file-less RWX PE blob.
    // Map at a system-picked (ASLR) base, NOT the fixed 0x180000000 preferred
    // base. A repeating image base is itself a scanner probe target ("MZ at the
    // same address in every armed client, absent from the loader list" is the
    // canonical manual-map IOC), and with the double-injection sentinel now a
    // session mutex the fixed base buys nothing. The relocation pass below
    // applies DIR64 fixups against wherever the kernel actually placed us.
    void* mem = nullptr;
    {
        SIZE_T sz = image_bytes;
        if (sys::allocate(proc, &mem, &sz, PAGE_READWRITE, MEM_COMMIT | MEM_RESERVE) != 0)
            return false;
    }
    if (!mem) return false;

    const size_t header_bytes = h->OptionalHeader.SizeOfHeaders;
    SIZE_T written = 0;
    if (sys::write_mem(proc, mem, raw.data(), std::min(header_bytes, raw.size()),
                       &written) != 0 || written == 0) return false;

    auto* sec = IMAGE_FIRST_SECTION(h);
    for (int i = 0; i < h->FileHeader.NumberOfSections; i++, sec++) {
        if (sec->SizeOfRawData == 0) continue;
        void* dst = rva_to_ptr(mem, sec->VirtualAddress);
        if (sys::write_mem(proc, dst, raw.data() + sec->PointerToRawData,
                           sec->SizeOfRawData, &written) != 0 || written == 0) return false;
    }

    // Relocations against the remote base. The relocation BLOCKS are parsed
    // from the raw file copy (local memory); only the value fixups touch the
    // target (remote memory), routed through NtRead/NtWriteVirtualMemory.
    const auto delta = reinterpret_cast<uintptr_t>(mem) - h->OptionalHeader.ImageBase;
    if (delta != 0) {
        auto& rdd = h->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_BASERELOC];
        if (rdd.VirtualAddress) {
            auto* reloc = static_cast<IMAGE_BASE_RELOCATION*>(rva_raw_ptr(raw, h, rdd.VirtualAddress));
            const uint8_t* end = reinterpret_cast<const uint8_t*>(reloc) + rdd.Size;
            while (reinterpret_cast<uintptr_t>(reloc) < reinterpret_cast<uintptr_t>(end)
                   && reloc->VirtualAddress) {
                const size_t count = (reloc->SizeOfBlock - sizeof(IMAGE_BASE_RELOCATION)) / 2;
                auto* entries = reinterpret_cast<uint16_t*>(reloc + 1);
                for (size_t j = 0; j < count; j++) {
                    const uint16_t e = entries[j];
                    if ((e >> 12) == IMAGE_REL_BASED_DIR64) {
                        void* p = rva_to_ptr(mem, reloc->VirtualAddress + (e & 0xFFF));
                        uintptr_t val = 0;
                        if (sys::read_mem(proc, p, &val, sizeof(val), &written) == 0
                            && written == sizeof(val)) {
                            val += delta;
                            sys::write_mem(proc, p, &val, sizeof(val), &written);
                        }
                    }
                }
                reloc = reinterpret_cast<IMAGE_BASE_RELOCATION*>(
                    reinterpret_cast<uint8_t*>(reloc) + reloc->SizeOfBlock);
            }
        }
    }

    // Imports: resolve against the TARGET's loaded modules. Descriptors and
    // name tables are parsed from the raw copy; the resolved IAT entries are
    // written into the target.
    auto& idd = h->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_IMPORT];
    if (idd.VirtualAddress) {
        auto* desc = static_cast<IMAGE_IMPORT_DESCRIPTOR*>(rva_raw_ptr(raw, h, idd.VirtualAddress));
        while (desc->Name) {
            const char* modname = static_cast<const char*>(rva_raw_ptr(raw, h, desc->Name));

            // Target-space IAT location; thunk/orig parsed from the raw copy.
            uintptr_t* thunk_t = static_cast<uintptr_t*>(rva_to_ptr(mem, desc->FirstThunk));
            auto* thunk = static_cast<uintptr_t*>(rva_raw_ptr(raw, h, desc->FirstThunk));
            auto* orig  = desc->OriginalFirstThunk
                ? static_cast<uintptr_t*>(rva_raw_ptr(raw, h, desc->OriginalFirstThunk))
                : thunk;
            for (size_t i = 0; orig[i]; i++) {
                uintptr_t val = orig[i];
                uintptr_t resolved = 0;
                if (val & 0x8000000000000000ull) {
                    // Import by ordinal: resolve through the module's export
                    // table (ordinal - OrdinalBase â†’ AddressOfFunctions).
                    resolved = resolve_import_ordinal(proc, modname,
                                                      static_cast<uint16_t>(val & 0xFFFF));
                } else {
                    auto* by_name = static_cast<IMAGE_IMPORT_BY_NAME*>(
                        rva_raw_ptr(raw, h, static_cast<uint32_t>(val)));
                    resolved = resolve_import_rec(proc, modname, by_name->Name, 0);
                }
                if (resolved) {
                    SIZE_T wr = 0;
                    sys::write_mem(proc, &thunk_t[i], &resolved, sizeof(resolved), &wr);
                    if (modname[0] == 'd' || modname[0] == 'D' ||
                        modname[0] == 'u' || modname[0] == 'U') {
                        diag("[fvem] import ok: %s slot %zu -> 0x%llX",
                             modname, i, static_cast<unsigned long long>(resolved));
                    }
                } else {
                    // Resolution failed: the IAT slot keeps its raw by-name RVA
                    // and calling it faults the game (DEP). Log for diagnosis.
                    diag("[fvem] import unresolved: %s slot %zu (raw 0x%llX)",
                         modname, i, static_cast<unsigned long long>(val));
                }
            }
            desc++;
        }
    }

    out.base = mem;
    out.entry = rva_to_ptr(mem, h->OptionalHeader.AddressOfEntryPoint);
    out.image_size = image_bytes;

    // Finalize protections in the TARGET (headers RO, code RX, data RW/RO) via
    // NtProtectVirtualMemory, before the caller starts the boot thread. This is
    // what closes the whole-image-RWX window the old one-shot commit left open.
    {
        SIZE_T hs = h->OptionalHeader.SizeOfHeaders;
        void* hp = mem; uint32_t old = 0;
        sys::protect(proc, &hp, &hs, PAGE_READONLY, &old);
        auto* s = IMAGE_FIRST_SECTION(h);
        for (int i = 0; i < h->FileHeader.NumberOfSections; i++, s++) {
            if (s->Misc.VirtualSize == 0) continue;
            DWORD prot;
            if (s->Characteristics & IMAGE_SCN_MEM_EXECUTE) prot = PAGE_EXECUTE_READ;
            else if (s->Characteristics & IMAGE_SCN_MEM_WRITE) prot = PAGE_READWRITE;
            else prot = PAGE_READONLY;
            void* p = rva_to_ptr(mem, s->VirtualAddress);
            SIZE_T sz = s->Misc.VirtualSize; uint32_t o = 0;
            sys::protect(proc, &p, &sz, prot, &o);
        }
    }
    return true;
}

} // namespace gfx::pe