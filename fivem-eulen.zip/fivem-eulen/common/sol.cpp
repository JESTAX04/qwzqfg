// language: C++, target: Windows 11, MSVC (x64)
#include "sol.h"
#include <cstring>

namespace gfx {

const char* run_lua(LuaRuntime& rt, const char* script, size_t len) {
    static thread_local char err[512];
    err[0] = 0;

    sol::state_view* v = nullptr;
    if (rt.view)      v = rt.view;
    else if (rt.state) { static thread_local sol::state_view own(*rt.state); v = &own; }
    if (!v || !v->lua_state()) { strncpy_s(err, "no lua state", sizeof(err)); return err; }

    sol::protected_function_result r = v->safe_script(std::string(script, len));
    if (!r.valid()) {
        sol::error e = r;
        strncpy_s(err, e.what(), sizeof(err) - 1);
        return err;
    }
    return nullptr;
}

} // namespace gfx
