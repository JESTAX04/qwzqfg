// language: C++, target: Windows 11, MSVC (x64)
// Indirect syscall dispatch. Each stub loads the SSN into eax/r10 and jumps
// through the gadget located in ntdll's syscall gate, so the return address
// lies inside ntdll and stack-walk detections see a legitimate call site.
#include "syscalls.h"
#include <cstring>
#include <cstdint>

namespace gfx::sys {

static SyscallTable g_table{};
static bool          g_ready = false;

SyscallTable* get_table() { return g_ready ? &g_table : nullptr; }
void set_table(SyscallTable* t) {
    if (!t) return;
    g_table = *t;
    g_ready = true;
}

// x64 syscall gate (non-MSVC fallback). MSVC builds link the MASM gate in
// common/syscall_gate.asm instead; this declaration is dead under _MSC_VER.
#if !defined(_MSC_VER)
extern "C" NTSTATUS __attribute__((naked)) _dispatch(const SyscallEntry& e, uint64_t a1 = 0,
    uint64_t a2 = 0, uint64_t a3 = 0, uint64_t a4 = 0, uint64_t a5 = 0, uint64_t a6 = 0,
    uint64_t a7 = 0);
#endif

#if defined(_MSC_VER)
// MSVC build path: emit the gate with inline asm is not supported on x64;
// use a raw byte stub compiled from a .asm fragment (common/syscall_gate.asm).
// The linker aliases _dispatch to that stub.
extern "C" NTSTATUS fvem_syscall_gate(const SyscallEntry* e, uint64_t a1 = 0, uint64_t a2 = 0,
    uint64_t a3 = 0, uint64_t a4 = 0, uint64_t a5 = 0, uint64_t a6 = 0, uint64_t a7 = 0);
// 11-syscall-arg gate (NtCreateThreadEx). entry + a1..a11.
extern "C" NTSTATUS fvem_syscall_gate11(const SyscallEntry* e,
    uint64_t a1, uint64_t a2, uint64_t a3, uint64_t a4, uint64_t a5, uint64_t a6,
    uint64_t a7, uint64_t a8, uint64_t a9, uint64_t a10, uint64_t a11);
#define GATE fvem_syscall_gate
#define GATE11 fvem_syscall_gate11
#else
#define GATE _dispatch
#define GATE11 _dispatch
#endif

NTSTATUS allocate(void* proc, void** base, std::size_t* size, uint32_t prot, uint32_t type) {
    if (!g_ready) return 0xC0000001;
    return GATE(&g_table.allocate_virtual_memory, (uint64_t)proc, (uint64_t)base, 0,
                (uint64_t)size, (uint64_t)type, (uint64_t)prot);
}
NTSTATUS protect(void* proc, void** base, std::size_t* size, uint32_t prot, uint32_t* old) {
    if (!g_ready) return 0xC0000001;
    // NtProtectVirtualMemory(HANDLE, PVOID*, PSIZE_T, ULONG NewProtect, PULONG OldProtect)
    return GATE(&g_table.protect_virtual_memory, (uint64_t)proc, (uint64_t)base,
                (uint64_t)size, (uint64_t)prot, (uint64_t)old);
}
NTSTATUS create_thread(void* proc, void** handle, uint32_t access, void* attr,
                       uint32_t flags, void* start, void* param, bool suspended) {
    if (!g_ready) return 0xC0000001;
    // NtCreateThreadEx(ThreadHandle, DesiredAccess, ObjectAttributes, ProcessHandle,
    //   StartAddress, Parameter, CreateFlags, ZeroStackBits, StackSize,
    //   MaximumStackSize, AttributeList)  â€” 11 args, the last four zero.
    // CreateFlags bit 0x1 = create suspended; bit 0x4 = hide-from-debugger (set in
    // the DLL, but we can arm it from the injector here so the boot thread is born
    // hidden rather than hiding itself after the fact).
    uint64_t create_flags = (uint64_t)flags;
    if (suspended) create_flags |= 0x1ull;
    return GATE11(&g_table.create_thread_ex,
                  (uint64_t)handle, (uint64_t)access, (uint64_t)attr,
                  (uint64_t)proc, (uint64_t)start, (uint64_t)param,
                  create_flags, 0, 0, 0, 0);
}
NTSTATUS open_process(uint32_t desired_access, bool inherit, uint32_t pid, void** handle) {
    (void)inherit;  // NtOpenProcess has no inherit parameter (Win32 OpenProcess artifact)
    if (!g_ready) return 0xC0000001;
    // NtOpenProcess(PHANDLE, ACCESS_MASK, POBJECT_ATTRIBUTES, PCLIENT_ID). The 4th
    // arg must be a pointer to a CLIENT_ID, not the pid value â€” passing the pid
    // integer made the kernel read from (PVOID)pid and fault.
    struct CLIENT_ID64 { void* UniqueProcess; void* UniqueThread; };
    CLIENT_ID64 ci{ reinterpret_cast<void*>(static_cast<uintptr_t>(pid)), nullptr };
    return GATE(&g_table.open_process, (uint64_t)handle, (uint64_t)desired_access,
                0 /* ObjectAttributes = NULL */, (uint64_t)&ci);
}
NTSTATUS read_mem(void* proc, void* addr, void* buf, std::size_t size, std::size_t* read) {
    if (!g_ready) return 0xC0000001;
    return GATE(&g_table.read_virtual_memory, (uint64_t)proc, (uint64_t)addr, (uint64_t)buf,
                (uint64_t)size, (uint64_t)read);
}
NTSTATUS write_mem(void* proc, void* addr, const void* buf, std::size_t size, std::size_t* written) {
    if (!g_ready) return 0xC0000001;
    return GATE(&g_table.write_virtual_memory, (uint64_t)proc, (uint64_t)addr, (uint64_t)buf,
                (uint64_t)size, (uint64_t)written);
}
NTSTATUS hide_current_thread(void* proc_handle) {
    if (!g_ready) return 0xC0000001;
    return GATE(&g_table.set_information_thread, (uint64_t)GetCurrentThread(),
                (uint64_t)17 /* ThreadHideFromDebugger */, 0, 0, 0, 0);
}

NTSTATUS query_system_info(uint32_t cls, void* buf, uint32_t size, uint32_t* retlen) {
    if (!g_ready) return 0xC0000001;
    return GATE(&g_table.query_system_info, (uint64_t)cls, (uint64_t)buf,
                (uint64_t)size, (uint64_t)retlen);
}

} // namespace gfx::sys