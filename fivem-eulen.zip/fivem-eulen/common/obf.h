// language: C++, target: Windows 11, MSVC (x64)
//
// Compile-time string obfuscation. The constructor is constexpr, so the
// compiler stores the ENCRYPTED code-unit sequence in .rdata and the plaintext
// marker never appears as a contiguous literal in the shipped image â€” the thing
// a static string scan / .rdata carve looks for. out() decrypts into a caller
// buffer at run time (a memory scanner still sees it transiently; this defeats
// the on-disk / idle-memory signature, which is the point at this layer).
//
// Shared by the injector and the mapped DLL (the arm-mutex object name has to
// derive identically in both, with no literal exposed in either).
#pragma once
#include <cstddef>

namespace gfx::obf {

template <std::size_t N>
struct EncW {
    wchar_t e[N]{};
    static constexpr unsigned char key(std::size_t i) {
        return static_cast<unsigned char>((0x5Au + i * 0x37u + ((i * i) & 0x1Fu)) & 0xFFu);
    }
    constexpr EncW(const wchar_t (&s)[N]) {
        for (std::size_t i = 0; i < N; ++i)
            e[i] = static_cast<wchar_t>(s[i] ^ static_cast<wchar_t>(key(i)));
    }
    // Decrypt into dst (dst holds >= cap wchar_t); always NUL-terminates dst.
    wchar_t* out(wchar_t* dst, std::size_t cap) const {
        if (!cap) return dst;
        std::size_t n = (N < cap) ? N : cap;
        for (std::size_t i = 0; i < n; ++i)
            dst[i] = static_cast<wchar_t>(e[i] ^ static_cast<wchar_t>(key(i)));
        dst[cap - 1] = 0;  // force-terminate (also covers the N terminator copy)
        return dst;
    }
};
template <std::size_t N> EncW(const wchar_t (&)[N]) -> EncW<N>;

template <std::size_t N>
struct EncA {
    char e[N]{};
    static constexpr unsigned char key(std::size_t i) {
        return static_cast<unsigned char>((0xA5u ^ (i * 0x2Bu) + ((i * i) & 0x3Fu)) & 0xFFu);
    }
    constexpr EncA(const char (&s)[N]) {
        for (std::size_t i = 0; i < N; ++i)
            e[i] = static_cast<char>(s[i] ^ static_cast<char>(key(i)));
    }
    char* out(char* dst, std::size_t cap) const {
        if (!cap) return dst;
        std::size_t n = (N < cap) ? N : cap;
        for (std::size_t i = 0; i < n; ++i)
            dst[i] = static_cast<char>(e[i] ^ static_cast<char>(key(i)));
        dst[cap - 1] = 0;
        return dst;
    }
};
template <std::size_t N> EncA(const char (&)[N]) -> EncA<N>;

// ---------------------------------------------------------------------------
// Armed-client / single-instance guard object.
//
// Replaces the old "poke MZ at 0x180000000 in every game process" sentinel.
// That sentinel forced a fixed, signature-prone image base AND depended on the
// PE header being present â€” both of which Layer 2 removes (randomized base +
// header erase). A named mutex does the same job base-independent: the mapped
// DLL creates-and-holds it for the game's lifetime.
//
// SCOPING: the name embeds the GAME PROCESS ID, so "already armed" can only
// ever mean "another fvem is mapped into THIS game". The old machine-wide name
// made a crashed-but-not-yet-exited client (FiveM keeps the process alive
// through crashometry/DumpServer upload) block every fresh injection, and a
// boot that aborts on it leaves the new game running WITHOUT a shield - which
// then dies to the early-exit trap the shield exists to absorb. Per-pid fixes
// both halves of that failure.
// ---------------------------------------------------------------------------
inline void arm_mutex_name(wchar_t* dst, int cap, unsigned long game_pid) {
    static const EncW kArmName{ L"MSCTF.FileMap.{7c1a9f3b-4e22-4d6a-9b0c-2f5a1e0d83a7}-" };
    kArmName.out(dst, static_cast<std::size_t>(cap));
    // Append the pid in decimal, no CRT (header is shared with the mapped DLL).
    int n = 0;
    while (dst[n] && n < cap - 12) ++n;
    char digits[12]; int t = 0;
    unsigned long v = game_pid;
    do { digits[t++] = static_cast<char>('0' + (v % 10)); v /= 10; } while (v && t < 11);
    while (t > 0 && n < cap - 1) dst[n++] = static_cast<wchar_t>(digits[--t]);
    dst[n] = 0;
}

} // namespace gfx::obf
