; language: x86-64 MASM, target: Windows 11, MSVC
; Indirect syscall gate. Invoked as:
;   NTSTATUS fvem_syscall_gate(const SyscallEntry*, a1..a7)  (shadow space)
; SyscallEntry layout: { uint32 ssn; pad4; void* gadget; }
; rcx -> entry. ssn at [rcx+0], gadget at [rcx+8].
;
; Syscall convention: arg1 in r10, arg2-4 in rdx/r8/r9, arg5+ on the stack
; (shadow at [rsp+20h], then [rsp+28h]...). Incoming a4..a7 sit at
; [rsp+28h] / [rsp+30h] / [rsp+38h] / [rsp+40h] past the 32-byte shadow.
; eax holds the SSN — loaded LAST so the arg shuffle never clobbers it.

.CODE

PUBLIC fvem_syscall_gate
PUBLIC fvem_syscall_gate11
fvem_syscall_gate PROC
    ; rcx = entry*, rdx = a1, r8 = a2, r9 = a3, [rsp+28h]=a4, [rsp+30h]=a5,
    ; [rsp+38h]=a6, [rsp+40h]=a7
    mov     r10, [rcx + 8]        ; gadget address -> r10
    mov     r11, r10              ; stash gadget in r11
    mov     r10, rdx              ; a1 -> r10 (syscall arg1)
    mov     rdx, r8               ; a2 -> rdx
    mov     r8,  r9               ; a3 -> r8
    mov     r9,  [rsp + 28h]      ; a4 -> r9
    ; Syscall stack args: the kernel reads arg5+ at [rsp+28h], [rsp+30h],
    ; [rsp+38h] relative to the rsp AT the syscall instruction. Our rsp here
    ; equals that rsp (jmp, not call, into the gadget), and a4..a7 arrived at
    ; [rsp+28h], [rsp+30h], [rsp+38h], [rsp+40h] — so shift each DOWN one slot
    ; (a5 -> [rsp+28h], a6 -> [rsp+30h], a7 -> [rsp+38h]). Reading the source
    ; slots before overwriting them is safe: each source is two slots ahead.
    mov     rax, [rsp + 30h]      ; a5
    mov     [rsp + 28h], rax      ; syscall arg5
    mov     rax, [rsp + 38h]      ; a6
    mov     [rsp + 30h], rax      ; syscall arg6
    mov     rax, [rsp + 40h]      ; a7
    mov     [rsp + 38h], rax      ; syscall arg7
    mov     eax, [rcx + 0]        ; SSN -> eax (rcx untouched since the top)
    jmp     r11                   ; into ntdll's syscall;ret gadget
fvem_syscall_gate ENDP

; 11-argument variant for NtCreateThreadEx (PHANDLE, ACCESS_MASK,
; POBJECT_ATTRIBUTES, HANDLE, start, param, CreateFlags, ZeroStackBits,
; StackSize, MaximumStackSize, PPS_ATTRIBUTE_LIST). Same entry/a1..a11 C
; layout; stack args a4..a11 sit at [rsp+28h]..[rsp+60h] and each slides down
; one slot into the syscall frame ([rsp+28h]..[rsp+58h]). Ascending copies are
; clobber-safe: every destination was the source of the previous step, already
; consumed.
fvem_syscall_gate11 PROC
    mov     r10, [rcx + 8]        ; gadget
    mov     r11, r10
    mov     r10, rdx              ; a1
    mov     rdx, r8               ; a2
    mov     r8,  r9               ; a3
    mov     r9,  [rsp + 28h]      ; a4
    mov     rax, [rsp + 30h]      ; a5
    mov     [rsp + 28h], rax
    mov     rax, [rsp + 38h]      ; a6
    mov     [rsp + 30h], rax
    mov     rax, [rsp + 40h]      ; a7
    mov     [rsp + 38h], rax
    mov     rax, [rsp + 48h]      ; a8
    mov     [rsp + 40h], rax
    mov     rax, [rsp + 50h]      ; a9
    mov     [rsp + 48h], rax
    mov     rax, [rsp + 58h]      ; a10
    mov     [rsp + 50h], rax
    mov     rax, [rsp + 60h]      ; a11
    mov     [rsp + 58h], rax
    mov     eax, [rcx + 0]        ; SSN
    jmp     r11
fvem_syscall_gate11 ENDP

END
