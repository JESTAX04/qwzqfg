// language: C++, target: Windows 11, MSVC (x64)
#include "scanner.h"
#include "../core/log.h"
#include <windows.h>
#include <cctype>
#include <cstdlib>

namespace gfx::scan {

static int hexval(char c) {
    if (c >= '0' && c <= '9') return c - '0';
    if (c >= 'a' && c <= 'f') return c - 'a' + 10;
    if (c >= 'A' && c <= 'F') return c - 'A' + 10;
    return -1;
}

Pattern::Pattern(const char* sig) {
    while (*sig) {
        while (*sig == ' ') sig++;
        if (!*sig) break;
        if (sig[0] == '?' && sig[1] == '?') {
            bytes.push_back(0);
            mask.push_back(false);
            sig += 2;
        } else {
            int hi = hexval(sig[0]), lo = hexval(sig[1]);
            if (hi < 0 || lo < 0) { bytes.clear(); mask.clear(); return; }
            bytes.push_back(static_cast<uint8_t>((hi << 4) | lo));
            mask.push_back(true);
            sig += 2;
        }
    }
}

bool Pattern::match(const uint8_t* p) const {
    for (size_t i = 0; i < bytes.size(); i++)
        if (mask[i] && p[i] != bytes[i]) return false;
    return true;
}

uintptr_t find_from(const uint8_t* begin, size_t length, const Pattern& pat) {
    if (pat.bytes.empty() || length < pat.bytes.size()) return 0;
    const uint8_t* p = begin;
    const uint8_t* end = begin + length - pat.bytes.size();
    for (; p <= end; p++) {
        __try {
            if (pat.match(p)) return reinterpret_cast<uintptr_t>(p);
        } __except (probe_filter(GetExceptionCode(), GetExceptionInformation())) {}
    }
    return 0;
}

uintptr_t scan_module(uintptr_t base, const Pattern& pat, int rip_offset, int ip_len) {
    auto* dos = reinterpret_cast<IMAGE_DOS_HEADER*>(base);
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return 0;
    auto* h = reinterpret_cast<IMAGE_NT_HEADERS64*>(base + dos->e_lfanew);
    if (h->Signature != IMAGE_NT_SIGNATURE) return 0;

    // Scan the executable sections for speed/correctness.
    auto* sec = IMAGE_FIRST_SECTION(h);
    for (int i = 0; i < h->FileHeader.NumberOfSections; i++, sec++) {
        if (!(sec->Characteristics & IMAGE_SCN_MEM_EXECUTE)) continue;
        uintptr_t begin = base + sec->VirtualAddress;
        uintptr_t hit = find_from(reinterpret_cast<const uint8_t*>(begin),
                                  sec->Misc.VirtualSize, pat);
        if (!hit) continue;
        if (rip_offset == 0) return hit;
        // RIP-relative: displacement at hit+rip_offset, next instruction at hit+ip_len
        int32_t disp = *reinterpret_cast<int32_t*>(hit + rip_offset);
        return hit + ip_len + disp;
    }
    return 0;
}

} // namespace gfx::scan