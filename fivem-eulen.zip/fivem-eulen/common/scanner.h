// language: C++, target: Windows 11, MSVC (x64)
// SIG / AOB pattern scanner. Byte pattern with ?? wildcards. Works on a raw
// memory range or a mapped module.
#pragma once
#include <cstdint>
#include <cstddef>
#include <vector>
#include <functional>

namespace gfx::scan {

struct Pattern {
    std::vector<uint8_t> bytes;
    std::vector<bool>    mask;
    explicit Pattern(const char* sig); // "48 8B ?? ?? E8 ?? ?? ?? ??"

    bool match(const uint8_t* p) const;
};

// Scan a range for the first match; apply resolver to derive a final address
// (e.g. RIP-relative decode). Returns 0 on miss.
uintptr_t find_from(const uint8_t* begin, size_t length, const Pattern& pat);

// Higher-level: scan a loaded module's image for a pattern + optional RIP
// relative resolution (opcode offset to the instruction start, instruction size).
uintptr_t scan_module(uintptr_t base, const Pattern& pat, int rip_offset = 0, int ip_len = 0);

} // namespace gfx::scan