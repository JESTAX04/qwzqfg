// language: C++, target: Windows 11, MSVC (x64)
// Minimal PE loader helpers shared by injector and core.
#pragma once
#include <windows.h>
#include <cstdint>
#include <vector>

namespace gfx::pe {

struct MappedImage {
    void*    base = nullptr;      // preferred/actual image base
    void*    entry = nullptr;     // address of entry point (RVA resolved)
    size_t   image_size = 0;
};

// Map an on-disk PE into memory manually: allocates, copies headers+sections,
// applies relocations, does NOT add a PEB Ldr entry and does NOT call LoadLibrary.
bool manual_map(const std::vector<uint8_t>& raw, MappedImage& out);

// Map a PE into a REMOTE process: VirtualAllocEx in the target, copies
// headers+sections there, applies relocations against the remote base, and
// resolves imports against the target's loaded modules. out.base/entry are
// target-space addresses. The local manual_map() above is NOT usable for
// injection â€” a thread started at its entry would execute in the wrong process.
bool map_in_target(HANDLE proc, const std::vector<uint8_t>& raw, MappedImage& out);

// Resolve an exported function by name from a raw PE image (no LoadLibrary).
void* rva_to_ptr(void* base, uint32_t rva);
void* find_export(void* base, const char* name);

// Resolve an export from an already-loaded module by walking its headers,
// not the PEB loader list.
void* find_export_from_loaded(uintptr_t module_base, const char* name);

// Locate a module base without touching PEB: walk the in-memory DOS/NT headers
// from a known pointer inside it.
uintptr_t module_base_from_ptr(void* ptr_inside);

} // namespace gfx::pe