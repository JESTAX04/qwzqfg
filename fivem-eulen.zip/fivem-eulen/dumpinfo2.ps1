param([string]$DumpPath)
# Correct MDMP minidump reader: header, exception stream (with CONTEXT +
# stack scan), module list resolved by name. Fixes dumpinfo.ps1's header
# offset bug (it read CheckSum as the stream-directory RVA) and its wrong
# stream-type tags.
#
# Stream types: 3=ThreadList 4=ModuleList 5=MemoryList 6=Exception
#               7=SystemInfo 15=Memory64List 24=HandleData
$fs = [System.IO.File]::OpenRead($DumpPath)
$br = New-Object System.IO.BinaryReader($fs)

function ReadStr([uint32]$rva) {
    try {
        if ($rva -eq 0 -or $rva -gt ($fs.Length - 8)) { return "<trunc:0x$('{0:X}' -f $rva)>" }
        $save = $fs.Position
        $fs.Position = $rva
        $len = $br.ReadUInt32()
        if ($len -gt 4096 -or ($rva + 4 + $len) -gt $fs.Length) { $fs.Position = $save; return "<badlen $len>" }
        $bytes = $br.ReadBytes([int]$len)
        $s = [System.Text.Encoding]::Unicode.GetString($bytes)
        $fs.Position = $save
        return $s
    } catch { return "<err>" }
}

try {
    $sig = [System.Text.Encoding]::ASCII.GetString($br.ReadBytes(4))
    $ver = $br.ReadUInt32()
    $nstreams = $br.ReadUInt32()
    $sdir = $br.ReadUInt32()          # StreamDirectoryRva (offset 0x0C)
    "sig=$sig streams=$nstreams sdir=0x$('{0:X}' -f $sdir)"

    $mods = @()          # base,size,name
    $excThread = 0; $excCode = 0; $excFlags = 0; $excAddr = 0; $excParams = @()
    $ctxRva = 0; $ctxSize = 0
    $threads = @{}       # tid -> @{teb; stackBase; stackRva; stackSize; ctxRva}

    for ($i = 0; $i -lt $nstreams; $i++) {
        $fs.Position = $sdir + $i * 12
        $type = $br.ReadUInt32(); $dsz = $br.ReadUInt32(); $dof = $br.ReadUInt32()
        switch ($type) {
            4 {   # ModuleList
                $fs.Position = $dof
                $count = $br.ReadUInt32()
                for ($m = 0; $m -lt $count; $m++) {
                    $base = $br.ReadUInt64(); $size = $br.ReadUInt32()
                    [void]$br.ReadUInt32()   # checksum
                    $nameRva = $br.ReadUInt32()
                    $fs.Position += 52 + 8 + 8 + 16   # VersionInfo..Reserved1
                    $mods += ,@($base, $size, (ReadStr $nameRva))
                }
                "modules=$($mods.Count)"
            }
            6 {   # Exception
                $fs.Position = $dof
                $excThread = $br.ReadUInt32()
                [void]$br.ReadUInt32()       # alignment
                $excCode = $br.ReadUInt32(); $excFlags = $br.ReadUInt32()
                [void]$br.ReadUInt64()       # ExceptionRecord ptr (8)
                $excAddr = $br.ReadUInt64()  # ExceptionAddress (8)
                $np = $br.ReadUInt32(); [void]$br.ReadUInt32()
                for ($p = 0; $p -lt [Math]::Min($np,6); $p++) { $excParams += $br.ReadUInt64() }
                $ctxRva = $br.ReadUInt32(); $ctxSize = $br.ReadUInt32()
                "exception: thread=$excThread code=0x$('{0:X8}' -f $excCode) addr=0x$('{0:X}' -f $excAddr) np=$np"
                for ($p = 0; $p -lt $excParams.Count; $p++) {
                    "  param$p = 0x$('{0:X}' -f $excParams[$p])"
                }
            }
            7 {   # SystemInfo
                $fs.Position = $dof
                $arch = $br.ReadUInt16()
                $fs.Position = $dof + 8
                $maj = $br.ReadUInt32(); $min = $br.ReadUInt32(); $bld = $br.ReadUInt32()
                "sysinfo: arch=$arch os=$maj.$min.$bld"
            }
            3 {   # ThreadList
                $fs.Position = $dof
                $count = $br.ReadUInt32()
                for ($t = 0; $t -lt $count; $t++) {
                    $tid = $br.ReadUInt32()
                    $flags = $br.ReadUInt32(); $susp = $br.ReadUInt32()
                    $pc = $br.ReadUInt32(); $prio = $br.ReadUInt32()
                    $teb = $br.ReadUInt64()
                    $stBase = $br.ReadUInt64(); $stSize = $br.ReadUInt32(); $stRva = $br.ReadUInt32()
                    $tcRva = $br.ReadUInt32(); $tcSize = $br.ReadUInt32()
                    $threads[$tid] = @{susp=$susp; stackBase=$stBase; stackRva=$stRva; stackSize=$stSize; ctxRva=$tcRva}
                }
                "threads=$count"
            }
        }
    }

    function Resolve([uint64]$addr) {
        foreach ($m in $mods) {
            if ($addr -ge $m[0] -and $addr -lt ($m[0] + $m[1])) {
                $nm = ($m[2] -split '[\\/]')[-1]
                if (-not $nm) { $nm = "mod_0x{0:X}" -f $m[0] }
                return "0x{0:X}  {1}+0x{2:X}" -f $addr, $nm, ($addr - $m[0])
            }
        }
        return ("0x{0:X}  <no module>" -f $addr)
    }

    "---- exception thread $excThread ----"
    if ($ctxRva -and ($ctxRva + $ctxSize) -le $fs.Length -and $ctxSize -ge 0x110) {
        $fs.Position = $ctxRva
        $ctx = New-Object byte[] $ctxSize
        [void]$fs.Read($ctx, 0, $ctxSize)
        function C64($o) { [BitConverter]::ToUInt64($ctx, $o) }
        $rip = C64 0xF8; $rsp = C64 0x98; $rbp = C64 0xA0
        "  RIP: $(Resolve $rip)"
        "  RSP=0x$('{0:X}' -f $rsp) RBP: $(Resolve $rbp)"
        "  RAX=0x$('{0:X16}' -f (C64 0x78)) RBX=0x$('{0:X16}' -f (C64 0x80)) RCX=0x$('{0:X16}' -f (C64 0x88))"
        "  RDX=0x$('{0:X16}' -f (C64 0x90)) R8=0x$('{0:X16}' -f (C64 0x50)) R9=0x$('{0:X16}' -f (C64 0x58))"
        "  R10=0x$('{0:X16}' -f (C64 0x60)) R11=0x$('{0:X16}' -f (C64 0x68))"
    }
    if ($threads.ContainsKey($excThread)) {
        $t = $threads[$excThread]
        $want = [Math]::Min($t.stackSize, 2048)
        if ($want -gt 0 -and ($t.stackRva + $want) -le $fs.Length) {
            $fs.Position = $t.stackRva
            $buf = $br.ReadBytes($want)
            "  -- stack return candidates (qword -> code) --"
            for ($o = 0; $o -lt $buf.Length - 8; $o += 8) {
                $q = [BitConverter]::ToUInt64($buf, $o)
                foreach ($m in $mods) {
                    if ($q -ge ($m[0] + 0x1000) -and $q -lt ($m[0] + $m[1])) {
                        "   +0x{0:X4}: {1}" -f $o, (Resolve $q)
                        break
                    }
                }
            }
        }
    }
    "---- interesting threads (suspended/known names omitted): total $($threads.Count) ----"
} finally {
    $br.Dispose(); $fs.Dispose()
}
