// language: C++, target: Windows 11, MSVC (x64)
// fvem Lua hub — Tier S executor core.
//
// Everything here runs on the overlay (trampoline) thread: the game main
// thread's ONLY fvem duty remains the scoped-native drain in native_invoker.
// User scripts are coroutines inside OUR OWN lua_State; Citizen.Wait yields
// into a deadline queue (never Sleep), state-changing natives go through the
// existing invoke_array_scoped main-thread queue, and a per-resume
// instruction budget (lua_sethook MASKCOUNT) kills runaway loops at VM
// instruction boundaries — a native call in flight always completes first,
// so a kill can never rip mid-handler.
//
// All Lua objects are registry references (integers): one owner, explicit
// release, no hidden lifetimes. Console is a bounded ring the menu reads.
#pragma once
#include <cstdint>
#include <string>
#include <vector>

namespace gfx {

// Lifecycle — called once from acquire_lua_state() during boot.
bool hub_init();
void hub_shutdown();

// Script control (all overlay-thread).
uint32_t hub_run_script(const std::string& name, const std::string& source);
bool     hub_run_once(const std::string& source, std::string& err);
bool     hub_stop(uint32_t id);
void     hub_stop_all();

struct HubScriptInfo {
    uint32_t    id = 0;
    std::string name;
    int         state = 0;   // 0 running, 1 waiting, 2 dead(err), 3 done
    std::string last_err;
};
void hub_list(std::vector<HubScriptInfo>& out);

// Frame pump — call from the overlay loop EVERY iteration.
void hub_tick();

// Console ring (menu + print converge here). Lines arrive prefixed.
void hub_console_push(const std::string& line);
const std::vector<std::string>& hub_console_lines();
void hub_console_clear();

// Command dispatch ("/name args..." from the console tab). Returns false + err
// when the command is unknown; handler errors land in the console.
bool hub_run_command(const std::string& line);

} // namespace gfx
