// language: C++, file: core/ui_theme.cpp
// See core/ui_theme.h. The style block is the source project's "2026 Luxury
// Obsidian" verbatim; the font wiring is adapted to fvem's vendored 1.93 and is
// hostile to missing assets (it falls back rather than lying).

#include "core/ui_theme.h"

#include "imgui.h"

namespace gfx::theme {
namespace {

ImFont* g_fonts[FontCount] = {};
bool    g_built = false;
bool    g_have_assets = false;

} // namespace

void ApplyStyle() {
    ImGuiStyle& style = ImGui::GetStyle();

    style.WindowRounding    = 10.0f;
    style.ChildRounding     = 8.0f;
    style.FrameRounding     = 5.0f;
    style.PopupRounding     = 6.0f;
    style.ScrollbarRounding = 8.0f;
    style.GrabRounding      = 5.0f;
    style.TabRounding       = 5.0f;

    style.WindowBorderSize = 1.0f;
    style.ChildBorderSize  = 1.0f;
    style.FrameBorderSize  = 1.0f;
    style.PopupBorderSize  = 1.0f;

    style.ItemSpacing      = ImVec2(10.0f, 8.0f);
    style.ItemInnerSpacing = ImVec2(8.0f, 6.0f);
    style.FramePadding     = ImVec2(10.0f, 6.0f);
    style.ScrollbarSize    = 6.0f;
}
