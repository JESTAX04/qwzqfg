// language: C++, target: Windows 11, MSVC (x64)
// Transparent overlay window for the FVEM menu.
//
// WHY (crash isolation): the previous design rendered ImGui inside the game's
// IDXGISwapChain::Present hook. Present runs on the game's main thread, so any
// ImGui work there (NewFrame -> menu -> RenderDrawData -> Present) extends the
// game's frame time. On this machine (i7-3770, FXServer + client on one box)
// the extra main-thread work, plus the game's own Present (vsync, 60fps),
// stalls the game's net thread past FiveM's watchdog limit and triggers the
// "early-exit trap". This overlay moves ALL drawing out of the game process's
// render loop: the overlay is a separate topmost layered window rendered by a
// dedicated thread through its OWN D3D11 device. The game's Present is never
// touched again â€” fvem costs zero time on the game's main thread.
//
// The overlay window is created with WS_EX_LAYERED + LWA_COLORKEY so that pure
// black pixels (the clear color) are fully transparent: the menu floats above
// the game while clicks pass through (WS_EX_TRANSPARENT). When the menu is
// open, WS_EX_TRANSPARENT is removed so ImGui can capture the mouse.
#pragma once
#include "pch.h"

namespace gfx {

// Create the overlay window sized/positioned over the game window. Returns the
// overlay HWND or nullptr on failure. The game HWND is remembered for
// follow/resize and for returning keyboard focus when the menu closes.
HWND overlay_create(HWND game_hwnd);

// Destroy the overlay window (also re-sets the game window's focus).
void overlay_destroy();

// Toggle click-through: true = menu open (overlay captures mouse + keyboard),
// false = menu closed (clicks/keyboard pass through to the game).
void overlay_set_clickable(bool clickable);

// Reposition/resize the overlay to exactly cover the game window (called from
// the render thread's follow poll).
void overlay_follow_game();

// Current overlay HWND (for ImGui_ImplWin32_Init + message pump).
HWND overlay_hwnd();

// --- Stream proofing (see overlay_window.cpp for the two layers) -------------
// Layer-2 tick, call from the overlay loop: scans (2 s throttle) for capture
// / stream / remote-desktop hosts and latches the stream lock. While latched
// the menu is force-closed and re-open is refused.
void overlay_stream_guard_tick();

// True while a capture host is live and the menu is locked out.
bool overlay_stream_guard_active();

} // namespace gfx
