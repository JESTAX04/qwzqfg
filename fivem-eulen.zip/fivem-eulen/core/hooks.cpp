// language: C++, target: Windows 11, MSVC (x64)
// Present hook Ã¢â‚¬â€ NOW A PURE PASSTHROUGH.
//
// The ImGui overlay has moved to a separate transparent window rendered by a
// dedicated thread through its own D3D11 device (overlay_render.cpp). The
// game's IDXGISwapChain::Present is therefore no longer extended in any way:
// this hook simply forwards to the original and returns. fvem adds ZERO work
// to the game's main thread, so it can no longer stall the net thread and
// trip FiveM's watchdog ("early-exit trap").
//
// Discovery still runs through this module, but NOTHING is patched anymore:
// the swapchain vtable stays stock (see the removal note near where
// present_hooked used to be), and the scoped native queue is drained on the
// game's main thread by two user32 PUMP detours (PeekMessageW/GetMessageW
// below) instead of a window-proc subclass - GWLP_WNDPROC stays stock, so
// the classic "wndproc pointer outside every module" tell no longer exists.
#include "pch.h"
#include "config.h"
#include "offsets.h"
#include "mem.h"
#include "log.h"
#include "native_invoker.h"
#include "overlay_render.h"
#include "evasion/detour.h"
#include "evasion/watchdog.h"
#include "../common/obf.h"

namespace gfx {

using PresentFn = HRESULT(STDMETHODCALLTYPE*)(IDXGISwapChain*, UINT, UINT);

static PresentFn       g_orig_present = nullptr;   // dxgi's real Present (reference)
static HWND            g_game_window  = nullptr;

// Pump-detour state (see pump_service below).
typedef BOOL (WINAPI *peek_fn_t)(LPMSG, HWND, UINT, UINT, UINT);
typedef BOOL (WINAPI *getmsg_fn_t)(LPMSG, HWND, UINT, UINT);
static peek_fn_t     g_orig_peek   = nullptr;
static getmsg_fn_t   g_orig_getmsg = nullptr;
static DWORD         g_pump_tid    = 0;   // cached game main-thread id
static volatile LONG g_pump_busy   = 0;   // re-entry guard (drain can pump)

// --- Probe swapchain: reach the shared IDXGISwapChain vtable ---------------
// All IDXGISwapChain objects in the process (the game's included) share the
// same vtable in dxgi.dll, so patching the probe's Present slot hooks every
// chain. The probe chain itself is never presented.
static IDXGISwapChain* create_probe_swapchain() {
    __try {
        WNDCLASSEXW wc{};
        wc.cbSize = sizeof(wc);
        wc.lpfnWndProc = DefWindowProcW;
        wc.hInstance = GetModuleHandleW(nullptr);
        // Benign, encrypted-stored class name. "fvem_probe" was a plaintext IOC
        // in the desktop class table; "D3DWindowClass" is the name D3D11 sample
        // apps use, so a registered class by that name draws no attention.
        wchar_t probe_cls[32]{};
        static const gfx::obf::EncW kProbeCls{ L"D3DWindowClass" };
        kProbeCls.out(probe_cls, 32);
        wc.lpszClassName = probe_cls;
        RegisterClassExW(&wc);
        HWND hwnd = CreateWindowExW(0, probe_cls, L"", WS_OVERLAPPEDWINDOW,
                                    0, 0, 100, 100, nullptr, nullptr, wc.hInstance, nullptr);
        SecureZeroMemory(probe_cls, sizeof(probe_cls));
        if (!hwnd) return nullptr;
        D3D_FEATURE_LEVEL fl{};
        DXGI_SWAP_CHAIN_DESC sd{};
        sd.BufferCount = 1;
        sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
        sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
        sd.OutputWindow = hwnd;
        sd.SampleDesc.Count = 1;
        sd.Windowed = TRUE;
        sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;
        IDXGISwapChain* sc = nullptr;
        ID3D11Device* dev = nullptr;
        HRESULT hr = D3D11CreateDeviceAndSwapChain(
            nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, 0, nullptr, 0,
            D3D11_SDK_VERSION, &sd, &sc, &dev, &fl, nullptr);
        if (FAILED(hr)) {
            hr = D3D11CreateDeviceAndSwapChain(
                nullptr, D3D_DRIVER_TYPE_WARP, nullptr, 0, nullptr, 0,
                D3D11_SDK_VERSION, &sd, &sc, &dev, &fl, nullptr);
        }
        if (FAILED(hr)) return nullptr;
        if (dev) dev->Release();
        return sc;
    } __except (log_fault_filter(GetExceptionCode(), GetExceptionInformation())) {
        return nullptr;
    }
}

// --- Swapchain acquisition --------------------------------------------------
static IDXGISwapChain* acquire_game_swapchain() {
    uintptr_t sc = mem::read_ptr(game::base() + game::build().Swapchain);
    if (mem::valid_ptr(sc)) {
        uintptr_t vt = mem::read_ptr(sc);
        uintptr_t present = mem::read_ptr(vt + 8 * sizeof(void*));
        if (present >= 0x10000 && present < 0x0000'7FFF'FFFF'FFFFull)
            return reinterpret_cast<IDXGISwapChain*>(sc);
        FVEM_LOGF("[fvem] swapchain: game global invalid, probe fallback");
    } else {
        FVEM_LOGF("[fvem] swapchain: game global read null, probe fallback");
    }
    return create_probe_swapchain();
}

// Is this address inside the dxgi.dll image? The Present slot we patch must
// resolve to dxgi's own code Ã¢â‚¬â€ if the game's swapchain global is stale (build
// table fell back without a match), the vtable read can return a garbage
// "valid-looking" pointer and patching it would corrupt game memory. The probe
// chain is always a real dxgi chain, so on any doubt we patch that instead.
static bool in_dxgi(uintptr_t addr) {
    HMODULE dxgi = GetModuleHandleW(L"dxgi.dll");
    if (!dxgi) return false;
    auto* dos = reinterpret_cast<IMAGE_DOS_HEADER*>(dxgi);
    auto* h = reinterpret_cast<IMAGE_NT_HEADERS64*>(
        reinterpret_cast<uintptr_t>(dxgi) + dos->e_lfanew);
    uintptr_t lo = reinterpret_cast<uintptr_t>(dxgi);
    uintptr_t hi = lo + h->OptionalHeader.SizeOfImage;
    return addr >= lo && addr < hi;
}

// --- Game window discovery --------------------------------------------------
struct WindowScan { HWND best; };
static BOOL CALLBACK enum_wnd(HWND h, LPARAM lp) {
    DWORD pid = 0;
    GetWindowThreadProcessId(h, &pid);
    if (pid != GetCurrentProcessId()) return TRUE;
    if (!IsWindowVisible(h)) return TRUE;
    wchar_t cls[256]{};
    GetClassNameW(h, cls, 256);
    auto* scan = reinterpret_cast<WindowScan*>(lp);
    if (!scan->best) scan->best = h;
    if (wcscmp(cls, L"grcWindow") == 0) scan->best = h;
    return TRUE;
}

static HWND find_game_window() {
    WindowScan scan{};
    EnumWindows(enum_wnd, reinterpret_cast<LPARAM>(&scan));
    if (!scan.best) scan.best = GetForegroundWindow();
    return scan.best;
}

HWND game_window() { return g_game_window; }

// --- Present: PURE PASSTHROUGH ---------------------------------------------
// Nothing is rendered here anymore. The overlay draws on its own thread with
// its own device. If our hook itself faults (it shouldn't Ã¢â‚¬â€ it's two calls),
// swallow and still present.
// (Removed: the Present slot write + passthrough handler. The overlay has
// always drawn on its own device/thread - the hooked Present did nothing but
// forward, while leaving a pointer that does not live in dxgi.dll parked in
// IDXGISwapChain vtable slot 8: a vtable-integrity hash sees it instantly,
// and any second executor patching the same slot (the "Eulen" chaining case)
// stacked into the classic double-hook signature. install_present_hook now
// performs the SAME discovery work and writes NOTHING.)

// --- Game main-thread pump hooks: drain + Insert toggle ----------------------
// State-changing natives queued from the overlay render thread execute here Ã¢â‚¬â€
// this callback runs on the game's main thread (the thread that created
// grcWindow), which is the one thread allowed to mutate game state.
//
// Implementation (U1 - UNDETECTED_FULL_PLAN): PRIMARY trigger is a kernel
// timer (SetTimer with TIMERPROC on the game window): win32k dispatches the
// callback on the thread that OWNS the window - the game main thread - with
// ZERO code patching. The old user32 PeekMessageW/GetMessageW inline detours
// remain as fallback (and hard-gate on the cached main-thread id), but the
// prologue bytes of the most-scanned cheat tell stay pristine while the timer
// path runs. Fallback rationale: kernel timer state lives in win32k objects
// unreachable without handles/natives; user32 diffs are checked by anyone.
//
// g_trigger_mode: 0 = detour pumps, 1 = kernel timer pumps. The Hz telemetry
// line names the live trigger so field logs prove which path is active.
static int g_trigger_mode = 0;
static void pump_service() {
    if (g_pump_tid && GetCurrentThreadId() != g_pump_tid) return;

    // FPS telemetry (FVEM_LOG builds): the game's main loop pumps exactly one
    // PeekMessage per frame, so this rate IS the main-thread frame rate.
    // Field answer to "is the UI costing FPS": ~60 Hz with menu closed = the
    // overlay costs nothing; a visible dip HERE is real, and comparing it
    // against the same server without fvem isolates our share of it.
    if (g_pump_tid) {
        static ULONGLONG s_win_start = 0;
        static LONG      s_n         = 0;
        const ULONGLONG t = GetTickCount64();
        if (!s_win_start) s_win_start = t;
        ++s_n;   // main-thread-only (past the tid gate): plain increment
        if (t - s_win_start >= 5000) {
            FVEM_LOGF("[fvem] %s: %ld Hz (5 s window)",
                      g_trigger_mode == 1 ? "timer drain" : "main pump",
                      static_cast<long>(s_n * 1000ull / (t - s_win_start)));
            s_win_start = t; s_n = 0;
        }
    }

    if (InterlockedCompareExchange(&g_pump_busy, 1, 0) != 0) return;  // re-entry
    __try {
        native::drain_scoped_queue();
        // THE single Insert trigger, computed as a real up->down edge from the
        // MSB (currently-down) state at 60 Hz - NOT the LSB "pressed since
        // last call" bit: the LSB is consumed by the first poller and FiveM's
        // own hotkey machinery polls too, which could silently steal ours.
        // This window polls every frame regardless of focus (async state is
        // global), so exactly one trigger fires per physical press no matter
        // which window holds the keyboard. (The overlay WndProc used to react
        // to the message as a second trigger - held presses opened AND closed
        // the menu in one keystroke; it now only claims the key.)
        static bool s_ins_prev_down = false;
        const bool ins_down = (GetAsyncKeyState(VK_INSERT) & 0x8000) != 0;
        const bool ins_edge = ins_down && !s_ins_prev_down;
        s_ins_prev_down = ins_down;
        if (ins_edge)
            overlay_toggle_menu();

        // F8 -> fvem console. Same MSB-edge rule: the async state is global,
        // so exactly one trigger per physical press no matter which window
        // (game or overlay) holds the keyboard.
        static bool s_f8_prev_down = false;
        const bool f8_down = (GetAsyncKeyState(VK_F8) & 0x8000) != 0;
        const bool f8_edge = f8_down && !s_f8_prev_down;
        s_f8_prev_down = f8_down;
        if (f8_edge)
            overlay_toggle_console();
    } __except (gfx::log_fault_filter(GetExceptionCode(), GetExceptionInformation())) {
    }
    InterlockedExchange(&g_pump_busy, 0);
}

// F8 hijack: with console_hijack_f8 on, the game's own debug console never
// sees its keydown. Only PM_REMOVE queues are filtered — under PM_NOREMOVE
// the same message would be re-returned forever (the spin guard is a belt).
static inline bool swallow_f8(const MSG* m, UINT rm) {
    return gfx::cfg().console_hijack_f8 && (rm & PM_REMOVE) != 0 &&
           m->message == WM_KEYDOWN && m->wParam == VK_F8;
}

static BOOL WINAPI peek_hook(LPMSG m, HWND h, UINT fmin, UINT fmax, UINT rm) {
    pump_service();
    BOOL r;
    for (int spins = 0; spins < 32; ++spins) {
        r = g_orig_peek ? g_orig_peek(m, h, fmin, fmax, rm) : FALSE;
        if (!r || !swallow_f8(m, rm)) break;
    }
    return r;
}

static BOOL WINAPI getmsg_hook(LPMSG m, HWND h, UINT fmin, UINT fmax) {
    pump_service();
    BOOL r;
    for (int spins = 0; spins < 32; ++spins) {
        r = g_orig_getmsg ? g_orig_getmsg(m, h, fmin, fmax) : FALSE;
        if (!r || !swallow_f8(m, PM_REMOVE)) break;
    }
    return r;
}

// --- U1 PRIMARY: kernel-timer drain trigger ----------------------------------
// SetTimer with a TIMERPROC stores the timer in win32k; WM_TIMER-class
// dispatch invokes our callback ON THE WINDOW-OWNER THREAD (the game main
// thread) - the same execution context the detours bought us, without
// writing a single byte into user32. 16 ms = 60 Hz ceiling; WM_TIMER is the
// LOWEST queue priority, so it cannot delay game input, and coalescing under
// load merely postpones a drain by one tick (the scoped queue absorbs that).
// The callback address lives in kernel timer state: reading it back requires
// in-process forensics (T3), not the one-liner "diff the export prologue".
static VOID CALLBACK drain_timer_proc(HWND, UINT, UINT_PTR, DWORD) {
    pump_service();
}
static bool install_drain_timer() {
    if (!g_game_window || !IsWindow(g_game_window)) return false;
    // Id 0xF7E4: outside the small-int id space game code typically uses.
    UINT_PTR ok = SetTimer(g_game_window, 0xF7E4u, 16, &drain_timer_proc);
    FVEM_LOGF("[fvem] drain trigger: kernel timer %s (game wnd %p, user32 bytes pristine)",
              ok ? "ARMED" : "failed", g_game_window);
    return ok != 0;
}

bool install_present_hook() {
    // Prefer a swapchain whose Present slot verifiably lives in dxgi.dll.
    // acquire_game_swapchain returns the game global when it looks sane, else
    // a fresh probe chain (always a real dxgi chain). Re-validate here: a
    // silent build-table fallback (stale Swapchain RVA) can pass the naive
    // range check with garbage; patching garbage memory corrupts the game.
    IDXGISwapChain* sc = acquire_game_swapchain();
    if (!sc) {
        FVEM_LOGF("[fvem] present hook: no swapchain acquired");
        return false;
    }
    void** vtbl = nullptr;
    __try {
        vtbl = *reinterpret_cast<void***>(sc);
        uintptr_t present = reinterpret_cast<uintptr_t>(vtbl[8]);
        if (!in_dxgi(present)) {
            FVEM_LOGF("[fvem] present hook: swapchain present not in dxgi "
                    "(stale offset?) Ã¢â‚¬â€ probe fallback");
            sc = create_probe_swapchain();
            if (!sc) return false;
            vtbl = *reinterpret_cast<void***>(sc);
        }
    } __except (log_fault_filter(GetExceptionCode(), GetExceptionInformation())) {
        FVEM_LOGF("[fvem] present hook: vtable read faulted, probe fallback");
        sc = create_probe_swapchain();
        if (!sc) return false;
        vtbl = *reinterpret_cast<void***>(sc);
    }

    // CRITICAL: Extract the game's D3D11 device from the swapchain and store it
    // for the overlay renderer to borrow. Without this, overlay_render.cpp's
    // create_overlay_d3d() cannot get the game device and the menu never draws.
    ID3D11Device* gameDev = nullptr;
    HRESULT hr = sc->GetDevice(__uuidof(ID3D11Device), (void**)&gameDev);
    if (SUCCEEDED(hr) && gameDev) {
        ID3D11DeviceContext* gameCtx = nullptr;
        gameDev->GetImmediateContext(&gameCtx);
        gfx::set_device(gameDev, gameCtx);
        FVEM_LOGF("[fvem] present: game D3D11 device %p ctx %p stored for overlay", gameDev, gameCtx);
    } else {
        FVEM_LOGF("[fvem] present: failed to get game D3D11 device hr=0x%lX", (unsigned long)hr);
    }

    g_game_window = find_game_window();
    FVEM_LOGF("[fvem] present: game window %p, activating scoped queue", g_game_window);
    native::set_scoped_queue_window(g_game_window);

    // NO slot write. Capture dxgi's real Present purely as reference data
    // (vtable stays 100% intact; see the removal note near the top of this
    //  file, where present_hooked used to be).
    g_orig_present = reinterpret_cast<PresentFn>(vtbl[8]);
    FVEM_LOGF("[fvem] present hook: DISCOVERY-ONLY - swapchain=%p real Present=%p "
              "(vtable untouched)", sc, g_orig_present);

    // Pump detour: drain + Insert toggle on the game's main thread WITHOUT
    // touching the window's WndProc chain. GWLP_WNDPROC stays stock; an
    // integrity scan reading the window-proc pointer finds the game's own
    // procedure, and our hooks ride two user32 entry points inside the same
    // hooked-family the watchdog shield already occupies.
    g_pump_tid = GetWindowThreadProcessId(g_game_window, nullptr);
    if (install_drain_timer()) {
        g_trigger_mode = 1;   // kernel timer; user32 stays byte-pristine
    } else {
        // Fallback only when SetTimer failed (null window / win32k refused):
        // the detour path we are trying to stop needing.
        g_trigger_mode = 0;
        HMODULE u32 = GetModuleHandleW(L"user32.dll");
        void* pk = u32 ? reinterpret_cast<void*>(
                     GetProcAddress(u32, "PeekMessageW")) : nullptr;
        void* gm = u32 ? reinterpret_cast<void*>(
                     GetProcAddress(u32, "GetMessageW")) : nullptr;
        bool a = pk && gfx::detour::install(pk, reinterpret_cast<void*>(&peek_hook),
                                            reinterpret_cast<void**>(&g_orig_peek));
        bool b = gm && gfx::detour::install(gm, reinterpret_cast<void*>(&getmsg_hook),
                                            reinterpret_cast<void**>(&g_orig_getmsg));
        FVEM_LOGF("[fvem] pump detour: Peek=%d Get=%d (main tid %lu, wndproc chain untouched)",
                  a ? 1 : 0, b ? 1 : 0, g_pump_tid);
    }
    return true;
}

} // namespace gfx
