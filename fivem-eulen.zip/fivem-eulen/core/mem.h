// language: C++, target: Windows 11, MSVC (x64)
// Bare SEH-guarded memory access for reading/writing the game's address space
// from inside it. Every helper is deliberately free of destructible locals so
// __try compiles under /EHsc (C2712) and a stale offset degrades to a safe
// zero/empty instead of crashing the target process.
//
// ALL fault filters here route through gfx::probe_filter (SILENT), NEVER a
// raw __except (EXCEPTION_EXECUTE_HANDLER) and NEVER log_fault_filter. A raw
// handler swallows MSVC C++ exceptions (0xE06D7363) before __CxxFrameHandler
// runs: the thrown object is never destroyed and the EH chain is left corrupt,
// crashing the game later (the observed "early-exit trap" ~30s after the
// swallow). probe_filter CONTINUE_SEARCHes C++ exceptions so try/catch
// unwinds normally. And these helpers are PROBES: module/section walks
// (game::init -> find_game_module -> match_build) routinely touch guard pages
// and unmapped regions while scanning; logging every one through
// log_fault_filter produced ~3MB of "FAULT" spam per boot (1029+ faults) on a
// RAM-starved machine, hammering disk/pagefile. Faults here are expected â€”
// the helper returns a safe zero/empty and the walk simply skips the entry.
#pragma once
#include <cstdint>
#include <cstddef>
#include "log.h"

namespace gfx::mem {

inline bool valid_ptr(uintptr_t p) {
    return p >= 0x10000 && p < 0x0000'7FFF'FFFF'FFFFull;
}

inline uintptr_t read_ptr(uintptr_t addr) {
    __try { return *reinterpret_cast<uintptr_t*>(addr); }
    __except (probe_filter(GetExceptionCode(), GetExceptionInformation())) { return 0; }
}

inline float read_float(uintptr_t addr) {
    __try { return *reinterpret_cast<float*>(addr); }
    __except (probe_filter(GetExceptionCode(), GetExceptionInformation())) { return 0.0f; }
}

inline int32_t read_i32(uintptr_t addr) {
    __try { return *reinterpret_cast<int32_t*>(addr); }
    __except (probe_filter(GetExceptionCode(), GetExceptionInformation())) { return 0; }
}

// Read a bounded char string (name buffers etc.).
inline void read_name(uintptr_t addr, char* out, size_t n) {
    __try {
        if (!out || n == 0) return;
        const char* s = reinterpret_cast<const char*>(addr);
        size_t i = 0;
        while (i < n - 1 && s[i]) { out[i] = s[i]; ++i; }
        out[i] = 0;
    } __except (probe_filter(GetExceptionCode(), GetExceptionInformation())) {
        if (out && n) out[0] = 0;
    }
}

inline void write_vec3(uintptr_t addr, float x, float y, float z) {
    __try {
        auto* p = reinterpret_cast<float*>(addr);
        p[0] = x; p[1] = y; p[2] = z;
    } __except (probe_filter(GetExceptionCode(), GetExceptionInformation())) { }
}

inline void write_ptr(uintptr_t addr, uintptr_t value) {
    __try { *reinterpret_cast<uintptr_t*>(addr) = value; }
    __except (probe_filter(GetExceptionCode(), GetExceptionInformation())) { }
}

} // namespace gfx::mem
