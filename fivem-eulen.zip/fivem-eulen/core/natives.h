// language: C++, target: Windows 11, MSVC (x64)
// Native-based feature layer. Everything funnels through the proven native
// invoker path (rage::scrEngine::GetNativeHandler + invoke_array / scoped) â€”
// NO game-module memory offsets, so a per-patch offset change cannot break
// the menu. State-changing calls route through invoke_scoped (borrowed script
// thread) so they never fault from the render thread.
//
// Hash space is the CFX universal namespace (natives_universal.lua).
#pragma once
#include <cstdint>
#include "native_invoker.h"

namespace gfx::nv {

// --- hashes (CFX universal) ---
inline constexpr uint64_t H_GET_PLAYER_NAME               = 0x6D0DE6A7B5DA71F8ull;
inline constexpr uint64_t H_GET_PLAYER_PED                = 0x43A66C31C68491C0ull;
inline constexpr uint64_t H_PLAYER_PED_ID                 = 0xD80958FC74E988A6ull;
inline constexpr uint64_t H_GET_ENTITY_COORDS             = 0x3FEF770D40960D5Aull;
inline constexpr uint64_t H_GET_ENTITY_HEADING            = 0xE83D4F9BA2A38914ull;
inline constexpr uint64_t H_GET_ENTITY_HEALTH             = 0xEEF059FAD016D209ull;
inline constexpr uint64_t H_GET_ENTITY_MAX_HEALTH         = 0x15D757606D170C3Cull;
inline constexpr uint64_t H_GET_ENTITY_SPEED              = 0xD5037BA82E12416Full;
inline constexpr uint64_t H_SET_ENTITY_COORDS             = 0x06843DA7060A026Bull;
inline constexpr uint64_t H_SET_ENTITY_HEADING            = 0x8E2530AA8ADA980Eull;
inline constexpr uint64_t H_SET_ENTITY_HEALTH             = 0x6B76DC1F3AE6E6A3ull;
inline constexpr uint64_t H_SET_ENTITY_MAX_HEALTH         = 0x166E7CF68597D8B5ull;
inline constexpr uint64_t H_SET_ENTITY_INVINCIBLE         = 0x3882114BDE571AD4ull;
inline constexpr uint64_t H_SET_ENTITY_CAN_BE_DAMAGED     = 0x1760FFA8AB074D66ull;
inline constexpr uint64_t H_SET_ENTITY_PROOFS             = 0xFAEE099C6F890BB8ull;
inline constexpr uint64_t H_SET_ENTITY_VISIBLE            = 0xEA1C610A04DB6BBBull;
inline constexpr uint64_t H_SET_ENTITY_ALPHA              = 0x44A0870B7E92D7C0ull;
inline constexpr uint64_t H_RESET_ENTITY_ALPHA            = 0x9B1E824FFBB7027Aull;
inline constexpr uint64_t H_GET_SCREEN_COORD_FROM_WORLD   = 0x34E82F05DF2974F5ull;
inline constexpr uint64_t H_GET_GAMEPLAY_CAM_ROT          = 0x837765A25378F0BBull;
inline constexpr uint64_t H_GET_GAMEPLAY_CAM_COORD        = 0x14D6F5678D8F1B37ull;
inline constexpr uint64_t H_GET_PED_BONE_COORDS           = 0x17C07FC640E86B4Eull;
inline constexpr uint64_t H_GET_PED_BONE_INDEX            = 0x3F428D08BE5AAE31ull;
inline constexpr uint64_t H_NETWORK_GET_NUM_CONNECTED     = 0xA4A79DD2D9600654ull;
inline constexpr uint64_t H_NETWORK_IS_PLAYER_ACTIVE      = 0xB8DFD30D6973E135ull;
inline constexpr uint64_t H_NETWORK_GET_PLAYER_INDEX_FROM_PED = 0x6C0E2E0125610278ull;
inline constexpr uint64_t H_IS_PED_A_PLAYER               = 0x12534C348C6CB68Bull;
inline constexpr uint64_t H_GET_PED_TYPE                  = 0xFF059E1E4C01E63Cull;
inline constexpr uint64_t H_GET_PED_ARMOUR                = 0x9483AF821605B1D8ull;
inline constexpr uint64_t H_SET_PED_ARMOUR                = 0xCEA04D83135264CCull;
inline constexpr uint64_t H_GIVE_WEAPON_TO_PED            = 0xBF0FD6E56C964FCBull;
inline constexpr uint64_t H_GET_PED_WEAPON                = 0x3A87E44BB9A01D54ull;
inline constexpr uint64_t H_SET_CURRENT_PED_WEAPON        = 0xADF692B254977C0Cull;
inline constexpr uint64_t H_REMOVE_ALL_PED_WEAPONS        = 0xF25DF915FA38C5F3ull;
inline constexpr uint64_t H_SET_PED_INTO_VEHICLE          = 0xF75B0D629E1C063Dull;
inline constexpr uint64_t H_TASK_WARP_PED_INTO_VEHICLE    = 0x9A7D091411C5F684ull;
inline constexpr uint64_t H_GET_VEHICLE_PED_IS_IN         = 0x9A9112A0FE9A4713ull;
inline constexpr uint64_t H_GET_PED_IN_VEHICLE_SEAT       = 0xBB40DD2270B65366ull;
inline constexpr uint64_t H_IS_PED_IN_ANY_VEHICLE         = 0x997ABD671D25CA0Bull;
inline constexpr uint64_t H_GET_IS_VEHICLE_ENGINE_RUNNING = 0xAE31E7DF9B5B132Eull;
inline constexpr uint64_t H_SET_VEHICLE_ENGINE_ON         = 0x2497C4717C8B881Eull;
inline constexpr uint64_t H_SET_VEHICLE_FIXED             = 0x115722B1B9C14C1Cull;
inline constexpr uint64_t H_SET_VEHICLE_DOORS_LOCKED      = 0xB664292EAECF7FA6ull;
inline constexpr uint64_t H_SET_VEHICLE_FORWARD_SPEED     = 0xAB54A438726D25D5ull;
inline constexpr uint64_t H_SET_VEHICLE_ON_GROUND_PROPERLY= 0x49733E92263139D1ull;
inline constexpr uint64_t H_GET_FIRST_BLIP_INFO_ID        = 0x1BEDE233E6CD2A1Full;
inline constexpr uint64_t H_GET_BLIP_COORDS               = 0x586AFE3FF72D996Eull;
inline constexpr uint64_t H_DOES_BLIP_EXIST               = 0xA6DB27D19ECBB7DAull;
inline constexpr uint64_t H_GET_BLIP_INFO_ID_TYPE         = 0xBE9B0959FFD0779Bull;
inline constexpr uint64_t H_SET_NEW_WAYPOINT              = 0xFE43368D2AA4F2FCull;
inline constexpr uint64_t H_IS_WAYPOINT_ACTIVE            = 0x1DD1F58F493F1DA5ull;
inline constexpr uint64_t H_SET_PLAYER_INVINCIBLE         = 0x239528EACDC3E7DEull;
inline constexpr uint64_t H_GET_PLAYER_WANTED_LEVEL       = 0xE28E54788CE8F12Dull;
inline constexpr uint64_t H_SET_PLAYER_WANTED_LEVEL       = 0x39FF19C64EF7DA5Bull;
inline constexpr uint64_t H_CLEAR_PLAYER_WANTED_LEVEL     = 0xB302540597885499ull;
inline constexpr uint64_t H_GET_ENTITY_TYPE               = 0x8ACD366038D14505ull;
inline constexpr uint64_t H_GET_ENTITY_ROTATION           = 0xAFBD61CC738D9EB9ull;
inline constexpr uint64_t H_SET_ENTITY_ROTATION           = 0x8524A8B0171D5E07ull;
inline constexpr uint64_t H_GET_CLOSEST_VEHICLE           = 0xF73EB622C4F1689Bull;
inline constexpr uint64_t H_GET_HASH_KEY                  = 0xD24D37CC275948CCull;

// Bone ids (GTA V, stable).
inline constexpr int kBoneHead   = 0x1D; // SKEL_Head
inline constexpr int kBoneNeck   = 0x05; // SKEL_Neck
inline constexpr int kBoneChest  = 0x07; // SKEL_Spine3
inline constexpr int kBonePelvis = 0x02; // SKEL_Pelvis

// --- position fix ---------------------------------------------------------
// GET_ENTITY_COORDS / blip / bone native results come back as (x, z, y) on
// this client: the third slot holds the map-plane y, the middle slot the
// height. Verified empirically: CREATE_VEHICLE succeeds exactly when the third
// slot is on-map (2113/-780 âœ“) and fails when it is off-map (7166 âœ—).
inline native::Vector3 fix_pos(const native::Vector3& v) {
    native::Vector3 out;
    out.x = v.x;
    out.y = v.z; // third slot is the real map-plane y
    out.z = v.y; // middle slot is the real height
    return out;
}

// --- reads (plain invoke â€” safe without a script context) ---
inline int num_connected_players() {
    return static_cast<int>(native::invoke<uint64_t>(H_NETWORK_GET_NUM_CONNECTED));
}
inline bool is_player_active(int player) {
    return native::invoke<bool>(H_NETWORK_IS_PLAYER_ACTIVE, static_cast<int64_t>(player)) != 0;
}
inline const char* player_name(int player) {
    return native::invoke<const char*>(H_GET_PLAYER_NAME, static_cast<int64_t>(player));
}
inline uint64_t player_ped(int player) {
    return native::invoke<uint64_t>(H_GET_PLAYER_PED, static_cast<int64_t>(player));
}
inline uint64_t player_ped_id() {
    return native::invoke<uint64_t>(H_PLAYER_PED_ID);
}
inline native::Vector3 entity_coords(uint64_t ent) {
    return fix_pos(native::invoke<native::Vector3>(H_GET_ENTITY_COORDS, ent, 0));
}
inline float entity_heading(uint64_t ent) {
    return native::invoke<float>(H_GET_ENTITY_HEADING, ent);
}
inline float entity_health(uint64_t ent) {
    return native::invoke<float>(H_GET_ENTITY_HEALTH, ent);
}
inline float entity_max_health(uint64_t ent) {
    return native::invoke<float>(H_GET_ENTITY_MAX_HEALTH, ent);
}
inline float entity_speed(uint64_t ent) {
    return native::invoke<float>(H_GET_ENTITY_SPEED, ent);
}
inline uint64_t get_entity_type(uint64_t ent) {
    return native::invoke<uint64_t>(H_GET_ENTITY_TYPE, ent);
}
inline int ped_armour(uint64_t ped) {
    return static_cast<int>(native::invoke<uint64_t>(H_GET_PED_ARMOUR, ped));
}
inline int get_ped_type(uint64_t ped) {
    return static_cast<int>(native::invoke<uint64_t>(H_GET_PED_TYPE, ped));
}
inline bool is_ped_a_player(uint64_t ped) {
    return native::invoke<bool>(H_IS_PED_A_PLAYER, ped) != 0;
}
inline uint64_t ped_bone_index(uint64_t ped, int bone) {
    return native::invoke<uint64_t>(H_GET_PED_BONE_INDEX, ped, static_cast<int64_t>(bone));
}
inline native::Vector3 ped_bone_coords(uint64_t ped, int bone) {
    return fix_pos(native::invoke<native::Vector3>(H_GET_PED_BONE_COORDS, ped,
                                                   static_cast<int64_t>(bone),
                                                   0.0f, 0.0f, 0.0f));
}
inline native::Vector3 gameplay_cam_rot(int order = 2) {
    return native::invoke<native::Vector3>(H_GET_GAMEPLAY_CAM_ROT,
                                           static_cast<int64_t>(order));
}
inline native::Vector3 gameplay_cam_coord() {
    return native::invoke<native::Vector3>(H_GET_GAMEPLAY_CAM_COORD);
}
// Returns true + screen pos when the world point is on screen.
inline bool world_to_screen(const native::Vector3& wp, float& sx, float& sy) {
    float ox = 0.0f, oy = 0.0f;
    uint64_t ok = native::invoke<uint64_t>(H_GET_SCREEN_COORD_FROM_WORLD, wp.x, wp.y, wp.z,
                                           &ox, &oy);
    if (!ok) return false;
    sx = ox; sy = oy;
    return true;
}
inline uint64_t first_blip_info_id(int type) {
    return native::invoke<uint64_t>(H_GET_FIRST_BLIP_INFO_ID, static_cast<int64_t>(type));
}
inline bool does_blip_exist(uint64_t blip) {
    return native::invoke<bool>(H_DOES_BLIP_EXIST, blip) != 0;
}
inline int blip_info_type(uint64_t blip) {
    return static_cast<int>(native::invoke<uint64_t>(H_GET_BLIP_INFO_ID_TYPE, blip));
}
inline native::Vector3 blip_coords(uint64_t blip) {
    return fix_pos(native::invoke<native::Vector3>(H_GET_BLIP_COORDS, blip));
}
inline bool is_waypoint_active() {
    return native::invoke<bool>(H_IS_WAYPOINT_ACTIVE) != 0;
}
inline uint64_t vehicle_ped_is_in(uint64_t ped, bool last = false) {
    return native::invoke<uint64_t>(H_GET_VEHICLE_PED_IS_IN, ped, last ? 1ull : 0ull);
}
inline uint64_t ped_in_vehicle_seat(uint64_t veh, int seat) {
    return native::invoke<uint64_t>(H_GET_PED_IN_VEHICLE_SEAT, veh, static_cast<int64_t>(seat));
}
inline bool is_ped_in_any_vehicle(uint64_t ped, bool at_getin = false) {
    return native::invoke<bool>(H_IS_PED_IN_ANY_VEHICLE, ped, at_getin ? 1ull : 0ull) != 0;
}
inline bool is_vehicle_engine_running(uint64_t veh) {
    return native::invoke<bool>(H_GET_IS_VEHICLE_ENGINE_RUNNING, veh) != 0;
}

// --- state-changing (scoped â€” borrowed script-thread context) ---
inline void set_entity_coords(uint64_t ent, float x, float y, float z,
                              bool ground = false, bool axis = false,
                              bool clear = false, bool keep = false) {
    native::invoke_scoped<void>(H_SET_ENTITY_COORDS, ent, x, y, z,
                                ground ? 1ull : 0ull, axis ? 1ull : 0ull,
                                clear ? 1ull : 0ull, keep ? 1ull : 0ull);
}
inline void set_entity_heading(uint64_t ent, float heading) {
    native::invoke_scoped<void>(H_SET_ENTITY_HEADING, ent, heading);
}
inline void set_entity_health(uint64_t ent, float health) {
    native::invoke_scoped<void>(H_SET_ENTITY_HEALTH, ent, health);
}
inline void set_entity_max_health(uint64_t ent, float health) {
    native::invoke_scoped<void>(H_SET_ENTITY_MAX_HEALTH, ent, health);
}
inline void set_entity_invincible(uint64_t ent, bool inv) {
    native::invoke_scoped<void>(H_SET_ENTITY_INVINCIBLE, ent, inv ? 1ull : 0ull);
}
inline void set_entity_can_be_damaged(uint64_t ent, bool dmg) {
    native::invoke_scoped<void>(H_SET_ENTITY_CAN_BE_DAMAGED, ent, dmg ? 1ull : 0ull);
}
inline void set_entity_proofs(uint64_t ent, bool bullet, bool fire, bool explosion,
                              bool collision, bool melee, bool steam, bool drown,
                              bool water) {
    native::invoke_scoped<void>(H_SET_ENTITY_PROOFS, ent, bullet ? 1ull : 0ull,
                                fire ? 1ull : 0ull, explosion ? 1ull : 0ull,
                                collision ? 1ull : 0ull, melee ? 1ull : 0ull,
                                steam ? 1ull : 0ull, drown ? 1ull : 0ull,
                                water ? 1ull : 0ull);
}
inline void set_ped_armour(uint64_t ped, int armour) {
    native::invoke_scoped<void>(H_SET_PED_ARMOUR, ped, static_cast<int64_t>(armour));
}
inline void give_weapon_to_ped(uint64_t ped, uint64_t weapon, int ammo,
                               bool hidden = false, bool equip = true) {
    native::invoke_scoped<void>(H_GIVE_WEAPON_TO_PED, ped, weapon,
                                static_cast<int64_t>(ammo), hidden ? 1ull : 0ull,
                                equip ? 1ull : 0ull);
}
inline void remove_all_ped_weapons(uint64_t ped, bool keep = false) {
    native::invoke_scoped<void>(H_REMOVE_ALL_PED_WEAPONS, ped, keep ? 1ull : 0ull);
}
inline void set_ped_into_vehicle(uint64_t ped, uint64_t veh, int seat) {
    native::invoke_scoped<void>(H_SET_PED_INTO_VEHICLE, ped, veh, static_cast<int64_t>(seat));
}
inline void task_warp_ped_into_vehicle(uint64_t ped, uint64_t veh, int seat) {
    native::invoke_scoped<void>(H_TASK_WARP_PED_INTO_VEHICLE, ped, veh, static_cast<int64_t>(seat));
}
inline void set_vehicle_engine_on(uint64_t veh, bool on, bool immediately = true) {
    native::invoke_scoped<void>(H_SET_VEHICLE_ENGINE_ON, veh, on ? 1ull : 0ull,
                                immediately ? 1ull : 0ull);
}
inline void set_vehicle_fixed(uint64_t veh) {
    native::invoke_scoped<void>(H_SET_VEHICLE_FIXED, veh);
}
inline void set_vehicle_doors_locked(uint64_t veh, int lock) {
    native::invoke_scoped<void>(H_SET_VEHICLE_DOORS_LOCKED, veh, static_cast<int64_t>(lock));
}
inline void set_vehicle_forward_speed(uint64_t veh, float speed) {
    native::invoke_scoped<void>(H_SET_VEHICLE_FORWARD_SPEED, veh, speed);
}
inline void set_vehicle_on_ground_properly(uint64_t veh) {
    native::invoke_scoped<void>(H_SET_VEHICLE_ON_GROUND_PROPERLY, veh);
}
inline void set_player_invincible(int player, bool inv) {
    native::invoke_scoped<void>(H_SET_PLAYER_INVINCIBLE, static_cast<int64_t>(player),
                                inv ? 1ull : 0ull);
}
inline void set_player_wanted_level(int player, int level) {
    native::invoke_scoped<void>(H_SET_PLAYER_WANTED_LEVEL, static_cast<int64_t>(player),
                                static_cast<int64_t>(level), 0);
}
inline void clear_player_wanted_level(int player) {
    native::invoke_scoped<void>(H_CLEAR_PLAYER_WANTED_LEVEL, static_cast<int64_t>(player));
}
inline void set_new_waypoint(float x, float y) {
    native::invoke_scoped<void>(H_SET_NEW_WAYPOINT, x, y);
}
inline uint64_t get_hash_key(const char* s) {
    return native::invoke<uint64_t>(H_GET_HASH_KEY, s);
}
inline uint64_t get_closest_vehicle(float x, float y, float z, float radius,
                                    int model = 0, int flags = 127) {
    return native::invoke<uint64_t>(H_GET_CLOSEST_VEHICLE, x, y, z,
                                    radius, static_cast<int64_t>(model),
                                    static_cast<int64_t>(flags));
}

} // namespace gfx::nv
