// language: C++, target: Windows 11, MSVC (x64)
#include "pch.h"
#include "config.h"

namespace gfx {

Config& cfg() {
    static Config c;
    return c;
}

std::atomic<bool> g_running{ false };

static ID3D11Device*        g_device = nullptr;
static ID3D11DeviceContext* g_ctx    = nullptr;

ID3D11Device*        d3d_device() { return g_device; }
ID3D11DeviceContext* d3d_ctx()    { return g_ctx; }

void set_device(ID3D11Device* d, ID3D11DeviceContext* c) { g_device = d; g_ctx = c; }

// Cached image base â€” see config.h. 0 until entry.cpp's DllMain sets it.
static uintptr_t g_image_base = 0;
uintptr_t image_base()            { return g_image_base; }
void      set_image_base(uintptr_t b) { g_image_base = b; }

} // namespace gfx