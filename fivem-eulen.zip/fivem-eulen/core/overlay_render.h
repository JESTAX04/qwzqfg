// language: C++, target: Windows 11, MSVC (x64)
// Overlay renderer: owns a SEPARATE D3D11 device + swap chain for the overlay
// window and drives ImGui from a dedicated loop â€” completely decoupled from
// the game's Present hook.
//
// WHY THIS FIXES THE EARLY-EXIT TRAP: the old build initialized ImGui against
// the game's swapchain device and rendered inside IDXGISwapChain::Present,
// which runs on the game's MAIN thread. Every ImGui frame there extended the
// game's frame time; under FXServer load on the same machine the main thread
// stalled past FiveM's watchdog limit and the watchdog killed the process
// ("early-exit trap"). Here the overlay renders on its own loop via its own
// device/swap chain, capped at 30 FPS with Sleep() yielding â€” the game's main
// thread is never involved, so fvem can no longer stall it.
//
// THREAD MODEL: this DLL is manual-mapped â€” the static CRT's per-thread state
// (_tiddata/TLS) only exists on the trampoline thread that ran
// _DllMainCRTStartup/_CRT_INIT. A raw CreateThread/_beginthreadex in this
// image died before its first instruction (startup fault swallowed by the
// game; observed "render thread spawned" with no "thread started"). The
// overlay therefore runs INLINE on that same trampoline thread: after boot
// completes, entry.cpp calls overlay_render_run() which never returns while
// g_running is true. The trampoline thread is a private remote thread
// (NtCreateThreadEx from the injector), NOT the game's main thread, so the
// watchdog never sees our work. The game's WndProc hook (game thread) only
// toggles cfg().menu_open â€” an atomic â€” and drains the scoped queue.
#pragma once
#include "pch.h"

namespace gfx {

// Run the overlay loop inline on the CALLING thread (the trampoline thread).
// Creates the overlay window, its own D3D11 device/swap chain, initializes
// ImGui and enters the render pump. Does not return while gfx::g_running is
// true; performs full cleanup before returning.
void overlay_render_run();

// Signal the render loop to stop. The loop joins itself out â€” it owns the
// ImGui context + D3D11 resources. Safe to call once from another thread.
void overlay_render_shutdown();

// Toggle the menu open/closed (Insert). Flips the click-through style so the
// overlay captures input exactly while the menu is visible.
void overlay_toggle_menu();

// One-way close used by the ImGui window X button (menu.cpp). Mirrors the
// toggle-to-close path exactly: flip state, release mouse + focus, wipe frame.
void overlay_close_menu();

// Toggle the standalone F8 console window (RedEngine-style REPL). Same
// single-trigger/debounce discipline as overlay_toggle_menu; open/close
// re-syncs overlay clickability against BOTH windows.
void overlay_toggle_console();

} // namespace gfx
