// language: C++, target: Windows 11, MSVC (x64)
// Full cheat menu: Visuals (ESP), Aimbot, Players, Vehicles, Teleport, Lua.
// Every feature routes through the native invoker (no memory offsets).
#include "pch.h"
#include "config.h"
#include "features.h"
#include "natives.h"
#include "overlay_render.h"   // overlay_close_menu (X-button path)
#include "../third_party/imgui/imgui.h"
#include "../third_party/imgui/misc/cpp/imgui_stdlib.h"
#include "lua_scheduler.h"
#include "../common/obf.h"

namespace gfx {

namespace {

const char* k_bones[] = { "Head", "Neck", "Chest", "Pelvis" };

static void style_tab() {
    auto& c = cfg();
    ImGui::Checkbox("ESP Enabled", &c.esp_enabled);
    ImGui::Checkbox("Boxes", &c.esp_boxes);
    ImGui::Checkbox("Health", &c.esp_health);
    ImGui::Checkbox("Names", &c.esp_names);
    ImGui::Checkbox("Distance", &c.esp_distance);
    ImGui::SliderFloat("Max Distance", &c.esp_max_dist, 50.0f, 2000.0f, "%.0f");
    ImGui::Separator();
    ImGui::Checkbox("Watermark", &c.watermark);
    ImGui::Checkbox("Info Overlay", &c.show_info);
    ImGui::Separator();
    // FPS cap: limits Present so the render loop doesn't peg every core.
    // 0 = uncapped. Critical when hosting the server on the same machine.
    ImGui::SliderInt("FPS Cap", &c.fps_cap, 0, 144, c.fps_cap ? "%d fps" : "Uncapped");
    if (ImGui::IsItemHovered())
        ImGui::SetTooltip("Caps the game's render loop. 60 keeps it smooth while halving CPU load.");
}

static void aim_tab() {
    auto& c = cfg();
    ImGui::Checkbox("Aimbot Enabled", &c.aim_enabled);
    ImGui::SliderFloat("FOV", &c.aim_fov, 0.5f, 45.0f, "%.1f deg");
    ImGui::SliderFloat("Smooth", &c.aim_smooth, 1.0f, 30.0f, "%.1f");
    ImGui::Combo("Bone", &c.aim_bone, k_bones, 4);
    ImGui::Checkbox("Silent (camera)", &c.aim_silent);
}

static void players_tab() {
    auto& c = cfg();
    ImGui::Checkbox("God Mode", &c.plr_godmode);
    ImGui::Checkbox("Infinite Health", &c.plr_infinite_health);
    ImGui::Checkbox("Infinite Armour", &c.plr_infinite_armour);
    ImGui::Checkbox("No Wanted Level", &c.plr_no_wanted);
    ImGui::Separator();
    ImGui::SliderInt("Set Health", &c.plr_health_amount, 0, 200);
    if (ImGui::Button("Apply Health")) {
        uint64_t ped = nv::player_ped_id();
        if (ped) {
            nv::set_entity_health(ped, static_cast<float>(c.plr_health_amount));
            nv::set_entity_max_health(ped, 200.0f);
        }
    }
    ImGui::SliderInt("Set Armour", &c.plr_armour_amount, 0, 100);
    if (ImGui::Button("Apply Armour")) {
        uint64_t ped = nv::player_ped_id();
        if (ped) nv::set_ped_armour(ped, c.plr_armour_amount);
    }
    ImGui::SliderInt("Wanted Level", &c.plr_wanted_level, 0, 5);
    if (ImGui::Button("Apply Wanted")) {
        nv::set_player_wanted_level(0, c.plr_wanted_level);
    }
    ImGui::Separator();
    if (ImGui::Button("Give Weapon (pistol)")) {
        uint64_t ped = nv::player_ped_id();
        if (ped) {
            uint64_t w = nv::get_hash_key("weapon_pistol");
            nv::give_weapon_to_ped(ped, w, 250, false, true);
        }
    }
    if (ImGui::Button("Give Weapon (assault rifle)")) {
        uint64_t ped = nv::player_ped_id();
        if (ped) {
            uint64_t w = nv::get_hash_key("weapon_assaultrifle");
            nv::give_weapon_to_ped(ped, w, 500, false, true);
        }
    }
    if (ImGui::Button("Remove All Weapons")) {
        uint64_t ped = nv::player_ped_id();
        if (ped) nv::remove_all_ped_weapons(ped, false);
    }
}

static void vehicle_tab() {
    auto& c = cfg();
    ImGui::InputText("Model", c.spawn_model, sizeof(c.spawn_model));
    if (ImGui::Button("Spawn Vehicle"))
        spawn_vehicle(c.spawn_model);
    ImGui::Separator();
    ImGui::Checkbox("Engine On (in vehicle)", &c.veh_engine);
    ImGui::Checkbox("Doors Locked (in vehicle)", &c.veh_doors);
    if (ImGui::Button("Fix Current Vehicle"))
        cfg().veh_fix = true;
}

static void teleport_tab() {
    auto& c = cfg();
    ImGui::Checkbox("Teleport to Waypoint", &c.tp_to_marker);
    ImGui::InputFloat3("Marker XYZ", &c.tp_marker_x);
    if (ImGui::Button("Teleport"))
        do_teleport();
}

static void lua_tab() {
    auto& c = cfg();
    static std::string src =
        "-- fvem Tier S executor\n"
        "-- Citizen.Wait yields (never blocks the game); top-level runs in a coroutine.\n"
        "CreateThread(function()\n"
        "    while true do\n"
        "        Wait(1000)\n"
        "        print('alive, ped =', PlayerPedId())\n"
        "    end\n"
        "end)\n";
    static std::string cmd;
    static char status[128]{};

    ImGui::InputTextMultiline("##src", &src,
                              ImVec2(-1, ImGui::GetTextLineHeight() * 9));
    if (ImGui::Button("Execute")) {
        std::string err;
        if (!hub_run_once(src, err) && !err.empty())
            hub_console_push("[exec] " + err);
    }
    ImGui::SameLine();
    if (ImGui::Button("Run (thread)")) {
        unsigned id = hub_run_script("script", src);
        snprintf(status, sizeof(status), id ? "started #%u" : "load failed (see console)");
    }
    ImGui::SameLine();
    if (ImGui::Button("Stop All")) hub_stop_all();
    ImGui::SameLine();
    if (ImGui::Button("Clear Editor")) src.clear();

    ImGui::Spacing();
    ImGui::Checkbox("Allow NETWORK natives", &c.lua_allow_net);
    ImGui::SameLine();
    ImGui::Checkbox("Hijack F8", &c.console_hijack_f8);
    ImGui::SameLine();
    ImGui::SliderInt("Kill budget", &c.lua_kill_budget, 0, 2000000,
                     "%d insns/resume");
    if (ImGui::IsItemHovered())
        ImGui::SetTooltip("0 = unlimited. Looping scripts are killed at this many VM instructions per frame.");

    if (ImGui::CollapsingHeader("Scripts", ImGuiTreeNodeFlags_DefaultOpen)) {
        std::vector<HubScriptInfo> list;
        hub_list(list);
        if (list.empty()) ImGui::TextDisabled("(no scripts running)");
        for (auto& s : list) {
            const char* st = s.state == 0 ? "waiting" : s.state == 1 ? "running"
                           : s.state == 2 ? "DEAD" : "done";
            ImGui::PushID((int)s.id);
            ImGui::Text("#%u %s [%s]", s.id, s.name.c_str(), st);
            if (s.state == 2 && !s.last_err.empty() && ImGui::IsItemHovered())
                ImGui::SetTooltip("%s", s.last_err.c_str());
            ImGui::SameLine(ImGui::GetWindowWidth() - 60);
            if (s.state != 3 && ImGui::SmallButton("Stop")) hub_stop(s.id);
            ImGui::PopID();
        }
    }

    ImGui::Text("Console");
    ImGui::BeginChild("##console", ImVec2(-1, 140), true);
    for (auto& line : hub_console_lines())
        ImGui::TextUnformatted(line.c_str());
    if (ImGui::GetScrollY() >= ImGui::GetScrollMaxY() - 4.0f)
        ImGui::SetScrollHereY(1.0f);
    ImGui::EndChild();
    ImGui::SameLine();
    if (ImGui::SmallButton("Clear")) hub_console_clear();

    ImGui::SetNextItemWidth(ImGui::GetContentRegionAvail().x - 70);
    bool submit = ImGui::InputTextWithHint("##cmd", "/command [args]", &cmd,
                                           ImGuiInputTextFlags_EnterReturnsTrue);
    ImGui::SameLine();
    if (ImGui::Button("Run##cmd") || submit) {
        if (!cmd.empty()) {
            if (!hub_run_command(cmd))
                hub_console_push("[hub] unknown command: " + cmd);
            cmd.clear();
        }
    }
    if (status[0]) { ImGui::SameLine(); ImGui::TextDisabled("%s", status); }
}

// --- F8 console window (RedEngine-style REPL) -------------------------------
// Gated by its own flag so it works with the menu closed. Enter runs the
// line INLINE on the overlay thread via hub_run_once (instant, errors into
// the scrollback); '/' lines are commands, with a few console-side ones.
void console_window() {
    static bool s_shown = false;
    static std::string in;
    const bool open = cfg().console_open.load(std::memory_order_relaxed);
    if (!open) { s_shown = false; return; }
    const bool just_opened = !s_shown;
    s_shown = true;

    static const gfx::obf::EncA kTitle{ "FVEM console" };
    char title[48]{}; kTitle.out(title, sizeof(title));
    const float dy = ImGui::GetIO().DisplaySize.y;
    const float dx = ImGui::GetIO().DisplaySize.x;
    if (just_opened) {
        ImGui::SetNextWindowPos(ImVec2(dx * 0.28f, dy * 0.24f), ImGuiCond_FirstUseEver);
        ImGui::SetNextWindowSize(ImVec2(dx * 0.44f, dy * 0.52f), ImGuiCond_FirstUseEver);
    }
    ImGui::Begin(title, nullptr, ImGuiWindowFlags_NoCollapse);
    if (just_opened) ImGui::SetWindowFocus();
    // ESC closes when no input field owns the keyboard (InputText eats the
    // first ESC to end editing, so this is the second press).
    if (ImGui::IsKeyPressed(ImGuiKey_Escape) && !ImGui::GetIO().WantCaptureKeyboard) {
        overlay_toggle_console();
        ImGui::End();
        return;
    }

    const float input_h = ImGui::GetFrameHeightWithSpacing() + 8.0f;
    ImGui::BeginChild("##hist", ImVec2(-1, -input_h), true);
    for (auto& line : hub_console_lines())
        ImGui::TextUnformatted(line.c_str());
    if (just_opened || ImGui::GetScrollY() >= ImGui::GetScrollMaxY() - 4.0f)
        ImGui::SetScrollHereY(1.0f);
    ImGui::EndChild();

    ImGui::PushItemWidth(ImGui::GetContentRegionAvail().x - 60.0f);
    if (just_opened) ImGui::SetKeyboardFocusHere(0);   // land in the input
    bool submit = ImGui::InputTextWithHint("##repl",
        "lua — Enter runs inline; /run <code> spawns a thread", &in,
        ImGuiInputTextFlags_EnterReturnsTrue);
    ImGui::PopItemWidth();
    if (just_opened) ImGui::SetKeyboardFocusHere(-1);
    ImGui::SameLine();
    bool run = ImGui::Button("Run");
    if (submit || run) {
        std::string line = in;
        in.clear();
        if (!line.empty()) {
            hub_console_push("> " + line);
            if (line[0] == '/') {
                std::string c = line.substr(1);
                if      (c == "clear") hub_console_clear();
                else if (c == "stopall") hub_stop_all();
                else if (c.rfind("stop ", 0) == 0)
                    hub_stop((unsigned)atoi(c.c_str() + 5));
                else if (c.rfind("run ", 0) == 0)
                    hub_run_script("console", c.substr(4));
                else if (!hub_run_command(line))
                    hub_console_push("[hub] unknown command: " + line);
            } else {
                std::string err;
                if (!hub_run_once(line, err) && !err.empty())
                    hub_console_push(err);
            }
        }
    }
    ImGui::End();
}

void draw_overlay() {
    auto& c = cfg();
    if (c.watermark) {
        // On-screen brand is stored encrypted so "FVEM" never appears as a
        // plaintext literal in .rdata (screenshot OCR aside, a static memory
        // scan for the brand is the detection path this closes).
        static const gfx::obf::EncA kMark{ "FVEM" };
        char mk[8]{}; kMark.out(mk, sizeof(mk));
        ImGui::GetBackgroundDrawList()->AddText(
            ImVec2(10, 10), IM_COL32(0, 255, 180, 255), mk);
    }
    if (c.show_info) {
        int players = 0;
        for (int p = 0; p < 256; ++p)
            if (nv::is_player_active(p)) ++players;
        char buf[96];
        snprintf(buf, sizeof(buf), "Players: %d   FPS: %.0f", players,
                 ImGui::GetIO().Framerate);
        ImGui::GetBackgroundDrawList()->AddText(ImVec2(10, 26),
                                                IM_COL32(255, 255, 255, 200), buf);
    }
}

} // namespace

void menu_draw() {
    if (cfg().menu_open.load(std::memory_order_relaxed)) {
        // Frame-local mirror: ImGui::Begin writes *p_open when the user hits
        // the window close box. menu_open is atomic (cross-thread toggles), so
        // we hand ImGui a local bool and propagate ONLY a close (true->false).
        // Never store `true` back: if another thread (Insert hook) closed the
        // menu mid-frame, writing true would reopen it â€” the flicker/reopen
        // class of bug.
        bool open = true;
        ImGui::SetNextWindowSize(ImVec2(460, 460), ImGuiCond_FirstUseEver);
        // Window title decoded from encrypted storage each frame (stable bytes ->
        // stable ImGui ID) so the brand isn't a plaintext literal in the image.
        static const gfx::obf::EncA kTitle{ "FVEM â€” FiveM Executor" };
        char title[64]{}; kTitle.out(title, sizeof(title));
        ImGui::Begin(title, &open,
                     ImGuiWindowFlags_NoCollapse);

        if (ImGui::BeginTabBar("tabs")) {
            if (ImGui::BeginTabItem("Visuals")) { style_tab(); ImGui::EndTabItem(); }
            if (ImGui::BeginTabItem("Aimbot"))  { aim_tab();   ImGui::EndTabItem(); }
            if (ImGui::BeginTabItem("Players")) { players_tab(); ImGui::EndTabItem(); }
            if (ImGui::BeginTabItem("Vehicles")){ vehicle_tab(); ImGui::EndTabItem(); }
            if (ImGui::BeginTabItem("Teleport")){ teleport_tab(); ImGui::EndTabItem(); }
            if (ImGui::BeginTabItem("Lua"))     { lua_tab();    ImGui::EndTabItem(); }
            ImGui::EndTabBar();
        }

        ImGui::End();
        // The X box must go through the SAME close path as the Insert key:
        // a bare store(false) left the overlay mouse-capturing, focus-held
        // and the last menu frame welded on screen ("opened, never closes"
        // symptom even on fresh builds when the user clicked X).
        if (!open) overlay_close_menu();
    }

    console_window();   // gated by its own flag; coexists with the menu
    draw_overlay();
}

} // namespace gfx
