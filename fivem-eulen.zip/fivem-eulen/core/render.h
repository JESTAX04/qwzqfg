// language: C++, target: Windows 11, MSVC (x64)
// Render glue: owns the ImGui context lifecycle and the per-frame draw pass.
// One-time init against the game's swapchain device, then render_frame() runs
// every hooked Present.
#pragma once
#include "pch.h"

namespace gfx {
// Create the ImGui context + backends against the game's device and window.
// Safe to call once; subsequent calls no-op.
void init_render(HWND hwnd, ID3D11Device* dev, ID3D11DeviceContext* ctx);

// Full overlay pass: new frame, menu + feature draw lists, present draw data.
void render_frame();
} // namespace gfx
