// language: C++, target: Windows 11, MSVC (x64)
// Feature/config state shared across menu, ESP, aimbot, spawner, teleport.
#pragma once
#include "pch.h"

namespace gfx {

struct Config {
    // ESP â€” off by default: the per-frame player gather loop must not run
    // unless the user explicitly enables it. On this hardware (i7-3770,
    // server+client on one machine) an always-on ESP loop starves the game
    // main thread and trips FiveM's watchdog ("early-exit trap").
    bool   esp_enabled   = false;
    bool   esp_boxes     = true;
    bool   esp_health    = true;
    bool   esp_names     = true;
    bool   esp_distance  = true;
    float  esp_max_dist  = 500.0f;

    // Aimbot
    bool   aim_enabled   = false;
    float  aim_fov       = 6.0f;   // degrees
    float  aim_smooth    = 8.0f;   // higher = slower
    int    aim_bone      = 0;      // 0 head, 1 neck, 2 chest, 3 pelvis
    bool   aim_silent    = false;

    // Vehicle spawn
    char   spawn_model[64] = "sultan";

    // Player cheats
    bool   plr_godmode = false;
    bool   plr_infinite_health = false;
    bool   plr_infinite_armour = false;
    bool   plr_no_wanted = false;
    int    plr_health_amount = 200;
    int    plr_armour_amount = 100;
    int    plr_wanted_level = 0;

    // Teleport
    float  tp_marker_x = 0, tp_marker_y = 0, tp_marker_z = 0;
    bool   tp_to_marker = false;
    bool   tp_teleport_back = false; // return to last position

    // Misc
    bool   veh_engine = false;
    bool   veh_doors = false;
    bool   veh_fix = false;

    // FPS cap â€” 0 = uncapped. The user's FXServer runs on the SAME machine as
    // the game (i7-3770): uncapped FPS during active play pegs every core,
    // starves the server's sync thread (100-200ms hitches), the game's net
    // thread stalls and FiveM's watchdog kills the process ("early-exit trap").
    // Capping Present to 60 halves the render-loop CPU load.
    int    fps_cap = 60;

    // Lua hub (Tier S executor)
    //  - lua_allow_net: NETWORK_* natives are gated off by default; a
    //    standalone-scripted network call out of context is a ban vector and
    //    a desync generator. Scripts still LOAD without it; flagged calls
    //    return nil and print a one-line console warning.
    //  - lua_kill_budget: MASKCOUNT instructions per coroutine resume.
    //    0 disables the kill switch. 200k = tens of ms worst case per tick.
    bool   lua_allow_net   = false;
    int    lua_kill_budget = 200000;

    // Menu defaults â€” closed and idle until the user presses Insert: no
    // ImGui window and no overlay draws while the game is under load.
    // ATOMIC: toggled from TWO threads (the game window's WndProc hook on the
    // game's main thread and the overlay window's WndProc on the overlay
    // thread). A plain bool would race â€” torn toggles are exactly how a menu
    // "sometimes won't open" (double-hook symptom class). ImGui's close box
    // writes through a frame-local mirror (menu.cpp) synced back each frame.
    std::atomic<bool> menu_open{ false };
    // RedEngine-style console: F8 (edge-polled in the game pump, same single
    // trigger model as Insert) opens an always-on-top REPL window wired to
    // the hub — Enter runs inline via hub_run_once, '/' lines are commands.
    std::atomic<bool> console_open{ false };
    // Swallow the game's own F8 debug-console keydown so the two consoles
    // never fight. Off = F8 opens FiveM's console as usual, ours too.
    bool   console_hijack_f8 = true;
    bool   show_info = false;   // FPS/player count overlay
    bool   watermark = false;   // "FVEM" watermark
};

Config& cfg();

// Globals established by entry.cpp / hooks.cpp
extern std::atomic<bool> g_running;
ID3D11Device* d3d_device();
ID3D11DeviceContext* d3d_ctx();
void set_device(ID3D11Device* d, ID3D11DeviceContext* c);

// Cached base of the mapped image. The injector now maps us at a randomized
// base (no fixed 0x180000000 signature) and the PE header is erased during
// evasion, so module_base_from_ptr()'s MZ-walk can no longer find us. entry.cpp
// caches the base from the DllMain hModule before any of that happens; every
// "where is my own image" query uses this instead of a header scan.
uintptr_t image_base();
void      set_image_base(uintptr_t b);

} // namespace gfx