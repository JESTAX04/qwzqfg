// language: C++, target: Windows 11, MSVC (x64)
// RAGE offsets tables for builds 3258 / 3751 / 3788, plus build detection.
// All values are RVAs (module_base + value). Heuristic/hardcoded fields are
// tagged inline; reverify per client patch.
//
// IMPORTANT: FiveM ships its game code in a renamed module (random word per
// build, e.g. "adhesive.dll"); the GTAProcess exe is only a loader. The RAGE
// globals/funcs live in THAT module, so base() must resolve to it â€” we walk
// the PEB loader list and match each module's GameBuildString global against
// the tables instead of trusting the main module.
#include "pch.h"
#include "offsets.h"
#include "mem.h"
#include "log.h"
#include <intrin.h>

namespace gfx::game {

namespace {

const GameBuild k3258{
    3258,
    // globals
    0x25B14B0, 0x201DBA0, 0x201E7D0, 0x201ED50, 0x1FBD4F0,
    0x25B1758, 0x2F23F78, 0x2244218, 0x2982050, 0x2023400,
    0x2D2CAA0, 0x1F73508, 0x1E63C68, 0x2721250, 0x22295B0,
    0x2CFA4E0, 0x26671F0, 0x1F74BD8,
    // cped
    0x10A8, 0x10B8, 0x280, 0x284, 0x150C, 0x189, 0x320, 0x1444,
    0xDD0, 0x20, 0x30, 0x2C8, 0x810, 0x10B8, 0x2B,
    0xFF8, 0x78, 0x0, 0x40, 0xC,
    // player info
    0x100, 0x88, 0x16E4,
    // entity / nav
    0x60, 0x90, 0x50,
    // vehicle
    0xC98, 0x960, 0xA48, 0x21C, 0xD50, 0x143C, 0x130, 0x840, 0x13C0,
    0x10A8, 0x10A0,
    // weapon
    0x2E8, 0x178, 0xB0, 0x41C, 0x250, 0xD6C, 0x10A8,
    // replay
    0x18, 0xD10,
    // funcs
    0x361134, 0x79EED4, 0x222234, 0xD7B760, 0xD8DD28, 0x10CFFDC,
    0x1613E0, 0x18BF88, 0xF4A86C, 0xA8455C, 0xA843C4, 0x81228C,
    0x38EE7C, 0x2679B8, 0x2083FC, 0xA6DCE0, 0x101A660, 0xD73990,
    0xD76558, 0xD753F8, 0x393134, 0xA88070, 0xD765D8, 0x255C88,
    0x441D80, 0x1088914, 0x627594, 0xD8D278, 0xCF6170, 0x15EA144,
    0x7C3E88, 0x12BBF4, 0xD9D1B4, 0x17C663, 0x102373B, 0x71366E,
    0x11BEA4,
    0x17240, 0x11570, 0x13674, 0x12D84,
};

const GameBuild k3751{
    3751,
    // globals
    0x2603908, 0x206C060, 0x206CC40, 0x206D1C0, 0x1FC38A8,
    0x2603BF0, 0x2FA8D48, 0x2296268, 0x29E6750, 0x206D600,
    0x2D7DE88, 0x1FC1CC8, 0x1EB1BD0, 0x27830D0, 0x227B610,
    0x2D7DBF0, 0x26C6D58, 0,
    // cped
    0x10A8, 0x10B8, 0x280, 0x28C, 0x150C, 0x189, 0x320, 0x1444,
    0xD10, 0x20, 0x30, 0x2C8, 0x810, 0x10B8, 0x2B,
    0x12B8, 0x78, 0x0, 0x40, 0xC,
    // player info
    0x100, 0x88, 0x16E4,
    // entity / nav
    0x60, 0x90, 0x50,
    // vehicle
    0xCA8, 0x960, 0xAF8, 0x21C, 0xD50, 0x143C, 0x130, 0x840, 0x13C0,
    0x10A8, 0x10A0,
    // weapon
    0x2E8, 0x178, 0xB0, 0x41C, 0x250, 0xD6C, 0x10A8,
    // replay
    0x18, 0xD10,
    // funcs
    0x35E5A8, 0x7A38B4, 0x21EBF0, 0xD8A5F0, 0xD9CDA8, 0x10E720C,
    0x160DC8, 0x189440, 0xF5AFCC, 0xA8A4F0, 0xA8A358, 0x8171F8,
    0x38C4DC, 0x2642A8, 0x204E28, 0xA73838, 0x102B560, 0xD825F4,
    0xD8530C, 0xD84064, 0x390794, 0xA8E0F8, 0xD8538C, 0x252610,
    0x43FA10, 0, 0x62B970, 0xD9C2F8, 0xD035B4, 0x1627134,
    0x7C895C, 0x12BB54, 0xDAC3C4, 0, 0x1034729, 0x71815E,
    0x11BE2C,
    0x1730C, 0x116A4, 0x1379C, 0x12EB8,
};

const GameBuild k3788{
    3788,
    // globals
    0x26068E0, 0x206F060, 0x206FC40, 0x20701C0, 0x1FC68A8,
    0x2606BD0, 0x2FA8D48, 0x2299250, 0x29E9738, 0x2070600,
    0x2D80E08, 0x1FC4CD0, 0x1EB4BE0, 0x27860B0, 0x227E5F0,
    0x2D80B70, 0, 0,
    // cped
    0x10A8, 0x10B8, 0x280, 0x284, 0x150C, 0x189, 0x320, 0x1444,
    0xDD0, 0x20, 0x30, 0x2C8, 0x810, 0x10B8, 0x2B,
    0x12B8, 0x78, 0x0, 0x40, 0xC,
    // player info
    0x100, 0x88, 0x16E4,
    // entity / nav
    0x60, 0x90, 0x50,
    // vehicle
    0xCA8, 0x960, 0xAF8, 0x21C, 0xD50, 0x143C, 0x130, 0x840, 0x13C0,
    0x10A8, 0x10A0,
    // weapon
    0x2E8, 0x178, 0xB0, 0x41C, 0x250, 0xD6C, 0x10A8,
    // replay
    0x18, 0xD10,
    // funcs
    0x35EA84, 0x7A4714, 0x21F2A8, 0xD8C1C0, 0xD9EAC8, 0x10EA0D8,
    0x161548, 0x189B54, 0xF5CB7C, 0xA8BD58, 0xA8BBC0, 0x8181B0,
    0x38C964, 0x264BD4, 0x2054E8, 0xA74EA0, 0x102DF54, 0xD8403C,
    0xD86DF8, 0xD85AE0, 0x390C1C, 0xA8F950, 0xD86EA8, 0x252E6C,
    0x43FC60, 0, 0x62BE50, 0xD9E00C, 0xD04E30, 0x162A270,
    0x7C97C4, 0x12C1BC, 0xDAE140, 0, 0x10370CD, 0x718EC6,
    0x11C3B0,
    0x17428, 0x11634, 0x1390C, 0x13028,
};

const GameBuild* kAll[] = { &k3258, &k3751, &k3788 };
uintptr_t g_base = 0;
uintptr_t g_size = 0;
const GameBuild* g_build = &k3788;

// Read a table's GameBuildString global and parse its digits (e.g. "b3258"
// or "1.0.3258.0" â†’ 3258). Tolerates both storage styles: global holding a
// pointer to the string, or the string inline at the global.
uint32_t parse_build_digits(uintptr_t mod_base, const GameBuild& b) {
    char buf[48]{};
    mem::read_name(mod_base + b.GameBuildString, buf, sizeof(buf));
    if (!buf[0]) {
        uintptr_t gs = mem::read_ptr(mod_base + b.GameBuildString);
        if (gs) mem::read_name(gs, buf, sizeof(buf));
    }
    uint32_t v = 0;
    bool any = false;
    for (char c : buf) {
        if (c >= '0' && c <= '9') { v = v * 10 + (c - '0'); any = true; }
    }
    return any ? v : 0;
}

// Scan a module's readable sections for an ASCII needle (version string).
// Storage-agnostic: finds "1.0.3258.0" / "b3258" wherever the client keeps it.
bool find_string_in_module(uintptr_t mod_base, const char* needle) {
    uintptr_t dos = mod_base;
    if (mem::read_i32(dos) != 0x00905A4D) return false; // MZ
    uintptr_t e_lfanew = mem::read_i32(dos + 0x3C);
    if (!e_lfanew) return false;
    uintptr_t nt = dos + e_lfanew;
    uintptr_t sec_off = nt + 0x18; // FileHeader
    int num_sec = mem::read_i32(nt + 0x06);
    if (num_sec < 1 || num_sec > 96) return false;

    size_t nlen = 0;
    while (needle[nlen]) ++nlen;
    if (nlen == 0) return false;

    for (int i = 0; i < num_sec; ++i) {
        uintptr_t s = sec_off + i * 40; // IMAGE_SECTION_HEADER = 40 bytes
        uint32_t chars = mem::read_i32(s + 36);
        if (!(chars & 0x80000000u)) continue; // IMAGE_SCN_MEM_READ
        uintptr_t va = mem::read_i32(s + 12);          // VirtualAddress
        uint32_t vsz = mem::read_i32(s + 8);           // VirtualSize
        if (vsz == 0 || vsz > 0x10000000u) continue;
        uintptr_t begin = mod_base + va;
        // Bounded memcmp scan (read via raw pointer â€” inside our process).
        __try {
            for (uint32_t off = 0; off + nlen < vsz; ++off) {
                if (*reinterpret_cast<const char*>(begin + off) == needle[0]) {
                    if (memcmp(reinterpret_cast<const void*>(begin + off),
                               needle, nlen) == 0)
                        return true;
                }
            }
        } __except (probe_filter(GetExceptionCode(), GetExceptionInformation())) { continue; }
    }
    return false;
}

// Test one module base against all tables; returns the matching table or null.
const GameBuild* match_build(uintptr_t mod_base) {
    for (auto* b : kAll) {
        // Primary: the literal version string somewhere in the module.
        char needle[32];
        snprintf(needle, sizeof(needle), "1.0.%u.0", b->version);
        if (find_string_in_module(mod_base, needle)) return b;
        // Secondary: the GameBuildString global (pointer or inline).
        if (parse_build_digits(mod_base, *b) == b->version) return b;
    }
    return nullptr;
}

// PE image size from the module's headers (SizeOfImage).
uintptr_t image_size(uintptr_t mod_base) {
    if (mem::read_i32(mod_base) != 0x00905A4D) return 0; // MZ
    uintptr_t e_lfanew = mem::read_i32(mod_base + 0x3C);
    if (!e_lfanew) return 0;
    uintptr_t nt = mod_base + e_lfanew;
    // OptionalHeader.SizeOfImage at NT_HEADERS64: Signature(4)+FileHeader(20)+0x38
    return mem::read_i32(nt + 0x50);
}

// Walk the PEB InLoadOrderModuleList; find the module whose GameBuildString
// matches one of our tables (the game-code module, whatever its name).
uintptr_t find_game_module(const GameBuild** out_build, uintptr_t* out_size) {
#if defined(_M_X64)
    auto* peb = reinterpret_cast<uint8_t*>(__readgsqword(0x60));
    uintptr_t ldr = mem::read_ptr(reinterpret_cast<uintptr_t>(peb) + 0x18);
    if (!ldr) return 0;

    uintptr_t head = ldr + 0x10; // InLoadOrderModuleList
    uintptr_t cur = mem::read_ptr(head);
    while (cur && cur != head) {
        uintptr_t dll = mem::read_ptr(cur + 0x30); // LDR_DATA_TABLE_ENTRY.DllBase
        if (mem::valid_ptr(dll)) {
            if (const GameBuild* b = match_build(dll)) {
                *out_build = b;
                *out_size = image_size(dll);
                return dll;
            }
        }
        cur = mem::read_ptr(cur); // Flink
    }
#endif
    return 0;
}

} // namespace

bool init(uint32_t version) {
    // Preferred: the game-code module found via the PEB loader walk.
    if (version != 0) {
        for (auto* b : kAll) {
            if (b->version == version) { g_build = b; break; }
        }
    }

    const GameBuild* b = nullptr;
    uintptr_t size = 0;
    g_base = find_game_module(&b, &size);

    if (!g_base) {
        // Fallback: main module (retail-style layout or stub still hosting the code).
        g_base = reinterpret_cast<uintptr_t>(GetModuleHandleW(nullptr));
        if (g_base) {
            b = match_build(g_base);
            size = image_size(g_base);
        }
    }

    if (!g_base) return false;

    if (b) g_build = b;
    g_size = size ? size : 0x4000000ull;
    if (!b) {
        FVEM_LOGF("[fvem] offsets: NO build string matched, defaulting to newest table");
    }

    // Boot audit: state the matched table explicitly (settles the b3751-
    // process-vs-3788-detected question from live logs), then probe every
    // global so the per-patch holes name themselves instead of silently
    // reading null (the old "swapchain: game global read null" leak).
    FVEM_LOGF("[fvem] offsets: table=%u base=%p size=%p",
              g_build->version, reinterpret_cast<void*>(g_base),
              reinterpret_cast<void*>(g_size));
    {
        struct named_global { const char* name; size_t off; };
        static const named_global gs[] = {
            {"World", offsetof(GameBuild, World)},
            {"Viewport", offsetof(GameBuild, Viewport)},
            {"Camera", offsetof(GameBuild, Camera)},
            {"CamGameplayDirector", offsetof(GameBuild, CamGameplayDirector)},
            {"ReplayInterface", offsetof(GameBuild, ReplayInterface)},
            {"PedPool", offsetof(GameBuild, PedPool)},
            {"VehiclePool", offsetof(GameBuild, VehiclePool)},
            {"NetworkPlayerMgr", offsetof(GameBuild, NetworkPlayerMgr)},
            {"NetworkObjectMgr", offsetof(GameBuild, NetworkObjectMgr)},
            {"BlipList", offsetof(GameBuild, BlipList)},
            {"Swapchain", offsetof(GameBuild, Swapchain)},
            {"AimCPed", offsetof(GameBuild, AimCPed)},
            {"PlayerNames", offsetof(GameBuild, PlayerNames)},
            {"SkySettings", offsetof(GameBuild, SkySettings)},
            {"GameBuildString", offsetof(GameBuild, GameBuildString)},
            {"RaycastXWord", offsetof(GameBuild, RaycastXWord)},
            {"StreamableTextureDict", offsetof(GameBuild, StreamableTextureDict)},
            {"IsSessionStarted", offsetof(GameBuild, IsSessionStarted)},
        };
        int zero = 0, bad = 0, ok = 0;
        for (const auto& g : gs) {
            uintptr_t rva = *reinterpret_cast<const uintptr_t*>(
                reinterpret_cast<const char*>(g_build) + g.off);
            if (!rva) { ++zero;
                FVEM_LOGF("[fvem] offsets: %s = MISSING", g.name); continue; }
            uintptr_t v = mem::read_ptr(g_base + rva);
            // Globals hold pointers OR inline data/flags: "bad" only when the
            // slot itself is unreadable (read_ptr returns 0 on fault) AND the
            // rva lies outside the image.
            if (!mem::valid_ptr(g_base + rva)) { ++bad;
                FVEM_LOGF("[fvem] offsets: %s rva=%p UNREADABLE", g.name,
                          reinterpret_cast<void*>(rva)); continue; }
            ++ok;
        }
        FVEM_LOGF("[fvem] offsets: globals audit ok=%d missing=%d unreadable=%d",
                  ok, zero, bad);
    }
    return true;
}

void set_base(uintptr_t base) { g_base = base; g_size = 0x4000000ull; }

const GameBuild& build() { return *g_build; }
uintptr_t base() { return g_base; }
uintptr_t image_size() { return g_size; }

} // namespace gfx::game
