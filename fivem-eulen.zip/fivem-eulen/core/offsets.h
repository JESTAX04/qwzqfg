// language: C++, target: Windows 11, MSVC (x64)
// RAGE game offsets, per build (3258 / 3751 / 3788). All values are module
// RVAs: resolve as module_base + value (globals are also RVAs, not absolute).
// Marked fields ("heuristic") came from memory dumps and are the per-patch
// re-derivation seam â€” reverify against the target client before trusting.
#pragma once
#include <cstdint>

namespace gfx::game {

struct GameBuild {
    uint32_t version;

    // --- engine globals ---
    uintptr_t World, Viewport, Camera, CamGameplayDirector, ReplayInterface,
              PedPool, VehiclePool, NetworkPlayerMgr, NetworkObjectMgr, BlipList,
              Swapchain, AimCPed, PlayerNames, SkySettings, GameBuildString,
              RaycastXWord, StreamableTextureDict, IsSessionStarted;

    // --- CPed ---
    uintptr_t ped_player_info, ped_weapon_manager, ped_health, ped_max_health,
              ped_armor, ped_godmode, ped_velocity, ped_config_flags,
              ped_last_vehicle, ped_model_info, ped_navigation, ped_net_object,
              ped_intelligence, ped_task_tree, ped_entity_type,
              ped_bone_matrix, ped_skel_o1, ped_skel_o2, ped_skel_stride,
              ped_skel_trans;

    // --- CPlayerInfo ---
    uintptr_t plr_name, plr_net_id, plr_stamina;

    // --- CEntity / CNav ---
    uintptr_t ent_visual_matrix, ent_position, nav_position;

    // --- CVehicle ---
    uintptr_t veh_driver, veh_handling, veh_engine_health, veh_engine_state,
              veh_speed, veh_seatbelt, veh_petrol_tank_health, veh_body_health,
              veh_door_lock, veh_damage_mod, veh_defense_mod;

    // --- CWeapon ---
    uintptr_t wpn_recoil, wpn_spread, wpn_damage, wpn_ammo_type, wpn_name_hash,
              wpn_defense_mod, wpn_melee_damage;

    // --- ReplayInterface ---
    uintptr_t replay_ped_interface, replay_vehicle_interface;

    // --- code RVAs (module_base + value) ---
    uintptr_t fn_get_bone_pos, fn_has_entity_clear_los, fn_line_of_sight,
              fn_get_vehicle_ped_is_in, fn_set_vehicle_plate, fn_get_player_name,
              fn_explode_vehicle, fn_world_probe, fn_get_ped_bone_index,
              fn_get_rendering_cam, fn_get_final_rendered_cam_coord,
              fn_get_gameplay_cam_rot, fn_get_shape_test_result, fn_shape_test,
              fn_intersect_ray, fn_attach_entity_to_entity, fn_bullet_handler,
              fn_current_ped_weapon, fn_get_entity_heading,
              fn_get_ped_last_weapon_impact, fn_give_weapon_to_ped,
              fn_is_cam_active, fn_is_model_in_cdimage, fn_is_ped_a_player,
              fn_network_get_entity_from_net_id, fn_network_is_session_started,
              fn_remove_all_ped_weapons, fn_repair_vehicle, fn_request_model,
              fn_set_entity_coords_no_offset, fn_set_ped_into_vehicle,
              fn_set_vehicle_engine_on, fn_task_warp_ped_into_vehicle,
              fn_weapon_spread_h, fn_weapon_spread_v, fn_player_stamina,
              fn_raycast_core,
              // low-RVA heuristic hits
              fn_is_cutscene, fn_set_vehicle_fixed,
              fn_start_shape_test_los_probe, fn_network_get_player_index_from_ped;
};

// Select a build table. version 0 = auto-detect by reading each table's
// GameBuildString global and matching its digits. Falls back to the newest
// known table (3788) when nothing matches; returns false only if the game
// module base itself is unavailable.
bool init(uint32_t version = 0);

// Active table + game module base (the FiveM game-code module, found via the
// PEB loader walk â€” NOT the GTAProcess loader exe).
const GameBuild& build();
uintptr_t base();
uintptr_t image_size();
void set_base(uintptr_t b);

} // namespace gfx::game
