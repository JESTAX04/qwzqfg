// language: C++, target: Windows 11, MSVC (x64)
// Render glue: owns the ImGui context lifecycle and the per-frame draw pass.
// init_render() runs once on the first hooked Present against the game's
// swapchain device; render_frame() runs every frame after that.
#include "pch.h"
#include "config.h"
#include "features.h"
#include "log.h"
#include "../third_party/imgui/imgui.h"
#include "../third_party/imgui/backends/imgui_impl_dx11.h"
#include "../third_party/imgui/backends/imgui_impl_win32.h"

namespace gfx {

namespace {
bool g_imgui_ready = false;
// Overlay draw cadence: the menu/ESP overlay only redraws every other frame
// (~30fps) instead of every frame. The menu stays fully usable, but the
// overlay's CPU cost on the game's main thread is halved Ã¢â‚¬â€ on weak machines
// (i7-3770 hosting the server) an always-60fps overlay starves the game and
// trips FiveM's watchdog. State-changing button actions still enqueue fine;
// only the visual redraw is throttled.
unsigned g_draw_ticks = 0;
}

void init_render(HWND hwnd, ID3D11Device* dev, ID3D11DeviceContext* ctx) {
    if (g_imgui_ready) return;
    if (!hwnd || !dev || !ctx) {
        FVEM_LOGF("[fvem] render: init_render skipped (hwnd=%p dev=%p ctx=%p)", hwnd, dev, ctx);
        return;
    }

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    // No imgui.ini / imgui_log.txt in the game's working directory. This is the
    // second of the two CreateContext() call sites; both must stay nulled or
    // one path silently reintroduces the disk write.
    ImGui::GetIO().IniFilename = nullptr;
    ImGui::GetIO().LogFilename = nullptr;
    ImGui::StyleColorsDark();

    bool ok_w = ImGui_ImplWin32_Init(hwnd);
    bool ok_d = ImGui_ImplDX11_Init(dev, ctx);
    FVEM_LOGF("[fvem] render: imgui init win32=%d dx11=%d", ok_w ? 1 : 0, ok_d ? 1 : 0);
    if (!ok_w || !ok_d) return;

    g_imgui_ready = true;
    FVEM_LOGF("[fvem] render: imgui ready");
}

// True when nothing wants a draw pass this frame: menu closed and no overlay
// (watermark / info / ESP). In that state we skip the entire ImGui frame so
// fvem costs zero CPU on the game's main thread Ã¢â‚¬â€ critical on weak hardware
// where an always-rendering overlay starves the game and trips FiveM's
// watchdog ("early-exit trap").
bool overlay_wants_frame() {
    const auto& c = cfg();
    return c.menu_open.load(std::memory_order_relaxed) || c.watermark ||
           c.show_info || c.esp_enabled;
}

void render_frame() {
    if (!g_imgui_ready) return;
    if (!overlay_wants_frame()) {
        // No visible overlay: still service per-frame cheat ticks (they early
        // return when disabled) but draw nothing.
        __try { aimbot_tick(); }          __except (gfx::log_fault_filter(GetExceptionCode(), GetExceptionInformation())) { cfg().aim_enabled = false; }
        __try { player_cheats_tick(); }   __except (gfx::log_fault_filter(GetExceptionCode(), GetExceptionInformation())) { cfg().plr_godmode = false; cfg().plr_infinite_health = false; cfg().plr_infinite_armour = false; cfg().plr_no_wanted = false; }
        __try { vehicle_tools_tick(); }   __except (gfx::log_fault_filter(GetExceptionCode(), GetExceptionInformation())) { cfg().veh_engine = false; cfg().veh_doors = false; cfg().veh_fix = false; }
        __try { tick_spawn(); }           __except (gfx::log_fault_filter(GetExceptionCode(), GetExceptionInformation())) { FVEM_LOGF("[fvem] render: tick_spawn faulted"); }
        return;
    }

    __try {
        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();
    } __except (gfx::log_fault_filter(GetExceptionCode(), GetExceptionInformation())) {
        FVEM_LOGF("[fvem] render: NewFrame faulted, imgui disabled for this boot");
        g_imgui_ready = false;
        return;
    }

    __try {
        menu_draw();
    } __except (gfx::log_fault_filter(GetExceptionCode(), GetExceptionInformation())) {
        FVEM_LOGF("[fvem] render: menu_draw faulted, disabled for this boot");
        cfg().menu_open.store(false, std::memory_order_relaxed);
    }

    __try {
        esp_draw();
    } __except (gfx::log_fault_filter(GetExceptionCode(), GetExceptionInformation())) {
        cfg().esp_enabled = false;
    }

    __try {
        aimbot_tick();
    } __except (gfx::log_fault_filter(GetExceptionCode(), GetExceptionInformation())) {
        cfg().aim_enabled = false;
    }

    // Per-frame cheat enforcement (godmode / health / armour / wanted).
    __try {
        player_cheats_tick();
    } __except (gfx::log_fault_filter(GetExceptionCode(), GetExceptionInformation())) {
        cfg().plr_godmode = false;
        cfg().plr_infinite_health = false;
        cfg().plr_infinite_armour = false;
        cfg().plr_no_wanted = false;
    }

    // Per-frame vehicle tools (engine / doors / one-shot fix).
    __try {
        vehicle_tools_tick();
    } __except (gfx::log_fault_filter(GetExceptionCode(), GetExceptionInformation())) {
        cfg().veh_engine = false;
        cfg().veh_doors = false;
        cfg().veh_fix = false;
    }

    // Advance the queued spawn one step per frame (never blocks Present).
    __try {
        tick_spawn();
    } __except (gfx::log_fault_filter(GetExceptionCode(), GetExceptionInformation())) {
        FVEM_LOGF("[fvem] render: tick_spawn faulted");
    }

    ImGui::Render();
    ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());
}

} // namespace gfx
