// language: C++, target: Windows 11, MSVC (x64)
// Render faÃ§ade: ties the feature draw calls into the frame loop.
#pragma once
#include "pch.h"

namespace gfx {
void menu_draw();
void esp_draw();      // overlays boxes/health/names/distance
void aimbot_tick();   // applied before Present returns
void run_user_lua(const char* script);
void spawn_vehicle(const char* model);
void tick_spawn();    // advance the queued spawn one step (per frame)
void do_teleport();
void player_cheats_tick();   // godmode / health / armour / wanted (per frame)
void vehicle_tools_tick();   // engine / doors / fix on current vehicle
} // namespace gfx