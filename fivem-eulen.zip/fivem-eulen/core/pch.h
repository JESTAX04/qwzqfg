// language: C++, target: Windows 11, MSVC (x64)
// Precompiled header for fvem_core.
#pragma once

#define WIN32_LEAN_AND_MEAN
#define NOMINMAX
#include <windows.h>
#include <d3d11.h>
#include <dxgi.h>
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <cstdio>
#include <exception>
#include <vector>
#include <string>
#include <unordered_map>
#include <functional>
#include <mutex>
#include <atomic>
#include <cmath>
#include <algorithm>

#include "../common/syscalls.h"
#include "../common/pe.h"
#include "../common/scanner.h"
#include "../common/sol.h"