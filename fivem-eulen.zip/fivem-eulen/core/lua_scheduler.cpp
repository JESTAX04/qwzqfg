// language: C++, target: Windows 11, MSVC (x64)
// See lua_scheduler.h for the architecture contract.
//
// Tier S hub: owns the lua_State, the Citizen compatibility layer, the
// coroutine scheduler with deadline Wait, the local event bus, commands,
// keybinds, session KVP, console ring and the instruction-budget kill
// switch. The native bridge (name __index + typed marshalling) lives in
// lua_state.cpp and is registered before the prelude runs.
//
// Threading: every entry point here (tick, hub_run_*, hub_stop, hub_list)
// runs on the overlay/trampoline thread — the same thread that owns the
// lua_State. There is exactly ONE lua_State and it is never touched from
// the game main thread. No locks, no cross-thread VM calls.
#include "pch.h"
#include "lua_scheduler.h"
#include "config.h"
#include "features.h"
#include "log.h"
#include "native_invoker.h"

#include <cstdlib>
#include <deque>
#include <unordered_map>

extern "C" {
#include "lua.h"
#include "lauxlib.h"
#include "lualib.h"
}

namespace gfx {
// bridge half (lua_state.cpp)
void register_native_bridge(lua_State* L);
void bridge_clear_string_arena();
}

namespace gfx::hub {
namespace {

lua_State*  gL = nullptr;

// NOTE: no sol2 here on purpose. sol::state's construction path throws C++
// exceptions (observed live: "attempt to index a nil value" panic surfaced
// as an uncaught 0xE06D7363 at boot and FiveM ate it — unwinding a mapped
// image is fragile ground). The whole hub is raw Lua C API, which never
// throws C++ and never unwinds. luaL_newstate + luaL_openlibs only.

// ---------------------------------------------------------------------------
// registry refs: every Lua object the hub holds is an explicit integer ref.
// ---------------------------------------------------------------------------
int  ref_pop()  { return luaL_ref(gL, LUA_REGISTRYINDEX); }
// C functions run on the CALLER coroutine's stack — refs must pop from that
// L, never gL (popping from the wrong state grabs garbage).
int  ref_pop(lua_State* L) { return luaL_ref(L, LUA_REGISTRYINDEX); }
void ref_push(int r) { if (r != LUA_NOREF) lua_rawgeti(gL, LUA_REGISTRYINDEX, r); }
void ref_drop(int r) { if (r != LUA_NOREF) luaL_unref(gL, LUA_REGISTRYINDEX, r); }

std::string lower(std::string s) {
    for (auto& c : s) c = static_cast<char>(::tolower((unsigned char)c));
    return s;
}

// ---------------------------------------------------------------------------
// console ring
// ---------------------------------------------------------------------------
std::vector<std::string> g_console;
void console_push(const std::string& line) {
    g_console.push_back(line);
    if (g_console.size() > 1200)
        g_console.erase(g_console.begin(), g_console.begin() + 400);
}

// ---------------------------------------------------------------------------
// coroutine engine
// ---------------------------------------------------------------------------
enum : int { ST_WAIT = 0, ST_RUN, ST_DEAD, ST_DONE };

struct Coroutine {
    int co_ref  = LUA_NOREF;
    int fn_ref  = LUA_NOREF;
    int arg_ref = LUA_NOREF;
    bool owns_fn = true;              // false = shared trampoline ref
    uint64_t deadline = 0;
    int state = ST_WAIT;
};

struct Script : Coroutine {
    uint32_t id = 0;
    std::string name;
    std::string last_err;
};

std::deque<Script>     g_scripts;   // user "Run (thread)" scripts
std::deque<Coroutine>  g_threads;   // Citizen.CreateThread / SetTimeout / handlers
uint32_t g_next_id = 1;

int g_tramp_ref = LUA_NOREF;        // __fvem_run body (shared)

void budget_hook(lua_State* L, lua_Debug*) {
    luaL_error(L, "instruction budget exceeded (script killed)");
}

// Resume once. Citizen.Wait(ms) yields one number -> deadline. Errors and
// the budget kill surface as ST_DEAD; normal end as ST_DONE.
int resume_one(Coroutine& c, std::string& err) {
    lua_State* co = nullptr;
    int nargs = 0;
    if (c.co_ref == LUA_NOREF) {
        co = lua_newthread(gL);
        c.co_ref = luaL_ref(gL, LUA_REGISTRYINDEX);   // pops thread, keeps alive
        ref_push(c.fn_ref);
        lua_xmove(gL, co, 1);                          // fn at thread slot 1
        if (c.arg_ref != LUA_NOREF) {
            ref_push(c.arg_ref);
            lua_xmove(gL, co, 1);                      // arg as fn's parameter
            nargs = 1;
        }
    } else {
        ref_push(c.co_ref);
        co = lua_tothread(gL, -1);
        lua_pop(gL, 1);
    }

    const int budget = cfg().lua_kill_budget;
    if (budget > 0) lua_sethook(co, budget_hook, LUA_MASKCOUNT, budget);
    int nres = 0;
    const int status = lua_resume(co, gL, nargs, &nres);
    lua_sethook(co, nullptr, 0, 0);

    if (status == LUA_OK) {
        ref_drop(c.co_ref); c.co_ref = LUA_NOREF;
        return ST_DONE;
    }
    if (status == LUA_YIELD) {
        double ms = 0;
        if (nres >= 1) {
            ms = lua_tonumber(co, -nres);
            if (!(ms >= 0.0)) ms = 0.0;
            if (ms > 300000.0) ms = 300000.0;          // 5-minute clamp
        }
        c.deadline = GetTickCount64() + (uint64_t)ms;
        lua_settop(co, 0);
        return ST_WAIT;
    }
    const char* msg = lua_tostring(co, -1);
    err = msg ? msg : "unknown lua error";
    lua_settop(co, 0);
    ref_drop(c.co_ref); c.co_ref = LUA_NOREF;
    return ST_DEAD;
}

void drop_coro(Coroutine& c) { ref_drop(c.co_ref); c.co_ref = LUA_NOREF; }

Coroutine* spawn_direct(int fn_ref) {
    g_threads.push_back(Coroutine{});
    Coroutine& c = g_threads.back();
    c.fn_ref = fn_ref;
    return &c;
}

// Dispatch (event/command/keybind) as a coroutine over the shared trampoline
// with pkg = { fn, args }. consume_args: drop args_ref after embedding it.
bool spawn_dispatch(int fn_ref, int args_ref, bool consume_args) {
    if (g_tramp_ref == LUA_NOREF) return false;
    lua_newtable(gL);
    ref_push(fn_ref);   lua_rawseti(gL, -2, 1);
    if (args_ref != LUA_NOREF) {
        ref_push(args_ref);
        lua_rawseti(gL, -2, 2);
        if (consume_args) ref_drop(args_ref);
    }
    int pkg = ref_pop();
    g_threads.push_back(Coroutine{});
    Coroutine& c = g_threads.back();
    c.fn_ref   = g_tramp_ref;
    c.owns_fn  = false;
    c.arg_ref  = pkg;
    return true;
}

// ---------------------------------------------------------------------------
// key names / control map (curated subset; unknown controls answer false)
// ---------------------------------------------------------------------------
int vk_from_name(const char* n) {
    if (!n) return 0;
    std::string s = lower(n);
    if (s.size() == 1) {
        const char c = s[0];
        if (c >= 'a' && c <= 'z') return c - 32;
        if (c >= '0' && c <= '9') return c;
    }
    struct { const char* n; int vk; } tbl[] = {
        { "space", VK_SPACE }, { "enter", VK_RETURN }, { "tab", VK_TAB },
        { "escape", VK_ESCAPE }, { "insert", VK_INSERT }, { "delete", VK_DELETE },
        { "backspace", VK_BACK }, { "home", VK_HOME }, { "end", VK_END },
        { "pageup", VK_PRIOR }, { "pagedown", VK_NEXT }, { "pgup", VK_PRIOR }, { "pgdn", VK_NEXT },
        { "left", VK_LEFT }, { "right", VK_RIGHT }, { "up", VK_UP }, { "down", VK_DOWN },
        { "shift", VK_LSHIFT }, { "lshift", VK_LSHIFT }, { "rshift", VK_RSHIFT },
        { "ctrl", VK_LCONTROL }, { "lctrl", VK_LCONTROL }, { "rctrl", VK_RCONTROL },
        { "alt", VK_MENU }, { "lalt", VK_LMENU }, { "ralt", VK_RMENU },
        { "capslock", VK_CAPITAL },
        { "num0", VK_NUMPAD0 }, { "num1", VK_NUMPAD1 }, { "num2", VK_NUMPAD2 },
        { "num3", VK_NUMPAD3 }, { "num4", VK_NUMPAD4 }, { "num5", VK_NUMPAD5 },
        { "num6", VK_NUMPAD6 }, { "num7", VK_NUMPAD7 }, { "num8", VK_NUMPAD8 },
        { "num9", VK_NUMPAD9 }, { "numadd", VK_ADD }, { "numsubtract", VK_SUBTRACT },
        { "multiply", VK_MULTIPLY }, { "divide", VK_DIVIDE },
    };
    for (auto& e : tbl) if (s == e.n) return e.vk;
    if (s.size() <= 3 && s[0] == 'f') {
        const int f = atoi(s.c_str() + 1);
        if (f >= 1 && f <= 24) return VK_F1 + (f - 1);
    }
    return 0;
}

int ctrl_to_vk(int ctrl) {
    switch (ctrl) {
        case 0: return VK_RETURN;  case 1: return VK_LBUTTON;
        case 20: return VK_LCONTROL; case 21: return VK_LSHIFT;
        case 22: return VK_SPACE;  case 23: return 'F';
        case 24: return VK_LBUTTON; case 25: return VK_RBUTTON;
        case 26: return VK_LMENU;
        case 30: return 'A'; case 31: return 'D'; case 32: return 'W'; case 33: return 'S';
        case 34: return 'A'; case 35: return 'D';
        case 36: return VK_LCONTROL; case 37: return VK_LMENU;
        case 38: return 'E'; case 39: return 'E'; case 44: return 'Q';
        case 45: return 'R'; case 46: return 'R'; case 47: return 'G';
        case 48: return VK_TAB; case 49: return 'H'; case 50: return VK_LBUTTON;
        case 51: return 'X'; case 52: return 'R'; case 59: return 'V';
        case 60: case 61: case 62: case 63: case 64: return VK_LMENU;
        case 68: return VK_LBUTTON;
        case 69: return 'A'; case 70: return 'D'; case 71: return 'W'; case 72: return 'S';
        case 73: return 'A'; case 75: return 'L';
        case 76: return 'I'; case 77: return 'K'; case 78: return 'J'; case 79: return 'O';
        case 80: return 'L';
        case 91: case 92: return VK_ESCAPE;
        case 96: return 'B'; case 98: return VK_LMENU;
        case 106: return VK_RBUTTON;
        case 114: return VK_SPACE;
        case 121: case 122: return VK_LCONTROL;
        case 140: return VK_LCONTROL; case 141: return VK_RSHIFT;
        case 142: return 'W'; case 143: return 'S';
        default: return 0;
    }
}

bool ctrl_down(int ctrl) {
    const int vk = ctrl_to_vk(ctrl);
    if (!vk) return false;
    return (GetAsyncKeyState(vk) & 0x8000) != 0;
}

std::unordered_map<int, bool> g_ctrl_prev;

// bus containers (declared before first use)
std::unordered_map<std::string, std::vector<int>> g_handlers;
std::unordered_map<std::string, int>              g_commands;
std::deque<std::pair<std::string, int>>           g_eventq;   // name, args-ref
struct Keybind { int vk = 0; int fn_ref = LUA_NOREF; bool prev = false; };
std::unordered_map<std::string, Keybind>          g_keybinds;

// ---------------------------------------------------------------------------
// hub C functions (registered raw; prelude re-exposes as Citizen.*)
// ---------------------------------------------------------------------------
int l_CreateThread(lua_State* L) {
    luaL_checktype(L, 1, LUA_TFUNCTION);
    lua_pushvalue(L, 1);
    spawn_direct(ref_pop(L));
    return 0;
}
int l_CreateThreadNow(lua_State* L) {
    luaL_checktype(L, 1, LUA_TFUNCTION);
    lua_pushvalue(L, 1);
    Coroutine* c = spawn_direct(ref_pop(L));
    std::string err;
    c->state = resume_one(*c, err);
    if (c->state == ST_DEAD) console_push("[citizen] CreateThreadNow: " + err);
    return 0;
}
int l_SetTimeout(lua_State* L) {
    double ms = luaL_checknumber(L, 1);
    luaL_checktype(L, 2, LUA_TFUNCTION);
    if (!(ms >= 0.0)) ms = 0.0;
    lua_pushvalue(L, 2);
    Coroutine* c = spawn_direct(ref_pop(L));
    c->deadline = GetTickCount64() + (uint64_t)ms;
    return 0;
}
int l_AddEventHandler(lua_State* L) {
    const char* n = luaL_checkstring(L, 1);
    luaL_checktype(L, 2, LUA_TFUNCTION);
    lua_pushvalue(L, 2);
    g_handlers[lower(n)].push_back(ref_pop(L));
    return 0;
}
int l_TriggerEvent(lua_State* L) {
    const char* n = luaL_checkstring(L, 1);
    const int nargs = lua_gettop(L) - 1;
    lua_newtable(L);
    for (int i = 2; i <= nargs + 1; ++i) {
        lua_pushvalue(L, i);
        lua_rawseti(L, -2, i - 1);
    }
    lua_pushinteger(L, nargs);
    lua_setfield(L, -2, "n");
    g_eventq.emplace_back(lower(n), ref_pop(L));
    return 0;
}
int l_RegisterCommand(lua_State* L) {
    const char* n = luaL_checkstring(L, 1);
    luaL_checktype(L, 2, LUA_TFUNCTION);
    std::string key = lower(n);
    auto it = g_commands.find(key);
    if (it != g_commands.end()) { ref_drop(it->second); g_commands.erase(it); }
    lua_pushvalue(L, 2);
    g_commands[key] = ref_pop(L);
    console_push("[hub] /" + key + " registered");
    return 0;
}
int l_RegisterKeybind(lua_State* L) {
    const char* idn = luaL_checkstring(L, 1);
    const char* key = luaL_checkstring(L, 2);
    luaL_checktype(L, 3, LUA_TFUNCTION);
    const int vk = vk_from_name(key);
    if (!vk) { console_push(std::string("[hub] RegisterKeybind: unknown key '") + key + "'"); return 0; }
    std::string kid = lower(idn);
    auto it = g_keybinds.find(kid);
    if (it != g_keybinds.end()) { ref_drop(it->second.fn_ref); g_keybinds.erase(it); }
    Keybind kb;
    kb.vk = vk;
    lua_pushvalue(L, 3);
    kb.fn_ref = ref_pop(L);
    g_keybinds[kid] = kb;
    return 0;
}
int l_UnregisterKeybind(lua_State* L) {
    auto it = g_keybinds.find(lower(luaL_checkstring(L, 1)));
    if (it != g_keybinds.end()) { ref_drop(it->second.fn_ref); g_keybinds.erase(it); }
    return 0;
}
int l_IsControlPressed(lua_State* L) {
    lua_pushboolean(L, ctrl_down((int)luaL_checkinteger(L, 2)) ? 1 : 0);
    return 1;
}
int l_IsControlJustPressed(lua_State* L) {
    const int ctrl = (int)luaL_checkinteger(L, 2);
    const bool now = ctrl_down(ctrl);
    const bool was = g_ctrl_prev.count(ctrl) && g_ctrl_prev[ctrl];
    g_ctrl_prev[ctrl] = now;
    lua_pushboolean(L, (now && !was) ? 1 : 0);
    return 1;
}
int l_IsControlJustReleased(lua_State* L) {
    const int ctrl = (int)luaL_checkinteger(L, 2);
    const bool now = ctrl_down(ctrl);
    const bool was = g_ctrl_prev.count(ctrl) && g_ctrl_prev[ctrl];
    g_ctrl_prev[ctrl] = now;
    lua_pushboolean(L, (!now && was) ? 1 : 0);
    return 1;
}

std::unordered_map<std::string, std::string> g_kvp;
std::unordered_map<std::string, int64_t>     g_kvp_int;
int l_SetKvpString(lua_State* L) { g_kvp[luaL_checkstring(L, 1)] = luaL_checkstring(L, 2); return 0; }
int l_GetKvpString(lua_State* L) {
    auto it = g_kvp.find(luaL_checkstring(L, 1));
    if (it == g_kvp.end()) lua_pushnil(L); else lua_pushstring(L, it->second.c_str());
    return 1;
}
int l_SetKvpInt(lua_State* L) { g_kvp_int[luaL_checkstring(L, 1)] = (int64_t)luaL_checkinteger(L, 2); return 0; }
int l_GetKvpInt(lua_State* L) {
    auto it = g_kvp_int.find(luaL_checkstring(L, 1));
    lua_pushinteger(L, it == g_kvp_int.end() ? 0 : (lua_Integer)it->second);
    return 1;
}
int l_GetParentResourceName(lua_State* L) { (void)L; lua_pushliteral(L, "fvem"); return 1; }

std::unordered_map<std::string, bool> g_warned;
int l_warnOnce(lua_State* L) {
    std::string s = luaL_checkstring(L, 1);
    if (!g_warned.count(s)) { g_warned[s] = true; console_push("[hub] warn: " + s); }
    return 0;
}

// ---------------------------------------------------------------------------
// print serialization (metamethod-aware, bounded)
// ---------------------------------------------------------------------------
void serialize_arg(lua_State* L, int idx, std::string& out, int depth) {
    switch (lua_type(L, idx)) {
        case LUA_TNONE: case LUA_TNIL: out += "nil"; break;
        case LUA_TBOOLEAN: out += lua_toboolean(L, idx) ? "true" : "false"; break;
        case LUA_TNUMBER: {
            char b[64];
            if (lua_isinteger(L, idx)) snprintf(b, sizeof(b), "%lld", (long long)lua_tointeger(L, idx));
            else snprintf(b, sizeof(b), "%g", lua_tonumber(L, idx));
            out += b;
            break;
        }
        case LUA_TSTRING: {
            size_t n = 0; const char* s = lua_tolstring(L, idx, &n);
            out.append(s ? s : "", n > 4096 ? 4096 : n);
            break;
        }
        case LUA_TFUNCTION: out += "function"; break;
        case LUA_TTABLE: {
            if (depth > 2) { out += "{...}"; break; }
            if (luaL_callmeta(L, idx, "__tostring") && lua_isstring(L, -1)) {
                out += lua_tostring(L, -1); lua_pop(L, 1); break;
            }
            // un-metamethoded table
            out += "{ ";
            int n = 0;
            lua_pushnil(L);
            const int top = lua_gettop(L);
            while (lua_next(L, idx) != 0 && n < 12) {
                if (n) out += ", ";
                serialize_arg(L, lua_gettop(L) - 1, out, depth + 1);
                out += "=";
                serialize_arg(L, lua_gettop(L), out, depth + 1);
                lua_pop(L, 1);
                ++n;
            }
            lua_settop(L, top);
            if (n >= 12) out += "...";
            out += " }";
            break;
        }
        default: out += std::string("[") + lua_typename(L, lua_type(L, idx)) + "]"; break;
    }
}
int l_print(lua_State* L) {
    std::string line;
    const int n = lua_gettop(L);
    for (int i = 1; i <= n; ++i) {
        if (i > 1) line += "\t";
        serialize_arg(L, i, line, 0);
    }
    console_push(line);
    return 0;
}
int l_osExitBlocked(lua_State* L) {
    (void)L;
    console_push("[hub] warn: script called os.exit — ignored (host protected)");
    return 0;
}

// forward decls for containers used above (declared here for readability)

const luaL_Reg k_hub_fns[] = {
    { "__fvem_CreateThread",          l_CreateThread },
    { "__fvem_CreateThreadNow",       l_CreateThreadNow },
    { "__fvem_SetTimeout",            l_SetTimeout },
    { "__fvem_AddEventHandler",       l_AddEventHandler },
    { "__fvem_TriggerEvent",          l_TriggerEvent },
    { "__fvem_RegisterCommand",       l_RegisterCommand },
    { "__fvem_RegisterKeybind",       l_RegisterKeybind },
    { "__fvem_UnregisterKeybind",     l_UnregisterKeybind },
    { "__fvem_IsControlPressed",      l_IsControlPressed },
    { "__fvem_IsControlJustPressed",  l_IsControlJustPressed },
    { "__fvem_IsControlJustReleased", l_IsControlJustReleased },
    { "__fvem_SetKvpString",          l_SetKvpString },
    { "__fvem_GetKvpString",          l_GetKvpString },
    { "__fvem_SetKvpInt",             l_SetKvpInt },
    { "__fvem_GetKvpInt",             l_GetKvpInt },
    { "__fvem_GetParentResourceName", l_GetParentResourceName },
    { "__fvem_WarnOnce",              l_warnOnce },
    { "__fvem_print",                 l_print },
    { "__fvem_osExit",                l_osExitBlocked },
    { nullptr, nullptr },
};

// ---------------------------------------------------------------------------
// Restricted standard library. luaL_openlibs() registers io, os, package and
// debug on top of the base lib. Every one of them is a disk or shell
// CAPABILITY in the shipped image:
//   io       -> fopen/popen/tmpfile          (liolib)
//   os       -> system/remove/rename         (loslib)
//   package  -> fopen to probe module paths  (loadlib)
//   base     -> dofile/loadfile              (lbaselib, via luaL_loadfilex)
//   debug    -> debug.sethook, which a script could use to clear the MASKCOUNT
//               budget hook that is our only stop for a runaway coroutine
// The no-file subset below is also the closer match to real FiveM: a resource
// gets LoadResourceFile, not io.open, and has no os.execute or require.
// `os` is kept as a shim with time/clock/date only - dropping those would break
// ordinary scripts for no security gain, since none of them touch the disk.
// The fopen sites in iolib/loslib/loadlib are removed by not compiling those
// translation units, and lbaselib's dofile/loadfile land on the
// FVEM_NO_FILE_LUA body of luaL_loadfilex. See MEMORY_ONLY_PLAN.md M2.5.
// ---------------------------------------------------------------------------
int l_osTime(lua_State* L) {
    FILETIME ft{};
    GetSystemTimeAsFileTime(&ft);
    ULARGE_INTEGER u{};
    u.LowPart  = ft.dwLowDateTime;
    u.HighPart = ft.dwHighDateTime;
    // FILETIME counts 100 ns ticks from 1601-01-01; shift to the unix epoch.
    lua_pushinteger(L, (lua_Integer)((u.QuadPart - 116444736000000000ull) / 10000000ull));
    return 1;
}

int l_osClock(lua_State* L) {
    lua_pushnumber(L, (lua_Number)GetTickCount64() / 1000.0);
    return 1;
}

// os.date([fmt]) - "*t"/"*T" returns the field table; anything else returns the
// default rendering. Hand-rolled digits: the CRT's printf family shares output
// machinery with the stdio streams, and pulling that back in would undo the
// whole point of this file. Not a strftime, and it does not pretend to be.
int l_osDate(lua_State* L) {
    SYSTEMTIME st{};
    GetLocalTime(&st);
    const char* fmt = luaL_optstring(L, 1, "*d");

    if (fmt[0] == '*' && (fmt[1] == 't' || fmt[1] == 'T')) {
        static const int mdays[12] = {31,28,31,30,31,30,31,31,30,31,30,31};
        int yday = st.wDay;
        for (int i = 0; i < (int)st.wMonth - 1 && i < 12; ++i) yday += mdays[i];
        lua_createtable(L, 0, 9);
        lua_pushinteger(L, st.wYear);        lua_setfield(L, -2, "year");
        lua_pushinteger(L, st.wMonth);       lua_setfield(L, -2, "month");
        lua_pushinteger(L, st.wDay);         lua_setfield(L, -2, "day");
        lua_pushinteger(L, st.wHour);        lua_setfield(L, -2, "hour");
        lua_pushinteger(L, st.wMinute);      lua_setfield(L, -2, "min");
        lua_pushinteger(L, st.wSecond);      lua_setfield(L, -2, "sec");
        lua_pushinteger(L, (lua_Integer)st.wDayOfWeek + 1);  // Lua: 1 = Sunday
        lua_setfield(L, -2, "wday");
        lua_pushinteger(L, yday);            lua_setfield(L, -2, "yday");
        lua_pushboolean(L, 0);               lua_setfield(L, -2, "isdst");
        return 1;
    }

    char buf[24];
    int n = 0;
    int d4[4] = { st.wYear / 1000 % 10, st.wYear / 100 % 10, st.wYear / 10 % 10, st.wYear % 10 };
    for (int i = 0; i < 4; ++i) buf[n++] = (char)('0' + d4[i]);
    buf[n++] = '-'; buf[n++] = (char)('0' + st.wMonth / 10);  buf[n++] = (char)('0' + st.wMonth % 10);
    buf[n++] = '-'; buf[n++] = (char)('0' + st.wDay / 10);    buf[n++] = (char)('0' + st.wDay % 10);
    buf[n++] = ' '; buf[n++] = (char)('0' + st.wHour / 10);   buf[n++] = (char)('0' + st.wHour % 10);
    buf[n++] = ':'; buf[n++] = (char)('0' + st.wMinute / 10); buf[n++] = (char)('0' + st.wMinute % 10);
    buf[n++] = ':'; buf[n++] = (char)('0' + st.wSecond / 10); buf[n++] = (char)('0' + st.wSecond % 10);
    lua_pushlstring(L, buf, (size_t)n);
    return 1;
}

// Open the no-file library set. luaL_requiref leaves the module table on the
// stack (and in _LOADED) - pop it after each.
static void open_safe_libs(lua_State* L) {
    static const luaL_Reg os_shim[] = {
        { "time",  l_osTime  },
        { "clock", l_osClock },
        { "date",  l_osDate  },
        { nullptr, nullptr   },
    };
    luaL_requiref(L, "_G",            luaopen_base,      1); lua_pop(L, 1);
    luaL_requiref(L, LUA_TABLIBNAME,  luaopen_table,     1); lua_pop(L, 1);
    luaL_requiref(L, LUA_STRLIBNAME,  luaopen_string,    1); lua_pop(L, 1);
    luaL_requiref(L, LUA_MATHLIBNAME, luaopen_math,      1); lua_pop(L, 1);
    luaL_requiref(L, LUA_COLIBNAME,   luaopen_coroutine, 1); lua_pop(L, 1);
    luaL_requiref(L, LUA_UTF8LIBNAME, luaopen_utf8,      1); lua_pop(L, 1);

    lua_newtable(L);
    luaL_setfuncs(L, os_shim, 0);
    lua_setglobal(L, "os");
}

// ---------------------------------------------------------------------------
// prelude: Citizen idiom, vector3, json, base64. Runs after the bridge so
// every native is reachable through _G's __index while this executes.
// ---------------------------------------------------------------------------
const char kPrelude[] = R"LUAPRE(
Citizen = Citizen or {}
Citizen.CreateThread        = __fvem_CreateThread
Citizen.CreateThreadNow     = __fvem_CreateThreadNow
Citizen.SetTimeout          = __fvem_SetTimeout
Citizen.AddEventHandler     = __fvem_AddEventHandler
Citizen.RemoveEventHandler  = function(handle) end
Citizen.TriggerEvent        = __fvem_TriggerEvent
Citizen.TriggerLatentEvent  = __fvem_TriggerEvent
Citizen.Wait                = function(ms) return coroutine.yield(ms or 0) end
Citizen.GetParentResourceName = __fvem_GetParentResourceName
Citizen.RegisterCommand     = __fvem_RegisterCommand
Citizen.Returns             = {}

function __fvem_run(pkg)
    local fn, args = pkg[1], pkg[2]
    if args then return fn(table.unpack(args, 1, args.n or #args)) end
    return fn()
end

CreateThread        = Citizen.CreateThread
CreateThreadNow     = Citizen.CreateThreadNow
SetTimeout          = Citizen.SetTimeout
Wait                = Citizen.Wait
AddEventHandler     = Citizen.AddEventHandler
RemoveEventHandler  = function(handle) end
RegisterCommand     = Citizen.RegisterCommand
RegisterNetEvent    = function() end
TriggerEvent        = Citizen.TriggerEvent
TriggerLatentEvent  = Citizen.TriggerEvent
TriggerServerEvent  = function(name, ...)
    __fvem_WarnOnce("TriggerServerEvent is LOCAL-only in standalone mode")
    return __fvem_TriggerEvent(name, ...)
end
TriggerServerEventInternal = TriggerServerEvent
TriggerLatentServerEvent   = TriggerServerEvent
RegisterKeybind       = __fvem_RegisterKeybind
UnregisterKeybind     = __fvem_UnregisterKeybind
GetParentResourceName = __fvem_GetParentResourceName
SetResourceKvpString  = __fvem_SetKvpString
GetResourceKvpString  = __fvem_GetKvpString
SetResourceKvpInt     = __fvem_SetKvpInt
GetResourceKvpInt     = __fvem_GetKvpInt
IsControlPressed      = __fvem_IsControlPressed
IsControlJustPressed  = __fvem_IsControlJustPressed
IsControlJustReleased = __fvem_IsControlJustReleased
IsDisabledControlPressed        = __fvem_IsControlPressed
IsDisabledControlJustPressed    = __fvem_IsControlJustPressed
IsDisabledControlJustReleased   = __fvem_IsControlJustReleased
DisableAllControlActions = function() end
EnableAllControlActions  = function() end
DisableControlAction     = function() end
EnableControlAction      = function() end
msg   = __fvem_print
trace = __fvem_print
print = __fvem_print
if os then os.exit = __fvem_osExit end
-- No package loader in Tier S (see open_safe_libs): io, os.execute/remove/rename
-- and require are absent by design. A clear error beats "attempt to call a nil
-- value (global 'require')" when a leaked resource script asks for one.
require = function(name)
    error("require('" .. tostring(name) .. "') is unavailable: no package " ..
          "loader in this build (Tier S)", 2)
end

-- vector3
local vmt = {}
vmt.__index = function(v, i)
    if i == 1 then return v.x elseif i == 2 then return v.y elseif i == 3 then return v.z elseif i == 4 then return v.w end
end
vmt.__tostring = function(v) return string.format("vector(%s, %s, %s)", tostring(v.x), tostring(v.y), tostring(v.z)) end
vmt.__add = function(a, b) return vector(a.x + b.x, a.y + b.y, a.z + b.z) end
vmt.__sub = function(a, b) return vector(a.x - b.x, a.y - b.y, a.z - b.z) end
vmt.__mul = function(a, b)
    if type(b) == 'number' then return vector(a.x * b, a.y * b, a.z * b) end
    return vector(a.x * b.x, a.y * b.y, a.z * b.z)
end
vmt.__div = function(a, b)
    if type(b) == 'number' then return vector(a.x / b, a.y / b, a.z / b) end
    return vector(a.x / b.x, a.y / b.y, a.z / b.z)
end
vmt.__unm = function(a) return vector(-a.x, -a.y, -a.z) end
vmt.__eq  = function(a, b) return a.x == b.x and a.y == b.y and a.z == b.z end
function vector(x, y, z) return setmetatable({ x = x or 0, y = y or 0, z = z or 0, w = 0 }, vmt) end
vector3 = vector
__fvem_vmt = vmt
function vector4(x, y, z, w) local v = vector(x, y, z) v.w = w or 0 return v end
function math.round(x) return math.floor(x + 0.5) end

-- json (compact safe subset)
json = {}
do
    local esc = { ['"'] = '\\"', ['\\'] = '\\\\', ['\b'] = '\\b', ['\f'] = '\\f',
                  ['\n'] = '\\n', ['\r'] = '\\r', ['\t'] = '\\t' }
    local function enc_str(s, out)
        out[#out + 1] = '"'
        for i = 1, #s do
            local c = s:sub(i, i)
            local e = esc[c]
            if e then out[#out + 1] = e
            elseif c:byte() < 32 then out[#out + 1] = string.format('\\u%04x', c:byte())
            else out[#out + 1] = c end
        end
        out[#out + 1] = '"'
    end
    local function enc(v, out, seen)
        local t = type(v)
        if v == nil then out[#out + 1] = 'null'
        elseif t == 'boolean' then out[#out + 1] = v and 'true' or 'false'
        elseif t == 'number' then out[#out + 1] = string.format('%.14g', v)
        elseif t == 'string' then enc_str(v, out)
        elseif t == 'table' then
            if seen[v] then error('json: cyclic') end
            seen[v] = true
            local count, isarr = 0, true
            for k in pairs(v) do
                count = count + 1
                if type(k) ~= 'number' then isarr = false break end
            end
            local seq = #v
            if isarr and seq == count then
                out[#out + 1] = '['
                for i = 1, seq do
                    if i > 1 then out[#out + 1] = ',' end
                    enc(v[i], out, seen)
                end
                out[#out + 1] = ']'
            else
                out[#out + 1] = '{'
                local keys = {}
                for k in pairs(v) do keys[#keys + 1] = tostring(k) end
                table.sort(keys)
                for j = 1, #keys do
                    if j > 1 then out[#out + 1] = ',' end
                    local k = keys[j]
                    enc_str(k, out)
                    out[#out + 1] = ':'
                    enc(v[k], out, seen)
                end
                out[#out + 1] = '}'
            end
            seen[v] = nil
        else out[#out + 1] = 'null' end
    end
    function json.encode(v) local out = {} enc(v, out, {}) return table.concat(out) end

    local function ws(s, p)
        while p <= #s do
            local c = s:sub(p, p)
            if c == ' ' or c == '\t' or c == '\n' or c == '\r' then p = p + 1 else break end
        end
        return p
    end
    local function dec(s, pos)
        pos = ws(s, pos)
        if pos > #s then return nil, pos end
        local c = s:sub(pos, pos)
        if c == '"' then
            local i, buf = pos + 1, {}
            while i <= #s do
                local ch = s:sub(i, i)
                if ch == '"' then return table.concat(buf), i + 1
                elseif ch == '\\' then
                    local nx = s:sub(i + 1, i + 1)
                    if nx == 'n' then buf[#buf + 1] = '\n'
                    elseif nx == 't' then buf[#buf + 1] = '\t'
                    elseif nx == 'r' then buf[#buf + 1] = '\r'
                    elseif nx == 'b' then buf[#buf + 1] = '\b'
                    elseif nx == 'f' then buf[#buf + 1] = '\f'
                    elseif nx == 'u' then
                        local code = tonumber(s:sub(i + 2, i + 5), 16) or 63
                        buf[#buf + 1] = code < 128 and string.char(code) or '?'
                        i = i + 6                       -- past \uXXXX
                    else buf[#buf + 1] = nx; i = i + 2 end  -- past \x
                else buf[#buf + 1] = ch; i = i + 1 end
            end
            error('json: unterminated string')
        elseif c == '{' then
            local t = {}
            pos = ws(s, pos + 1)
            if s:sub(pos, pos) == '}' then return t, pos + 1 end
            while true do
                local k; k, pos = dec(s, pos)
                pos = ws(s, pos)
                if s:sub(pos, pos) ~= ':' then error('json: expected :') end
                local v; v, pos = dec(s, pos + 1)
                t[k] = v
                pos = ws(s, pos)
                local d = s:sub(pos, pos)
                if d == ',' then pos = pos + 1
                elseif d == '}' then return t, pos + 1
                else error('json: expected , or }') end
            end
        elseif c == '[' then
            local t = {}
            pos = ws(s, pos + 1)
            if s:sub(pos, pos) == ']' then return t, pos + 1 end
            while true do
                local v; v, pos = dec(s, pos)
                t[#t + 1] = v
                pos = ws(s, pos)
                local d = s:sub(pos, pos)
                if d == ',' then pos = pos + 1
                elseif d == ']' then return t, pos + 1
                else error('json: expected , or ]') end
            end
        elseif c == 't' then
            if s:sub(pos, pos + 3) ~= 'true' then error('json: bad literal') end
            return true, pos + 4
        elseif c == 'f' then
            if s:sub(pos, pos + 4) ~= 'false' then error('json: bad literal') end
            return false, pos + 5
        elseif c == 'n' then
            if s:sub(pos, pos + 3) ~= 'null' then error('json: bad literal') end
            return nil, pos + 4
        else
            local num = s:match('^[-+]?[%d%.eE]+', pos)
            if not num then error('json: unexpected ' .. c) end
            return tonumber(num), pos + #num
        end
    end
    function json.decode(str)
        if type(str) ~= 'string' or str == '' then return nil end
        local ok, v = pcall(dec, str, 1)
        return ok and v or nil
    end
end

-- base64
do
    local chars = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789+/'
    local idx = {}
    for i = 1, 64 do idx[chars:sub(i, i)] = i - 1 end
    function base64Encode(s)
        if not s then return '' end
        local out = {}
        for i = 1, #s, 3 do
            local a, b2, c = s:byte(i, i + 2)
            local n = (a or 0) * 65536 + (b2 or 0) * 256 + (c or 0)
            local e1 = math.floor(n / 262144) % 64
            local e2 = math.floor(n / 4096) % 64
            local e3 = math.floor(n / 64) % 64
            local e4 = n % 64
            out[#out + 1] = chars:sub(e1 + 1, e1 + 1) .. chars:sub(e2 + 1, e2 + 1)
            if b2 then out[#out + 1] = chars:sub(e3 + 1, e3 + 1) end
            if c then out[#out + 1] = chars:sub(e4 + 1, e4 + 1) end
        end
        local pad = #s % 3
        local res = table.concat(out)
        if pad == 1 then res = res .. '==' elseif pad == 2 then res = res .. '=' end
        return res
    end
    function base64Decode(s)
        if not s then return '' end
        local acc, nbits = 0, 0
        local out = {}
        for i = 1, #s do
            local c = s:sub(i, i)
            if c == '=' then break end
            local v = idx[c]
            if v then
                acc = acc * 64 + v
                nbits = nbits + 6
                if nbits >= 8 then
                    nbits = nbits - 8
                    out[#out + 1] = string.char(math.floor(acc / 2 ^ nbits) % 256)
                    acc = acc % 2 ^ nbits          -- keep only the leftover bits
                end
            end
        end
        return table.concat(out)
    end
end
)LUAPRE";

// ---------------------------------------------------------------------------
// lifecycle + tick
// ---------------------------------------------------------------------------
bool init() {
    try {
        FVEM_LOGF("[fvem] hub: newstate");
        gL = luaL_newstate();
        if (!gL) return false;
        FVEM_LOGF("[fvem] hub: openlibs (no-file subset)");
        open_safe_libs(gL);

        FVEM_LOGF("[fvem] hub: setfuncs");
        // luaL_setfuncs registers into the table on top of the stack (it does
        // lua_setfield(L, -(nup+2), name)). With nup=0 and an empty stack that
        // setfield indexes below the frame -> "attempt to index a nil value" ->
        // lua's panic -> abort(). Push _G first, pop it after.
        lua_pushglobaltable(gL);
        luaL_setfuncs(gL, k_hub_fns, 0);
        lua_pop(gL, 1);
        FVEM_LOGF("[fvem] hub: bridge");
        register_native_bridge(gL);

        FVEM_LOGF("[fvem] hub: prelude");
        if (luaL_loadbuffer(gL, kPrelude, sizeof(kPrelude) - 1, "fvem-prelude") ||
            lua_pcall(gL, 0, 0, 0) != 0) {
            const char* e = lua_tostring(gL, -1);
            console_push(std::string("[hub] prelude FAILED: ") + (e ? e : "?"));
            FVEM_LOGF("[fvem] hub: prelude error: %s", e ? e : "?");
            lua_pop(gL, 1);
            return false;
        }
        FVEM_LOGF("[fvem] hub: prelude ok, tramp");
        lua_getglobal(gL, "__fvem_run");
        if (lua_isfunction(gL, -1)) g_tramp_ref = ref_pop();
        else { lua_pop(gL, 1); console_push("[hub] no trampoline — events disabled"); }

        FVEM_LOGF("[fvem] hub: online");
        console_push("[hub] Tier S executor online");
        return true;
    } catch (...) {
        FVEM_LOGF("[fvem] hub: init threw");
        return false;
    }
}

void shutdown() {
    for (auto& s : g_scripts) { drop_coro(s); ref_drop(s.fn_ref); }
    g_scripts.clear();
    for (auto& c : g_threads) { drop_coro(c); }
    g_threads.clear();
    for (auto& kv : g_handlers) for (int r : kv.second) ref_drop(r);
    g_handlers.clear();
    for (auto& kv : g_commands) ref_drop(kv.second);
    g_commands.clear();
    for (auto& kv : g_keybinds) ref_drop(kv.second.fn_ref);
    g_keybinds.clear();
    while (!g_eventq.empty()) { ref_drop(g_eventq.front().second); g_eventq.pop_front(); }
    ref_drop(g_tramp_ref); g_tramp_ref = LUA_NOREF;
    if (gL) lua_close(gL);
    gL = nullptr;
}

void reap_threads() {
    g_threads.erase(
        std::remove_if(g_threads.begin(), g_threads.end(), [](Coroutine& c) {
            if (c.state == ST_DEAD || c.state == ST_DONE) {
                drop_coro(c);
                ref_drop(c.arg_ref); c.arg_ref = LUA_NOREF;
                if (c.owns_fn) ref_drop(c.fn_ref);
                return true;
            }
            return false;
        }),
        g_threads.end());
}

void tick() {
    if (!gL) return;
    bridge_clear_string_arena();
    const uint64_t now = GetTickCount64();

    // 1. queued events -> handler dispatch (deferred, never re-entrant)
    int ev_budget = 64;
    while (!g_eventq.empty() && ev_budget-- > 0) {
        auto ev = g_eventq.front();
        g_eventq.pop_front();
        auto it = g_handlers.find(ev.first);
        if (it != g_handlers.end()) {
            for (int fn_ref : it->second)
                spawn_dispatch(fn_ref, ev.second, false);   // shared args ref
        }
        ref_drop(ev.second);
    }

    // 2. keybind edges
    for (auto& kv : g_keybinds) {
        const bool down = (GetAsyncKeyState(kv.second.vk) & 0x8000) != 0;
        if (down && !kv.second.prev) {
            lua_newtable(gL);
            lua_pushstring(gL, kv.first.c_str());
            lua_rawseti(gL, -2, 1);
            lua_pushinteger(gL, 1);
            lua_setfield(gL, -2, "n");
            int args = ref_pop();
            spawn_dispatch(kv.second.fn_ref, args, false);
            ref_drop(args);
        }
        kv.second.prev = down;
    }

    // 3. Citizen threads / timeouts / handlers
    for (auto& c : g_threads) {
        if (c.state == ST_WAIT && c.deadline <= now) {
            std::string err;
            c.state = resume_one(c, err);
            if (c.state == ST_DEAD) console_push("[thread] " + err);
        }
    }
    reap_threads();

    // 4. scripts
    for (auto& s : g_scripts) {
        if (s.state == ST_WAIT && s.deadline <= now) {
            std::string err;
            s.state = resume_one(s, err);
            if (s.state == ST_DEAD) { s.last_err = err; console_push("[" + s.name + "] " + err); }
            else if (s.state == ST_DONE) console_push("[" + s.name + "] finished");
        }
    }
}

} // namespace
} // namespace gfx::hub

// ---------------------------------------------------------------------------
// public API
// ---------------------------------------------------------------------------
namespace gfx {

bool hub_init() { return hub::init(); }
void hub_shutdown() { hub::shutdown(); }

uint32_t hub_run_script(const std::string& name, const std::string& source) {
    if (!hub::gL) return 0;
    try {
        if (luaL_loadbuffer(hub::gL, source.c_str(), source.size(), name.c_str())) {
            const char* e = lua_tostring(hub::gL, -1);
            hub::console_push("[" + name + "] load error: " + (e ? e : "?"));
            lua_pop(hub::gL, 1);
            return 0;
        }
        // bind a per-script env: setmetatable({}, {__index = _G})
        lua_newtable(hub::gL);                       // env
        lua_newtable(hub::gL);                       // meta
        lua_rawgeti(hub::gL, LUA_REGISTRYINDEX, LUA_RIDX_GLOBALS);
        lua_setfield(hub::gL, -2, "__index");
        lua_setmetatable(hub::gL, -2);               // metatable(meta)(env)
        if (lua_setupvalue(hub::gL, -2, 1) == nullptr) { /* no _ENV: run on _G */ }
        int fn = hub::ref_pop();                     // pops the chunk

        hub::g_scripts.push_back(hub::Script{});
        hub::Script& s = hub::g_scripts.back();
        s.id = hub::g_next_id++;
        s.name = name;
        s.fn_ref = fn;
        hub::console_push("[" + name + "] started (id " + std::to_string(s.id) + ")");
        return s.id;
    } catch (...) {
        hub::console_push("[" + name + "] hub internal error");
        return 0;
    }
}

bool hub_run_once(const std::string& source, std::string& err) {
    if (!hub::gL) { err = "hub offline"; return false; }
    try {
        if (luaL_loadbuffer(hub::gL, source.c_str(), source.size(), "fvem-once")) {
            const char* e = lua_tostring(hub::gL, -1);
            err = e ? e : "?"; lua_pop(hub::gL, 1); return false;
        }
        if (lua_pcall(hub::gL, 0, 0, 0) != 0) {
            const char* e = lua_tostring(hub::gL, -1);
            err = e ? e : "?"; lua_pop(hub::gL, 1); return false;
        }
        return true;
    } catch (const std::exception& ex) { err = ex.what(); return false; }
    catch (...) { err = "hub internal error"; return false; }
}

bool hub_stop(uint32_t id) {
    for (auto& s : hub::g_scripts) {
        if (s.id == id && s.fn_ref != LUA_NOREF) {
            s.state = hub::ST_DEAD;
            hub::drop_coro(s);
            hub::ref_drop(s.fn_ref);
            s.fn_ref = LUA_NOREF;
            hub::console_push("[" + s.name + "] stopped");
            return true;
        }
    }
    return false;
}

void hub_stop_all() {
    for (auto& s : hub::g_scripts) hub::drop_coro(s);
    hub::g_scripts.clear();
    for (auto& c : hub::g_threads) hub::drop_coro(c);
    hub::g_threads.clear();
    hub::console_push("[hub] all stopped");
}

void hub_list(std::vector<HubScriptInfo>& out) {
    out.clear();
    for (auto& s : hub::g_scripts) {
        HubScriptInfo i;
        i.id = s.id; i.name = s.name; i.state = s.state; i.last_err = s.last_err;
        out.push_back(std::move(i));
    }
}

void hub_tick() {
    try { hub::tick(); }
    catch (...) { hub::console_push("[hub] tick internal error"); }
}

void hub_console_push(const std::string& line) { hub::console_push(line); }
const std::vector<std::string>& hub_console_lines() { return hub::g_console; }
void hub_console_clear() { hub::g_console.clear(); }

bool hub_run_command(const std::string& line) {
    if (!hub::gL || hub::g_tramp_ref == LUA_NOREF) return false;
    std::string s = line;
    if (!s.empty() && s[0] == '/') s.erase(0, 1);
    const size_t sp = s.find_first_of(" \t");
    std::string name = sp == std::string::npos ? s : s.substr(0, sp);
    std::string rawtext = sp == std::string::npos ? std::string() : s.substr(sp + 1);
    for (auto& c : name) c = static_cast<char>(::tolower((unsigned char)c));
    auto it = hub::g_commands.find(name);
    if (it == hub::g_commands.end()) return false;

    std::vector<std::string> args;
    {
        std::string cur; bool inq = false;
        for (char ch : rawtext) {
            if (ch == '"') { inq = !inq; continue; }
            if (!inq && (ch == ' ' || ch == '\t')) {
                if (!cur.empty()) { args.push_back(cur); cur.clear(); }
                continue;
            }
            cur += ch;
        }
        if (!cur.empty()) args.push_back(cur);
    }
    // args table
    lua_newtable(hub::gL);
    for (size_t i = 0; i < args.size(); ++i) {
        lua_pushlstring(hub::gL, args[i].c_str(), args[i].size());
        lua_rawseti(hub::gL, -2, (int)i + 1);
    }
    lua_pushinteger(hub::gL, (lua_Integer)args.size());
    lua_setfield(hub::gL, -2, "n");
    const int aref = hub::ref_pop();
    // FiveM signature: fn(source, args, rawCommand)
    lua_newtable(hub::gL);
    lua_pushinteger(hub::gL, 0);
    lua_rawseti(hub::gL, -2, 1);
    lua_rawgeti(hub::gL, LUA_REGISTRYINDEX, aref);
    lua_rawseti(hub::gL, -2, 2);
    lua_pushlstring(hub::gL, rawtext.c_str(), rawtext.size());
    lua_rawseti(hub::gL, -2, 3);
    lua_pushinteger(hub::gL, 3);
    lua_setfield(hub::gL, -2, "n");
    const int pkg = hub::ref_pop();
    hub::ref_drop(aref);
    hub::spawn_dispatch(it->second, pkg, true);
    return true;
}

} // namespace gfx
