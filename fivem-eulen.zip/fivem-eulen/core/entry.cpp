// language: C++, target: Windows 11, MSVC (x64)
// DLL entry. Runs in the manual-mapped image, no PEB loader entry. BootCtx
// (passed as lpvReserved) carries the syscall table and target pid.
//
// Boot runs INLINE on the entry thread ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â the trampoline thread created by the
// mapper, and the ONLY thread proven to execute this image with full CRT state
// (_DllMainCRTStartup ran _CRT_INIT on it). We deliberately do NOT spawn a
// boot thread: a raw CreateThread here died before its first instruction (its
// startup fault was swallowed by the game; in debug builds it also produced a
// fault loop on boot). The overlay thread is the single exception ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â it is
// created at the END of boot via _beginthreadex so the static CRT initializes
// per-thread state (see overlay_render.cpp).
#include "pch.h"
#include "config.h"
#include "../common/obf.h"
#include "native_invoker.h"
#include "offsets.h"
#include "log.h"
#include "overlay_render.h"

namespace gfx {
bool install_present_hook();
void acquire_lua_state();
void karmuda_shim();
void chain_eulen();
HWND game_window();
}

#include "evasion/watchdog.h"

// Keep byte-identical to the injector's BootCtx (injector/main.cpp).
struct BootCtx { gfx::sys::SyscallTable* table; DWORD pid; void* tramp; SIZE_T tramp_size; };

// Held for the game's lifetime so a second injector run sees ERROR_ALREADY_EXISTS
// and refuses to double-arm (the successor to the fixed-base MZ sentinel).
static HANDLE g_arm_mutex = nullptr;

static void run_boot_try(BootCtx* ctx);

static void run_boot(BootCtx* ctx) {
    // C++ boundary around the whole boot: the __except filter CONTINUE_SEARCHes
    // 0xE06D7363 by design (see log.h) so a C++ exception here would unwind
    // PAST our SEH frame, out of DllMain, into the game's loader ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â crash with
    // no log line. Boot allocates (sol state, vectors, maps) and can throw
    // (bad_alloc, sol::error). Catch at our boundary, log, and let the game
    // live with a dead menu.
    try {
        run_boot_try(ctx);
    } catch (const std::exception& e) {
        FVEM_LOGF("[fvem] boot C++ exception: %s", e.what());
    } catch (...) {
        FVEM_LOGF("[fvem] boot unknown C++ exception");
    }
}

static void run_boot_try(BootCtx* ctx) {
    __try {
        // Set syscall table FIRST before any FVEM_LOGF.
        // NOTE: this stamp is per-TU (only refreshes when THIS file rebuilds) -
        // trust feature lines (menu tick=..., offsets: audit) over it.
        if (ctx && ctx->table) gfx::sys::set_table(ctx->table);
        FVEM_LOGF("[fvem] boot started (pid %lu, param=%p, build %s %s)",
                  GetCurrentProcessId(), ctx, __DATE__, __TIME__);

        // Free the boot trampoline the injector staged for us. We were started
        // AT it (NtCreateThreadEx -> mov/jmp stub), but the stub did `jmp`, not
        // `call`, into DllMain ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â so it is not on this thread's call stack and is
        // safe to release. A private executable page with no backing file object
        // is the loudest memory-scan signature a manual map leaves behind, so we
        // reclaim it before any anticheat sampling window opens.
        if (ctx && ctx->tramp) {
            void* tr = ctx->tramp;
            if (VirtualFree(tr, 0, MEM_RELEASE))
                FVEM_LOGF("[fvem] boot trampoline %p freed", tr);
            else
                FVEM_LOGF("[fvem] boot trampoline %p free failed (err %lu)",
                              tr, GetLastError());
        }

        // Arm-client guard. Create-and-hold a PID-SCOPED mutex (name embeds
        // GetCurrentProcessId, so it can only collide with another fvem in
        // THIS game - never with an unrelated zombie elsewhere on the
        // machine). The injector derives the same name from its target pid.
        {
            wchar_t mname[80]{};
            gfx::obf::arm_mutex_name(mname, 80, GetCurrentProcessId());
            g_arm_mutex = CreateMutexW(nullptr, FALSE, mname);
            DWORD gle = GetLastError();
            FVEM_LOGF("[fvem] arm mutex %p (gle=%lu%s)", g_arm_mutex, gle,
                          gle == ERROR_ALREADY_EXISTS ? ", prior instance" : "");
            // A prior armed instance is ACTIVE in this game process - two
            // shims double-hook the same APIs, both drive the watchdog park
            // logic, and the older copy carries whatever bug the newer one
            // fixed (observed: identical crash from a session whose log says
            // "prior instance"). Abort; the arm-mutex is released with the
            // process, so after a clean game restart re-injection works.
            if (gle == ERROR_ALREADY_EXISTS) {
                FVEM_LOGF("[fvem] BOOT ABORTED: fvem already armed in this game");
                // Release OUR hold before bailing. Without this, an aborted
                // boot (e.g. caused by the injector's probe-handle race, or a
                // transient prior instance that has since died) keeps the
                // named object alive for the whole game lifetime and every
                // later injection into this client aborts too - one false
                // positive becomes a permanent lockout. If a REAL armed fvem
                // exists, its own open handle keeps the object alive anyway,
                // so the refusal still holds correctly.
                if (g_arm_mutex) { CloseHandle(g_arm_mutex); g_arm_mutex = nullptr; }
                return;
            }
        }

        // Watchdog shield FIRST, before any heavy boot work. The trampoline
        // thread competes with the game's main thread for CPU while it scans
        // Lua/offsets; on a box that also runs FXServer, that competition can
        // stall the main thread past FiveM's watchdog limit before the rest of
        // boot finishes. Installing the probe shield with a null window arms
        // global WM_NULL hang-probe interception immediately; the Present hook
        // below re-scopes it to the exact game window once resolved.
        {
            gfx::watchdog::ShieldOptions wo{};
            wo.hook_probes    = true;   // L1a user32 hang-probe detours
            wo.hook_win32u    = true;   // L1b win32u choke point
            wo.suspend_thread = false;  // L2 OFF by default: the park is now
                                        // probe-based (no count stacking), but
                                        // L1 answers every probe and L3
                                        // absorbs every verdict anyway -
                                        // parking the game's watchdog was the
                                        // thing that actually killed sessions
                                        // (suspend count 23 at fail-fast).
                                        // Set true only if you WANT the belt.
            wo.suppress_trap  = true;   // L3  revive the early-exit fault
            wo.block_kill     = true;   // L4  refuse a watchdog self-terminate
            wo.diagnose       = false;  // flip true to log every probe's caller
            if (gfx::watchdog::shield_install(nullptr, wo)) {
                const gfx::watchdog::ShieldStatus st = gfx::watchdog::shield_status();
                FVEM_LOGF("[fvem] watchdog shield active: user32=%d/5 win32u=%d/1 "
                              "kill=%d/3 main_tid=%lu",
                              st.user32_hooks, st.win32u_hooks, st.kill_hooks,
                              st.main_tid);
            } else {
                FVEM_LOGF("[fvem] watchdog shield failed to install");
            }
        }

        // Self-evasion BEFORE the stabilization sleep. The image sat mapped with
        // its PE headers intact and its section protections un-hardened for the
        // full 5000 ms "wait for the game" window - any snapshot in that window
        // saw a PE-shaped blob with an MZ header and no loader entry. The shim
        // needs only the syscall table (armed above) and the cached image base
        // (set in DllMain before run_boot), so it can run here; the sleep then
        // only covers gameplay settling for the scan/init work after it.
        gfx::karmuda_shim();
        FVEM_LOGF("[fvem] karmuda shim done (headers erased pre-sleep)");

        gfx::chain_eulen();
        FVEM_LOGF("[fvem] chain_eulen done");

        // Hide our thread from debuggers before doing anything visible.
        gfx::sys::hide_current_thread(GetCurrentProcess());
        FVEM_LOGF("[fvem] thread hidden");

        // Wait for the game to stabilize before doing anything heavy.
        Sleep(5000);

        // The user runs FXServer and the game client on the SAME machine. Under
        // active gameplay the server's sync threads (normal priority) steal CPU
        // from the game's main thread, stalling it past FiveM's watchdog limit
        // -> "early-exit trap" kills the process.
        //
        // DO NOT promote the game process to HIGH_PRIORITY_CLASS for this: it
        // also promotes the trampoline/overlay thread (inherits the class), and
        // that thread's maintenance loop at HIGH starves BOTH the co-located
        // FXServer and ordinary system traffic, creating the very stall the
        // promotion was meant to prevent.
        //
        // But do NOT demote this thread BELOW_NORMAL either - it is the
        // OVERLAY RENDER LOOP's thread (manual-map CRT keeps the loop inline
        // here), and under co-located load the OS starves a below-normal
        // thread: Sleep(16) slips to 30-50 ms and the menu lags (field
        // report). NORMAL is the balance: the loop sleeps every frame
        // (~1 ms of 16 ms duty), so it can never out-preempt the game it
        // shares the class with; it just stops being the last one starved.
        SetThreadPriority(GetCurrentThread(), THREAD_PRIORITY_NORMAL);
        FVEM_LOGF("[fvem] boot/overlay thread priority -> NORMAL (process stays NORMAL)");

        // Smoke-test the indirect syscall path before anything depends on it:
        // NtQuerySystemInformation (no args -> cannot AV on arguments) and a
        // scratch NtProtectVirtualMemory on our own image. Logs every status so
        // a broken SSN/gadget is visible immediately.
        {
            gfx::sys::SyscallTable* t = gfx::sys::get_table();
            if (t) {
                FVEM_LOGF("[fvem] syscalls: protect.ssn=%u gadget=%p ntdll=%p",
                        t->protect_virtual_memory.ssn, t->protect_virtual_memory.gadget,
                        GetModuleHandleW(L"ntdll.dll"));
                SYSTEM_BASIC_INFORMATION sbi{};
                uint32_t len = 0;
                NTSTATUS st = gfx::sys::query_system_info(0, &sbi, sizeof(sbi), &len);
                FVEM_LOGF("[fvem] syscalls: NtQuerySystemInformation st=0x%X len=%lu",
                        static_cast<unsigned>(st), len);
                uint32_t old = 0;
                size_t sz = 0x1000;
                void* scratch = nullptr;
                NTSTATUS sta = gfx::sys::allocate(GetCurrentProcess(), &scratch, &sz,
                        PAGE_NOACCESS, MEM_COMMIT | MEM_RESERVE);
                FVEM_LOGF("[fvem] syscalls: NtAllocateVirtualMemory st=0x%X base=%p",
                        static_cast<unsigned>(sta), scratch);
                void* base = scratch;
                NTSTATUS stp = gfx::sys::protect(GetCurrentProcess(), &base, &sz, PAGE_READWRITE, &old);
                FVEM_LOGF("[fvem] syscalls: NtProtectVirtualMemory(self) st=0x%X old=0x%X base=%p",
                        static_cast<unsigned>(stp), old, base);
                NTSTATUS stf = gfx::sys::protect(GetCurrentProcess(), &base, &sz, PAGE_NOACCESS, &old);
                FVEM_LOGF("[fvem] syscalls: restore st=0x%X", static_cast<unsigned>(stf));
            } else {
                FVEM_LOGF("[fvem] syscalls: table unavailable");
            }
        }

        // (karmuda_shim / chain_eulen / thread-hide moved UP, before the sleep.)

        // Pattern-scan the live lua_State (FiveM/CFX) and open sol2 over it.
        gfx::acquire_lua_state();
        FVEM_LOGF("[fvem] lua state acquired");

        // Select the per-build RAGE offsets table FIRST ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â native_invoker and the
        // features read through it. The game-code module is found by walking the
        // PEB loader list (FiveM renames it, e.g. "adhesive.dll").
        if (gfx::game::init()) {
            FVEM_LOGF("[fvem] game module %p build %u offsets active",
                    reinterpret_cast<void*>(gfx::game::base()),
                    gfx::game::build().version);
        } else {
            FVEM_LOGF("[fvem] game offsets: module base unavailable");
        }

        // Resolve FiveM's exported native registry for the invoker.
        if (!gfx::native::init()) {
            FVEM_LOGF("[fvem] native invoker: init failed");
        }

        // Hook the DX11 swapchain Present for the overlay.
        if (!gfx::install_present_hook()) {
            FVEM_LOGF("[fvem] present hook failed");
        }

        // The shield went up with a null window (global probe scope) at boot
        // start, before any heavy work. Now that the Present hook has resolved
        // the game window, tighten the interception to it and record the
        // main-thread id for the kill interceptor.
        gfx::watchdog::shield_set_game_window(gfx::game_window());

        // The overlay renders on a SEPARATE D3D11 device + swap chain with its
        // OWN loop (overlay_render.cpp). The Present hook is a pure
        // passthrough, so fvem never extends the game's frame time on the main
        // thread ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â the root cause of the "early-exit trap" watchdog kills is
        // gone.
        //
        // The loop runs INLINE on this trampoline thread: manual-mapped images
        // have static-CRT per-thread state only on the thread that ran
        // _CRT_INIT (this one), so CreateThread/_beginthreadex here dies
        // before the first instruction. The trampoline thread is a private
        // remote thread (NtCreateThreadEx from the injector), NOT the game's
        // main thread, so FiveM's watchdog never sees our work.
        gfx::g_running = true;
        gfx::overlay_render_run(); // blocks until g_running goes false

        FVEM_LOGF("[fvem] boot complete (overlay loop ended)");
    } __except (gfx::log_fault_filter(GetExceptionCode(), GetExceptionInformation())) {
    }
}

// Manual-mapped images have NO PEB loader entry, and x64 exception dispatch
// (RtlLookupFunctionEntry) only finds unwind info for modules in the loader
// list. Without registration, every __try/__except in this DLL silently never
// fires and any fault becomes an unhandled crash ÃƒÂ¢Ã¢â€šÂ¬Ã¢â‚¬Â that is why earlier faults
// produced no "boot FAULT" line and killed the game. RtlAddFunctionTable makes
// our .pdata visible to the dispatcher; must run before anything fault-prone.
static void register_exception_table(uintptr_t base) {
    auto* dos = reinterpret_cast<IMAGE_DOS_HEADER*>(base);
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return;
    auto* h = reinterpret_cast<IMAGE_NT_HEADERS64*>(base + dos->e_lfanew);
    if (h->Signature != IMAGE_NT_SIGNATURE) return;
    auto& ed = h->OptionalHeader.DataDirectory[IMAGE_DIRECTORY_ENTRY_EXCEPTION];
    if (!ed.VirtualAddress || !ed.Size) return;

    typedef BOOLEAN(NTAPI* RtlAddFunctionTable_t)(PRUNTIME_FUNCTION, DWORD, DWORD64);
    auto fn = reinterpret_cast<RtlAddFunctionTable_t>(
        GetProcAddress(GetModuleHandleW(L"ntdll.dll"), "RtlAddFunctionTable"));
    if (!fn) return;
    auto* rt = reinterpret_cast<PRUNTIME_FUNCTION>(base + ed.VirtualAddress);
    if (fn(rt, ed.Size / sizeof(RUNTIME_FUNCTION), base)) {
        FVEM_LOGF("[fvem] exception table registered (%u entries)",
                ed.Size / static_cast<DWORD>(sizeof(RUNTIME_FUNCTION)));
    }
}

BOOL APIENTRY DllMain(HMODULE h, DWORD reason, LPVOID reserved) {
    if (reason == DLL_PROCESS_ATTACH) {
        // Cache the image base FIRST, from the hModule the trampoline passed as
        // rcx. Everything downstream (evasion header work, the eventual PE-header
        // erase) needs the base without an MZ walk, and after erase there is no
        // MZ to walk for.
        gfx::set_image_base(reinterpret_cast<uintptr_t>(h));
        // Do NOT call FVEM_LOGF here; syscall table not set yet.
        register_exception_table(reinterpret_cast<uintptr_t>(h));
        // Copy ctx off the remote buffer before the mapper frees it.
        static BootCtx local_ctx{};
        auto* ctx = static_cast<BootCtx*>(reserved);
        if (ctx) local_ctx = *ctx;
        // Run the whole boot inline on this thread (the trampoline thread).
        run_boot(&local_ctx);
    } else if (reason == DLL_PROCESS_DETACH) {
        // Signal the overlay render thread to stop and join it. It owns the
        // overlay window + its D3D11 device + the ImGui context, so it also
        // performs the full cleanup on exit.
        FVEM_LOGF("[fvem] DllMain detach, stopping overlay");
        if (g_arm_mutex) { CloseHandle(g_arm_mutex); g_arm_mutex = nullptr; }
        gfx::overlay_render_shutdown();
    }
    return TRUE;
}