// language: C++, target: Windows 11, MSVC (x64)
// Native invoker implementation Ã¢â‚¬â€ FiveM exported-registry edition.
//
// Data paths, first match wins:
//   1. direct table  Ã¢â‚¬â€ {hash, func} pairs from native_invoker_dumper_tool
//   2. fiveM export  Ã¢â‚¬â€ rage::scrEngine::GetNativeHandler(hash) from
//                      rage-scripting-five.dll, returns scrNativeHandler
//   3. empty         Ã¢â‚¬â€ get_handler returns 0, invoke no-ops
// Also owns the gfx::natives extern contract that features/esp.cpp declares.
#include "pch.h"
#include "native_invoker.h"
#include "offsets.h"
#include "log.h"
#include "../common/obf.h"

#include <cstdlib>
#ifdef FVEM_DEV_TOOLS
#include <fstream>
#endif

namespace gfx::native {

namespace {

// The exported lookup FiveM's own Lua runtime imports and uses for every
// script-native call. Resolved lazily; stable per process.
using GetNativeHandlerFn = void* (*)(uint64_t hash);
GetNativeHandlerFn g_get_native_handler = nullptr;
bool g_resolve_tried = false;

// Direct table mode (preferred, from the dumper tool).
std::unordered_map<uint64_t, void*> g_direct;

// Canonical hash -> current-build hash (registration mode only).
std::unordered_map<uint64_t, uint64_t> g_crossmap;

bool valid_pointer(uintptr_t p) {
    return p >= 0x10000 && p < 0x0000'FFFF'FFFF'FFFFull;
}

// A handler must live in executable memory. FiveM's export can return the
// hash itself on a registry miss; reject anything that isn't committed,
// executable memory (in-process VirtualQuery is cheap and safe here).
bool is_executable(uintptr_t p) {
    if (!valid_pointer(p)) return false;
    MEMORY_BASIC_INFORMATION mbi{};
    if (!VirtualQuery(reinterpret_cast<LPCVOID>(p), &mbi, sizeof(mbi))) return false;
    if (mbi.State != MEM_COMMIT) return false;
    DWORD prot = mbi.Protect;
    // Guard pages must never be treated as callable.
    if (prot & PAGE_GUARD) return false;
    return (prot & 0xF0) != 0 && (prot & (PAGE_EXECUTE | PAGE_EXECUTE_READ |
                                          PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY)) != 0;
}

// Committed, readable-or-executable memory Ã¢â‚¬â€ for heap objects like GtaThread
// instances and their vtables (heap data is read/write, never executable).
bool is_readable_memory(uintptr_t p) {
    if (!valid_pointer(p)) return false;
    MEMORY_BASIC_INFORMATION mbi{};
    if (!VirtualQuery(reinterpret_cast<LPCVOID>(p), &mbi, sizeof(mbi))) return false;
    if (mbi.State != MEM_COMMIT) return false;
    if (mbi.Protect & PAGE_GUARD) return false;
    return (mbi.Protect &
            (PAGE_READONLY | PAGE_READWRITE | PAGE_WRITECOPY | PAGE_EXECUTE |
             PAGE_EXECUTE_READ | PAGE_EXECUTE_READWRITE | PAGE_EXECUTE_WRITECOPY)) != 0;
}

// SEH requires the __try frame to hold no destructible locals (C2712 under
// /EHsc), so the guarded reads live in bare helpers. Filters route through
// log_fault_filter: a raw EXCEPTION_EXECUTE_HANDLER would swallow MSVC C++
// exceptions (0xE06D7363) and corrupt the EH chain (see log.h) Ã¢â‚¬â€ the
// "early-exit trap" the diary documents.
uintptr_t read_slot_safe(uintptr_t addr) {
    __try {
        return *reinterpret_cast<uintptr_t*>(addr);
    } __except (log_fault_filter(GetExceptionCode(), GetExceptionInformation())) {
        return 0;
    }
}

// Resolve the FiveM export. Retried on every get_handler miss until the
// module shows up (rage-scripting-five.dll loads with the scripting layer).
bool resolve_fivem_export() {
    if (g_get_native_handler) return true;

    HMODULE mod = GetModuleHandleW(L"rage-scripting-five.dll");
    if (!mod) return false;

    // Export name from the official citizenfx symbol set (stable ABI):
    //   rage::scrEngine::GetNativeHandler(unsigned __int64) -> scrNativeHandler
    const char* kName =
        "?GetNativeHandler@scrEngine@rage@@SAP6AXPEAVscrNativeCallContext@2@@Z_K@Z";
    auto fn = reinterpret_cast<GetNativeHandlerFn>(GetProcAddress(mod, kName));
    if (!fn) {
        // Fallback: the RVA is a per-build seam; only used if GetProcAddress
        // fails (e.g. exports stripped). 0x16E60 = verified on build 3788.
        fn = reinterpret_cast<GetNativeHandlerFn>(
            reinterpret_cast<uintptr_t>(mod) + 0x16E60);
        if (fn) FVEM_LOGF("[fvem] native: GetNativeHandler via RVA fallback");
    }
    if (!fn) return false;

    g_get_native_handler = fn;
    FVEM_LOGF("[fvem] native: rage::scrEngine::GetNativeHandler @ %p",
                  reinterpret_cast<void*>(fn));
    return true;
}

// SEH-guarded call into FiveM's lookup. Returns 0 on any fault.
void* lookup_handler(uint64_t hash) {
    void* result = nullptr;
    __try {
        result = g_get_native_handler(hash);
    } __except (log_fault_filter(GetExceptionCode(), GetExceptionInformation())) {
        return nullptr;
    }
    if (!is_executable(reinterpret_cast<uintptr_t>(result))) return nullptr;
    return result;
}

// ---------------------------------------------------------------------------
// Active script-thread context.
//
// FiveM's native handlers run inside citizen script threads; state-changing
// handlers (CREATE_VEHICLE and friends) read rage::scrEngine::GetActiveThread()
// and deref the thread's context. Called from our render thread there is no
// active script thread -> null+8 deref. rage-scripting-five exports the
// machinery to fix this: SetActiveThread(scrThread*) stores into a per-thread
// (TLS) citizen context slot.
//
// CRITICAL: never set a LIVE game thread as active. State-changing handlers
// write script bookkeeping into the active thread (ip, stack pointer, return
// context, Ã¢â‚¬Â¦), and the game's main thread runs live threads concurrently Ã¢â‚¬â€
// that race corrupts the thread, and the game faults when the script next
// ticks. This is the observed crash: after every scoped state change (weapon,
// godmode, spawn) the game died ~30-90s later with FiveM's "early-exit trap"
// (dump at game base+0x1000 region, exception thread context empty).
// Instead we fabricate a private thread, never registered in the collection
// (so the game never schedules it), snapshotted from a real thread so the
// layout is byte-exact and handlers see the same script context that makes
// today's calls succeed.
// ---------------------------------------------------------------------------
using GetActiveThreadFn = void* (*)();
using SetActiveThreadFn = void (*)(void*);

GetActiveThreadFn g_get_active_thread = nullptr;
SetActiveThreadFn g_set_active_thread = nullptr;
void* (*g_get_thread_collection)() = nullptr;
using ShouldBlockNativeFn = bool (*)(uint64_t hash);
ShouldBlockNativeFn g_should_block = nullptr;
void* g_borrowed_thread = nullptr;
bool g_scoped_tried = false;

void* scoped_get_active_thread() {
    __try {
        return g_get_active_thread ? g_get_active_thread() : nullptr;
    } __except (log_fault_filter(GetExceptionCode(), GetExceptionInformation())) {
        return nullptr;
    }
}

void scoped_set_active_thread(void* t) {
    __try {
        if (g_set_active_thread) g_set_active_thread(t);
    } __except (log_fault_filter(GetExceptionCode(), GetExceptionInformation())) {
    }
}

// Read a qword with an SEH guard (avoids crashing while probing foreign
// structures).
uintptr_t read_qword_safe(uintptr_t addr) {
    __try {
        return *reinterpret_cast<uintptr_t*>(addr);
    } __except (log_fault_filter(GetExceptionCode(), GetExceptionInformation())) {
        return 0;
    }
}

bool resolve_scoped_exports() {
    if (g_scoped_tried) return g_get_active_thread && g_set_active_thread;
    g_scoped_tried = true;

    HMODULE mod = GetModuleHandleW(L"rage-scripting-five.dll");
    if (!mod) return false;

    g_get_active_thread = reinterpret_cast<GetActiveThreadFn>(
        GetProcAddress(mod, "?GetActiveThread@scrEngine@rage@@SAPEAVscrThread@2@XZ"));
    g_set_active_thread = reinterpret_cast<SetActiveThreadFn>(
        GetProcAddress(mod, "?SetActiveThread@scrEngine@rage@@SAXPEAVscrThread@2@@Z"));
    g_get_thread_collection = reinterpret_cast<void* (*)()>(GetProcAddress(
        mod,
        "?GetThreadCollection@scrEngine@rage@@SAPEAV?$pgPtrCollection@VGtaThread@@@2@XZ"));
    g_should_block = reinterpret_cast<ShouldBlockNativeFn>(GetProcAddress(
        mod, "?ShouldBlockNative@scrEngine@rage@@SA_N_K@Z"));

    FVEM_LOGF("[fvem] native: thread ctx get=%p set=%p coll=%p",
                  reinterpret_cast<void*>(g_get_active_thread),
                  reinterpret_cast<void*>(g_set_active_thread),
                  reinterpret_cast<void*>(g_get_thread_collection));
    if (g_get_active_thread && g_set_active_thread) {
        FVEM_LOGF("[fvem] native: scrEngine thread context exports ok");
        return true;
    }
    FVEM_LOGF("[fvem] native: scrEngine thread context exports missing");
    return false;
}

// Locate a live GtaThread in scrEngine's thread collection and return its
// REAL pointer for scoped context. The collection is a
// rage::pgPtrCollection<GtaThread>: vtable@0, count(u16)@0x08, pad@0x0C,
// data(T**)@0x10. GtaThread derives from rage::scrThread, so the first
// qword of any valid entry is its vtable (readable for live threads).
//
// HISTORY: this used to copy a template thread into a private buffer and
// zero its execution state. That is a landmine: REQUEST_MODEL /
// CREATE_VEHICLE register the ACTIVE thread as OWNER of the streaming
// request, and gta-streaming-five later RESUMES the owner (observed crash:
// gta-streaming-five.dll+0x727BD -> GTA5_b3751.exe+0x310E - a real AV and
// a FiveM crash report, minutes after spawning). A zeroed fake dies under
// that resume. The game's scheduler owns the pool, so borrowing a real,
// live thread is strictly safer: handlers execute on the C stack we are
// already on, and any owner callback is legitimate, schedulable work.
bool script_thread_alive(void* t) {
    if (!g_get_thread_collection || !t) return false;
    uintptr_t coll = 0;
    __try {
        coll = reinterpret_cast<uintptr_t>(g_get_thread_collection());
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
    if (!valid_pointer(coll)) return false;
    uint16_t count = static_cast<uint16_t>(read_qword_safe(coll + 0x08) & 0xFFFF);
    uintptr_t data = read_qword_safe(coll + 0x10);
    if (count == 0 || count > 0x1000 || !valid_pointer(data)) return false;
    __try {
        for (uint16_t i = 0; i < count; ++i)
            if (read_qword_safe(data + static_cast<uintptr_t>(i) * 8) ==
                reinterpret_cast<uintptr_t>(t))
                return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        return false;
    }
    return false;  // cached thread stopped with the session - re-pick
}

// scrThread state at +0x08 (classic RAGE layout: vftable@0x00, state@0x08;
// scrThreadState { FREE, RUNNING, UNACTIVATED, KILLED, EXITED }). The layout
// is VERIFIED before trusted: a sane 0..4 value on most entries is strong
// evidence; garbage keeps us on the old (blind) behavior.
//
// Why this matters (field evidence): borrowing the FIRST live pool entry
// lands on a resource-owned thread - the "vMenu: activated <- root" script
// deadloop dialog is exactly that: REQUEST_MODEL under vMenu's context
// registers THEIR thread as streaming owner, the continuation resumes inside
// their tick, and their `while not HAS_MODEL_LOADED do WAIT(0)` never
// completes. A thread that is RUNNING right now is also about to collide
// with our scratch writes. So: prefer UNACTIVATED (registered but not
// executing), then FREE/EXITED, and never keep a cached thread that turned
// RUNNING since the last borrow.
int thread_state(void* t) {
    const uint64_t v = read_qword_safe(reinterpret_cast<uintptr_t>(t) + 0x08);
    const int s = static_cast<int>(v & 0xFFFFFFFFull);
    return (s >= 0 && s <= 4) ? s : -1;
}

bool thread_borrowable(void* t) {
    const int s = thread_state(t);
    return s == 2 || s == 0 || s == 4;   // UNACTIVATED / FREE / EXITED
}

void* borrow_script_thread() {
    if (g_borrowed_thread) {
        if (script_thread_alive(g_borrowed_thread) &&
            thread_borrowable(g_borrowed_thread))
            return g_borrowed_thread;
        g_borrowed_thread = nullptr;  // died OR got activated - re-pick
    }
    // Ensure the scrEngine thread-context exports are resolved before we
    // read them - async queue jobs reach here without a prior scoped call.
    resolve_scoped_exports();
    if (!g_get_thread_collection) {
        FVEM_LOGF("[fvem] native: no thread collection export");
        return nullptr;
    }

    uintptr_t coll = 0;
    __try {
        coll = reinterpret_cast<uintptr_t>(g_get_thread_collection());
    } __except (log_fault_filter(GetExceptionCode(), GetExceptionInformation())) {
        return nullptr;
    }
    if (!valid_pointer(coll)) {
        FVEM_LOGF("[fvem] native: thread collection invalid %p",
                  reinterpret_cast<void*>(coll));
        return nullptr;
    }

    uint16_t count = static_cast<uint16_t>(read_qword_safe(coll + 0x08) & 0xFFFF);
    uintptr_t data = read_qword_safe(coll + 0x10);
    FVEM_LOGF("[fvem] native: thread collection @%p count=%u data=%p",
                  reinterpret_cast<void*>(coll), count,
                  reinterpret_cast<void*>(data));
    // Live FiveM servers routinely hold 300+ citizen threads; cap generously.
    if (count == 0 || count > 0x1000 || !valid_pointer(data)) {
        FVEM_LOGF("[fvem] native: thread collection empty/invalid");
        return nullptr;
    }

    // ONE-SHOT layout probe: dump the raw first fields of the first five
    // entries. This is the evidence that PROVES or KILLS the scrThread-layout
    // assumption (vftable@+0x00, state@+0x08 in 0..4, tid-ish @+0x18) against
    // b3751 instead of trusting a header copied from classic RAGE. Read one
    // line per entry once per process; the next log paste settles it.
    static bool s_pool_dumped = false;
    if (!s_pool_dumped) {
        s_pool_dumped = true;
        for (uint16_t i = 0; i < count && i < 5; ++i) {
            uintptr_t t = read_qword_safe(data + static_cast<uintptr_t>(i) * 8);
            if (!valid_pointer(t)) {
                FVEM_LOGF("[fvem] native: pool[%u]=%p invalid", i,
                          reinterpret_cast<void*>(t));
                continue;
            }
            FVEM_LOGF("[fvem] native: pool[%u] t=%p +0=%p +8=%p +10=%p +18=%p",
                      i, reinterpret_cast<void*>(t),
                      reinterpret_cast<void*>(read_qword_safe(t)),
                      reinterpret_cast<void*>(read_qword_safe(t + 0x08)),
                      reinterpret_cast<void*>(read_qword_safe(t + 0x10)),
                      reinterpret_cast<void*>(read_qword_safe(t + 0x18)));
        }
    }

    // Two-pass pick over validated entries: PREFER a state-verified idle
    // thread (UNACTIVATED/FREE/EXITED - see thread_state note); fall back to
    // the first live entry (old behavior) only when the +0x08 layout does not
    // verify anywhere in this pool. Re-checked on every borrow, so a thread
    // stopped or ACTIVATED between sessions is replaced before streaming can
    // ever resume into a dead or busy owner.
    uintptr_t fallback = 0;
    for (uint16_t pass = 0; pass < 2; ++pass) {
        for (uint16_t i = 0; i < count; ++i) {
            uintptr_t t = read_qword_safe(data + static_cast<uintptr_t>(i) * 8);
            if (!valid_pointer(t)) continue;
            uintptr_t vt = read_qword_safe(t);
            if (!valid_pointer(vt)) continue;
            if (!is_readable_memory(t)) continue;   // heap object: committed R/W
            if (!is_readable_memory(vt)) continue;  // vtable: committed, any R/X
            const int s = thread_state(reinterpret_cast<void*>(t));
            if (pass == 0) {
                if (s < 0) continue;                 // layout unverified: pass 2
                if (!thread_borrowable(reinterpret_cast<void*>(t))) continue;
                g_borrowed_thread = reinterpret_cast<void*>(t);
                FVEM_LOGF("[fvem] native: borrowed idle script thread %p "
                          "(entry %u/%u state %d)",
                          g_borrowed_thread, i, count, s);
                return g_borrowed_thread;
            }
            if (!fallback) fallback = t;             // unverified pool: old pick
        }
    }
    if (fallback) {
        g_borrowed_thread = reinterpret_cast<void*>(fallback);
        FVEM_LOGF("[fvem] native: borrowed live script thread %p "
                  "(state layout unverified - blind pick)", g_borrowed_thread);
        return g_borrowed_thread;
    }
    FVEM_LOGF("[fvem] native: no valid live thread in pool (count=%u)", count);
    return nullptr;
}

} // namespace

bool init() {
    // Keep the game-module base for any feature that needs offsets, but the
    // invoker itself no longer scans the game module.
    (void)game::base();

    if (!resolve_fivem_export()) {
        // Not fatal: rage-scripting-five may not be mapped yet. get_handler
        // will keep retrying; log once.
        FVEM_LOGF("[fvem] native: rage-scripting-five.dll not loaded yet "
                      "(retrying on first call)");
    }
    return true;
}

void set_direct_table(const void* entries, size_t entry_count) {
    g_direct.clear();
    const uint64_t* p = static_cast<const uint64_t*>(entries);
    for (size_t i = 0; i < entry_count; ++i) {
        uint64_t hash = p[i * 2];
        uint64_t func = p[i * 2 + 1];
        if (hash != 0 && valid_pointer(func))
            g_direct.emplace(hash, reinterpret_cast<void*>(func));
    }
}

#ifdef FVEM_DEV_TOOLS
size_t load_direct_csv(const char* path) {
    std::ifstream in(path);
    if (!in) return 0;

    std::vector<uint64_t> pairs;
    std::string line;
    while (std::getline(in, line)) {
        // format: "0xHASH,0xADDR" (header line tolerated)
        auto comma = line.find(',');
        if (comma == std::string::npos) continue;
        uint64_t hash = strtoull(line.substr(0, comma).c_str(), nullptr, 16);
        uint64_t func = strtoull(line.substr(comma + 1).c_str(), nullptr, 16);
        if (hash != 0 && func != 0) {
            pairs.push_back(hash);
            pairs.push_back(func);
        }
    }
    if (pairs.empty()) return 0;
    set_direct_table(pairs.data(), pairs.size() / 2);
    return g_direct.size();
}
#endif // FVEM_DEV_TOOLS

void set_crossmap(const std::unordered_map<uint64_t, uint64_t>& map) {
    g_crossmap = map;
}

void* get_handler(uint64_t hash) {
    auto it = g_direct.find(hash);
    if (it != g_direct.end()) return it->second; // direct table is already build-accurate

    auto cm = g_crossmap.find(hash);
    if (cm != g_crossmap.end()) hash = cm->second;

    if (!g_get_native_handler) {
        if (g_resolve_tried) return nullptr; // one retry per process
        g_resolve_tried = true;
        if (!resolve_fivem_export()) return nullptr;
    }

    return lookup_handler(hash);
}

bool should_block(uint64_t hash) {
    if (!g_should_block) {
        HMODULE mod = GetModuleHandleW(L"rage-scripting-five.dll");
        if (!mod) return false;
        g_should_block = reinterpret_cast<ShouldBlockNativeFn>(
            GetProcAddress(mod, "?ShouldBlockNative@scrEngine@rage@@SA_N_K@Z"));
    }
    if (!g_should_block) return false;
    bool out = false;
    __try {
        out = g_should_block(hash);
    } __except (log_fault_filter(GetExceptionCode(), GetExceptionInformation())) {
        return false;
    }
    return out;
}

void invoke_array(uint64_t hash, const uint64_t* args, int argc, void* scratch) {
    Handler h = reinterpret_cast<Handler>(get_handler(hash));
    if (!h || argc < 0) return;
    if (argc > 16) argc = 16; // clamp; 16 covers the longest common signatures

    alignas(16) uint8_t tmp[16]{};
    alignas(16) uint64_t slots[16]{};
    for (int i = 0; i < argc; ++i) slots[i] = args[i];

    scrNativeCallContext ctx{};
    ctx.m_ReturnValue = tmp;
    ctx.m_ArgCount = static_cast<uint32_t>(argc);
    ctx.m_DataCount = static_cast<uint32_t>(argc);
    ctx.m_Args = slots;
    h(&ctx);
    // CRITICAL: scratch may legitimately be null (fire-and-forget async calls).
    // Writing the 16-byte result to address 0 faults on the game's main thread,
    // unwinds the handler mid-execution via SEH and leaves game state half-
    // mutated Ã¢â‚¬â€ the observed "early-exit trap" seconds later.
    if (scratch) std::memcpy(scratch, tmp, 16);
}

// ---------------------------------------------------------------------------
// Main-thread execution queue for state-changing natives.
//
// The game's main thread updates game state every frame; native handlers that
// MUTATE state (CREATE_VEHICLE, SET_ENTITY_COORDS, GIVE_WEAPON_TO_PED, Ã¢â‚¬Â¦) are
// not safe to run from the render thread Ã¢â‚¬â€ the concurrent mutation corrupts
// game state and the game dies with FiveM's "early-exit trap" seconds later
// (observed after every state change, with no fault in our code). Scoped calls
// are therefore queued here and executed on the game's main thread, drained
// from the game window's WndProc hook (Windows dispatches window messages on
// the window's creating thread Ã¢â‚¬â€ the game's main thread, proven by our Insert
// toggle working). The render thread enqueues and wakes the pump; blocking
// callers spin on a caller-owned result flag (immune to ring-slot reuse).
//
// In this build the Present hook ALSO runs on the game's main thread
// (g_queue_tid == window thread tid). That made the "already on main thread"
// fast-path run handlers INLINE mid-render Ã¢â‚¬â€ racing the citizen script
// threads and corrupting state. While in_present() is true we therefore
// ALWAYS queue and let the WndProc drain (which runs between frames, at the
// top of the game's message loop) execute the job. Never inline from Present.
// ---------------------------------------------------------------------------
namespace {

constexpr int kScopedQueueCap = 128;

struct ScopedResult {
    volatile LONG done;       // 0 pending, 1 executed (main thread)
    uint8_t       result[16];
};

struct ScopedJob {
    uint64_t      hash;
    uint64_t      args[16];
    uint32_t      argc;
    ScopedResult* res;        // null for fire-and-forget
};

ScopedJob   g_ring[kScopedQueueCap];
volatile LONG g_head = 0;     // producer (render thread)
volatile LONG g_tail = 0;     // consumer (main thread)
void*         g_queue_hwnd = nullptr;
DWORD         g_queue_tid = 0; // window's creating thread = the game main thread
UINT          g_wm_drain = 0;
volatile LONG g_in_present = 0;

} // namespace

bool in_present() { return g_in_present != 0; }
void set_in_present(bool value) { InterlockedExchange(&g_in_present, value ? 1 : 0); }

bool enqueue_scoped(uint64_t hash, const uint64_t* args, int argc,
                    ScopedResult* res) {
    LONG h = g_head, t = g_tail;
    if (h - t >= kScopedQueueCap) return false; // ring full Ã¢â‚¬â€ drop
    ScopedJob& j = g_ring[h % kScopedQueueCap];
    j.hash = hash;
    j.argc = static_cast<uint32_t>(argc);
    j.res = res;
    for (int i = 0; i < argc && i < 16; ++i) j.args[i] = args[i];
    InterlockedIncrement(&g_head); // publish: consumer may now see slot h
    return true;
}

// Run one queued job on the CURRENT thread (must be the game's main thread).
void run_scoped_job(const ScopedJob& j) {
    // C++ boundary: state-changing handlers can throw (sol::error, bad_alloc,
    // internal CFX throws). Our __except filter CONTINUE_SEARCHes 0xE06D7363 by
    // design (see log.h) Ã¢â‚¬â€ without a try/catch HERE the exception keeps
    // unwinding past our frame into the game's WndProc dispatch, where FiveM's
    // own exception handling runs first and kills the process with no log
    // line. Catch it at our boundary and log instead.
    try {
        void* borrowed = borrow_script_thread();
        if (!borrowed) {
            if (j.res) InterlockedExchange(&j.res->done, 1);
            return;
        }
        void* prev = scoped_get_active_thread();
        scoped_set_active_thread(borrowed);
        invoke_array(j.hash, j.args, static_cast<int>(j.argc),
                     j.res ? j.res->result : nullptr);
        scoped_set_active_thread(prev);
        if (j.res) InterlockedExchange(&j.res->done, 1);
    } catch (const std::exception& e) {
        FVEM_LOGF("[fvem] native: scoped job 0x%llX C++ exception: %s",
                      j.hash, e.what());
        if (j.res) InterlockedExchange(&j.res->done, 1);
    } catch (...) {
        FVEM_LOGF("[fvem] native: scoped job 0x%llX unknown C++ exception",
                      j.hash);
        if (j.res) InterlockedExchange(&j.res->done, 1);
    }
}

void set_scoped_queue_window(void* hwnd) {
    if (hwnd == g_queue_hwnd) return;
    g_queue_hwnd = hwnd;
    if (hwnd) {
        // The drain message used to be registered under the literal
        // "fvem_scoped_drain" â€” RegisterWindowMessage names live in a GLOBAL
        // atom table any process can probe, so that was an identifiable,
        // cross-process signature. Use a GUID-shaped token that reads as an
        // ordinary private message, stored encrypted (no plaintext in .rdata),
        // and zero the stack copy after the atom is obtained. The atom VALUE is
        // what matches sender to handler (both read g_wm_drain), so any stable
        // name works.
        static const gfx::obf::EncW kDrainMsg{ L"{C4E1D2A0-3F7B-4A19-8E2D-6B5A0941F3C0}" };
        wchar_t mname[64]{};
        kDrainMsg.out(mname, 64);
        g_wm_drain = RegisterWindowMessageW(mname);
        SecureZeroMemory(mname, sizeof(mname));
        if (g_wm_drain == 0) g_wm_drain = WM_APP + 0x4F0;
        g_queue_tid = GetWindowThreadProcessId(static_cast<HWND>(hwnd), nullptr);
        g_head = 0;
        g_tail = 0;
        FVEM_LOGF("[fvem] native: scoped queue active (hwnd=%p tid=%lu wm=0x%X)",
                      hwnd, g_queue_tid, g_wm_drain);
    }
}

void drain_scoped_queue() {
    // Only the game's main thread may run these handlers. g_queue_tid is the
    // thread that created the game window Ã¢â‚¬â€ Windows dispatches that window's
    // messages (and our WndProc hook) on that same thread.
    if (!g_queue_hwnd || !g_queue_tid ||
        GetCurrentThreadId() != g_queue_tid) {
        return;
    }
    // RE-ENTRANCY GUARD: a native handler executed below can pump messages
    // (citizen handlers with blocking waits, D3D dialogs, SetForegroundWindow),
    // re-entering this WndProc while we are mid-job. A nested drain would
    // SetActiveThread(ours) OVER the outer job's active-context restore,
    // stranding the game's own script-thread pointer on our private fake
    // thread - the scheduler then never resumes its real threads, the main
    // thread heartbeat stalls, and FiveM fires the early-exit trap
    // (GTA5_bXXXX.exe+0x101C). Nested calls return instantly; the outer loop
    // picks their jobs up on its next pass.
    static volatile LONG s_draining = 0;
    if (InterlockedCompareExchange(&s_draining, 1, 0) != 0) return;

    // BUDGET: at most 4 jobs per pass. Per-frame async tick callers can queue
    // faster than a frame drains; running the whole ring inline holds the main
    // thread in OUR code long enough to trip the same heartbeat this guard
    // protects (the 19:31 death: main starved, self-trapped, and the bounce
    // derailed it). If work remains, re-post the wake so jobs never strand.
    int budget = 4;
    while (budget-- > 0 && g_tail < g_head) {
        ScopedJob j = g_ring[g_tail % kScopedQueueCap];
        InterlockedIncrement(&g_tail); // free the slot (result is caller-owned)
        __try {
            run_scoped_job(j);
        } __except (log_fault_filter(GetExceptionCode(), GetExceptionInformation())) {
            if (j.res) InterlockedExchange(&j.res->done, 1);
        }
    }
    if (g_tail < g_head)
        PostMessageW(static_cast<HWND>(g_queue_hwnd), g_wm_drain, 0, 0);
    InterlockedExchange(&s_draining, 0);
}

void invoke_array_scoped(uint64_t hash, const uint64_t* args, int argc,
                         void* scratch) {
    resolve_scoped_exports();
    if (!g_queue_hwnd) {
        // Queue mode off (no game window yet) Ã¢â‚¬â€ legacy direct path. If no
        // thread can be borrowed, DO NOT run the handler: state-changing
        // natives without a script-thread context corrupt game state.
        void* borrowed = borrow_script_thread();
        if (!borrowed) {
            FVEM_LOGF("[fvem] native: scoped 0x%llX dropped (no thread ctx)",
                          hash);
            return;
        }
        void* prev = scoped_get_active_thread();
        scoped_set_active_thread(borrowed);
        invoke_array(hash, args, argc, scratch);
        scoped_set_active_thread(prev);
        return;
    }
    if (in_present()) {
        // Inside the hooked Present frame: NEVER run a state-changing handler
        // inline here (races the citizen script threads mid-render). Queue it
        // for the WndProc drain, which runs at the top of the game's message
        // loop Ã¢â‚¬â€ between frames, on the main thread. Fire-and-forget with no
        // wait: a sync caller from Present cannot block for the drain (the
        // drain runs on this same thread, after we return), and the caller's
        // result slot would be stack memory we must not keep a pointer to.
        // All Present-time callers are void natives, so the result is unused.
        if (enqueue_scoped(hash, args, argc, nullptr))
            PostMessageW(static_cast<HWND>(g_queue_hwnd), g_wm_drain, 0, 0);
        return;
    }
    // Not in Present. On the main thread already (WndProc drain context or a
    // native callback): execute directly Ã¢â‚¬â€ no queue hop needed.
    if (g_queue_tid && GetCurrentThreadId() == g_queue_tid) {
        void* borrowed = borrow_script_thread();
        if (borrowed) {
            void* prev = scoped_get_active_thread();
            scoped_set_active_thread(borrowed);
            invoke_array(hash, args, argc, scratch);
            scoped_set_active_thread(prev);
            return;
        }
    }
    ScopedResult res{};
    if (!enqueue_scoped(hash, args, argc, &res)) {
        // Ring full Ã¢â‚¬â€ drop, never run state-changing natives on a foreign
        // thread without a script-thread context.
        FVEM_LOGF("[fvem] native: scoped 0x%llX dropped (queue full)", hash);
        return;
    }
    PostMessageW(static_cast<HWND>(g_queue_hwnd), g_wm_drain, 0, 0);
    // Bounded wait: the main thread drains within a frame (~16ms); 250ms cap
    // covers stalls (loading screens) without hanging the render thread.
    for (int i = 0; i < 250 && !res.done; ++i) Sleep(1);
    if (res.done) std::memcpy(scratch, res.result, 16);
}

void invoke_array_scoped_async(uint64_t hash, const uint64_t* args, int argc) {
    if (!g_queue_hwnd) {
        invoke_array_scoped(hash, args, argc, nullptr);
        return;
    }
    if (in_present()) {
        // Never inline from Present (see invoke_array_scoped).
        if (enqueue_scoped(hash, args, argc, nullptr))
            PostMessageW(static_cast<HWND>(g_queue_hwnd), g_wm_drain, 0, 0);
        return;
    }
    if (enqueue_scoped(hash, args, argc, nullptr))
        PostMessageW(static_cast<HWND>(g_queue_hwnd), g_wm_drain, 0, 0);
}

void invoke_array_scoped_async_res(uint64_t hash, const uint64_t* args, int argc,
                                   ScopedResultSlot* slot) {
    if (!slot) return;
    InterlockedExchange(&slot->done, 0);
    if (!g_queue_hwnd) {
        // No queue yet Ã¢â‚¬â€ legacy direct path, result written synchronously.
        invoke_array_scoped(hash, args, argc, slot->result);
        InterlockedExchange(&slot->done, 1);
        return;
    }
    if (in_present()) {
        if (enqueue_scoped(hash, args, argc, reinterpret_cast<ScopedResult*>(slot)))
            PostMessageW(static_cast<HWND>(g_queue_hwnd), g_wm_drain, 0, 0);
        return;
    }
    if (enqueue_scoped(hash, args, argc, reinterpret_cast<ScopedResult*>(slot)))
        PostMessageW(static_cast<HWND>(g_queue_hwnd), g_wm_drain, 0, 0);
}

} // namespace gfx::native

// ---------------------------------------------------------------------------
// Feature contract (declared in core/features/esp.cpp): the hash externs are
// resolved through the invoker so features can use stable canonical hashes.
// Values below are CFX native DB hashes Ã¢â‚¬â€ extracted from FiveM's own
// citizen/scripting/lua/natives_universal.lua (authoritative for this build).
// ---------------------------------------------------------------------------
namespace gfx {
namespace natives {

using InvokeFn = void (*)(uint64_t hash, void* result, void* args, int argc);

InvokeFn g_invoke = [](uint64_t hash, void* result, void* args, int argc) {
    native::invoke_array(hash, static_cast<const uint64_t*>(args), argc, result);
};

// canonical -> current-build resolution for feature hashes. With the FiveM
// export the canonical CFX hash is what the registry expects, so this simply
// verifies the hash resolves.
static uint64_t resolve(uint64_t canonical, uint64_t fallback) {
    if (native::get_handler(canonical)) return canonical; // resolves in-game
    return fallback;
}

uint64_t GET_PLAYER_PED             = resolve(0x43A66C31C68491C0ull, 0x43A66C31C68491C0ull);
uint64_t GET_PLAYER_COORDS          = 0; // script-level helper; use GET_ENTITY_COORDS on the ped
uint64_t GET_ENTITY_COORDS          = resolve(0x3FEF770D40960D5Aull, 0x3FEF770D40960D5Aull);
uint64_t GET_NUMBER_OF_PLAYERS      = resolve(0x407C7F91DDB46C16ull, 0x407C7F91DDB46C16ull);
uint64_t GET_PLAYER_NAME            = resolve(0x6D0DE6A7B5DA71F8ull, 0x6D0DE6A7B5DA71F8ull);
uint64_t GET_ENTITY_HEALTH          = resolve(0xEEF059FAD016D209ull, 0xEEF059FAD016D209ull);
uint64_t IS_PED_DEAD                = resolve(0x3317DEDB88C95038ull, 0x3317DEDB88C95038ull); // IS_PED_DEAD_OR_DYING
uint64_t GET_SCREEN_COORD_FROM_WORLD= resolve(0x34E82F05DF2974F5ull, 0x34E82F05DF2974F5ull); // ...FROM_WORLD_COORD
uint64_t GET_ENTITY_BONE_INDEX_BY_NAME = resolve(0xFB71170B7E76ACBAull, 0xFB71170B7E76ACBAull);
uint64_t GET_CAM_COORD              = resolve(0xBAC038F7459AE5AEull, 0xBAC038F7459AE5AEull);
uint64_t GET_CAM_ROT                = resolve(0x7D304C1C955E3E12ull, 0x7D304C1C955E3E12ull);

} // namespace natives
} // namespace gfx
