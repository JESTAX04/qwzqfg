// language: C++, target: Windows 11, MSVC (x64)
// Teleport Ã¢â‚¬â€ 100% native-based. Moves the local ped with SET_ENTITY_COORDS
// (through invoke_scoped Ã¢â‚¬â€ state-changing native, safe from the render
// thread). Waypoint teleport reads the first type-8 blip via
// GetFirstBlipInfoId + GetBlipCoords. No game-module memory offsets.
#include "pch.h"
#include "config.h"
#include "features.h"
#include "natives.h"
#include "log.h"

namespace gfx {

namespace {

// Blip type 8 = waypoint/radius marker.
constexpr int kBlipTypeWaypoint = 8;

uint64_t local_ped() {
    return nv::player_ped_id();
}

void teleport_to(float x, float y, float z) {
    uint64_t ped = local_ped();
    if (!ped) return;
    nv::set_entity_coords(ped, x, y, z, false, false, false, false);
    FVEM_LOGF("[fvem] tp: ped=0x%llX -> %d,%d,%d", ped,
                  static_cast<int>(x), static_cast<int>(y), static_cast<int>(z));
}

// Resolve the first waypoint blip's world position.
bool waypoint_coords(float& x, float& y, float& z) {
    uint64_t blip = nv::first_blip_info_id(kBlipTypeWaypoint);
    if (!nv::does_blip_exist(blip)) return false;
    if (nv::blip_info_type(blip) != kBlipTypeWaypoint) return false;
    native::Vector3 c = nv::blip_coords(blip);
    x = c.x; y = c.y; z = c.z;
    return true;
}

} // namespace

void do_teleport() {
    auto& c = cfg();
    if (c.tp_to_marker) {
        float x, y, z;
        if (waypoint_coords(x, y, z)) {
            teleport_to(x, y, z);
        } else {
            FVEM_LOGF("[fvem] tp: no waypoint blip found");
        }
    } else {
        teleport_to(c.tp_marker_x, c.tp_marker_y, c.tp_marker_z);
    }
}

} // namespace gfx
