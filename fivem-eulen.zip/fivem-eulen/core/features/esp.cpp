// language: C++, target: Windows 11, MSVC (x64)
// ESP overlay: boxes, health bars, names, distance â€” 100% native-based.
// Players are enumerated through NetworkIsPlayerActive/GetPlayerPed, positions
// through GetEntityCoords, projection through the game's own
// GetScreenCoordFromWorldCoord (no game-module memory offsets at all). A stale
// client patch can only break individual native hashes, which the invoker
// no-ops â€” never a crash.
#include "pch.h"
#include "config.h"
#include "features.h"
#include "natives.h"
#include "../../third_party/imgui/imgui.h"

namespace gfx {

namespace {

struct PlayerEntity {
    int    player;
    uint64_t ped;
    float  x, y, z;
    float  health;
    float  max_health;
    char   name[32];
    bool   alive;
    bool   valid;
};

void gather_players(std::vector<PlayerEntity>& list, uint64_t me) {
    // FiveM supports up to 256 connected players; skip inactive slots fast.
    for (int p = 0; p < 256; ++p) {
        if (!nv::is_player_active(p)) continue;

        uint64_t ped = nv::player_ped(p);
        if (!ped || ped == me) continue;

        PlayerEntity e{};
        e.player = p;
        e.ped = ped;

        const char* nm = nv::player_name(p);
        if (!nm || !nm[0]) continue;
        size_t i = 0;
        while (nm[i] && i < sizeof(e.name) - 1) { e.name[i] = nm[i]; ++i; }
        e.name[i] = 0;

        native::Vector3 c = nv::entity_coords(ped);
        e.x = c.x; e.y = c.y; e.z = c.z;

        e.health = nv::entity_health(ped);
        e.max_health = nv::entity_max_health(ped);
        if (e.max_health <= 0.0f) e.max_health = 200.0f;
        e.alive = e.health > 0.0f;
        e.valid = true;
        list.push_back(e);
    }
}

} // namespace

void esp_draw() {
    if (!cfg().esp_enabled) return;

    uint64_t me = nv::player_ped_id();
    std::vector<PlayerEntity> players;
    gather_players(players, me);

    ImDrawList* dl = ImGui::GetBackgroundDrawList();
    for (auto& p : players) {
        if (!p.valid || !p.alive) continue;

        // Head at the nav position, feet 1.8m below.
        ImVec2 head, feet;
        native::Vector3 wp{p.x, p.y, p.z};
        float sx, sy;
        if (!nv::world_to_screen(wp, sx, sy)) continue;
        head.x = sx; head.y = sy;

        native::Vector3 wf{p.x, p.y, p.z - 1.8f};
        if (!nv::world_to_screen(wf, sx, sy)) continue;
        feet.x = sx; feet.y = sy;

        float h = feet.y - head.y;
        if (h < 5.0f) h = 60.0f; // degenerate projection guard
        float w = h * 0.55f;

        if (cfg().esp_boxes) {
            dl->AddRect(ImVec2(head.x - w / 2, head.y),
                        ImVec2(head.x + w / 2, head.y + h),
                        IM_COL32(0, 255, 180, 255), 0.0f, 0, 1.5f);
        }
        if (cfg().esp_health) {
            float pct = p.health / p.max_health;
            if (pct > 1.0f) pct = 1.0f;
            if (pct < 0.0f) pct = 0.0f;
            dl->AddRectFilled(ImVec2(head.x - w / 2 - 7, head.y),
                              ImVec2(head.x - w / 2 - 3, head.y + h),
                              IM_COL32(20, 20, 20, 200));
            dl->AddRectFilled(ImVec2(head.x - w / 2 - 7, head.y + h * (1.0f - pct)),
                              ImVec2(head.x - w / 2 - 3, head.y + h),
                              IM_COL32(0, 255, 80, 255));
        }
        if (cfg().esp_names) {
            dl->AddText(ImVec2(head.x, head.y - 14), IM_COL32(255, 255, 255, 255),
                        p.name);
        }
        if (cfg().esp_distance) {
            native::Vector3 mep = nv::entity_coords(me);
            float dx = p.x - mep.x, dy = p.y - mep.y, dz = p.z - mep.z;
            char buf[48];
            snprintf(buf, sizeof(buf), "%.0fm", sqrtf(dx * dx + dy * dy + dz * dz));
            dl->AddText(ImVec2(head.x, head.y + h + 2), IM_COL32(200, 200, 200, 255),
                        buf);
        }
    }
}

} // namespace gfx
