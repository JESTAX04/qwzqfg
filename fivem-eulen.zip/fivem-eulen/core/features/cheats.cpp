// language: C++, target: Windows 11, MSVC (x64)
// Player & vehicle cheat loops Ã¢â‚¬â€ 100% native-based (no memory offsets).
// Toggled states are enforced per frame through the proven native invoker;
// state-changing natives run under a borrowed script-thread context
// (invoke_scoped) so they never fault from the render thread.
#include "pch.h"
#include "config.h"
#include "features.h"
#include "natives.h"
#include "log.h"

namespace gfx {

namespace {

// Apply one frame of the player cheat states to the local player. All state
// changes are fire-and-forget (invoke_scoped_async): they re-apply every frame
// and execute on the game's main thread via the scoped queue.
void apply_player_cheats() {
    const auto& c = cfg();
    uint64_t ped = nv::player_ped_id();
    if (!ped) return;

    int player = 0; // local player index on FiveM

    if (c.plr_godmode) {
        native::invoke_scoped_async(nv::H_SET_ENTITY_INVINCIBLE, ped, 1ull);
        native::invoke_scoped_async(nv::H_SET_ENTITY_CAN_BE_DAMAGED, ped, 0ull);
        native::invoke_scoped_async(nv::H_SET_PLAYER_INVINCIBLE,
                                    static_cast<int64_t>(player), 1ull);
        native::invoke_scoped_async(nv::H_SET_ENTITY_PROOFS, ped, 1ull, 1ull,
                                    1ull, 1ull, 1ull, 1ull, 1ull, 1ull);
    }
    if (c.plr_infinite_health) {
        float maxh = nv::entity_max_health(ped);
        if (maxh <= 0.0f) maxh = 200.0f;
        native::invoke_scoped_async(nv::H_SET_ENTITY_HEALTH, ped, maxh);
    }
    if (c.plr_infinite_armour) {
        native::invoke_scoped_async(nv::H_SET_PED_ARMOUR, ped,
                                    static_cast<int64_t>(100));
    }
    if (c.plr_no_wanted) {
        native::invoke_scoped_async(nv::H_CLEAR_PLAYER_WANTED_LEVEL,
                                    static_cast<int64_t>(player));
    }
}

} // namespace

void player_cheats_tick() {
    const auto& c = cfg();
    if (!c.plr_godmode && !c.plr_infinite_health && !c.plr_infinite_armour &&
        !c.plr_no_wanted)
        return;
    apply_player_cheats();
}

// Apply the vehicle tools to the vehicle the local ped is currently in.
void vehicle_tools_tick() {
    const auto& c = cfg();
    if (!c.veh_engine && !c.veh_doors && !c.veh_fix) return;

    uint64_t ped = nv::player_ped_id();
    if (!ped) return;
    uint64_t veh = nv::vehicle_ped_is_in(ped, false);
    if (!veh) return;

    if (c.veh_fix) {
        native::invoke_scoped_async(nv::H_SET_VEHICLE_FIXED, veh);
        cfg().veh_fix = false; // one-shot
        FVEM_LOGF("[fvem] veh: fixed 0x%llX", veh);
    }
    if (c.veh_engine)
        native::invoke_scoped_async(nv::H_SET_VEHICLE_ENGINE_ON, veh, 1ull, 1ull);
    if (c.veh_doors)
        native::invoke_scoped_async(nv::H_SET_VEHICLE_DOORS_LOCKED, veh,
                                    static_cast<int64_t>(2)); // locked
}

} // namespace gfx
