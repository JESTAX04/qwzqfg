// language: C++, target: Windows 11, MSVC (x64)
// Vehicle spawner Ã¢â‚¬â€ non-blocking, per-frame state machine.
//
// The invoker runs on the render (Present) thread. Blocking that thread for
// model streaming (Sleep loops) starves the game's own frame machinery and
// faults FiveM's patched dispatch loops, so the spawn advances one native
// call per render frame: REQUEST_MODEL -> (frames) HAS_MODEL_LOADED ->
// GET_ENTITY_COORDS/HEADING -> CREATE_VEHICLE -> SET_PED_INTO_VEHICLE.
#include "pch.h"
#include "config.h"
#include "features.h"
#include "native_invoker.h"
#include "natives.h"
#include "log.h"

namespace gfx {

namespace {

bool have(uint64_t hash, const char* name) {
    bool ok = native::get_handler(hash) != nullptr;
    if (!ok) FVEM_LOGF("[fvem] spawn: native %s (0x%llX) unresolved", name, hash);
    return ok;
}

// CFX native hashes Ã¢â‚¬â€ from FiveM's natives_universal.lua (authoritative).
const uint64_t H_GET_HASH_KEY                = 0xD24D37CC275948CCull;
const uint64_t H_REQUEST_MODEL               = 0x963D27A58DF860ACull;
const uint64_t H_HAS_MODEL_LOADED            = 0x98A4EB5D89A0C952ull;
const uint64_t H_PLAYER_PED_ID               = 0xD80958FC74E988A6ull;
const uint64_t H_GET_ENTITY_COORDS           = 0x3FEF770D40960D5Aull;
const uint64_t H_GET_ENTITY_HEADING          = 0xE83D4F9BA2A38914ull;
const uint64_t H_CREATE_VEHICLE              = 0xAF35D0D2583051B0ull;
const uint64_t H_SET_PED_INTO_VEHICLE        = 0xF75B0D629E1C063Dull;
const uint64_t H_SET_MODEL_AS_NO_LONGER_NEEDED = 0xE532F5D78798DAABull;

// One spawn operation, advanced one step per render frame.
struct SpawnJob {
    bool     active = false;
    char     model[64]{};
    uint32_t hash = 0;
    int      frames = 0; // frames spent waiting for the model
    bool     armed = false; // natives verified at least once
    // CREATE_VEHICLE is state-changing and runs on the main-thread queue, so
    // its result arrives asynchronously: slot is polled once per frame.
    native::ScopedResultSlot create_slot{};
    bool     create_pending = false;
};

SpawnJob g_job;

} // namespace

// Queue a spawn for the per-frame pump. Safe to call from menu/UI code.
void spawn_vehicle(const char* model) {
    if (!model || !*model) return;
    SpawnJob j{};
    j.active = true;
    j.armed = false;
    j.frames = 0;
    strncpy_s(j.model, model, sizeof(j.model) - 1);
    j.hash = 0;
    FVEM_LOGF("[fvem] spawn: queued model=%s", j.model);
    g_job = j;
}

// Advance the queued spawn by one step. Called once per render frame; never
// sleeps, never blocks the render thread for more than one native call.
// State-changing natives (REQUEST_MODEL/CREATE_VEHICLE/SET_PED_INTO_VEHICLE)
// run under a borrowed scrEngine script-thread context via invoke_scoped.
void tick_spawn() {
    if (!g_job.active) return;

    // CREATE_VEHICLE result pending: poll once per frame until the main
    // thread executed it, then seat the ped.
    if (g_job.create_pending) {
        if (g_job.create_slot.done == 0) return; // not executed yet
        g_job.create_pending = false;
        uint64_t veh = 0;
        std::memcpy(&veh, g_job.create_slot.result, sizeof(veh));
        FVEM_LOGF("[fvem] spawn: CREATE_VEHICLE ret=0x%llX", veh);
        if (veh) {
            uint64_t ped = native::invoke<uint64_t>(H_PLAYER_PED_ID);
            if (ped && native::get_handler(H_SET_PED_INTO_VEHICLE))
                native::invoke_scoped_async(H_SET_PED_INTO_VEHICLE, ped, veh,
                                            static_cast<int64_t>(-1));
            FVEM_LOGF("[fvem] spawn: created veh=0x%llX", veh);
        } else {
            FVEM_LOGF("[fvem] spawn: CreateVehicle returned 0");
        }
        // RELEASE the model request too - it mutates the streaming request
        // table owned by the scripted thread that requested the model, so it
        // must run on the main-thread scoped queue like its siblings. Calling
        // it inline from the render thread was racing gta-streaming-five's
        // own bookkeeping (crash family: GTA5_b3751.exe+0x310E under
        // gta-streaming-five.dll).
        if (native::get_handler(H_SET_MODEL_AS_NO_LONGER_NEEDED))
            native::invoke_scoped_async(H_SET_MODEL_AS_NO_LONGER_NEEDED, g_job.hash);
        g_job.active = false;
        FVEM_LOGF("[fvem] spawn: job complete");
        return;
    }

    // Verify natives once, before the first call (cheap, SEH-guarded).
    if (!g_job.armed) {
        g_job.armed = true;
        // Prefer the game's own hash (authoritative string rules).
        if (native::get_handler(H_GET_HASH_KEY)) {
            g_job.hash = static_cast<uint32_t>(nv::get_hash_key(g_job.model));
            FVEM_LOGF("[fvem] spawn: GET_HASH_KEY(%s) = 0x%X", g_job.model,
                          g_job.hash);
        }
        if (!have(H_REQUEST_MODEL, "REQUEST_MODEL") ||
            !have(H_CREATE_VEHICLE, "CREATE_VEHICLE") ||
            !have(H_PLAYER_PED_ID, "PLAYER_PED_ID") ||
            !have(H_GET_ENTITY_COORDS, "GET_ENTITY_COORDS")) {
            FVEM_LOGF("[fvem] spawn: core natives unresolvable Ã¢â‚¬â€ aborting");
            g_job.active = false;
            return;
        }
        (void)have(H_HAS_MODEL_LOADED, "HAS_MODEL_LOADED");
        (void)have(H_GET_ENTITY_HEADING, "GET_ENTITY_HEADING");
        (void)have(H_SET_PED_INTO_VEHICLE, "SET_PED_INTO_VEHICLE");
        (void)have(H_SET_MODEL_AS_NO_LONGER_NEEDED, "SET_MODEL_AS_NO_LONGER_NEEDED");
        // Diagnostic: is FiveM blocking client-side vehicle creation?
        FVEM_LOGF("[fvem] spawn: block(CREATE_VEHICLE)=%d block(REQUEST_MODEL)=%d",
                      native::should_block(H_CREATE_VEHICLE) ? 1 : 0,
                      native::should_block(H_REQUEST_MODEL) ? 1 : 0);
        FVEM_LOGF("[fvem] spawn: handler(CREATE_VEHICLE)=%p handler(REQUEST_MODEL)=%p",
                      native::get_handler(H_CREATE_VEHICLE),
                      native::get_handler(H_REQUEST_MODEL));
        native::invoke_scoped_async(H_REQUEST_MODEL, g_job.hash);
        FVEM_LOGF("[fvem] spawn: step REQUEST_MODEL queued");
        return;
    }

    // Wait for the model (bounded at ~10s = 600 frames @ 60fps).
    if (g_job.frames < 600) {
        if (native::get_handler(H_HAS_MODEL_LOADED)) {
            if (!native::invoke<bool>(H_HAS_MODEL_LOADED, g_job.hash)) {
                ++g_job.frames;
                return; // still streaming Ã¢â‚¬â€ come back next frame
            }
        }
    }
    FVEM_LOGF("[fvem] spawn: step model loaded (frames=%d)", g_job.frames);

    // Local ped + coords + heading. GET_ENTITY_COORDS results are reordered
    // (x, z, y) by the client Ã¢â‚¬â€ nv::fix_pos restores real map coords.
    uint64_t ped = native::invoke<uint64_t>(H_PLAYER_PED_ID);
    if (!ped) {
        FVEM_LOGF("[fvem] spawn: no local ped");
        g_job.active = false;
        return;
    }
    native::Vector3 c = nv::fix_pos(
        native::invoke<native::Vector3>(H_GET_ENTITY_COORDS, ped, 0));
    float heading = native::get_handler(H_GET_ENTITY_HEADING)
                        ? native::invoke<float>(H_GET_ENTITY_HEADING, ped)
                        : 0.0f;
    FVEM_LOGF("[fvem] spawn: ped=0x%llX coords=%d,%d,%d heading=%d", ped,
                  static_cast<int>(c.x), static_cast<int>(c.y),
                  static_cast<int>(c.z), static_cast<int>(heading));

    // Spawn and seat. isNetwork=0 keeps the vehicle local to the client.
    // CREATE_VEHICLE/SET_PED_INTO_VEHICLE are state-changing natives: their
    // handlers read the active script-thread context, so they run under a
    // borrowed scrEngine thread context on the game's MAIN thread (scoped
    // queue). CREATE_VEHICLE's result arrives asynchronously (the queue runs
    // it outside the render frame), so the vehicle is polled on later frames.
    // NOTE: never retry with isNetwork=1 Ã¢â‚¬â€ a client-side network vehicle
    // request is routed to the server and has repeatedly closed the game
    // (kick/desync); keep creation strictly local.
    uint64_t args[6] = { g_job.hash,
                         native::Arg::double_bits(c.x), native::Arg::double_bits(c.y),
                         native::Arg::double_bits(c.z), native::Arg::double_bits(heading), 0 };
    native::invoke_array_scoped_async_res(H_CREATE_VEHICLE, args, 6, &g_job.create_slot);
    g_job.create_pending = true;
    FVEM_LOGF("[fvem] spawn: CREATE_VEHICLE(isNet=0) queued");
}

} // namespace gfx

