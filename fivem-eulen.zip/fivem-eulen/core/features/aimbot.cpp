// language: C++, target: Windows 11, MSVC (x64)
// Aimbot â€” 100% native-based. Bone world positions come from
// GetPedBoneCoords, screen projection from GetScreenCoordFromWorldCoord, and
// the silent path writes the gameplay camera relative rotation
// (SetGameplayCamRelativePitch/Heading via the native invoker). No game-module
// memory offsets anywhere; unknown/blocked hashes no-op cleanly.
#include "pch.h"
#include "config.h"
#include "features.h"
#include "natives.h"
#include "../../third_party/imgui/imgui.h"

namespace gfx {

namespace {

// Gameplay camera relative rotation natives â€” resolved through the invoker.
inline constexpr uint64_t H_SET_GAMEPLAY_CAM_REL_PITCH   = 0x6D0858B8EDFD2B7Dull;
inline constexpr uint64_t H_SET_GAMEPLAY_CAM_REL_HEADING = 0xB4EC2312F4E5B1F1ull;

float clamp_deg(float v) {
    while (v > 180.0f) v -= 360.0f;
    while (v < -180.0f) v += 360.0f;
    return v;
}

} // namespace

void aimbot_tick() {
    if (!cfg().aim_enabled) return;

    uint64_t me = nv::player_ped_id();
    if (!me) return;

    ImVec2 center = ImGui::GetIO().DisplaySize;
    center.x *= 0.5f; center.y *= 0.5f;
    float fov_px = cfg().aim_fov * 9.0f; // degrees â†’ pixels heuristic

    // Best target: smallest screen distance within FOV.
    uint64_t best_ped = 0;
    ImVec2 best_screen{};
    float best_score = 1e30f;

    for (int p = 0; p < 256; ++p) {
        if (!nv::is_player_active(p)) continue;
        uint64_t ped = nv::player_ped(p);
        if (!ped || ped == me) continue;
        if (nv::entity_health(ped) <= 0.0f) continue;

        native::Vector3 bone = nv::ped_bone_coords(ped, nv::kBoneHead);
        float sx, sy;
        if (!nv::world_to_screen(bone, sx, sy)) continue;

        float dx = sx - center.x, dy = sy - center.y;
        float dist = sqrtf(dx * dx + dy * dy);
        if (dist > fov_px) continue;

        // Prefer closest-to-center; tie-break by world distance.
        native::Vector3 mep = nv::entity_coords(me);
        float wdx = bone.x - mep.x, wdy = bone.y - mep.y, wdz = bone.z - mep.z;
        float score = dist + sqrtf(wdx * wdx + wdy * wdy + wdz * wdz) * 0.01f;
        if (score < best_score) {
            best_score = score;
            best_ped = ped;
            best_screen.x = sx;
            best_screen.y = sy;
        }
    }

    if (!best_ped) return;

    if (cfg().aim_silent) {
        // Silent aim: snap the gameplay camera rotation to face the target.
        // Camera rotation native gives (x=pitch, y=roll, z=yaw) in degrees.
        native::Vector3 cam_rot = nv::gameplay_cam_rot(2);
        native::Vector3 cam_pos = nv::gameplay_cam_coord();
        native::Vector3 bone = nv::ped_bone_coords(best_ped, nv::kBoneHead);

        float dy = bone.y - cam_pos.y;
        float dx = bone.x - cam_pos.x;
        float dz = bone.z - cam_pos.z;
        float yaw_target = atan2f(dx, dy) * (180.0f / 3.14159265f);
        float dist = sqrtf(dx * dx + dy * dy);
        float pitch_target = atan2f(dz, dist) * (180.0f / 3.14159265f);

        float d_yaw = clamp_deg(yaw_target - cam_rot.z);
        float d_pitch = clamp_deg(pitch_target - cam_rot.x);

        native::invoke_scoped_async(H_SET_GAMEPLAY_CAM_REL_PITCH, d_pitch, 1.0f);
        native::invoke_scoped_async(H_SET_GAMEPLAY_CAM_REL_HEADING, d_yaw);
        return;
    }

    // Non-silent: smooth cursor toward the projected head.
    POINT c{};
    GetCursorPos(&c);
    ImVec2 size = ImGui::GetIO().DisplaySize;
    float k = cfg().aim_smooth > 1.0f ? 1.0f / cfg().aim_smooth : 1.0f;
    int nx = static_cast<int>(c.x + (best_screen.x - c.x) * k);
    int ny = static_cast<int>(c.y + (best_screen.y - c.y) * k);
    SetCursorPos(nx, ny);
}

} // namespace gfx
