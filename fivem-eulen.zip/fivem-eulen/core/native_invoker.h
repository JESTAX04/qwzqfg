// language: C++, target: Windows 11, MSVC (x64)
// Native invoker, Hoyagana/BigBaseV2 lineage â€” FiveM edition.
//
// FiveM keeps its own native registry inside rage-scripting-five.dll and
// exposes it through the exported rage::scrEngine::GetNativeHandler(hash),
// which returns a plain scrNativeHandler function pointer (the classic RAGE
// ABI: handler(&rage::scrNativeCallContext)). The Lua runtime imports the
// same export, so the hash space is the CFX namespace our table already uses â€”
// no game-module registration-table pattern scan required.
//
// Calling convention (verified against citizen-scripting-core's dispatcher
// 0x5E660): the handler reads args as uniform 64-bit slots (floats as bit
// patterns) from the context and writes its result through the context's
// return-value pointer.
#pragma once
#include <cstdint>
#include <cstddef>
#include <cstring>
#include <unordered_map>

namespace gfx::native {

// The context every RAGE native handler reads. Classic layout:
//   +0x00 return-value pointer (handler writes the result here)
//   +0x08 argument count (u32)
//   +0x0C data count (u32, mirrors argc for direct calls)
//   +0x10 pointer to the argument slot array (u64 slots, floats as bits)
//   +0x18 inline space â€” kept large and zeroed for parity; handlers that
//         index m_ArgSpace directly only do so when m_Args points at it.
struct scrNativeCallContext {
    void*    m_ReturnValue;   // +0x00
    uint32_t m_ArgCount;      // +0x08
    uint32_t m_DataCount;     // +0x0C
    uint64_t* m_Args;         // +0x10
    uint64_t m_ArgSpace[32];  // +0x18
    uint64_t m_ReturnSpace[4];// +0x118
};

// Handler calling convention: handler(&ctx). scratch lives in ctx.m_ReturnValue.
using Handler = void (*)(scrNativeCallContext*);

// A Vector3 native result is written as three consecutive floats at the
// return pointer.
struct Vector3 {
    float x, y, z;
};

// --- data sources ---------------------------------------------------------

// Resolve FiveM's exported rage::scrEngine::GetNativeHandler from
// rage-scripting-five.dll (lazy â€” safe to call before init; returns false
// only if the module never loads). Returns true once a resolution path is up.
bool init();

// Preferred path: feed the live {u64 hash, u64 func} table dumped by
// native_invoker_dumper_tool. Entries are hash/func pairs; the table is
// current-build hashes already, so no crossmap translation applies.
void set_direct_table(const void* entries, size_t entry_count);

// Convenience: load a "hash,address" CSV (native_invoker_dumper_tool --csv
// output) into the direct table. Returns the entry count, 0 on failure.
// DEV ONLY (FVEM_DEV_TOOLS): <fstream> drags fread/ftell and, through the CRT's
// lowio layer, ReadFile + GetFileSizeEx into the image. Nothing in the shipped
// DLL calls this - the in-process dumper hands set_direct_table() pairs already
// in memory. Leaving it linked would keep a file-read CAPABILITY in the shipped
// binary for a dev convenience. See MEMORY_ONLY_PLAN.md M2.3.
#ifdef FVEM_DEV_TOOLS
size_t load_direct_csv(const char* path);
#endif

// Optional canonical-hash -> current-build-hash translation, applied only in
// registration-table mode. Load from a crossmap file matching the client build.
void set_crossmap(const std::unordered_map<uint64_t, uint64_t>& map);

// --- lookup ---------------------------------------------------------------

// Resolve a hash to its handler. 0 if unknown â€” features must no-op on 0.
// Result is validated to be an executable pointer (rejects the "hash on
// miss" sentinel FiveM's export can return).
void* get_handler(uint64_t hash);

// Query FiveM's native-blocking policy (rage::scrEngine::ShouldBlockNative).
// Returns true when the server/registry blocks a hash for client scripts â€”
// a clean way to explain a native returning 0 (e.g. CREATE_VEHICLE on
// servers that restrict vehicle spawning). False if the export is missing.
bool should_block(uint64_t hash);

// --- invocation -----------------------------------------------------------

// Array form: args in a u64 array, result written to scratch (must be
// >= 16 bytes). Supports up to 16 arguments.
void invoke_array(uint64_t hash, const uint64_t* args, int argc, void* scratch);

// Scoped form: same as invoke_array, but wraps the handler call with
// rage::scrEngine::SetActiveThread(borrowed_live_thread) so state-changing
// natives (CreateVehicle etc.) see a valid script-thread context. Reads and
// streaming requests don't need this and should keep using invoke_array.
// Falls back to a plain call (or a no-op) if no thread can be borrowed.
//
// MAIN-THREAD EXECUTION: state-changing handlers mutate game state that the
// game's main thread also touches every frame. Executing them from the render
// thread races with the game's own updates â€” the observed cause of FiveM's
// delayed "early-exit trap" after every state change. Scoped calls are
// therefore queued and executed on the game's main thread: the render thread
// enqueues + wakes the game window's message pump, and our WndProc hook
// (which Windows dispatches on the window's creating thread â€” the game's main
// thread) drains and runs them. Blocking calls spin on a done flag; per-frame
// loops (godmode, silent aim) should use invoke_array_scoped_async.
//
// CALLED FROM PRESENT: our Present hook executes on the game's main thread in
// this build, so the "already on main thread" check would run handlers INLINE
// mid-render. That races with the citizen script threads and corrupts state.
// While in_present() is true the call is ALWAYS queued for the WndProc drain
// (which runs between frames) and never executed inline.
void invoke_array_scoped(uint64_t hash, const uint64_t* args, int argc,
                         void* scratch);

// Fire-and-forget scoped call (per-frame loops): enqueues into the same
// main-thread queue without waiting for the result. Safe to call every frame;
// drops silently when the queue is full (callers re-apply state per frame).
void invoke_array_scoped_async(uint64_t hash, const uint64_t* args, int argc);

// Fire-and-forget scoped call that records the 16-byte result into a
// caller-owned slot when the main thread executes it. Poll *slot.done once per
// frame; never spin on it from the render thread.
struct ScopedResultSlot {
    volatile LONG done = 0; // 0 pending, 1 executed (main thread)
    uint8_t       result[16]{};
};
void invoke_array_scoped_async_res(uint64_t hash, const uint64_t* args, int argc,
                                   ScopedResultSlot* slot);

// True while executing inside our hooked Present frame. Scoped calls made
// from this context must not run inline (see above).
bool in_present();
void set_in_present(bool value);

// --- main-thread execution queue plumbing ---------------------------------
// Called by the hook layer once the game window is known: enables queue mode
// (state-changing natives execute on the game's main thread via the window's
// message pump). Passing null keeps the legacy direct-call path.
void set_scoped_queue_window(void* hwnd);

// Drains and executes queued scoped calls. Must run on the game's main thread
// (the window's creating thread). Safe to call from the WndProc hook; also
// called from the present hook only when it is on the main thread.
void drain_scoped_queue();

// Uniform-64-bit argument wrapper. Floats are passed as their bit patterns so
// they land in the integer slots the handlers actually read â€” variadic
// promotion would corrupt them.
struct Arg {
    uint64_t bits;

    Arg() : bits(0) {}
    Arg(int64_t v) : bits(static_cast<uint64_t>(v)) {}
    Arg(uint64_t v) : bits(v) {}
    Arg(int32_t v) : bits(static_cast<uint64_t>(static_cast<int64_t>(v))) {}
    Arg(uint32_t v) : bits(v) {}
    Arg(bool v) : bits(v ? 1ull : 0ull) {}
    Arg(const void* p) : bits(reinterpret_cast<uint64_t>(p)) {}
    Arg(float v) : bits(static_cast<uint64_t>(float_bits(v))) {}
    Arg(double v) : bits(static_cast<uint64_t>(double_bits(v))) {}

    static uint32_t float_bits(float v) {
        uint32_t out; // memcpy avoids aliasing/pun UB in C++17
        std::memcpy(&out, &v, sizeof(out));
        return out;
    }
    static uint64_t double_bits(double v) {
        uint64_t out;
        std::memcpy(&out, &v, sizeof(out));
        return out;
    }
};

namespace detail {
template <typename T> T load_result(const uint8_t* s) {
    T out;
    std::memcpy(&out, s, sizeof(T)); // scalar: first 8 bytes
    return out;
}
template <> inline void load_result<void>(const uint8_t*) {}
template <> inline Vector3 load_result<Vector3>(const uint8_t* s) {
    Vector3 out;
    std::memcpy(&out, s, sizeof(out)); // three floats at scratch[0..11]
    return out;
}
} // namespace detail

// Typed variadic invoke. Ret may be a scalar (int/float/pointer/bool) or
// native::Vector3. Unknown hash returns Ret{} (a zeroed default).
template <typename Ret, typename... A>
Ret invoke(uint64_t hash, A... args) {
    alignas(16) uint8_t scratch[16]{};
    alignas(16) uint64_t slots[16]{};
    uint32_t argc = 0;
    ((slots[argc++] = Arg(args).bits), ...);

    Handler h = reinterpret_cast<Handler>(get_handler(hash));
    if (!h) return Ret{};

    scrNativeCallContext ctx{};
    ctx.m_ReturnValue = scratch;
    ctx.m_ArgCount = argc;
    ctx.m_DataCount = argc;
    ctx.m_Args = slots;
    h(&ctx);
    return detail::load_result<Ret>(scratch);
}

// Typed scoped invoke â€” same as invoke(), but routes through
// invoke_array_scoped (sets a borrowed active script-thread context around the
// handler call for state-changing natives).
template <typename Ret, typename... A>
Ret invoke_scoped(uint64_t hash, A... args) {
    alignas(16) uint8_t scratch[16]{};
    alignas(16) uint64_t slots[16]{};
    uint32_t argc = 0;
    ((slots[argc++] = Arg(args).bits), ...);
    invoke_array_scoped(hash, slots, argc, scratch);
    return detail::load_result<Ret>(scratch);
}

// Fire-and-forget scoped invoke for per-frame loops. No result is produced;
// the call is queued for the game's main thread and returns immediately.
template <typename... A>
void invoke_scoped_async(uint64_t hash, A... args) {
    alignas(16) uint64_t slots[16]{};
    uint32_t argc = 0;
    ((slots[argc++] = Arg(args).bits), ...);
    invoke_array_scoped_async(hash, slots, argc);
}

} // namespace gfx::native
