// language: C++, target: Windows 11, MSVC (x64)
// Native bridge v2 — the typed, whole-namespace face of the Tier S executor.
//
// Resolution model: _G has an __index metamethod. A script touches an
// unknown global (GetEntityCoords / SET_ENTITY_COORDS — normalized to the
// same key); the metamethod binary-searches the generated native table
// (hashed keys, zero native-name strings in the image), and on a hit
// caches a light C closure bound to that NativeMeta back into _G — so the
// first use pays a search, every later use is a plain global hit.
//
// Marshalling is driven by the table's per-slot type metadata: floats are
// packed as their 32-bit pattern into the uniform-64 RAGE ABI slots (the
// bug class NativeInvoke could never express), strings handed to natives
// are pinned in a per-tick arena (a handler keeping our pointer past the
// call can never read freed memory), vector returns materialize as the
// prelude's vector3 tables, and state-changing natives route through the
// proven scoped main-thread queue instead of touching RAGE handlers from
// the overlay thread.
#include "pch.h"
#include "config.h"
#include "features.h"
#include "native_invoker.h"
#include "lua_scheduler.h"
#include "log.h"
#include "generated/native_meta.h"

#include <cstdlib>
#include <deque>

extern "C" {
#include "lua.h"
#include "lauxlib.h"
}

namespace gfx {
namespace {

namespace nm = gfx::natmeta;

// ---------------------------------------------------------------------------
// per-tick arenas (rotated by bridge_clear_string_arena each tick):
// strings copy into the ACTIVE deque; on rotation the previous tick's deque
// becomes BACK and is freed — so anything the main-thread queue captured at
// least two ticks ago is dead, and anything still in flight is alive. Double
// buffering removes the one-frame dangling window a single arena would leave
// for queued (scoped) natives that keep the char* past the enqueue.
// ---------------------------------------------------------------------------
std::deque<std::string> g_arena[2];
int       g_arena_cur = 0;
std::deque<void*>       g_arena_ptr[2];

const char* arena_pin(const char* s, size_t n) {
    g_arena[g_arena_cur].emplace_back(s, n);
    return g_arena[g_arena_cur].back().c_str();
}
void* arena_alloc(size_t bytes) {
    void* p = malloc(bytes);
    if (p) g_arena_ptr[g_arena_cur].push_back(p);
    return p;
}

uint8_t nib(const nm::NativeMeta& m, int i) {
    return (uint8_t)((m.ptypes[i >> 1] >> ((i & 1) * 4)) & 0xF);
}

// ---------------------------------------------------------------------------
// vector3 table (the prelude defines the metatable; we build raw tables and
// attach by name so both sides share one shape).
// ---------------------------------------------------------------------------
void push_vector3(lua_State* L, float x, float y, float z) {
    lua_newtable(L);
    lua_pushnumber(L, x); lua_setfield(L, -2, "x");
    lua_pushnumber(L, y); lua_setfield(L, -2, "y");
    lua_pushnumber(L, z); lua_setfield(L, -2, "z");
    lua_pushinteger(L, 0); lua_setfield(L, -2, "w");
    // metatable: cached at registry index 2 slot? keep simple: getglobal vmt
    lua_getglobal(L, "__fvem_vmt");
    if (lua_istable(L, -1)) lua_setmetatable(L, -2);
    else lua_pop(L, 1);
}

// Scratch string read: validate the pointer, copy into a Lua string.
// Returns true when a value was pushed; false pushes nil.
bool push_ret_str(lua_State* L, uint64_t ptr) {
    if (!ptr || ptr > 0x0000'FFFF'FFFF'FFFFull) { lua_pushnil(L); return false; }
    __try {
        const char* s = reinterpret_cast<const char*>(uintptr_t(ptr));
        int len = 0;
        while (len < 1024 && s[len]) ++len;
        if (len == 0 || len >= 1024) { lua_pushnil(L); return false; }
        lua_pushlstring(L, s, (size_t)len);
        return true;
    } __except (EXCEPTION_EXECUTE_HANDLER) {
        lua_pushnil(L);
        return false;
    }
}

// ---------------------------------------------------------------------------
// the generic native closure: upvalue 1 = the NativeMeta pointer.
// ---------------------------------------------------------------------------
int native_generic(lua_State* L) {
    const nm::NativeMeta* m =
        reinterpret_cast<const nm::NativeMeta*>(lua_touserdata(L, lua_upvalueindex(1)));
    if (!m) { lua_pushnil(L); return 1; }

    try {
        const bool allow_net = cfg().lua_allow_net;
        if ((m->flags & nm::FL_net_risky) && !allow_net) {
            static std::unordered_map<uint64_t, bool> warned;
            if (!warned.count(m->hash)) {
                warned[m->hash] = true;
                hub_console_push("fvem: a NETWORK native was called and is gated off "
                                 "(enable lua_allow_net in the Lua tab to use it)");
            }
            lua_pushnil(L);
            return 1;
        }

        uint64_t slots[16]{};
        const int provided = lua_gettop(L);
        const int argc = m->argc > 16 ? 16 : m->argc;
        for (int i = 0; i < argc; ++i) {
            if (i >= provided) break;                 // zero-pad: FiveM convention
            const int pt = nib(*m, i);
            switch (pt) {
                case nm::PT_FLOAT:
                    if (lua_isnumber(L, i + 1)) {
                        float f = (float)lua_tonumber(L, i + 1);
                        uint32_t bits; memcpy(&bits, &f, 4);
                        slots[i] = bits;
                    }
                    break;
                case nm::PT_DOUBLE: {
                    double d = lua_isnumber(L, i + 1) ? lua_tonumber(L, i + 1) : 0.0;
                    uint64_t bits; memcpy(&bits, &d, 8);
                    slots[i] = bits;
                    break;
                }
                case nm::PT_BOOL:
                    slots[i] = lua_toboolean(L, i + 1) ? 1 : 0;
                    break;
                case nm::PT_STR: {
                    if (lua_isnoneornil(L, i + 1)) break;
                    size_t n = 0;
                    const char* s = lua_tolstring(L, i + 1, &n);
                    if (s) {
                        const char* pinned = arena_pin(s, n);
                        memcpy(&slots[i], &pinned, sizeof(void*));
                    }
                    break;
                }
                case nm::PT_VEC3: {
                    if (lua_istable(L, i + 1)) {
                        float* v = (float*)arena_alloc(16);   // 12 used, pad to 16
                        if (v) {
                            v[0] = v[1] = v[2] = 0; v[3] = 0;
                            // x/y/z fields first, numeric [1..3] as fallback
                            const char* keys[3] = { "x", "y", "z" };
                            for (int k = 0; k < 3; ++k) {
                                lua_getfield(L, i + 1, keys[k]);
                                if (!lua_isnumber(L, -1)) {
                                    lua_pop(L, 1);
                                    lua_rawgeti(L, i + 1, k + 1);
                                }
                                if (lua_isnumber(L, -1)) v[k] = (float)lua_tonumber(L, -1);
                                lua_pop(L, 1);
                            }
                            memcpy(&slots[i], &v, sizeof(void*));
                        }
                    }
                    break;
                }
                case nm::PT_PTR:
                case nm::PT_INT:
                default:
                    if (lua_isboolean(L, i + 1)) slots[i] = lua_toboolean(L, i + 1);
                    else if (lua_isinteger(L, i + 1)) slots[i] = (uint64_t)(int64_t)lua_tointeger(L, i + 1);
                    else if (lua_isnumber(L, i + 1)) {
                        double d = lua_tonumber(L, i + 1);
                        int64_t i64 = (int64_t)d;
                        memcpy(&slots[i], &i64, 8);
                    } else if (lua_isstring(L, i + 1)) {
                        size_t n = 0;
                        const char* s = lua_tolstring(L, i + 1, &n);
                        const char* pinned = arena_pin(s, n);
                        memcpy(&slots[i], &pinned, sizeof(void*));
                    }
                    break;
            }
        }
        // gated network flags: force zero on the flagged slots
        if (!allow_net && m->netmask) {
            for (int i = 0; i < argc; ++i)
                if (m->netmask & (1u << i)) slots[i] = 0;
        }

        alignas(16) uint8_t scratch[16]{};
        if ((m->flags & nm::FL_state_changing) && m->ret == nm::RT_VOID) {
            // fire-and-forget: per-frame SET_* loops never block the overlay
            native::invoke_array_scoped_async(m->hash, slots, argc);
            return 0;
        }
        if (m->flags & nm::FL_state_changing)
            native::invoke_array_scoped(m->hash, slots, argc, scratch);
        else
            native::invoke_array(m->hash, slots, argc, scratch);

        switch (m->ret) {
            case nm::RT_VOID:
                return 0;
            case nm::RT_BOOL: {
                uint32_t v = 0; memcpy(&v, scratch, 4);
                lua_pushboolean(L, v != 0);
                return 1;
            }
            case nm::RT_INT: {
                uint64_t v = 0; memcpy(&v, scratch, 8);
                lua_pushinteger(L, (lua_Integer)v);
                return 1;
            }
            case nm::RT_FLOAT: {
                float f = 0; memcpy(&f, scratch, 4);
                lua_pushnumber(L, (double)f);
                return 1;
            }
            case nm::RT_VEC3: {
                float x = 0, y = 0, z = 0;
                memcpy(&x, scratch + 0, 4);
                memcpy(&y, scratch + 4, 4);
                memcpy(&z, scratch + 8, 4);
                push_vector3(L, x, y, z);
                return 1;
            }
            case nm::RT_STR: {
                uint64_t ptr = 0; memcpy(&ptr, scratch, 8);
                push_ret_str(L, ptr);
                return 1;
            }
            case nm::RT_PTR:
            default: {
                uint64_t v = 0; memcpy(&v, scratch, 8);
                lua_pushinteger(L, (lua_Integer)v);
                return 1;
            }
        }
    } catch (...) {
        lua_pushnil(L);
        return 1;
    }
}

// Rotate arenas: the buffer that served last tick is retired and freed now;
// the one that served two ticks ago can no longer be referenced by the
// main-thread queue (a queued job lives far less than one overlay tick).
void clear_string_arena() {
    g_arena_cur ^= 1;
    g_arena[g_arena_cur].clear();
    for (void* p : g_arena_ptr[g_arena_cur]) free(p);
    g_arena_ptr[g_arena_cur].clear();
}

// ---------------------------------------------------------------------------
// _G __index: name -> table hit? cache a closure, return it.
// ---------------------------------------------------------------------------
int g_index(lua_State* L) {
    // (T, K) — T is _G, K the missing global
    size_t n = 0;
    const char* k = lua_tolstring(L, 2, &n);
    if (!k || n == 0 || n > 64) { lua_pushnil(L); return 1; }
    char buf[80];
    memcpy(buf, k, n); buf[n] = 0;
    const nm::NativeMeta* m = nm::find_by_name(buf);
    if (!m) { lua_pushnil(L); return 1; }
    try {
        lua_pushlightuserdata(L, const_cast<nm::NativeMeta*>(m));
        lua_pushcclosure(L, native_generic, 1);
        // cache: rawset(T, K, closure)
        lua_pushvalue(L, 1);
        lua_pushvalue(L, 2);
        lua_pushvalue(L, -3);
        lua_rawset(L, -3);
        lua_pop(L, 1);             // drop the T copy; closure is the result
        return 1;
    } catch (...) {
        lua_pushnil(L);
        return 1;
    }
}

// ---------------------------------------------------------------------------
// helper globals that are NOT natives
// ---------------------------------------------------------------------------
// GET_HASH_KEY (CFX) — from citizenfx/natives MISC/GetHashKey.md:
// 0xD24D37CC275948CC. The docs confirm plain joaat32 ("jenkins one at a
// time"), so the local fold below is byte-exact when the native can't be
// resolved; the native stays authoritative for whatever FiveM tweaks.
constexpr uint64_t kHASH_GET_HASH_KEY = 0xD24D37CC275948CCull;

int l_GetHashKey(lua_State* L) {
    size_t n = 0;
    const char* s = luaL_checklstring(L, 1, &n);
    const char* pinned = arena_pin(s, n);
    uint64_t h = 0;
    try {
        h = native::invoke<uint64_t>(kHASH_GET_HASH_KEY, (uint64_t)(uintptr_t)pinned);
    } catch (...) { h = 0; }
    if (!h) {
        uint32_t j = 0;
        for (const char* p = s; *p; ++p) {
            j += (uint8_t)*p; j += j << 10; j ^= j >> 6;
        }
        j += j << 3; j ^= j >> 11; j += j << 15;
        h = j;
    }
    lua_pushinteger(L, (lua_Integer)(int64_t)(uint32_t)h);
    return 1;
}

// Raw escape hatch for unnamed/_0x natives: NativeInvoke(hash, int|num|bool|str...)
// up to 16 uniform-64 slots. Integer-shaped args only (floats bit-raw, like
// the legacy menu path); use table-driven calls for typed marshalling.
int l_NativeInvoke(lua_State* L) {
    const uint64_t hash = (uint64_t)luaL_checkinteger(L, 1);
    uint64_t slots[16]{};
    const int n = lua_gettop(L) - 1;
    for (int i = 0; i < n && i < 16; ++i) {
        if (lua_isinteger(L, i + 2)) slots[i] = (uint64_t)(int64_t)lua_tointeger(L, i + 2);
        else if (lua_isboolean(L, i + 2)) slots[i] = lua_toboolean(L, i + 2) ? 1 : 0;
        else if (lua_isnumber(L, i + 2)) {
            double d = lua_tonumber(L, i + 2);
            int64_t i64 = (int64_t)d; memcpy(&slots[i], &i64, 8);
        } else if (lua_isstring(L, i + 2)) {
            size_t sn = 0; const char* sp = lua_tolstring(L, i + 2, &sn);
            const char* pinned = arena_pin(sp, sn);
            memcpy(&slots[i], &pinned, sizeof(void*));
        }
    }
    try {
        alignas(16) uint8_t scratch[16]{};
        native::invoke_array(hash, slots, n > 16 ? 16 : n, scratch);
        uint64_t v = 0; memcpy(&v, scratch, 8);
        lua_pushinteger(L, (lua_Integer)v);
    } catch (...) { lua_pushnil(L); }
    return 1;
}

} // namespace

void bridge_clear_string_arena() { clear_string_arena(); }

// called by the hub right after open_libraries
void register_native_bridge(lua_State* L) {
    try {
        // helpers
        lua_register(L, "GetHashKey", l_GetHashKey);
        lua_register(L, "NativeInvoke", l_NativeInvoke);
        lua_register(L, "NativeInvoke_u64", l_NativeInvoke);

        // vector3 metatable handle for the bridge's push_vector3: the
        // prelude defines __fvem_vmt; the bridge only reads it at call time.

        // _G.__index fallback into the native table
        lua_rawgeti(L, LUA_REGISTRYINDEX, LUA_RIDX_GLOBALS);
        lua_newtable(L);                      // mt
        lua_pushcfunction(L, g_index);
        lua_setfield(L, -2, "__index");
        lua_setmetatable(L, -2);              // setmt(_G, mt); _G popped
        lua_pop(L, 1);
    } catch (...) {
        FVEM_LOGF("[fvem] bridge init failed");
    }
}

// ---------------------------------------------------------------------------
// boot seam: acquire_lua_state now means "bring the hub up". The old
// pattern-scan for FiveM's internal lua_State is retired on purpose: CFX
// runs a MODIFIED Lua; building sol/running our own scheduler over a foreign
// struct layout is a fault with no recovery (their SEH beats ours). Own
// state + this bridge is the contract — see LUA_EXECUTOR_PLAN.md.
// ---------------------------------------------------------------------------
void acquire_lua_state() {
    hub_init();
}

// legacy menu seam ("Run" button): starts as a scheduler script (id ignored).
void run_user_lua(const char* script) {
    hub_run_script("snippet", script ? script : "");
}

} // namespace gfx
