// language: C++, target: Windows 11, MSVC (x64)
// Transparent overlay window implementation. See overlay_window.h for the
// design rationale (moving ImGui out of the game's Present = no main-thread
// hitch = no FiveM watchdog kill).
//
// The overlay is a WS_POPUP window with WS_EX_LAYERED | WS_EX_TRANSPARENT |
// WS_EX_TOPMOST. LWA_COLORKEY makes pure black (0,0,0) fully transparent, so
// the overlay's own D3D clear color must be pure black (overlay_render.cpp
// clears to {0,0,0,0}) Ã¢â‚¬â€ anything drawn on top of it is visible, everything
// else clicks through to the game.
#include "pch.h"
#include "overlay_window.h"
#include "overlay_render.h"
#include "config.h"
#include "log.h"
#include "../common/syscalls.h"
#include <winternl.h>
#include "../third_party/imgui/backends/imgui_impl_win32.h"

// imgui_impl_win32.h hides the wndproc handler behind `#if 0`; per the
// header's own instruction, forward-declare it here.
IMGUI_IMPL_API LRESULT ImGui_ImplWin32_WndProcHandler(HWND hWnd, UINT msg, WPARAM wParam, LPARAM lParam);

namespace gfx {

namespace {

constexpr wchar_t kOverlayClassFallback[] = L"DefaultIMClass";
wchar_t g_class_name[80]{};   // session-unique registered class, for unregister on teardown
HWND  g_game    = nullptr;
HWND  g_overlay = nullptr;
bool  g_clickable = false;

// Build a window-class name that carries no cheat keyword. A literal like
// "fvem_overlay_cls" is caught by any overlay sweep that does
// EnumWindows + GetClassName and greps for fvem/overlay/menu/esp/cheat. Deriving
// the name from the game's OWN class (plus a per-process numeric suffix so we do
// not collide with the game's registered class) leaves a token that reads as
// part of the game. Hand-composed: no CRT (this may run before the thread that
// owns our static-CRT state has initialised it).
static void derive_class_name(HWND game, wchar_t* out, int cap) {
    wchar_t base[64]{};
    int n = 0;
    if (game && GetClassNameW(game, base, 63) > 0) {
        while (base[n] && n < 40) { out[n] = base[n]; ++n; }
    } else {
        const wchar_t* f = kOverlayClassFallback;
        while (*f && n < cap - 8) { out[n] = *f; ++f; ++n; }
    }
    // Append '_x<low-bits-of-hwnd>' in hex so the name is unique to this session
    // but still contains no matching keyword.
    const wchar_t* mid = L"_x";
    for (int i = 0; mid[i] && n < cap - 8; ++i) out[n++] = mid[i];
    uintptr_t bits = reinterpret_cast<uintptr_t>(game) & 0xFFFFFFull;
    if (!bits) bits = reinterpret_cast<uintptr_t>(out) & 0xFFFFFFull;
    const wchar_t* hx = L"0123456789ABCDEF";
    for (int shift = 20; shift >= 0 && n < cap - 2; shift -= 4)
        out[n++] = hx[(bits >> shift) & 0xF];
    out[n] = 0;
}

// Overlay window procedure. ImGui's Win32 backend consumes the messages it
// needs (mouse wheel, cursor shape, IME); everything else falls through to
// DefWindowProc. WS_EX_TRANSPARENT (when the menu is closed) makes Windows
// pass ALL mouse input through to the game Ã¢â‚¬â€ the overlay never intercepts
// clicks while idle.
LRESULT CALLBACK overlay_wndproc(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    // Insert is toggled by the MAIN-THREAD PUMP ONLY (hooks.cpp edge poll of
    // GetAsyncKeyState - global state, it sees every press regardless of who
    // holds focus). This window must NOT also react to the message: an earlier
    // revision did, and the result was the "menu closes itself after opening"
    // bug - the pump opened on the edge, focus moved to us, and the SAME
    // press delivered WM_KEYDOWN here a second time (held key / auto-repeat /
    // dispatch racing the focus hand-off, all beyond the 150 ms debounce).
    // Two triggers, one press = open+close. Here we merely CLAIM the key so
    // the ImGui backend does not push INSERT into io.KeysDown (and do NOT
    // fall through to the handler - it claims every WM_KEYDOWN for itself).
    if (msg == WM_KEYDOWN && wp == VK_INSERT)
        return 0;

    // Let ImGui_ImplWin32 handle its messages (mouse, keyboard state, IME).
    if (ImGui_ImplWin32_WndProcHandler(hwnd, msg, wp, lp))
        return 1;

    switch (msg) {
    case WM_ERASEBKGND:
        return 1; // we redraw the whole surface every frame
    case WM_DESTROY:
        PostQuitMessage(0);
        return 0;
    default:
        break;
    }
    return DefWindowProcW(hwnd, msg, wp, lp);
}

// --- Stream-proofing ---------------------------------------------------------
// The overlay must be invisible to capture/telemetry that a server or a
// viewer can drive: OBS/vMix display capture, Discord/Zoom screen share,
// ShadowPlay/ReLive, remote-desktop mirrors (RDP/TeamViewer/Parsec), and any
// AC that duplicates the desktop. Two independent layers:
//
//   1. Window Display Affinity. SetWindowDisplayAffinity(WDA_EXCLUDEFROMCAPTURE
//      = 0x11) tells the DWM to omit THIS window from every capture path while
//      the physical monitor (and the user's own eyes) still see it. The older
//      WDA_MONITOR (=1) paints us BLACK in captures - a fullscreen black hole
//      in a stream is a louder tell than the menu itself - so when 0x11 is
//      refused (pre-2004 Windows) we skip affinity entirely and rely on
//      layer 2 rather than deploy our own silhouette.
//
//   2. Capture-host process watcher. Enumerate processes via the indirect
//      NtQuerySystemInformation syscall (no CreateToolhelp32Snapshot to be
//      hooked/blinded). Dedicated capture/stream/remote-desktop processes
//      FORCE the menu shut until the host exits. Deliberately NO plain chat
//      apps (Discord/Skype/Zoom run idle for everyone - locking on those is
//      self-DoS); their *share* paths are DWM-duplication-based and layer 1
//      already hides the window from them.
//
// Affinity re-asserts on the follow-tick: DWM restarts and GPU resets silently
// drop it, mid-stream is the worst possible moment to lose it unnoticed.
#ifndef WDA_MONITOR
#define WDA_MONITOR 0x00000001
#endif
#ifndef WDA_EXCLUDEFROMCAPTURE
#define WDA_EXCLUDEFROMCAPTURE 0x00000011
#endif

typedef BOOL (WINAPI* SetWindowDisplayAffinity_t)(HWND, DWORD);

bool set_capture_invisible(HWND hwnd) {
    static SetWindowDisplayAffinity_t pSetAff =
        reinterpret_cast<SetWindowDisplayAffinity_t>(
            reinterpret_cast<FARPROC>(
                GetProcAddress(GetModuleHandleW(L"user32.dll"),
                               "SetWindowDisplayAffinity")));
    if (!pSetAff || !hwnd) return false;
    return pSetAff(hwnd, WDA_EXCLUDEFROMCAPTURE) == TRUE;
}

// Substrings matched case-insensitively against process image names:
// dedicated capture / stream producers / recorders / remote-desktop hosts.
const wchar_t* const kCaptureHosts[] = {
    L"obs32", L"obs64", L"streamlab", L"slobs", L"prismlive", L"vmix",
    L"xsplit", L"wirecast", L"bandicam", L"screenrec", L"sharex",
    L"camtasia", L"snagit", L"mstsc", L"teamviewer", L"tv_w32", L"tv_x64",
    L"anydesk", L"rustdesk", L"parsec", L"ultraviewer", L"action_",
};

bool ci_contains(const wchar_t* hay, const wchar_t* needle) {
    for (const wchar_t* h = hay; *h; ++h) {
        const wchar_t* a = h;
        const wchar_t* b = needle;
        while (*a && *b) {
            wchar_t ca = *a, cb = *b;
            if (ca >= L'A' && ca <= L'Z') ca = wchar_t(ca - L'A' + L'a');
            if (cb >= L'A' && cb <= L'Z') cb = wchar_t(cb - L'A' + L'a');
            if (ca != cb) break;
            ++a; ++b;
        }
        if (!*b) return true;
    }
    return false;
}

// Walk SystemProcessInformation (class 5) looking for a capture host.
// out_name (optional) receives the matched image name for the log line.
bool capture_host_running(wchar_t* out_name, ULONG cch) {
    static void* buf = nullptr;
    static ULONG cap = 0;
    constexpr NTSTATUS kLenMismatch = static_cast<NTSTATUS>(0xC0000004L);
    for (int attempt = 0; attempt < 3; ++attempt) {
        uint32_t retlen = 0;
        NTSTATUS st = gfx::sys::query_system_info(
            5 /*SystemProcessInformation*/, buf, cap, &retlen);
        if (st == kLenMismatch || retlen > cap) {
            const ULONG need = retlen ? (retlen + 65536u) : (256u * 1024u);
            void* nb = VirtualAlloc(nullptr, need, MEM_COMMIT | MEM_RESERVE,
                                    PAGE_READWRITE);
            if (!nb) return false;
            if (buf) VirtualFree(buf, 0, MEM_RELEASE);
            buf = nb; cap = need;
            continue;
        }
        if (st != 0 || !buf) return false;   // gate dead: safe no-op
        break;
    }
    if (!buf) return false;

    auto* e = static_cast<SYSTEM_PROCESS_INFORMATION*>(buf);
    for (;;) {
        const wchar_t* name = e->ImageName.Buffer;   // NOT guaranteed NUL-terminated
        if (name && e->ImageName.Length >= sizeof(wchar_t)) {
            wchar_t tmp[64];
            ULONG nch = e->ImageName.Length / sizeof(wchar_t);
            if (nch >= 64) nch = 63;
            for (ULONG i = 0; i < nch; ++i) tmp[i] = name[i];
            tmp[nch] = 0;
            for (const wchar_t* kw : kCaptureHosts)
                if (ci_contains(tmp, kw)) {
                    if (out_name && cch) {
                        ULONG k = 0;
                        for (; k + 1 < cch && tmp[k]; ++k) out_name[k] = tmp[k];
                        out_name[k] = 0;
                    }
                    return true;
                }
        }
        if (e->NextEntryOffset == 0) break;
        e = reinterpret_cast<SYSTEM_PROCESS_INFORMATION*>(
            reinterpret_cast<unsigned char*>(e) + e->NextEntryOffset);
    }
    return false;
}

} // namespace

HWND overlay_create(HWND game_hwnd) {
    FVEM_LOGF("[fvem] overlay: overlay_create called with game_hwnd=%p", game_hwnd);
    if (g_overlay) {
        FVEM_LOGF("[fvem] overlay: overlay already exists %p", g_overlay);
        return g_overlay;
    }
    g_game = game_hwnd;

    // Session-unique, keyword-free class name (see derive_class_name).
    wchar_t class_name[80]{};
    derive_class_name(g_game, class_name, 80);
    wcscpy_s(g_class_name, class_name);

    WNDCLASSEXW wc{};
    wc.cbSize        = sizeof(wc);
    wc.lpfnWndProc   = overlay_wndproc;
    wc.hInstance     = GetModuleHandleW(nullptr);
    wc.hbrBackground = static_cast<HBRUSH>(GetStockObject(BLACK_BRUSH)); // color-key color
    wc.lpszClassName = class_name;
    if (!RegisterClassExW(&wc)) {
        FVEM_LOGF("[fvem] overlay: RegisterClassExW failed (err=%lu)", GetLastError());
        // ignore, maybe already registered
    }

    RECT rc{};
    if (g_game) {
        GetWindowRect(g_game, &rc);
        FVEM_LOGF("[fvem] overlay: game rect (%d,%d)-(%d,%d)", rc.left, rc.top, rc.right, rc.bottom);
    } else {
        FVEM_LOGF("[fvem] overlay: game window is null, using default 1280x720");
        rc.right = 1280; rc.bottom = 720;
    }

    // Layered + transparent + topmost: clicks pass through by default, black
    // is made invisible via LWA_COLORKEY, and the window always floats above
    // the game. WS_POPUP + owner = the game window folds it under the game's
    // root-owner chain (GetAncestor(GA_ROOTOWNER) resolves to the game, not a
    // foreign root), and WS_EX_TOOLWINDOW keeps it out of Alt-Tab and the
    // taskbar. Owning it to g_game is what defeats the "unknown topmost
    // fullscreen layered window owned by this pid" heuristic.
    g_overlay = CreateWindowExW(
        WS_EX_LAYERED | WS_EX_TRANSPARENT | WS_EX_TOPMOST | WS_EX_TOOLWINDOW,
        class_name, L"", WS_POPUP,
        rc.left, rc.top, rc.right - rc.left, rc.bottom - rc.top,
        g_game, nullptr, wc.hInstance, nullptr);
    if (!g_overlay) {
        FVEM_LOGF("[fvem] overlay: CreateWindowExW failed (err=%lu)", GetLastError());
        return nullptr;
    }

    // Pure black => transparent. The overlay renderer clears to {0,0,0,0}
    // every frame, so only the drawn ImGui content is visible.
    SetLayeredWindowAttributes(g_overlay, RGB(0, 0, 0), 0, LWA_COLORKEY);

    // Stream-proof layer 1: absent from every DWM-composited capture path.
    const bool invisible = set_capture_invisible(g_overlay);
    FVEM_LOGF("[fvem] stream proof: capture-invisible=%d (WDA_EXCLUDEFROMCAPTURE)",
              invisible ? 1 : 0);

    ShowWindow(g_overlay, SW_SHOW);
    // Force topmost and bring to front without stealing focus from the game
    // (SWP_NOACTIVATE keeps the game's input intact).
    SetWindowPos(g_overlay, HWND_TOPMOST, 0, 0, 0, 0, SWP_NOMOVE | SWP_NOSIZE | SWP_NOACTIVATE | SWP_SHOWWINDOW);
    FVEM_LOGF("[fvem] overlay: window created %p over game %p", g_overlay, g_game);
    return g_overlay;
}

void overlay_destroy() {
    if (g_overlay) {
        DestroyWindow(g_overlay);
        g_overlay = nullptr;
    }
    UnregisterClassW(g_class_name, GetModuleHandleW(nullptr));
    g_clickable = false;
}

void overlay_set_clickable(bool clickable) {
    if (!g_overlay) return;
    g_clickable = clickable;
    LONG_PTR ex = GetWindowLongPtrW(g_overlay, GWL_EXSTYLE);
    if (clickable)
        ex &= ~WS_EX_TRANSPARENT;      // menu open: capture mouse
    else
        ex |= WS_EX_TRANSPARENT;       // menu closed: click-through
    SetWindowLongPtrW(g_overlay, GWL_EXSTYLE, ex);
    set_capture_invisible(g_overlay);   // style surgery can drop affinity

    // Keyboard focus follows the menu: open -> overlay, closed -> game.
    //
    // Cross-thread SetFocus is only legal when the calling thread is attached
    // to the thread that OWNS THE TARGET WINDOW. The old code attached to
    // whatever thread owned the current foreground window instead - so the
    // hand-back to the game could silently fail and leave focus parked on a
    // now-invisible overlay (killing the game's keyboard input). Attach to
    // the target's thread, which is the one the focus actually needs.
    const DWORD curThread = GetCurrentThreadId();
    const HWND  target    = clickable ? g_overlay : g_game;
    if (target && IsWindow(target)) {
        const DWORD tgtThread = GetWindowThreadProcessId(target, nullptr);
        const bool  attached  = (tgtThread != curThread) &&
                                AttachThreadInput(curThread, tgtThread, TRUE);
        SetFocus(target);
        SetForegroundWindow(target);
        if (attached) AttachThreadInput(curThread, tgtThread, FALSE);
    }
    if (clickable) ShowWindow(g_overlay, SW_SHOW);
}

void overlay_follow_game() {
    if (!g_overlay || !g_game || !IsWindow(g_game)) return;

    // 10 s-cadence affinity re-assert: covers silent DWM-restart / GPU-reset
    // loss WITHOUT hammering SetWindowDisplayAffinity on every 500 ms poll -
    // repeated affinity calls can churn the capture-shadow rebuild, exactly
    // the compositor wobble a user feels as "the UI eats frames".
    static ULONGLONG s_last_aff = 0;
    const ULONGLONG now = GetTickCount64();
    if (now - s_last_aff > 10000) { s_last_aff = now; set_capture_invisible(g_overlay); }

    // Geometry diff first, move only on REAL change. The old code poked a
    // fullscreen SetWindowPos twice a second forever; every poke is a DWM
    // z-order + composition event. Idle cost should be two GetWindowRects.
    RECT rc{};
    if (!GetWindowRect(g_game, &rc)) return;
    RECT cur{};
    GetWindowRect(g_overlay, &cur);
    if (cur.left  == rc.left  && cur.top == rc.top &&
        (cur.right  - cur.left) == (rc.right  - rc.left) &&
        (cur.bottom - cur.top)  == (rc.bottom - rc.top))
        return;                                   // nothing moved: stay silent
    SetWindowPos(g_overlay, HWND_TOPMOST, rc.left, rc.top,
                 rc.right - rc.left, rc.bottom - rc.top,
                 SWP_NOACTIVATE | SWP_NOOWNERZORDER);
}

// Capture-host watcher - DEMOTED from hard lock to telemetry on purpose.
// Field-proven self-DoS: a user with OBS merely OPEN (pid 17096 incident)
// got "menu LOCKED / open refused" forever. And the lock buys nothing the
// affinity does not already provide: WDA_EXCLUDEFROMCAPTURE is enforced at
// DWM composition, so display-capture, Desktop Duplication, BitBlt AND
// remote-desktop mirrors (RDP/TeamViewer/AnyDesk) all read a framebuffer
// with the overlay already gone. The residual threats a process scan can't
// see anyway (camera at the monitor, HDMI splitter) are unaddressable in
// software; the residual threats WDA covers do not need a lock. So: name
// the host once on transition, touch nothing else. Menu opens always.
void overlay_stream_guard_tick() {
    static ULONGLONG s_last = 0;
    static wchar_t   s_logged[64] = {};
    const ULONGLONG now = GetTickCount64();
    if (now - s_last < 2000) return;
    s_last = now;
    wchar_t name[64] = {};
    if (capture_host_running(name, 64)) {
        if (wcscmp(s_logged, name) != 0) {
            wcsncpy_s(s_logged, name, _TRUNCATE);
            FVEM_LOGF("[fvem] stream watch: capture host live: %ls "
                      "(WDA-excluded already - no lock)", name);
        }
    } else if (s_logged[0]) {
        s_logged[0] = 0;
        FVEM_LOGF("[fvem] stream watch: capture host gone");
    }
}

bool overlay_stream_guard_active() {
    return false;   // watcher never locks; kept for header/API stability
}

HWND overlay_hwnd() {
    return g_overlay;
}

} // namespace gfx