// language: C++, target: Windows 11, MSVC (x64)
// Minimal thread-safe file + debug-output logger. Writes to %TEMP%\fvem.log
// so boot diagnostics are readable without DebugView. Header-only; the static
// critical section is shared across TUs (inline function statics are one
// object per program).
//
// ZERO CRT DEPENDENCY: the DLL is /MT (static CRT), and the boot thread is
// created with CreateThread (not _beginthreadex), so the new thread has no
// per-thread CRT state â€” any CRT call here (vsnprintf_s, strlen, toupperâ€¦)
// can fault silently. Formatting is hand-rolled; only Win32 is used.
#pragma once
#include <windows.h>
#include <cstdarg>
#include <cstdint>

namespace gfx {

namespace detail {

// Append decimal/hex digits for v (little-endian order); returns new length.
inline int append_num(char* buf, int len, uint64_t v, bool hex) {
    char tmp[22];
    int t = 0;
    if (hex) {
        do { tmp[t++] = "0123456789ABCDEF"[v & 0xF]; v >>= 4; } while (v);
    } else {
        do { tmp[t++] = static_cast<char>('0' + (v % 10)); v /= 10; } while (v);
    }
    while (t > 0 && len < 500) buf[len++] = tmp[--t];
    return len;
}

inline int append_str(char* buf, int len, const char* s) {
    if (!s) s = "(null)";
    while (*s && len < 500) buf[len++] = *s++;
    return len;
}

inline int append_wstr(char* buf, int len, const wchar_t* s) {
    if (!s) return append_str(buf, len, "(null)");
    while (*s && len < 500) {
        wchar_t c = *s++;
        if (c < 0x80) buf[len++] = static_cast<char>(c);
        else buf[len++] = '?'; // non-ASCII: placeholder
    }
    return len;
}

} // namespace detail

// The logging WORKER. Writes to the debug pipe + %TEMP%\fvem.log. It is only
// ever referenced through the FVEM_LOGF macro below, which is a no-op in
// Release â€” so in the shipped build log_write is unreferenced, never emitted,
// and its "%TEMP%\â€¦log" path literal dies with it. FVEM_LOG is defined for
// Debug only (see CMakeLists.txt).
//
// ZERO CRT DEPENDENCY: /MT static CRT, and the boot thread is created raw
// (not _beginthreadex), so any CRT call here (swprintf_s, strlenâ€¦) can fault
// silently. Formatting + path build are hand-rolled; Win32 only.
inline void log_write(const char* fmt, ...) {
    static bool init = false;
    static CRITICAL_SECTION cs;
    if (!init) { InitializeCriticalSection(&cs); init = true; }

    EnterCriticalSection(&cs);

    char buf[512];
    int len = 0;

    va_list ap;
    va_start(ap, fmt);

    const char* p = fmt;
    while (*p && len < 490) {
        if (*p != '%') { buf[len++] = *p++; continue; }
        ++p;
        if (!*p) break;
        if (*p == '%') { buf[len++] = '%'; ++p; continue; }

        // Length modifiers we care about: l (long) and ll (long long).
        int ll = 0;
        while (*p == 'l') { ++ll; ++p; }
        if (!*p) break;

        switch (*p) {
        case 's': {
            if (ll >= 1) { // %ls -> wide string
                const wchar_t* s = va_arg(ap, const wchar_t*);
                len = detail::append_wstr(buf, len, s);
            } else {
                const char* s = va_arg(ap, const char*);
                len = detail::append_str(buf, len, s);
            }
            break;
        }
        case 'S': { // %ls
            const wchar_t* s = va_arg(ap, const wchar_t*);
            len = detail::append_wstr(buf, len, s);
            break;
        }
        case 'c': {
            buf[len++] = static_cast<char>(va_arg(ap, int));
            break;
        }
        case 'd':
        case 'i': {
            int64_t v = (ll >= 2) ? va_arg(ap, int64_t)
                                  : (ll == 1) ? va_arg(ap, long)
                                              : va_arg(ap, int);
            if (v < 0) { buf[len++] = '-'; v = -v; }
            len = detail::append_num(buf, len, static_cast<uint64_t>(v), false);
            break;
        }
        case 'u': {
            uint64_t v = (ll >= 2) ? va_arg(ap, uint64_t)
                                   : (ll == 1) ? va_arg(ap, unsigned long)
                                               : va_arg(ap, unsigned int);
            len = detail::append_num(buf, len, v, false);
            break;
        }
        case 'x':
        case 'X': {
            uint64_t v = (ll >= 2) ? va_arg(ap, uint64_t)
                                   : (ll == 1) ? va_arg(ap, unsigned long)
                                               : va_arg(ap, unsigned int);
            len = detail::append_num(buf, len, v, true);
            break;
        }
        case 'p': {
            void* v = va_arg(ap, void*);
            len = detail::append_str(buf, len, "0x");
            len = detail::append_num(buf, len, reinterpret_cast<uintptr_t>(v), true);
            break;
        }
        default:
            buf[len++] = '%';
            buf[len++] = *p;
            break;
        }
        ++p;
    }
    va_end(ap);
    buf[len] = 0;

    OutputDebugStringA(buf);
    OutputDebugStringA("\n");

    wchar_t dir[MAX_PATH];
    if (GetTempPathW(MAX_PATH, dir)) {
        // Hand-rolled "dir + L"fvem.log"" â€” no CRT (swprintf_s would fault on
        // a thread that lacks per-thread CRT state).
        wchar_t path[MAX_PATH];
        int i = 0;
        while (dir[i] && i < MAX_PATH - 8) { path[i] = dir[i]; ++i; }
        const wchar_t tail[] = L"fvem.log";
        int t = 0;
        while (tail[t] && i < MAX_PATH - 1) path[i++] = tail[t++];
        path[i] = 0;
        HANDLE f = CreateFileW(path, FILE_APPEND_DATA, FILE_SHARE_READ | FILE_SHARE_WRITE,
                               nullptr, OPEN_ALWAYS, FILE_ATTRIBUTE_NORMAL, nullptr);
        if (f != INVALID_HANDLE_VALUE) {
            DWORD written = 0;
            WriteFile(f, buf, static_cast<DWORD>(len), &written, nullptr);
            WriteFile(f, "\r\n", 2, &written, nullptr);
            CloseHandle(f);
        }
    }
    LeaveCriticalSection(&cs);
}

// The call-site macro. Debug forwards to log_write; Release expands to
// ((void)0) so the whole call â€” the "[fvem] â€¦" literal and all its arguments â€”
// is discarded and never lands in the image. This is the tag-strip: the ONLY
// way to drop a string a call site passes is to drop the call.
#ifdef FVEM_LOG
#define FVEM_LOGF(...) ::gfx::log_write(__VA_ARGS__)
#else
#define FVEM_LOGF(...) ((void)0)
#endif

// Shared fault logger for __except FILTER expressions. The filter expression
// itself must evaluate GetExceptionInformation() (the intrinsic is only valid
// lexically there), so callers pass the whole record in:
//   __except (log_fault_filter(GetExceptionCode(),
//              GetExceptionInformation())) { }
// CRITICAL: MSVC C++ exceptions surface through SEH with code 0xE06D7363.
// Returning EXCEPTION_EXECUTE_HANDLER for them swallows the exception BEFORE
// the C++ EH machinery (__CxxFrameHandler) runs â€” the thrown object is never
// destroyed and the EH chain is left corrupt, which crashes the game later
// (observed: FiveM "early-exit trap" ~30s after the swallow). So 0xE06D7363
// is logged and then CONTINUE_SEARCHed so C++ try/catch unwinds normally.
inline int log_fault_filter(unsigned code, EXCEPTION_POINTERS* ep) {
    uintptr_t data = 0;
    if (ep && ep->ExceptionRecord && ep->ExceptionRecord->NumberParameters >= 1)
        data = static_cast<uintptr_t>(ep->ExceptionRecord->ExceptionInformation[0]);
#ifndef FVEM_LOG
    (void)data;  // in Release the FAULT log lines are compiled away entirely
#endif
    FVEM_LOGF("[fvem] FAULT code=0x%X addr=%p data=%p", code,
            ep ? ep->ExceptionRecord->ExceptionAddress : nullptr,
            reinterpret_cast<void*>(data));
    // C++ exceptions (0xE06D7363): info[0]=throw-site, info[1]=throwInfo
    // (type descriptor), info[2]=thrown object. Dump all present params.
    if (ep && ep->ExceptionRecord && ep->ExceptionRecord->NumberParameters > 1) {
        FVEM_LOGF("[fvem] FAULT params[1]=%p params[2]=%p",
                reinterpret_cast<void*>(ep->ExceptionRecord->ExceptionInformation[1]),
                reinterpret_cast<void*>(ep->ExceptionRecord->ExceptionInformation[2]));
    }
    // Register context â€” key registers at the fault site (x64 CONTEXT).
    if (ep && ep->ContextRecord) {
        FVEM_LOGF("[fvem] FAULT regs rax=%p rbx=%p rcx=%p rdx=%p rsi=%p rdi=%p "
                "r13=%p r14=%p r15=%p rbp=%p rsp=%p rip=%p",
                reinterpret_cast<void*>(ep->ContextRecord->Rax),
                reinterpret_cast<void*>(ep->ContextRecord->Rbx),
                reinterpret_cast<void*>(ep->ContextRecord->Rcx),
                reinterpret_cast<void*>(ep->ContextRecord->Rdx),
                reinterpret_cast<void*>(ep->ContextRecord->Rsi),
                reinterpret_cast<void*>(ep->ContextRecord->Rdi),
                reinterpret_cast<void*>(ep->ContextRecord->R13),
                reinterpret_cast<void*>(ep->ContextRecord->R14),
                reinterpret_cast<void*>(ep->ContextRecord->R15),
                reinterpret_cast<void*>(ep->ContextRecord->Rbp),
                reinterpret_cast<void*>(ep->ContextRecord->Rsp),
                reinterpret_cast<void*>(ep->ContextRecord->Rip));
    }
    if (code == 0xE06D7363u) {
        FVEM_LOGF("[fvem] FAULT: C++ exception â€” continuing search for C++ EH");
        return EXCEPTION_CONTINUE_SEARCH;
    }
    return EXCEPTION_EXECUTE_HANDLER;
}

// SILENT variant for hot probe loops (pattern scans, PEB/module walks) that
// routinely touch guard/unmapped pages: same semantics as log_fault_filter â€”
// C++ exceptions (0xE06D7363) CONTINUE_SEARCH so the EH chain is never
// corrupted, everything else is swallowed â€” but emits no log line, because a
// scan probe faulting on expected guard pages is not a fault worth logging.
// Using a raw EXCEPTION_EXECUTE_HANDLER here would swallow C++ exceptions and
// corrupt the EH chain (the documented "early-exit trap" root cause).
inline int probe_filter(unsigned code, EXCEPTION_POINTERS*) {
    if (code == 0xE06D7363u) return EXCEPTION_CONTINUE_SEARCH;
    return EXCEPTION_EXECUTE_HANDLER;
}

} // namespace gfx
