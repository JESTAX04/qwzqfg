// language: C++, target: Windows 11, MSVC (x64)
// Overlay renderer Ã¢â‚¬â€ see overlay_render.h for the design rationale.
//
// Renders ImGui on a DEDICATED loop through the overlay's OWN D3D11 device
// and swap chain, fully decoupled from the game's Present (which is a pure
// passthrough in hooks.cpp). The game's main thread is never extended by
// fvem, so the overlay cannot stall the net thread and cannot trip FiveM's
// watchdog ("early-exit trap").
//
// THREAD MODEL: manual-mapped DLL Ã¢â‚¬â€ the static CRT's per-thread state only
// exists on the trampoline thread that ran _CRT_INIT. CreateThread/
// _beginthreadex here died before the first instruction (observed: "render
// thread spawned" with zero "thread started" lines). The overlay therefore
// runs INLINE on that same trampoline thread: entry.cpp calls
// overlay_render_run() after boot, which never returns while g_running is
// true. The trampoline thread is a private remote thread (NtCreateThreadEx
// from the injector), NOT the game's main thread Ã¢â‚¬â€ the FiveM watchdog only
// watches the game's main thread, so our loop can never trip it.
#include "pch.h"
#include "overlay_window.h"
#include "overlay_render.h"
#include "config.h"
#include "features.h"
#include "native_invoker.h"
#include "offsets.h"
#include "log.h"
#include "lua_scheduler.h"
#include "evasion/watchdog.h"
#include "../third_party/imgui/imgui.h"
#include "../third_party/imgui/backends/imgui_impl_dx11.h"
#include "../third_party/imgui/backends/imgui_impl_win32.h"

namespace gfx {

// Game window lookup: provided by hooks.cpp. Declared at fvem namespace scope
// (NOT inside the anonymous namespace, which would give it internal linkage
// and hide the real function).
HWND game_window();

namespace {

// ---- Overlay's OWN D3D11 device/context/swap chain ------------------------
ID3D11Device*        g_dev  = nullptr;
ID3D11DeviceContext* g_ctx  = nullptr;
IDXGISwapChain*      g_sc   = nullptr;
bool                 g_ok   = false;

HWND g_overlay_ready = nullptr;

// True once the game world exists (local ped handle non-zero). SEH-wrapped:
// PLAYER_PED_ID may not be safe to call before the scripting layer is stable;
// a fault here must mean "not ready yet", never a crash.
bool world_ready() {
    uint64_t ped = 0;
    __try {
        ped = native::invoke<uint64_t>(0xD80958FC74E988A6ull); // PLAYER_PED_ID
    } __except (probe_filter(GetExceptionCode(), GetExceptionInformation())) {
        return false;
    }
    return ped != 0;
}

// Create the overlay's OWN D3D11 device + swap chain bound to the overlay
// window. Hardware first, WARP fallback, REF last. Never touches the game's
// device Ã¢â‚¬â€ rendering happens entirely on a separate provider.
bool create_overlay_d3d(HWND hwnd) {
    RECT rc{};
    GetClientRect(hwnd, &rc);
    UINT w = rc.right - rc.left, h = rc.bottom - rc.top;
    if (w < 8) w = 1280;
    if (h < 8) h = 720;

    DXGI_SWAP_CHAIN_DESC sd{};
    sd.BufferCount = 2;
    sd.BufferDesc.Width = w;
    sd.BufferDesc.Height = h;
    sd.BufferDesc.Format = DXGI_FORMAT_R8G8B8A8_UNORM;
    sd.BufferDesc.RefreshRate = { 60, 1 };
    sd.BufferUsage = DXGI_USAGE_RENDER_TARGET_OUTPUT;
    sd.OutputWindow = hwnd;
    sd.SampleDesc.Count = 1;
    sd.Windowed = TRUE;
    sd.SwapEffect = DXGI_SWAP_EFFECT_DISCARD;
    sd.Flags = DXGI_SWAP_CHAIN_FLAG_ALLOW_MODE_SWITCH;

    D3D_FEATURE_LEVEL levels[] = {
        D3D_FEATURE_LEVEL_11_0, D3D_FEATURE_LEVEL_10_1, D3D_FEATURE_LEVEL_10_0
    };
    D3D_FEATURE_LEVEL got{};
    HRESULT hr = E_FAIL;

    hr = D3D11CreateDeviceAndSwapChain(
        nullptr, D3D_DRIVER_TYPE_HARDWARE, nullptr, D3D11_CREATE_DEVICE_BGRA_SUPPORT,
        levels, ARRAYSIZE(levels), D3D11_SDK_VERSION, &sd, &g_sc, &g_dev, &got, &g_ctx);
    if (FAILED(hr)) {
        FVEM_LOGF("[fvem] overlay: HARDWARE failed hr=0x%lX, trying WARP", (unsigned long)hr);
        hr = D3D11CreateDeviceAndSwapChain(
            nullptr, D3D_DRIVER_TYPE_WARP, nullptr, D3D11_CREATE_DEVICE_BGRA_SUPPORT,
            levels, ARRAYSIZE(levels), D3D11_SDK_VERSION, &sd, &g_sc, &g_dev, &got, &g_ctx);
    }
    if (FAILED(hr)) {
        FVEM_LOGF("[fvem] overlay: WARP failed hr=0x%lX, trying REF", (unsigned long)hr);
        hr = D3D11CreateDeviceAndSwapChain(
            nullptr, D3D_DRIVER_TYPE_REFERENCE, nullptr, D3D11_CREATE_DEVICE_BGRA_SUPPORT,
            levels, ARRAYSIZE(levels), D3D11_SDK_VERSION, &sd, &g_sc, &g_dev, &got, &g_ctx);
    }
    if (FAILED(hr) || !g_dev || !g_ctx || !g_sc) {
        FVEM_LOGF("[fvem] overlay: ALL D3D init failed hr=0x%lX", (unsigned long)hr);
        if (g_sc) { g_sc->Release(); g_sc = nullptr; }
        if (g_ctx) { g_ctx->Release(); g_ctx = nullptr; }
        if (g_dev) { g_dev->Release(); g_dev = nullptr; }
        return false;
    }
    FVEM_LOGF("[fvem] overlay: own device %p sc=%p feature=0x%X", g_dev, g_sc, got);
    return true;
}

// Set when the menu closes: the loop is presentation-idle while the menu is
// shut (zero GPU cost while playing), which WOULD otherwise weld the last
// open frame - menu pixels and all - onto the layered window forever. One
// extra frame (drawn with menu_open already false) wipes it back to the
// watermark/ESP-only surface.
static volatile LONG g_wipe_request = 0;

// Advance the queued spawn / per-frame cheat ticks. Each tick is SEH-wrapped
// so a fault disables that feature instead of killing the game.
void run_feature_ticks() {
    __try { aimbot_tick(); }         __except (probe_filter(GetExceptionCode(), GetExceptionInformation())) { cfg().aim_enabled = false; }
    __try { player_cheats_tick(); }  __except (probe_filter(GetExceptionCode(), GetExceptionInformation())) { cfg().plr_godmode = false; cfg().plr_infinite_health = false; cfg().plr_infinite_armour = false; cfg().plr_no_wanted = false; }
    __try { vehicle_tools_tick(); }  __except (probe_filter(GetExceptionCode(), GetExceptionInformation())) { cfg().veh_engine = false; cfg().veh_doors = false; cfg().veh_fix = false; }
    __try { tick_spawn(); }          __except (probe_filter(GetExceptionCode(), GetExceptionInformation())) { FVEM_LOGF("[fvem] overlay: tick_spawn faulted"); }
}

// One full ImGui frame on the overlay loop. The WHOLE frame is fault-wrapped:
// on device loss (alt-tab, monitor change, GPU reset) GetBuffer /
// CreateRenderTargetView / Present fault; an unhandled fault here would kill
// the process. The game's main thread is untouched by our drawing, so the
// game survives and the overlay simply retries next frame.
void draw_overlay_frame() {
    __try {
        if (!g_sc || !g_dev || !g_ctx) return;

        ID3D11RenderTargetView* rtv = nullptr;
        ID3D11Texture2D* bb = nullptr;
        HRESULT hr = g_sc->GetBuffer(0, __uuidof(ID3D11Texture2D), reinterpret_cast<void**>(&bb));
        if (FAILED(hr) || !bb) return;
        hr = g_dev->CreateRenderTargetView(bb, nullptr, &rtv);
        bb->Release();
        if (FAILED(hr) || !rtv) return;
        g_ctx->OMSetRenderTargets(1, &rtv, nullptr);

        // Clear to pure black = the LWA_COLORKEY transparent color.
        const float clear[4] = { 0.0f, 0.0f, 0.0f, 0.0f };
        g_ctx->ClearRenderTargetView(rtv, clear);

        ImGui_ImplDX11_NewFrame();
        ImGui_ImplWin32_NewFrame();
        ImGui::NewFrame();

        __try { menu_draw(); }
        __except (probe_filter(GetExceptionCode(), GetExceptionInformation())) {
            FVEM_LOGF("[fvem] overlay: menu_draw faulted");
            cfg().menu_open.store(false, std::memory_order_relaxed);
        }
        __try { esp_draw(); }
        __except (probe_filter(GetExceptionCode(), GetExceptionInformation())) {
            cfg().esp_enabled = false;
        }

        ImGui::Render();
        ImGui_ImplDX11_RenderDrawData(ImGui::GetDrawData());

        g_ctx->OMSetRenderTargets(0, nullptr, nullptr);
        rtv->Release();

        hr = g_sc->Present(0, 0);   // vsync-OFF: Sleep(16) is the only pacer.
        // Present(1) coupled the overlay into the DWM vblank queue: a second
        // vsync chain on the same GPU (game vsync + overlay vsync) can
        // serialize frame pacing and is a classic "menu open = fps dip"
        // source. Color-key composition hides any theoretical tearing anyway.
        if (FAILED(hr)) {
            FVEM_LOGF("[fvem] overlay: Present failed hr=0x%lX - device lost", (unsigned long)hr);
        }
    } __except (probe_filter(GetExceptionCode(), GetExceptionInformation())) {
        FVEM_LOGF("[fvem] overlay: draw frame faulted (device lost?)");
        if (g_sc) { g_sc->Release(); g_sc = nullptr; }
    }
}

} // namespace

// Run the overlay loop inline on the calling thread (the trampoline thread Ã¢â‚¬â€
// the only thread with valid static-CRT state in this manual-mapped image).
// Does not return while gfx::g_running is true.
// Overlay init failed, but the watchdog shield still needs its maintenance
// owner: shield_tick (trap arming, hook self-heal, watchdog-thread re-park)
// only runs from this loop. Falling off the loop entirely silently disarmed
// the whole shield - the early-exit trap then reached FiveM's fatal dialog
// untouched. Win32-only here; the trampoline thread's CRT is valid, so even
// this degraded path is safe.
static void run_shield_maintenance_only() {
    FVEM_LOGF("[fvem] overlay: init failed - shield maintenance fallback engaged");
    while (gfx::g_running.load()) {
        gfx::watchdog::shield_tick();
        Sleep(1000);
    }
}

void overlay_render_run() {
    gfx::native::set_in_present(false); // belt: never considered in-Present
    FVEM_LOGF("[fvem] overlay: loop started (tid=%lu)", GetCurrentThreadId());

    // Wait for the game world to exist (up to ~20s), then sleep 5s for
    // stability before touching D3D/ImGui Ã¢â‚¬â€ the game is still bringing up
    // its pipeline right after launch and a competing overlay device can
    // interfere with present-mode switches.
    for (int i = 0; i < 40 && gfx::g_running.load(); ++i) {
        if (gfx::game::base() && world_ready()) break;
        Sleep(500);
    }
    if (!gfx::g_running.load()) return;
    Sleep(5000);

    HWND game = game_window();
    HWND ov = overlay_create(game);
    if (!ov) {
        FVEM_LOGF("[fvem] overlay: window creation failed, abort");
        run_shield_maintenance_only();
        return;
    }
    FVEM_LOGF("[fvem] overlay: window created %p (game %p)", ov, game);

    if (!create_overlay_d3d(ov)) {
        FVEM_LOGF("[fvem] overlay: d3d init failed, abort");
        run_shield_maintenance_only();
        return;
    }

    IMGUI_CHECKVERSION();
    ImGui::CreateContext();
    // Memory-only posture: ImGui's default is to auto-save "imgui.ini" into the
    // process CWD (inside the FiveM tree) a few seconds after any window move.
    // That was the only live disk write in the shipped DLL. Nulling both kills
    // the sink and the path literal; layout persistence, if ever wanted, goes
    // through SaveIniSettingsToMemory into the in-memory ring and back via
    // LoadIniSettingsFromMemory. Never SaveIniSettingsToDisk.
    ImGui::GetIO().IniFilename = nullptr;
    ImGui::GetIO().LogFilename = nullptr;
    ImGui::StyleColorsDark();
    bool okw = ImGui_ImplWin32_Init(ov);
    bool okd = ImGui_ImplDX11_Init(g_dev, g_ctx);
    if (!okw || !okd) {
        FVEM_LOGF("[fvem] overlay: imgui init failed (win32=%d dx11=%d)", okw ? 1 : 0, okd ? 1 : 0);
        run_shield_maintenance_only();
        return;
    }
    g_ok = true;
    g_overlay_ready = ov;
    FVEM_LOGF("[fvem] overlay: imgui ready on overlay window %p (60 FPS menu / 200 Hz ticks)", ov);

    // Message pump for the overlay window (ImGui input + WM_DESTROY), follow/
    // resize poll, and the 30 FPS render loop.
    MSG msg{};
    uint64_t last_follow = 0;
    bool world_was_ready = false;
    while (gfx::g_running.load()) {
        while (PeekMessageW(&msg, nullptr, 0, 0, PM_REMOVE)) {
            TranslateMessage(&msg);
            DispatchMessageW(&msg);
        }

        uint64_t now = GetTickCount64();

        // Lua hub pump: Wait-deadlines, event queue, keybind edges, coroutine
        // resumes — all here on the trampoline thread (the one lua_State
        // owner). Costs nothing when the hub is idle.
        gfx::hub_tick();

        if (now - last_follow > 500) {
            overlay_follow_game();
            // Stream-proof layer 2: capture-host watcher (2 s throttle
            // internally). Forces the menu shut while OBS/vMix/TeamViewer-
            // class hosts are live, so a zero-day in the affinity layer or a
            // backbuffer-reading capture path never sees the menu either.
            gfx::overlay_stream_guard_tick();
            // Watchdog shield maintenance. Arms the trap suppressor the first
            // time a hang probe is seen, then parks the watchdog thread the
            // first time it is found safely blocked inside ntdll. Self-
            // throttled to a 5 s scan internally, so 2 Hz here is cheap.
            gfx::watchdog::shield_tick();
            last_follow = now;
        }

        if (!world_was_ready && gfx::game::base() && world_ready()) {
            world_was_ready = true;
            FVEM_LOGF("[fvem] overlay: world ready, features enabled");
        }

        if (cfg().menu_open.load(std::memory_order_relaxed) ||
            cfg().console_open.load(std::memory_order_relaxed)) {
            // Interactive UI (menu, F8 console, or both) → 60 FPS redraw.
            draw_overlay_frame();
            Sleep(16); // ~60 FPS while the user interacts; 30 felt laggy
        } else {
            // ESP / watermark need presents too - previously the whole frame
            // only drew while the menu was open, so enabling ESP then closing
            // the menu silently killed the ESP render (features ticked, but
            // nothing drew). HUD state presents at 30 FPS; nothing on screen
            // stays fully presentation-idle (zero GPU, zero composition).
            const bool hud = cfg().esp_enabled || cfg().watermark || cfg().show_info;
            if (hud || InterlockedExchange(&g_wipe_request, 0))
                draw_overlay_frame();   // live HUD frame, or the close-wipe
            if (world_was_ready) run_feature_ticks();
            // 200 Hz feature cadence. The old Sleep(1) woke this thread
            // ~1000x/s: pointless for cheats (one frame is 16 ms), and on
            // this loop every async native a feature enqueues lands in the
            // main-thread drain ring — flooding it is how the drain budget
            // gets spent starving the game. Cheap loop, quiet queue.
            Sleep(hud ? 33 : 5);
        }
    }

    // --- Cleanup (this loop owns ImGui + D3D) ---
    FVEM_LOGF("[fvem] overlay: loop stopping, releasing resources");
    ImGui_ImplDX11_Shutdown();
    ImGui_ImplWin32_Shutdown();
    ImGui::DestroyContext();
    if (g_sc) { g_sc->Release(); g_sc = nullptr; }
    if (g_ctx) { g_ctx->Release(); g_ctx = nullptr; }
    if (g_dev) { g_dev->Release(); g_dev = nullptr; }
    overlay_destroy();
    g_ok = false;
    g_overlay_ready = nullptr;
    FVEM_LOGF("[fvem] overlay: loop exited");
}

void overlay_render_shutdown() {
    // Signal stop; the loop (on the trampoline thread) exits by itself and
    // performs the cleanup it owns.
    gfx::g_running = false;
}

void overlay_toggle_menu() {
    // Atomic CAS flip so concurrent Insert pressers (game pump hook +
    // overlay WndProc) can never lose an update, plus a 150ms debounce so a
    // focus hand-off between the two windows cannot double-fire.
    static volatile LONG s_last_toggle_ms = 0;
    LONG now = static_cast<LONG>(GetTickCount());
    LONG prev = s_last_toggle_ms;
    if (now - prev < 150) return;
    if (InterlockedCompareExchange(&s_last_toggle_ms, now, prev) != prev) return;

    bool cur = cfg().menu_open.load(std::memory_order_relaxed);
    while (!cfg().menu_open.compare_exchange_weak(
        cur, !cur, std::memory_order_relaxed)) {
        // cur was reloaded with the winner's value; retry the flip on it.
    }
    bool next = cfg().menu_open.load(std::memory_order_relaxed);
    // Console may be the only UI still open — keep the overlay interactive.
    const bool con = cfg().console_open.load(std::memory_order_relaxed);
    overlay_set_clickable(next || con);
    if (!next && !con) InterlockedExchange(&g_wipe_request, 1);
    FVEM_LOGF("[fvem] overlay: menu %s (clickable=%d tick=%lu)",
                  next ? "OPEN" : "closed", (next || con) ? 1 : 0,
                  static_cast<unsigned long>(GetTickCount()));
}

void overlay_toggle_console() {
    // Same single-trigger discipline as the menu: one 150 ms-debounced flip.
    static volatile LONG s_last_toggle_ms = 0;
    LONG now = static_cast<LONG>(GetTickCount());
    LONG prev = s_last_toggle_ms;
    if (now - prev < 150) return;
    if (InterlockedCompareExchange(&s_last_toggle_ms, now, prev) != prev) return;

    bool cur = cfg().console_open.load(std::memory_order_relaxed);
    while (!cfg().console_open.compare_exchange_weak(
        cur, !cur, std::memory_order_relaxed)) {
    }
    bool next = cfg().console_open.load(std::memory_order_relaxed);
    const bool menu = cfg().menu_open.load(std::memory_order_relaxed);
    overlay_set_clickable(next || menu);
    if (!next && !menu) InterlockedExchange(&g_wipe_request, 1);
    FVEM_LOGF("[fvem] overlay: console %s (tick=%lu)",
                  next ? "OPEN" : "closed",
                  static_cast<unsigned long>(GetTickCount()));
}

void overlay_close_menu() {
    // One-way close for the ImGui X button (menu.cpp). Must mirror the
    // toggle-to-close COMPLETELY: state flip + release mouse/focus + wipe
    // frame. The old bare store(false) closed the STATE while the overlay
    // kept focus, kept the mouse, and kept showing the frozen last menu
    // frame - indistinguishable from "the menu does not close".
    if (!cfg().menu_open.exchange(false, std::memory_order_relaxed))
        return;                       // already closed; closer did the work
    const bool con = cfg().console_open.load(std::memory_order_relaxed);
    overlay_set_clickable(con);       // console keeps the overlay alive
    if (!con) InterlockedExchange(&g_wipe_request, 1);
    FVEM_LOGF("[fvem] overlay: menu closed (X button)");
}

} // namespace gfx