// language: C++, target: Windows 11, MSVC (x64)
// FiveM Window Watchdog bypass.
//
// FiveM's watchdog is a thread named "FiveM Window Watchdog" that probes the
// game window on a ~1 s loop with
//     SendMessageTimeout(hwnd, WM_NULL, 0, 0,
//                        SMTO_ABORTIFHUNG | SMTO_BLOCK, timeout, &result)
// A timeout means "the main thread is not pumping messages" -> the client logs
// "FiveM has stopped responding", treats the process as hung, and takes it down
// through GTA5's deliberate early-exit trap (the fault at
// FiveM_b3751_GTAProcess.exe+0x101C seen in the crash dumps).
//
// The trap is downstream of the probe. Three independent layers neutralise it:
//
//   1. PROBE SHIELD   - inline detours on the hang-probe APIs. The probe
//                       answers itself with TRUE, so the watchdog never
//                       reaches a verdict regardless of how long the main
//                       thread is stalled.
//   2. THREAD PARK    - locate the watchdog by its thread description and
//                       suspend it, but ONLY when its RIP is inside ntdll
//                       (i.e. it is blocked in a wait, not holding a lock or
//                       mid-allocation). Parking a thread inside user32 while
//                       it holds the loader lock is how you turn a stall into
//                       a permanent deadlock.
//   3. TRAP SUPPRESS  - a vectored exception handler that revives the
//                       deliberate execute-fault in the launcher image, so
//                       even if the client decides to die the process keeps
//                       running with the trap function returning 0.
//
// CRT DISCIPLINE: every function reachable from a detour body or the VEH runs
// on a thread this manual-mapped image never initialised the static CRT for.
// Those paths are Win32-only - no std::, no string, no malloc. install/scan
// helpers run on the trampoline thread and may use the full CRT.
#include "pch.h"
#include "watchdog.h"
#include "detour.h"
#include "log.h"
#include "config.h"
#include <tlhelp32.h>
#include <intrin.h>

namespace gfx::watchdog {
namespace {

HWND          g_game_window  = nullptr;
volatile LONG g_probe_count  = 0;
volatile LONG g_sm_count     = 0;
volatile LONG g_iha_count    = 0;
volatile LONG g_trap_revives = 0;
volatile LONG g_trap_armed   = 0;
volatile LONG g_diagnose     = 0;
DWORD         g_watchdog_tid = 0;
DWORD         g_main_tid     = 0;
volatile LONG g_watchdog_parked = 0;
volatile LONG g_kill_block   = 0;   // L4 enabled
volatile LONG g_kill_count   = 0;   // self-terminates refused so far
volatile LONG g_repair_count = 0;   // hooks re-installed by the self-heal pass
volatile LONG g_user32_on    = 0;   // L1a enabled
volatile LONG g_win32u_on    = 0;   // L1b enabled
bool          g_want_suspend = true;
bool          g_installed    = false;
uintptr_t     g_ntdll_lo     = 0;
uintptr_t     g_ntdll_hi     = 0;
uintptr_t     g_launcher_lo  = 0;
uintptr_t     g_launcher_hi  = 0;
uint8_t*      g_revive_page  = nullptr;
void*         g_veh          = nullptr;

// Module table captured at install, for caller attribution in diagnose mode.
struct mod_row { uintptr_t base; uintptr_t end; char name[28]; };
mod_row g_mods[192];
int     g_mod_count = 0;

void capture_modules() {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPMODULE | TH32CS_SNAPMODULE32,
                                           GetCurrentProcessId());
    if (snap == INVALID_HANDLE_VALUE) return;
    MODULEENTRY32W me{};
    me.dwSize = sizeof(me);
    if (Module32FirstW(snap, &me)) {
        do {
            if (g_mod_count >= 192) break;
            mod_row& r = g_mods[g_mod_count++];
            r.base = reinterpret_cast<uintptr_t>(me.modBaseAddr);
            r.end  = r.base + me.modBaseSize;
            int i = 0;
            for (; me.szModule[i] && i < 27; ++i) {
                wchar_t c = me.szModule[i];
                r.name[i] = (c < 0x80) ? static_cast<char>(c) : '?';
            }
            r.name[i] = 0;
        } while (Module32NextW(snap, &me));
    }
    CloseHandle(snap);
}

// CRT-free attribution: writes "mod+0x1234" into a caller-supplied buffer.
void attribute(uintptr_t addr, char* out, int cap) {
    int n = 0;
    for (int i = 0; i < g_mod_count; ++i) {
        if (addr >= g_mods[i].base && addr < g_mods[i].end) {
            const char* s = g_mods[i].name;
            while (*s && n < cap - 12) out[n++] = *s++;
            out[n++] = '+';
            out[n++] = '0';
            out[n++] = 'x';
            uintptr_t rva = addr - g_mods[i].base;
            char tmp[18];
            int t = 0;
            do { tmp[t++] = "0123456789ABCDEF"[rva & 0xF]; rva >>= 4; } while (rva && t < 16);
            while (t > 0 && n < cap - 1) out[n++] = tmp[--t];
            out[n] = 0;
            return;
        }
    }
    const char* u = "(unmapped)";
    while (*u && n < cap - 1) out[n++] = *u++;
    out[n] = 0;
}

// ===========================================================================
// LAYER 1 - probe shield
// ===========================================================================
using smt_fn = LRESULT (WINAPI*)(HWND, UINT, WPARAM, LPARAM, UINT, PDWORD_PTR);
using sm_fn  = LRESULT (WINAPI*)(HWND, UINT, WPARAM, LPARAM);
using iha_fn = BOOL    (WINAPI*)(HWND);

smt_fn g_orig_smt_w = nullptr;
smt_fn g_orig_smt_a = nullptr;
sm_fn  g_orig_sm_w  = nullptr;
sm_fn  g_orig_sm_a  = nullptr;
iha_fn g_orig_iha   = nullptr;

// A hang probe is: a null message, with the hung-detection flags, aimed at the
// game window (or broadcast - a null hwnd probe is still a liveness check).
bool is_hang_probe(HWND hwnd, UINT msg, UINT flags) {
    if (msg != WM_NULL) return false;
    if (!(flags & (SMTO_ABORTIFHUNG | SMTO_BLOCK))) return false;
    if (g_game_window && hwnd && hwnd != g_game_window) return false;
    return true;
}

void note_probe(const char* api) {
    InterlockedIncrement(&g_probe_count);
    if (InterlockedCompareExchange(&g_diagnose, 0, 0) != 0) {
        // _ReturnAddress() here is the watchdog's own call site.
        char who[64];
        attribute(reinterpret_cast<uintptr_t>(_ReturnAddress()), who, sizeof(who));
        FVEM_LOGF("[fvem] watchdog: probe %s from %s (suppressed)", api, who);
    }
}

LRESULT WINAPI hooked_send_message_timeout_w(HWND hwnd, UINT msg, WPARAM wp,
                                             LPARAM lp, UINT flags, PDWORD_PTR result) {
    if (is_hang_probe(hwnd, msg, flags)) {
        note_probe("SendMessageTimeoutW");
        if (result) *result = 0;
        return TRUE; // report success: the window is alive as far as anyone knows
    }
    return g_orig_smt_w(hwnd, msg, wp, lp, flags, result);
}

LRESULT WINAPI hooked_send_message_timeout_a(HWND hwnd, UINT msg, WPARAM wp,
                                             LPARAM lp, UINT flags, PDWORD_PTR result) {
    if (is_hang_probe(hwnd, msg, flags)) {
        note_probe("SendMessageTimeoutA");
        if (result) *result = 0;
        return TRUE;
    }
    return g_orig_smt_a(hwnd, msg, wp, lp, flags, result);
}

// The blocking forms are rarely the watchdog's probe (it uses the timeout
// variant precisely so it cannot block), but some builds shell out to them and
// a naked SendMessage to a stalled window is an instant hang. Answer null
// messages directly and forward everything else.
LRESULT WINAPI hooked_send_message_w(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    if (msg == WM_NULL && (!g_game_window || !hwnd || hwnd == g_game_window)) {
        InterlockedIncrement(&g_sm_count);
        return 0;
    }
    return g_orig_sm_w(hwnd, msg, wp, lp);
}

LRESULT WINAPI hooked_send_message_a(HWND hwnd, UINT msg, WPARAM wp, LPARAM lp) {
    if (msg == WM_NULL && (!g_game_window || !hwnd || hwnd == g_game_window)) {
        InterlockedIncrement(&g_sm_count);
        return 0;
    }
    return g_orig_sm_a(hwnd, msg, wp, lp);
}

BOOL WINAPI hooked_is_hung_app_window(HWND hwnd) {
    if (!g_game_window || !hwnd || hwnd == g_game_window) {
        InterlockedIncrement(&g_iha_count);
        return FALSE; // "not hung" - the direct answer to the question asked
    }
    return g_orig_iha(hwnd);
}

// ===========================================================================
// LAYER 2 - watchdog thread park
// ===========================================================================

// Is the thread currently blocked inside ntdll? Suspending a thread that is
// mid-allocation or holding the loader lock is how you convert a stall into a
// deadlock, so the park is gated on the RIP being inside ntdll's wait path.
bool parked_in_ntdll(HANDLE thread) {
    if (!g_ntdll_lo) return false;
    CONTEXT ctx{};
    ctx.ContextFlags = CONTEXT_CONTROL;
    if (!GetThreadContext(thread, &ctx)) return false;
    uintptr_t rip = static_cast<uintptr_t>(ctx.Rip);
    if (rip < g_ntdll_lo || rip >= g_ntdll_hi) return false;

    // ntdll wait primitives: NtWaitForSingleObject / NtWaitForMultipleObjects /
    // NtDelayExecution / NtUserGetMessage. RVA slots drift per Windows build,
    // so identify by the syscall prologue rather than a fixed offset: a
    // "mov r10, rcx" (4C 8B D1) immediately before the stub body.
    __try {
        const uint8_t* p = reinterpret_cast<const uint8_t*>(rip);
        for (int back = 0; back < 48; ++back) {
            if (p[-back] == 0x4C && p[-back + 1] == 0x8B && p[-back + 2] == 0xD1)
                return true;
        }
    } __except (probe_filter(GetExceptionCode(), GetExceptionInformation())) {
        return false;
    }
    return false;
}

void suspend_thread_crt_safe(DWORD tid) {
    HANDLE t = OpenThread(THREAD_SUSPEND_RESUME | THREAD_GET_CONTEXT | THREAD_QUERY_INFORMATION,
                          FALSE, tid);
    if (!t) {
        FVEM_LOGF("[fvem] watchdog: cannot open thread %lu (err %lu)", tid, GetLastError());
        return;
    }
    // PROBE-PARK. SuspendThread returns the PREVIOUS suspend count.
    //   prev >= 1  -> already parked (by us): the single ResumeThread below
    //                 unwinds this probe only and the thread stays parked at
    //                 its real count. No accumulation, ever.
    //   prev == 0  -> we just froze a RUNNING thread: GetThreadContext is now
    //                 well-defined (it is NOT reliable against a running
    //                 thread, which the old flow called before suspending).
    //                 Park it only if its RIP sits inside an ntdll wait
    //                 stub; otherwise undo and leave it alone.
    // The old blind re-suspend every scan stacked the count 4, 5, 6 ... 23
    // (visible in the runtime log seconds before death): nothing could ever
    // resume the thread, FiveM's own supervisor concluded the watchdog was
    // dead, and the client fail-fasted ~2 minutes in. That is the exact
    // signature we are removing.
    DWORD prev = SuspendThread(t);
    if (prev == static_cast<DWORD>(-1)) { CloseHandle(t); return; }
    if (prev >= 1) { ResumeThread(t); CloseHandle(t); return; }  // still parked
    if (!parked_in_ntdll(t)) {
        ResumeThread(t);
        FVEM_LOGF("[fvem] watchdog: thread %lu not parked in ntdll, leaving it alone", tid);
        CloseHandle(t);
        return;
    }
    FVEM_LOGF("[fvem] watchdog: thread %lu parked cleanly (count 0 -> 1)", tid);
    CloseHandle(t);
}

// Find the watchdog thread. Primary key is the thread description FiveM sets
// ("Window Watchdog"/"FiveM Window Watchdog"); the fallback accepts any thread
// whose start address is in the launcher image and whose stack holds the
// "stopped responding" literal - that survives a rename.
DWORD find_watchdog_thread(bool allow_heuristic) {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
    if (snap == INVALID_HANDLE_VALUE) return 0;
    const DWORD me = GetCurrentProcessId();

    DWORD found = 0, heuristic = 0;
    THREADENTRY32 te{};
    te.dwSize = sizeof(te);
    if (Thread32First(snap, &te)) {
        do {
            if (te.th32OwnerProcessID != me) continue;
            if (te.th32ThreadID == GetCurrentThreadId()) continue;

            HANDLE t = OpenThread(THREAD_QUERY_LIMITED_INFORMATION, FALSE, te.th32ThreadID);
            if (!t) continue;

            wchar_t desc[128]{};
            BOOL have = FALSE;
            typedef HRESULT (WINAPI* _GetThreadDescription)(HANDLE, PWSTR*);
            static _GetThreadDescription pGetDesc = nullptr;
            if (!pGetDesc) {
                pGetDesc = reinterpret_cast<_GetThreadDescription>(
                    GetProcAddress(GetModuleHandleW(L"kernel32.dll"), "GetThreadDescription"));
            }
            PWSTR raw = nullptr;
            if (pGetDesc && SUCCEEDED(pGetDesc(t, &raw)) && raw) {
                have = TRUE;
                int i = 0;
                for (; raw[i] && i < 127; ++i) desc[i] = raw[i];
                desc[i] = 0;
                LocalFree(raw);
            }

            if (have) {
                // Case-insensitive search for "watchdog" without CRT.
                for (int i = 0; desc[i]; ++i) {
                    wchar_t c = desc[i];
                    if (c >= L'A' && c <= L'Z') c = static_cast<wchar_t>(c + 32);
                    if (c == L'w' && (desc[i+1] == L'a' || desc[i+1] == L'A')) {
                        const wchar_t* w = L"watchdog";
                        int k = 0;
                        while (w[k]) {
                            wchar_t d = desc[i + k];
                            if (d >= L'A' && d <= L'Z') d = static_cast<wchar_t>(d + 32);
                            if (d != w[k]) break;
                            ++k;
                        }
                        if (!w[k]) { found = te.th32ThreadID; }
                        break;
                    }
                }
                if (found) {
                    FVEM_LOGF("[fvem] watchdog: matched by description on tid %lu", found);
                    CloseHandle(t);
                    break;
                }
            }

            if (allow_heuristic && !heuristic && g_launcher_lo) {
                CONTEXT ctx{};
                ctx.ContextFlags = CONTEXT_CONTROL;
                if (GetThreadContext(t, &ctx)) {
                    uintptr_t rip = static_cast<uintptr_t>(ctx.Rip);
                    if (rip >= g_launcher_lo && rip < g_launcher_hi)
                        heuristic = te.th32ThreadID;
                }
            }
            CloseHandle(t);
        } while (Thread32Next(snap, &te));
    }
    CloseHandle(snap);

    if (!found && heuristic) {
        FVEM_LOGF("[fvem] watchdog: no description match; heuristic tid %lu", heuristic);
        found = heuristic;
    }
    return found;
}

// ===========================================================================
// LAYER 3 - early-exit trap suppression
// ===========================================================================
//
// Two trap signatures are observed in the crash dumps, and both make the
// process fault DELIBERATELY after the watchdog verdict:
//
//   A. EXECUTE fault in the launcher image (ExceptionInformation[0] == 8).
//      The classic path: the launcher jumps a non-executable page.
//   B. READ/WRITE fault at the sentinel address 0xDEED (observed on the
//      b3751-era client: 0xC0000005, read @ 0xDEED, at
//      citizen-devtools.dll+0x2CCD6 Ã¢â‚¬â€ identical RVA and address in every
//      dump we captured). The watchdog kills through a devtools module
//      dereferencing a poisoned 0xDEED pointer, not through the launcher.
//
// The revive page holds "xor eax,eax; ret": jumping Rip there makes the trap
// function return 0 to its caller instead of taking the process down. Only
// faults matching one of the two signatures are revived, and only once the
// watchdog has been seen Ã¢â‚¬â€ a genuine crash in game code still propagates
// untouched.
// Defined below with L4; forward-declared so the trap layer can use it.
[[noreturn]] void park_thread_forever();

// Per-thread strike counter for KILL-DECISION faults (execute traps into the
// launcher's trap stubs + fastfail family). Evidence from the 23:31 session:
// 14,100 revives in ~90 s at exe+0x1688/0x16CC - the ret-revive returned the
// killer thread into its own kill loop (a trap stub is a JUMP target: ret pops
// the WRONG frame's return address, which is how a "revived" session then
// died for real with gta-streaming-five.dll+727BD on the stack - the
// quiet-princess-dakota signature). A thread that executes a deliberate trap
// stub is making a kill decision, so the decision-maker is retired instead of
// bounced: park on first strike (main thread excepted: it may trap as a
// last-resort suicide and freezing it is a worse failure than one bounce;
// give it 32 strikes before parking too).
namespace {
struct strike_slot { volatile LONG tid; volatile LONG n; };
strike_slot g_strikes[16] = {};

LONG note_kill_strike(DWORD tid) {
    for (int i = 0; i < 16; ++i) {
        LONG cur = InterlockedCompareExchange(&g_strikes[i].tid, 0, 0);
        if (cur == 0) {
            InterlockedCompareExchange(&g_strikes[i].tid, static_cast<LONG>(tid), 0);
            cur = InterlockedCompareExchange(&g_strikes[i].tid, 0, 0);
        }
        if (cur == static_cast<LONG>(tid))
            return InterlockedIncrement(&g_strikes[i].n);
    }
    return 1000;  // table full: treat the caller as a repeat offender
}

// Retire a kill-decision thread. MAIN gets a CAPPED bounce instead: field-
// proven twice - bouncing main forever derailed it (19:31 dump: write 0x0 ->
// exec 0x1B), parking main guarantees the "stopped responding (script
// deadloop) - vMenu: activated <- root" dialog (01:49 session: PARK ...
// site=+0x1028 main=1 -> frozen frame loop). Two bounces give FiveM's own
// handlers a chance to take over; past that a main stuck in the kill loop is
// parked like any other decision-maker. The import-thunk probe in trap_veh
// runs BEFORE this call and is the real fix for the main=1 case: several of
// these low-RVA "traps" are FiveM's OWN thunk-trap dispatches (12/64/68-byte
// RVA strides, three unrelated threads incl. main) whose completion is
// FiveM's handlers' business - stealing them froze or derailed victims.
void retire_or_bounce(EXCEPTION_RECORD* er, CONTEXT* cr,
                      const char* kind, uintptr_t rip) {
    const DWORD tid = GetCurrentThreadId();
    const LONG  n   = note_kill_strike(tid);
    const bool  is_main = (g_main_tid && tid == g_main_tid);
    InterlockedIncrement(&g_trap_revives);
    FVEM_LOGF("[fvem] watchdog: PARK %s tid=%lu site=+0x%llX strike=%ld main=%d code=0x%X",
              kind, tid,
              static_cast<unsigned long long>(rip - g_launcher_lo), n,
              is_main ? 1 : 0, er->ExceptionCode);
    if (is_main && n <= 2 && g_revive_page) {
        cr->Rip = reinterpret_cast<DWORD64>(g_revive_page);  // bounce, capped
        return;
    }
    park_thread_forever();
}

// --- Import-thunk trap discriminator ----------------------------------------
// A "kill decision" thread JUMPS into a NOACCESS/zero-filled stub and must be
// retired. But an EXECUTE fault whose target bytes are readable and decode as
// classic thunk shapes (FF 25 jmp [mem] / FF 15 call [mem] / 68 imm32 E9) is
// FiveM's own import/CFG trap dispatch - the game's handlers are built to
// complete it, and the correct answer is EXCEPTION_CONTINUE_SEARCH so THEIR
// chain runs. Our first-position VEH stealing those froze main (the 01:49
// session's PARK main=1 at +0x1028 -> vMenu deadloop dialog) and livelocked
// the +0x1688 storm (bounced legit per-call dispatches forever).
bool probe_thunk(uintptr_t rip, uint8_t out[16]) {
    SIZE_T rd = 0;
    if (!ReadProcessMemory(GetCurrentProcess(), reinterpret_cast<void*>(rip),
                           out, 16, &rd) || rd < 16)
        return false;                       // page unreadable: true NOACCESS trap
    if (out[0] == 0xFF &&
        (out[1] == 0x25 || out[1] == 0x15 || out[1] == 0x1D))
        return true;                        // jmp/call [rip+disp] or [abs]
    if (out[0] == 0x68 && out[5] == 0xE9)
        return true;                        // push imm32; jmp near (bound thunk)
    return false;                           // zero-filled / CC padding: a trap
}
} // namespace

LONG NTAPI trap_veh(EXCEPTION_POINTERS* ep) {
    auto* er = ep->ExceptionRecord;
    auto* cr = ep->ContextRecord;
    if (!er || !cr) return EXCEPTION_CONTINUE_SEARCH;

    // C/D family: EARLY-EXIT TRAP is __fastfail (int 29h -> 0xC0000409), plus
    // the illegal/privileged-instruction and breakpoint variants FiveM's
    // loaders have used. The old filter returned CONTINUE_SEARCH on anything
    // that was not 0xC0000005, so every deliberate fastfail walked straight
    // into the fatal dialog WITH THE SUPPRESSOR ARMED - the +101C/+1028
    // deaths. Scope: first 64 KB of the launcher image (the trap-stub block;
    // the game's own /GS fastfails live at higher RVAs and still crash
    // normally).
    if (er->ExceptionCode != 0xC0000005u) {
        const DWORD     c2 = er->ExceptionCode;
        const uintptr_t r2 = static_cast<uintptr_t>(cr->Rip);
        const bool trap_block =
            r2 >= g_launcher_lo && r2 < (g_launcher_lo + 0x10000ull);
        const bool fatal_family =
            (c2 == 0xC0000409u || c2 == 0xC000001Du ||
             c2 == 0xC0000096u || c2 == 0x80000003u);
        if (trap_block && fatal_family && g_revive_page &&
            InterlockedCompareExchange(&g_trap_armed, 0, 0) != 0) {
            // Kill decision, not a crash: the deciding thread is retired
            // (park) instead of bounced back into its kill loop.
            retire_or_bounce(er, cr, "kill-request (fastfail stub)", r2);
            return EXCEPTION_CONTINUE_EXECUTION;  // unreachable: retire parks
        }
        return EXCEPTION_CONTINUE_SEARCH;
    }
    if (er->NumberParameters < 2) return EXCEPTION_CONTINUE_SEARCH;
    // The revive page is only allocated when suppress_trap was requested. Without
    // this guard a session that armed the trap but skipped the page would set Rip
    // to null and turn a survivable trap into a hard crash.
    if (!g_revive_page) return EXCEPTION_CONTINUE_SEARCH;
    if (InterlockedCompareExchange(&g_trap_armed, 0, 0) == 0)
        return EXCEPTION_CONTINUE_SEARCH; // trap not expected in this session

    const uintptr_t rip  = static_cast<uintptr_t>(cr->Rip);
    const uintptr_t op   = er->ExceptionInformation[0];
    const uintptr_t addr = er->ExceptionInformation[1];

    // A. launcher execute-fault Ã¢â‚¬â€ require the faulting RIP inside the launcher.
    const bool launcher_exec =
        (op == 8) && rip >= g_launcher_lo && rip < (g_launcher_lo + 0x10000ull);

    // B. sentinel-address read/write Ã¢â‚¬â€ the b3751 trap dereferences 0xDEED.
    //    0xDEED is a deliberate constant; no legitimate game path touches that
    //    exact address, so gate purely on the sentinel (module is irrelevant).
    const bool sentinel_rw = (op == 1 || op == 2) && addr == 0xDEED;

    // B2. POST-REFUSAL FAIL-FAST (proven from the 22:42 minidump: the refused
    //     terminate thread then executed a deliberate null-base write -
    //     "write to 0x10 at exe+0x245D01" ~0ms after we returned from the
    //     hook). TerminateProcess that RETURNS is unexpected to its caller:
    //     FiveM's post-terminate path is a fail-fast corruption step. L4 now
    //     parks the caller so it never resumes - but sibling death paths
    //     exist that skip terminate entirely. A WRITE to a page-zero object
    //     (addr < 0x1000) from inside the exe body is never recoverable game
    //     logic (it IS the crash), so reviving beats the dialog outright.
    const bool failfast_low_write =
        (op == 1 || op == 2) && addr < 0x1000 &&
        rip >= g_launcher_lo && rip < g_launcher_hi;

    if (!launcher_exec && !sentinel_rw && !failfast_low_write)
        return EXCEPTION_CONTINUE_SEARCH;

    // A. Execute-trap stub = a KILL DECISION, not a crash: the thread jumped
    //    into the launcher's non-executable trap page on purpose. Retiring it
    //    (park) is the only safe response: `ret` here pops the WRONG frame
    //    (a stub is a jump target, not a call target) and hands the killer
    //    thread back to its kill loop. Both proven tonight: the 14,100-strike
    //    storm at exe+0x1688 (bounce -> re-trap forever), and the streaming
    //    crash (gta-streaming-five+727BD) after bad-frame returns corrupted
    //    execution. Main parks too (a bounced main is a derailed main).
    //    UPDATED (01:49 session evidence): main PARKED at +0x1028 froze the
    //    frame loop -> "script deadloop (vMenu: activated)" dialog. And the
    //    low-RVA stride pattern (0x101C/0x1028/0x1050, 0x1688/0x16CC) is
    //    thunk-table cadence. Hence the probe first: readable thunk-shaped
    //    bytes mean FiveM's OWN trap dispatch -> hand it back to their
    //    handler chain untouched (CONTINUE_SEARCH). Zero/CC/NOACCESS pages
    //    remain true kill traps -> retire (with the capped main bounce).
    if (launcher_exec) {
        uint8_t bytes[16]{};
        const bool thunk = probe_thunk(rip, bytes);
        static LONG s_exec_probe = 0;
        const LONG pn = InterlockedIncrement(&s_exec_probe);
        if (pn <= 6)
            FVEM_LOGF("[fvem] watchdog: exec-trap #%ld site=+0x%llX tid=%lu "
                      "readable-thunk=%d bytes=%X %X %X %X %X %X",
                      pn, static_cast<unsigned long long>(rip - g_launcher_lo),
                      GetCurrentThreadId(), thunk ? 1 : 0,
                      (unsigned)bytes[0], (unsigned)bytes[1], (unsigned)bytes[2],
                      (unsigned)bytes[3], (unsigned)bytes[4], (unsigned)bytes[5]);
        if (thunk) return EXCEPTION_CONTINUE_SEARCH;
        retire_or_bounce(er, cr, "kill-request (exec trap stub)", rip);
        return EXCEPTION_CONTINUE_EXECUTION;   // park; bounce only main<=2
    }

    // B / B2. DATA faults (0xDEED sentinel read, page-zero fail-fast write).
    // On the MAIN thread these are derailment cascades (the 19:31 dump: main
    // wrote 0x0 mid-corruption after a bounced trap) - bouncing dug deeper.
    // Main parks. A worker gets the ret-abort (real return address on stack,
    // aborting one function keeps the subsystem alive), but a worker repeating
    // >8 times is livelocking and is parked too.
    const DWORD dtid = GetCurrentThreadId();
    const bool  dmain = (g_main_tid && dtid == g_main_tid);
    const LONG  dn    = note_kill_strike(dtid);
    InterlockedIncrement(&g_trap_revives);
    if ((dmain && dn > 2) || (!dmain && dn > 8)) {
        FVEM_LOGF("[fvem] watchdog: PARK data-trap tid=%lu rip=%p addr=0x%llX strike=%ld main=%d",
                  dtid, reinterpret_cast<void*>(rip),
                  static_cast<unsigned long long>(addr), dn, dmain ? 1 : 0);
        park_thread_forever();
    }
    FVEM_LOGF("[fvem] watchdog: revived data trap 0x%X op=%lu rip=%p addr=0x%llX (total %ld)",
              er->ExceptionCode, static_cast<unsigned long>(op),
              reinterpret_cast<void*>(rip),
              static_cast<unsigned long long>(addr),
              InterlockedCompareExchange(&g_trap_revives, 0, 0));
    cr->Rip = reinterpret_cast<DWORD64>(g_revive_page);
    return EXCEPTION_CONTINUE_EXECUTION;
}

bool install_trap_suppressor() {
    g_revive_page = static_cast<uint8_t*>(
        VirtualAlloc(nullptr, 0x1000, MEM_COMMIT | MEM_RESERVE, PAGE_EXECUTE_READWRITE));
    if (!g_revive_page) {
        FVEM_LOGF("[fvem] watchdog: revive page alloc failed");
        return false;
    }
    // 31 C0        xor eax, eax
    // C3           ret
    g_revive_page[0] = 0x31;
    g_revive_page[1] = 0xC0;
    g_revive_page[2] = 0xC3;
    FlushInstructionCache(GetCurrentProcess(), g_revive_page, 3);

    // F1 (UNDETECTED_FULL_PLAN): the page is written exactly once, here.
    // RWX private memory is the signature the memory-only posture exists to
    // avoid — drop to RX for the page's remaining life. Every later touch is
    // execution-only (retire_or_bounce sets Rip to it; nothing writes it).
    {
        DWORD rx_old = 0;
        VirtualProtect(g_revive_page, 0x1000, PAGE_EXECUTE_READ, &rx_old);
    }

    g_veh = AddVectoredExceptionHandler(1 /* first */, trap_veh);
    if (!g_veh) {
        FVEM_LOGF("[fvem] watchdog: AddVectoredExceptionHandler failed (err %lu)",
                      GetLastError());
        return false;
    }
    // Arm IMMEDIATELY, not "once a window probe is observed". The probe layers
    // answer the hang probes themselves, so a session whose verdict comes from
    // the game's main-thread heartbeat (not a probe timeout) never increments
    // g_probe_count - and the un-armed suppressor let the +0x101C execute
    // fault reach FiveM's fatal dialog. Safety does not depend on the delay:
    // trap_veh only revives an execute fault (op==8) whose RIP is inside the
    // tiny launcher image - no genuine game crash matches that signature.
    InterlockedExchange(&g_trap_armed, 1);
    FVEM_LOGF("[fvem] watchdog: trap suppressor armed (revive page %p)",
                  static_cast<void*>(g_revive_page));
    return true;
}

// ===========================================================================
// LAYER 1b - win32u choke point
// ===========================================================================
//
// user32's SendMessage* family funnels into win32u!NtUserMessageCall. Hooking
// the user32 exports covers everything that goes through the documented API,
// but not code that calls the win32u entry directly (or a FiveM build that
// links against win32u). This is the single choke point underneath all of it:
// a WM_NULL arriving here is a liveness probe no matter which door it came
// through, so the answer is generated at the bottom rather than guessed at the
// top.
//
// The result pointer is deliberately left untouched. Its meaning depends on
// the FNID in `type`, and writing a DWARF pointer we mis-identified would
// corrupt the caller's stack. Returning non-zero is sufficient: the probe only
// ever reads the BOOL.
using nt_user_message_call_fn = LRESULT (WINAPI*)(HWND, UINT, WPARAM, LPARAM,
                                                  ULONG_PTR, ULONG, BOOL);
nt_user_message_call_fn g_orig_nt_user_message_call = nullptr;

LRESULT WINAPI hooked_nt_user_message_call(HWND hwnd, UINT msg, WPARAM wp,
                                           LPARAM lp, ULONG_PTR result_info,
                                           ULONG type, BOOL ansi) {
    if (msg == WM_NULL && (!g_game_window || !hwnd || hwnd == g_game_window)) {
        InterlockedIncrement(&g_probe_count);
        if (InterlockedCompareExchange(&g_diagnose, 0, 0) != 0) {
            char who[64];
            attribute(reinterpret_cast<uintptr_t>(_ReturnAddress()), who, sizeof(who));
            FVEM_LOGF("[fvem] watchdog: probe NtUserMessageCall from %s "
                          "(type 0x%X, suppressed)", who, static_cast<unsigned>(type));
        }
        return 1;
    }
    return g_orig_nt_user_message_call(hwnd, msg, wp, lp, result_info, type, ansi);
}

// ===========================================================================
// LAYER 4 - kill interceptor
// ===========================================================================
//
// If every probe layer above missed, the watchdog's last act is to take the
// process down itself. Both paths - kernel32!TerminateProcess and the
// ntdll!NtTerminateProcess underneath it - are refused here when they are a
// self-terminate from a thread that is not the main thread.
//
// REFUSED CALLS NEVER RETURN. Proven from the 22:42/22:43 minidumps
// (lion-november-nevada): exception thread 13080 was the SAME thread the log
// shows us refusing ("refused self-terminate #1 ... tid 13080") - we returned
// success, and ~0ms later that thread executed a DELIBERATE null-base write
// (write to 0x10 at GTA5_b3751.exe+0x245D01). TerminateProcess that "fails"
// is unexpected to the caller: FiveM's post-terminate path is a fail-fast
// corruption step, exactly like the +101C/+1028 traps. A terminate that the
// caller believes succeeded must behave like the real API: it never resumes
// the caller. We park the thread forever instead - which is also the
// legitimate fate of a watchdog thread that just tried to kill the process.
// The CRT-safe note: parking happens on the CALLER's own thread, so unlike
// L2's cross-thread SuspendThread this never stacks a suspend count.
//
// The main thread is never blocked: that is the game's own clean-shutdown path
// and refusing it would leave an unkillable process. There is also a hard
// give-up valve: after kKillGiveUp refusals the interceptor disarms itself, so
// a genuinely wedged client still dies instead of becoming a zombie that only
// Task Manager can remove.
constexpr LONG kKillGiveUp = 64;

[[noreturn]] void park_thread_forever() {
    for (;;) Sleep(60000);  // Sleep never touches CRT state
}

bool is_self_handle(HANDLE h) {
    if (h == nullptr) return true;                       // NtCurrentProcess()
    if (h == reinterpret_cast<HANDLE>(static_cast<INT_PTR>(-1))) return true;
    return h == GetCurrentProcess();
}

bool should_block_kill() {
    if (InterlockedCompareExchange(&g_kill_block, 0, 0) == 0) return false;

    const DWORD cur = GetCurrentThreadId();
    // Never refuse the main thread: that is a legitimate shutdown.
    if (g_main_tid && cur == g_main_tid) return false;

    const LONG n = InterlockedIncrement(&g_kill_count);
    if (n > kKillGiveUp) {
        if (n == kKillGiveUp + 1) {
            InterlockedExchange(&g_kill_block, 0);
            FVEM_LOGF("[fvem] watchdog: kill interceptor disarmed after %ld "
                          "refusals - letting the process exit", n - 1);
        }
        return false;
    }

    char who[64];
    attribute(reinterpret_cast<uintptr_t>(_ReturnAddress()), who, sizeof(who));
    FVEM_LOGF("[fvem] watchdog: refused self-terminate #%ld from %s (tid %lu)",
                  n, who, cur);
    return true;
}

using nt_terminate_fn = NTSTATUS (WINAPI*)(HANDLE, NTSTATUS);
using terminate_fn    = BOOL     (WINAPI*)(HANDLE, UINT);
nt_terminate_fn g_orig_nt_terminate = nullptr;
terminate_fn    g_orig_terminate    = nullptr;

NTSTATUS WINAPI hooked_nt_terminate_process(HANDLE proc, NTSTATUS code) {
    if (is_self_handle(proc) && should_block_kill())
        park_thread_forever();  // never returns: a real terminate never does
    return g_orig_nt_terminate(proc, code);
}

BOOL WINAPI hooked_terminate_process(HANDLE proc, UINT code) {
    if (is_self_handle(proc) && should_block_kill())
        park_thread_forever();  // never returns: a real terminate never does
    return g_orig_terminate(proc, code);
}

// ===========================================================================
// Hook registry + self-heal
// ===========================================================================
//
// Anything that walks the export table and restores original bytes - an
// integrity check, a driver, another injected module - silently disarms a
// layer. The registry lets shield_tick() notice and re-apply, without needing
// to know who undid it.
struct hook_ref {
    const char* module;
    const char* name;
    void*       hook;
    void**      original;
    void*       target;      // resolved at install
    bool        installed;
};

hook_ref g_refs[] = {
    { "user32.dll", "SendMessageTimeoutW", reinterpret_cast<void*>(&hooked_send_message_timeout_w),
      reinterpret_cast<void**>(&g_orig_smt_w), nullptr, false },
    { "user32.dll", "SendMessageTimeoutA", reinterpret_cast<void*>(&hooked_send_message_timeout_a),
      reinterpret_cast<void**>(&g_orig_smt_a), nullptr, false },
    { "user32.dll", "SendMessageW",        reinterpret_cast<void*>(&hooked_send_message_w),
      reinterpret_cast<void**>(&g_orig_sm_w),  nullptr, false },
    { "user32.dll", "SendMessageA",        reinterpret_cast<void*>(&hooked_send_message_a),
      reinterpret_cast<void**>(&g_orig_sm_a),  nullptr, false },
    { "user32.dll", "IsHungAppWindow",     reinterpret_cast<void*>(&hooked_is_hung_app_window),
      reinterpret_cast<void**>(&g_orig_iha),   nullptr, false },
    { "win32u.dll", "NtUserMessageCall",   reinterpret_cast<void*>(&hooked_nt_user_message_call),
      reinterpret_cast<void**>(&g_orig_nt_user_message_call), nullptr, false },
    { "ntdll.dll",  "NtTerminateProcess",  reinterpret_cast<void*>(&hooked_nt_terminate_process),
      reinterpret_cast<void**>(&g_orig_nt_terminate), nullptr, false },
    { "kernel32.dll", "TerminateProcess",  reinterpret_cast<void*>(&hooked_terminate_process),
      reinterpret_cast<void**>(&g_orig_terminate), nullptr, false },
};
constexpr int kRefCount = static_cast<int>(sizeof(g_refs) / sizeof(g_refs[0]));

// Layer 1b owns index 5; layer 4 owns 6 and 7. shield_install gates them.
bool ref_enabled(int i) {
    if (i == 5) return InterlockedCompareExchange(&g_win32u_on, 0, 0) != 0;
    if (i >= 6) return InterlockedCompareExchange(&g_kill_block, 0, 0) != 0;
    return InterlockedCompareExchange(&g_user32_on, 0, 0) != 0;
}

int install_enabled_refs(bool log_each) {
    int ok = 0;
    for (int i = 0; i < kRefCount; ++i) {
        if (!ref_enabled(i)) continue;
        if (g_refs[i].installed && detour::is_installed(g_refs[i].target)) { ++ok; continue; }

        if (!g_refs[i].target) {
            HMODULE m = GetModuleHandleA(g_refs[i].module);
            if (!m) {
                if (log_each) FVEM_LOGF("[fvem] watchdog: %s not loaded", g_refs[i].module);
                continue;
            }
            g_refs[i].target = reinterpret_cast<void*>(GetProcAddress(m, g_refs[i].name));
            if (!g_refs[i].target) {
                if (log_each) FVEM_LOGF("[fvem] watchdog: %s!%s not exported",
                                            g_refs[i].module, g_refs[i].name);
                continue;
            }
        }

        if (detour::install(g_refs[i].target, g_refs[i].hook, g_refs[i].original)) {
            g_refs[i].installed = true;
            ++ok;
            if (log_each) {
                FVEM_LOGF("[fvem] watchdog: hooked %s!%s at %p",
                              g_refs[i].module, g_refs[i].name, g_refs[i].target);
            }
        } else if (log_each) {
            FVEM_LOGF("[fvem] watchdog: REFUSED %s!%s at %p",
                          g_refs[i].module, g_refs[i].name, g_refs[i].target);
        }
    }
    return ok;
}

} // namespace

// ===========================================================================
// Public surface
// ===========================================================================

bool shield_install(HWND game_window, const ShieldOptions& opt) {
    if (g_installed) return true;
    g_game_window = game_window;
    if (opt.diagnose) InterlockedExchange(&g_diagnose, 1);

    HMODULE ntdll = GetModuleHandleW(L"ntdll.dll");
    if (ntdll) {
        auto* dos = reinterpret_cast<IMAGE_DOS_HEADER*>(ntdll);
        auto* h = reinterpret_cast<IMAGE_NT_HEADERS64*>(
            reinterpret_cast<uintptr_t>(ntdll) + dos->e_lfanew);
        g_ntdll_lo = reinterpret_cast<uintptr_t>(ntdll);
        g_ntdll_hi = g_ntdll_lo + h->OptionalHeader.SizeOfImage;
    }

    HMODULE launcher = GetModuleHandleW(nullptr);
    if (launcher) {
        auto* dos = reinterpret_cast<IMAGE_DOS_HEADER*>(launcher);
        auto* h = reinterpret_cast<IMAGE_NT_HEADERS64*>(
            reinterpret_cast<uintptr_t>(launcher) + dos->e_lfanew);
        g_launcher_lo = reinterpret_cast<uintptr_t>(launcher);
        g_launcher_hi = g_launcher_lo + h->OptionalHeader.SizeOfImage;
    }

    capture_modules();
    FVEM_LOGF("[fvem] watchdog: install (ntdll %p-%p, launcher %p-%p, %d modules)",
                  reinterpret_cast<void*>(g_ntdll_lo), reinterpret_cast<void*>(g_ntdll_hi),
                  reinterpret_cast<void*>(g_launcher_lo), reinterpret_cast<void*>(g_launcher_hi),
                  g_mod_count);

    // Arm the layer flags BEFORE the registry runs: ref_enabled() reads them,
    // and install_enabled_refs() is also what the self-heal pass calls later,
    // so the same gate has to serve both entry points.
    InterlockedExchange(&g_user32_on, opt.hook_probes ? 1 : 0);
    InterlockedExchange(&g_win32u_on, opt.hook_win32u ? 1 : 0);
    InterlockedExchange(&g_kill_block, opt.block_kill ? 1 : 0);
    g_want_suspend = opt.suspend_thread;

    // The kill interceptor refuses a self-terminate from any non-main thread.
    // Record the main thread now so its own clean shutdown is never refused.
    if (game_window) {
        g_main_tid = GetWindowThreadProcessId(game_window, nullptr);
        FVEM_LOGF("[fvem] watchdog: main thread tid %lu", g_main_tid);
    }

    const int hooked = install_enabled_refs(/*log_each=*/true);

    bool trap_ok = false;
    if (opt.suppress_trap) trap_ok = install_trap_suppressor();

    FVEM_LOGF("[fvem] watchdog: %d/%d hooks up, trap suppressor %s",
                  hooked, kRefCount, trap_ok ? "armed" : "off");
    if (hooked == 0 && !trap_ok) {
        FVEM_LOGF("[fvem] watchdog: NOTHING installed - bypass inactive");
        return false;
    }

    g_installed = true;

    // Diagnose mode: dump the thread inventory so the watchdog's description
    // string on this build is known up front rather than inferred from a
    // failed name match. This is the one call that answers "did layer 2 find
    // the right thread" without waiting for a crash.
    if (opt.diagnose) dump_process_threads();

    return true;
}

// Re-scope the probe interception once the game window is known. The shield
// installs with a null window (global probe scope) and this is called again
// after the Present hook resolves the real window, tightening the interception
// to the game window and recording the main-thread id for the kill
// interceptor (which must never refuse the game's own clean shutdown).
void shield_set_game_window(HWND hwnd) {
    if (hwnd) g_game_window = hwnd;
    if (g_game_window) {
        g_main_tid = GetWindowThreadProcessId(g_game_window, nullptr);
        FVEM_LOGF("[fvem] watchdog: rescoped to hwnd %p (main tid %lu)",
                      g_game_window, g_main_tid);
    }
}

// Called from the overlay loop (~2 Hz is plenty; both passes are throttled).
void shield_tick() {
    if (!g_installed) return;

    // Arm the trap suppressor as soon as the watchdog shows signs of life: from
    // that point an execute-fault in the launcher is the deliberate trap, not a
    // genuine game crash.
    if (g_revive_page && InterlockedCompareExchange(&g_probe_count, 0, 0) > 0)
        InterlockedExchange(&g_trap_armed, 1);

    static DWORD last_repair = 0;
    static DWORD last_scan   = 0;
    const DWORD now = GetTickCount();

    // --- self-heal -----------------------------------------------------------
    // Anything that walks the export table and restores original bytes silently
    // disarms a layer. Re-installing is cheap and idempotent, so poll rather
    // than try to detect who did it.
    if (now - last_repair >= 2000) {
        last_repair = now;
        for (int i = 0; i < kRefCount; ++i) {
            if (!ref_enabled(i) || !g_refs[i].installed) continue;
            if (detour::is_installed(g_refs[i].target)) continue;
            FVEM_LOGF("[fvem] watchdog: hook %s!%s was removed - repairing",
                          g_refs[i].module, g_refs[i].name);
            if (detour::install(g_refs[i].target, g_refs[i].hook, g_refs[i].original)) {
                InterlockedIncrement(&g_repair_count);
            } else {
                g_refs[i].installed = false; // stop retrying a target we cannot patch
                FVEM_LOGF("[fvem] watchdog: repair of %s!%s failed",
                              g_refs[i].module, g_refs[i].name);
            }
        }
    }

    // --- watchdog thread park ------------------------------------------------
    if (!g_want_suspend) return;
    if (now - last_scan < 5000) return;
    last_scan = now;

    // Re-park every scan instead of latching: a suspended thread can be resumed
    // by anything that holds a handle to it, and once the watchdog is running
    // again the whole probe layer is back to being the only thing standing
    // between a stall and the trap.
    DWORD tid = g_watchdog_tid ? g_watchdog_tid : find_watchdog_thread(true);
    if (!tid) return;

    suspend_thread_crt_safe(tid);
    if (InterlockedCompareExchange(&g_watchdog_parked, 1, 0) == 0) {
        g_watchdog_tid = tid;
        FVEM_LOGF("[fvem] watchdog: parked tid %lu (probes seen so far: %ld)",
                      tid, InterlockedCompareExchange(&g_probe_count, 0, 0));
    }
}

ShieldStatus shield_status() {
    ShieldStatus s{};
    for (int i = 0; i < kRefCount; ++i) {
        if (!g_refs[i].installed || !detour::is_installed(g_refs[i].target)) continue;
        if (i <= 4)      ++s.user32_hooks;
        else if (i == 5) ++s.win32u_hooks;
        else             ++s.kill_hooks;
    }
    s.thread_parked     = InterlockedCompareExchange(&g_watchdog_parked, 0, 0) != 0;
    s.trap_armed        = InterlockedCompareExchange(&g_trap_armed, 0, 0) != 0;
    s.probes_suppressed = InterlockedCompareExchange(&g_probe_count, 0, 0);
    s.kills_blocked     = InterlockedCompareExchange(&g_kill_count, 0, 0);
    s.traps_revived     = InterlockedCompareExchange(&g_trap_revives, 0, 0);
    s.hooks_repaired    = InterlockedCompareExchange(&g_repair_count, 0, 0);
    s.watchdog_tid      = g_watchdog_tid;
    s.main_tid          = g_main_tid;
    return s;
}

void dump_process_threads() {
    HANDLE snap = CreateToolhelp32Snapshot(TH32CS_SNAPTHREAD, 0);
    if (snap == INVALID_HANDLE_VALUE) return;
    const DWORD me = GetCurrentProcessId();
    int n = 0;
    THREADENTRY32 te{};
    te.dwSize = sizeof(te);
    if (Thread32First(snap, &te)) {
        do {
            if (te.th32OwnerProcessID != me) continue;
            ++n;
            char who[64] = "(no desc)";
            wchar_t desc[128]{};
            HANDLE t = OpenThread(THREAD_QUERY_LIMITED_INFORMATION, FALSE, te.th32ThreadID);
            typedef HRESULT (WINAPI* _GetThreadDescription)(HANDLE, PWSTR*);
            static _GetThreadDescription pGetDesc = nullptr;
            if (!pGetDesc) {
                pGetDesc = reinterpret_cast<_GetThreadDescription>(
                    GetProcAddress(GetModuleHandleW(L"kernel32.dll"), "GetThreadDescription"));
            }
            PWSTR raw = nullptr;
            if (t && pGetDesc && SUCCEEDED(pGetDesc(t, &raw)) && raw) {
                int i = 0;
                for (; raw[i] && i < 127; ++i) desc[i] = raw[i];
                desc[i] = 0;
                LocalFree(raw);
                int k = 0;
                for (; desc[k] && k < 63; ++k)
                    who[k] = (desc[k] < 0x80) ? static_cast<char>(desc[k]) : '?';
                who[k] = 0;
            }
            if (t) CloseHandle(t);
            FVEM_LOGF("[fvem] watchdog: thread %lu  %s", te.th32ThreadID, who);
        } while (Thread32Next(snap, &te));
    }
    CloseHandle(snap);
    FVEM_LOGF("[fvem] watchdog: %d threads in this process", n);
}

} // namespace gfx::watchdog
