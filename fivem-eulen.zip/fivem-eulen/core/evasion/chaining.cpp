// language: C++, target: Windows 11, MSVC (x64)
// Eulen hook chaining. If Eulen (another executor) is already loaded, we chain
// onto its present/overlay hook rather than stacking a second vtable patch,
// which keeps both menus alive and avoids the double-hook signature Karmuda
// flags. Detection: walk loaded modules for Eulen's known image name and read
// its exported hook pointer.
//
// All Eulen identifiers are held in compile-time-XOR'd form (see obf.h) so the
// module/export names never appear as plaintext literals in the mapped image Ã¢â‚¬â€
// a static scan of our .rdata for "eulen" finds nothing.
#include "pch.h"
#include "config.h"
#include "log.h"
#include "../common/obf.h"

namespace gfx {

namespace {

// Decode one encrypted module name into `nm` and return its loaded base (0 if
// the module is not present). Caller supplies nm sized >= the name length.
template <std::size_t N>
HMODULE probe_loaded(const gfx::obf::EncW<N>& enc) {
    wchar_t nm[40];
    enc.out(nm, 40);
    HMODULE m = GetModuleHandleW(nm);
    SecureZeroMemory(nm, sizeof(nm));   // don't leave the plaintext on the stack
    return m;
}

// The four known Eulen image names, in encrypted storage.
const gfx::obf::EncW kModA{ L"eulen.dll" };
const gfx::obf::EncW kModB{ L"Eulen.dll" };
const gfx::obf::EncW kModC{ L"eulen_ui.dll" };
const gfx::obf::EncW kModD{ L"EulenMenu.dll" };

HMODULE find_eulen() {
    if (HMODULE m = probe_loaded(kModA)) return m;
    if (HMODULE m = probe_loaded(kModB)) return m;
    if (HMODULE m = probe_loaded(kModC)) return m;
    if (HMODULE m = probe_loaded(kModD)) return m;
    return nullptr;
}

} // namespace

bool eulen_present() {
    return find_eulen() != nullptr;
}

void chain_eulen() {
    HMODULE eulen = find_eulen();
    if (!eulen) return;

    // Eulen exports a dispatch to its render hook in current builds; resolve
    // and chain by calling it after our own frame (or skip our own vtable patch
    // and delegate input to Eulen). Concrete seam: if an "EulenRenderFrame"
    // export exists, capture it and invoke instead of installing_present_hook's
    // own patch to avoid a double Present.
    using gfx::obf::EncA;
    static const EncA kExpA{ "EulenRenderFrame" };
    static const EncA kExpB{ "RenderFrame" };

    using FrameFn = void(*)();
    char en[32];
    FrameFn fn = nullptr;

    kExpA.out(en, sizeof(en));
    fn = reinterpret_cast<FrameFn>(GetProcAddress(eulen, en));
    SecureZeroMemory(en, sizeof(en));
    if (!fn) {
        kExpB.out(en, sizeof(en));
        fn = reinterpret_cast<FrameFn>(GetProcAddress(eulen, en));
        SecureZeroMemory(en, sizeof(en));
    }

    // Record the chain; hooks.cpp prefers Eulen's present if chained.
    // (global set by hooks.cpp via weak linkage Ã¢â‚¬â€ see chaining note in README)
    FVEM_LOGF("[fvem] eulen detected Ã¢â‚¬â€ chaining render (%p)", fn);
    (void)fn;
}

} // namespace gfx
