// language: C++, target: Windows 11, MSVC (x64)
// FiveM Window Watchdog - full bypass.
//
// Five layers, ordered by how much each one assumes about FiveM's internals.
// Each is independently toggleable; shield_status() reports which ones are up.
#pragma once
#include <windows.h>

namespace gfx::watchdog {

struct ShieldOptions {
    bool hook_probes    = true;   // L1a: user32 hang-probe detours
    bool hook_win32u    = true;   // L1b: win32u!NtUserMessageCall detour
    bool suspend_thread = true;   // L2 : park the watchdog thread
    bool suppress_trap  = true;   // L3 : revive the early-exit fault
    bool block_kill     = true;   // L4 : swallow a watchdog-issued self-kill
    bool diagnose       = false;  // log every probe with its caller
};

struct ShieldStatus {
    int           user32_hooks      = 0;  // of 5
    int           win32u_hooks      = 0;  // of 1
    int           kill_hooks        = 0;  // of 3
    bool          thread_parked     = false;
    bool          trap_armed        = false;
    long          probes_suppressed = 0;
    long          kills_blocked     = 0;
    long          traps_revived     = 0;
    long          hooks_repaired    = 0;
    unsigned long watchdog_tid      = 0;
    unsigned long main_tid          = 0;
};

// Install the shield. `game_window` scopes the probe interception and gives
// the main-thread id used by the kill interceptor. Returns true when at least
// one layer came up.
bool shield_install(HWND game_window, const ShieldOptions& opt);

// Re-scope the probe interception to the real game window once it is resolved.
// The shield can be installed BEFORE the window exists (null scope = global
// probe interception, safe: only WM_NULL hang-probes are answered). Call this
// again after the Present hook resolves the window; it also (re)records the
// game's main-thread id for the kill interceptor. Safe to call any time.
void shield_set_game_window(HWND hwnd);

// Periodic maintenance: verify every hook is still in place, re-park the
// watchdog thread if it was resumed, arm the trap suppressor once probes are
// observed. Cheap enough to call a few times a second; internally throttled.
void shield_tick();

// Snapshot of what is currently up. Safe to call from any thread.
ShieldStatus shield_status();

// Log every thread in this process with its description (diagnostics).
void dump_process_threads();

} // namespace gfx::watchdog