// language: C++, target: Windows 11, MSVC (x64)
// Karmuda evasion shim. Karmuda (FiveM's server/anticheat ecosystem) and
// common EDR look for: nameless threads, RWX regions, injection threads,
// modified module memory, and LoadLibrary history. This shim neutralizes the
// tell-tale signals our manual-mapper leaves behind.
#include "pch.h"
#include "config.h"
#include <intrin.h>

namespace gfx {

namespace {
// Break the module-walk view: Karmuda walks the loaded module list looking for
// modules not on disk â†’ our mapped image must be unlinked from the loader list.
// manual_map never added us to it, so this is a no-op by construction, but we
// scrub the PEB's InLoadOrderModuleList for any stray entry just in case.
void scrub_peb_loader_entry() {
#if defined(_M_X64)
    auto* peb = reinterpret_cast<uint8_t*>(__readgsqword(0x60));
    auto* ldr = *reinterpret_cast<uint8_t**>(peb + 0x18); // PEB->Ldr
    auto* list_head = ldr + 0x10;                          // InLoadOrderModuleList
    auto* cur = *reinterpret_cast<uint8_t**>(list_head);
    auto* my_base = reinterpret_cast<uint8_t*>(gfx::image_base());
    while (cur && cur != list_head) {
        auto* base = *reinterpret_cast<uint8_t**>(cur + 0x30); // LDR_DATA_TABLE_ENTRY->DllBase
        if (base == my_base) {
            // Unlink this entry.
            auto* flink = *reinterpret_cast<uint8_t**>(cur);
            auto* blink = *reinterpret_cast<uint8_t**>(cur + 0x08);
            *reinterpret_cast<uint8_t**>(blink) = flink;
            *reinterpret_cast<uint8_t**>(flink + 0x08) = blink;
        }
        cur = *reinterpret_cast<uint8_t**>(cur);
    }
#endif
}

// Strip the RWX permissions on our image: remap code pages RX, data RW.
void harden_page_protections() {
    uintptr_t base = gfx::image_base();
    if (!base) return;
    auto* dos = reinterpret_cast<IMAGE_DOS_HEADER*>(base);
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return;   // already erased / not our image
    auto* h = reinterpret_cast<IMAGE_NT_HEADERS64*>(base + dos->e_lfanew);
    if (h->Signature != IMAGE_NT_SIGNATURE) return;
    auto* sec = IMAGE_FIRST_SECTION(h);
    for (int i = 0; i < h->FileHeader.NumberOfSections; i++, sec++) {
        DWORD prot = PAGE_READWRITE;
        if (sec->Characteristics & IMAGE_SCN_MEM_EXECUTE) prot = PAGE_EXECUTE_READ;
        else if (sec->Characteristics & IMAGE_SCN_MEM_WRITE) prot = PAGE_READWRITE;
        else prot = PAGE_READONLY;
        void* addr = reinterpret_cast<void*>(base + sec->VirtualAddress);
        size_t size = sec->Misc.VirtualSize;
        void* a = addr;
        uint32_t old = 0;
        sys::protect(GetCurrentProcess(), &a, &size, prot, &old);
    }
}

// Erase our PE header (DOS + NT headers + section-name table, i.e. everything
// in SizeOfHeaders) so signature scanners and memory carve-out see no
// recognizable MZ image where we map. The exception/unwind table was already
// registered with the dispatcher by RtlAddFunctionTable in DllMain, so x64
// unwinding survives the header being gone (unwind resolves by base+RVA range,
// not by re-reading the erased headers). MUST run after harden_page_protections
// (which still reads the section table) and never before the image base is
// cached â€” after erase there is no MZ to recover the base from.
void erase_pe_header() {
    uintptr_t base = gfx::image_base();
    if (!base) return;
    auto* dos = reinterpret_cast<IMAGE_DOS_HEADER*>(base);
    if (dos->e_magic != IMAGE_DOS_SIGNATURE) return;   // already erased
    auto* h = reinterpret_cast<IMAGE_NT_HEADERS64*>(base + dos->e_lfanew);
    if (h->Signature != IMAGE_NT_SIGNATURE) return;
    DWORD hdr_size = h->OptionalHeader.SizeOfHeaders;
    if (hdr_size < 0x40 || hdr_size > 0x10000) hdr_size = 0x1000;  // sanity, then wipe a page
    size_t sz = hdr_size;
    void* addr = reinterpret_cast<void*>(base);
    uint32_t old = 0;
    sys::protect(GetCurrentProcess(), &addr, &sz, PAGE_READWRITE, &old);
    memset(addr, 0, hdr_size);
    // Leave the headers read-only (never writable): a writable image-page-0 is
    // itself a tell, and nothing legitimately needs to write here now.
    sz = hdr_size;
    sys::protect(GetCurrentProcess(), &addr, &sz, PAGE_READONLY, &old);
}

// Anti-debug: ThreadHideFromDebugger already applied in entry; also null the
// PEB->BeingDebugged flag.
void clear_being_debugged() {
#if defined(_M_X64)
    auto* peb = reinterpret_cast<uint8_t*>(__readgsqword(0x60));
    *reinterpret_cast<uint8_t*>(peb + 0x02) = 0;
#endif
}
} // namespace

void karmuda_shim() {
    scrub_peb_loader_entry();
    harden_page_protections();
    // Header erase LAST-of-the-header-users: scrub + harden still read the
    // section table off the headers. After this the image has no MZ/PE header to
    // carve or signature-match, and unwinding is already handled by the
    // RtlAddFunctionTable registration in DllMain.
    erase_pe_header();
    clear_being_debugged();
#ifdef FVEM_LOG
    OutputDebugStringA("[fvem] karmuda shim applied");
#endif
}

} // namespace gfx