// language: C++, target: Windows 11, MSVC (x64)
//
// Per-hook layout:
//   [target]  E9 <rel32 -> stub>           5..15 bytes patched, remainder NOP
//   [stub]    FF 25 00000000 <hook>        14 bytes
//   [tramp]   <relocated stolen bytes> FF 25 00000000 <target+stolen>
//
// The relay page (stub at +0x00, trampoline at +0x40) is allocated inside
// +/-2GB of the target, so a rel32 reaches it and every relocated RIP-relative
// disp32 or rel32 branch still resolves with a constant delta
// (target - tramp). A prologue containing a rel8 branch is refused: rel8
// cannot be widened here without a rewrite pass, and no real function prologue
// opens with one.
#include "pch.h"
#include "detour.h"
#include "log.h"
#include <intrin.h>

namespace gfx::detour {
namespace {

constexpr int kMaxSteal = 16;
constexpr int kMaxHooks = 32;

struct hook_record {
    void*   target      = nullptr;
    uint8_t stolen[kMaxSteal]{};
    int     stolen_len  = 0;
    void*   relay       = nullptr;
    void*   trampoline  = nullptr;
    bool    active      = false;
};

hook_record      g_hooks[kMaxHooks];
int              g_hook_count = 0;
CRITICAL_SECTION g_lock{};
bool             g_lock_ready = false;

void lock_init() {
    if (!g_lock_ready) { InitializeCriticalSection(&g_lock); g_lock_ready = true; }
}

// ---------------------------------------------------------------------------
// Instruction length decoder (subset: everything that appears in a real
// function prologue, plus enough of the integer map to keep the total exact).
// ---------------------------------------------------------------------------
struct decoded {
    int  len      = 0;
    bool riprel   = false;   // operand is RIP-relative (needs disp32 fixup)
    int  disp_off = -1;      // byte offset of that disp32
    bool branch   = false;   // rel8/rel32 immediate branch
    int  rel_off  = -1;
    int  rel_size = 0;
};

bool modrm_opcode_1(uint8_t op) {
    switch (op) {
    case 0x00: case 0x01: case 0x02: case 0x03:
    case 0x08: case 0x09: case 0x0A: case 0x0B:
    case 0x10: case 0x11: case 0x12: case 0x13:
    case 0x18: case 0x19: case 0x1A: case 0x1B:
    case 0x20: case 0x21: case 0x22: case 0x23:
    case 0x28: case 0x29: case 0x2A: case 0x2B:
    case 0x30: case 0x31: case 0x32: case 0x33:
    case 0x38: case 0x39: case 0x3A: case 0x3B:
    case 0x62: case 0x63:
    case 0x69: case 0x6B:
        return true;
    default: break;
    }
    if (op >= 0x80 && op <= 0x8F) return true; // 80-83 grp1, 84-8F mov/lea/pop
    if (op == 0xC0 || op == 0xC1) return true;
    if (op == 0xC4 || op == 0xC5) return true;
    if (op == 0xC6 || op == 0xC7) return true;
    if (op >= 0xD0 && op <= 0xD3) return true;
    if (op >= 0xD8 && op <= 0xDF) return true; // x87
    if (op == 0xF6 || op == 0xF7) return true;
    if (op == 0xFE || op == 0xFF) return true;
    return false;
}

// 0F-map opcodes that carry NO ModRM. Everything else in the map does.
bool modrm_opcode_2(uint8_t op) {
    switch (op) {
    case 0x05: case 0x06: case 0x07: case 0x08: case 0x09:
    case 0x0B: case 0x0E:
    case 0x30: case 0x31: case 0x32: case 0x33: case 0x34:
    case 0x35: case 0x37:
    case 0x77:
    case 0xA0: case 0xA1: case 0xA2:
    case 0xA8: case 0xA9: case 0xAA:
    case 0xC8: case 0xC9: case 0xCA: case 0xCB:
    case 0xCC: case 0xCD: case 0xCE: case 0xCF:
        return false;
    default: return true;
    }
}

bool decode_one(const uint8_t* p, decoded& d) {
    int i = 0;
    bool opsize16 = false;
    bool rex_w = false;

    // Legacy prefixes.
    for (;;) {
        uint8_t b = p[i];
        if (b == 0x66) { opsize16 = true; ++i; continue; }
        if (b == 0x67 || b == 0xF0 || b == 0xF2 || b == 0xF3 ||
            b == 0x2E || b == 0x36 || b == 0x3E || b == 0x26 ||
            b == 0x64 || b == 0x65) { ++i; continue; }
        break;
    }
    if (i > 14) return false;

    // REX (0x40-0x4F is always REX in 64-bit mode).
    if (p[i] >= 0x40 && p[i] <= 0x4F) {
        rex_w = (p[i] & 0x08) != 0;
        ++i;
    }

    uint8_t op = p[i++];
    bool two = false, map38 = false, map3a = false;
    if (op == 0x0F) {
        two = true;
        op = p[i++];
        if (op == 0x38)      { map38 = true; op = p[i++]; }
        else if (op == 0x3A) { map3a = true; op = p[i++]; }
    }

    bool need_modrm = false;
    int  imm = 0;

    if (!two) {
        need_modrm = modrm_opcode_1(op);
        switch (op) {
        case 0x04: case 0x0C: case 0x14: case 0x1C:
        case 0x24: case 0x2C: case 0x34: case 0x3C:
        case 0x6A: case 0xA8: case 0xCD:
        case 0xE4: case 0xE5: case 0xE6: case 0xE7: imm = 1; break;
        case 0x05: case 0x0D: case 0x15: case 0x1D:
        case 0x25: case 0x2D: case 0x35: case 0x3D:
        case 0x68: case 0x69: case 0xA9: imm = opsize16 ? 2 : 4; break;
        case 0x6B: case 0x80: case 0x82: case 0x83:
        case 0xC0: case 0xC1: case 0xC6: imm = 1; break;
        case 0x81: case 0xC7: imm = opsize16 ? 2 : 4; break;
        case 0xB0: case 0xB1: case 0xB2: case 0xB3:
        case 0xB4: case 0xB5: case 0xB6: case 0xB7: imm = 1; break;
        case 0xB8: case 0xB9: case 0xBA: case 0xBB:
        case 0xBC: case 0xBD: case 0xBE: case 0xBF:
            imm = rex_w ? 8 : (opsize16 ? 2 : 4); break;
        case 0xC2: case 0xCA: imm = 2; break;
        case 0x70: case 0x71: case 0x72: case 0x73: case 0x74: case 0x75:
        case 0x76: case 0x77: case 0x78: case 0x79: case 0x7A: case 0x7B:
        case 0x7C: case 0x7D: case 0x7E: case 0x7F:
        case 0xEB:
            d.branch = true; d.rel_size = 1; break;
        case 0xE8: case 0xE9:
            d.branch = true; d.rel_size = 4; break;
        default: break;
        }
    } else if (map38) {
        need_modrm = true;
    } else if (map3a) {
        need_modrm = true;
        imm = 1;
    } else {
        need_modrm = modrm_opcode_2(op);
        switch (op) {
        case 0x70: case 0x71: case 0x72: case 0x73:
        case 0xA4: case 0xAC: case 0xBA:
        case 0xC2: case 0xC4: case 0xC5: case 0xC6: imm = 1; break;
        case 0x80: case 0x81: case 0x82: case 0x83:
        case 0x84: case 0x85: case 0x86: case 0x87:
        case 0x88: case 0x89: case 0x8A: case 0x8B:
        case 0x8C: case 0x8D: case 0x8E: case 0x8F:
            d.branch = true; d.rel_size = 4; break;
        default: break;
        }
    }

    int modrm_reg = -1;
    if (need_modrm) {
        uint8_t modrm = p[i];
        int mod = modrm >> 6;
        int rm  = modrm & 7;
        modrm_reg = (modrm >> 3) & 7;
        ++i;
        if (mod != 3) {
            if (rm == 4) {
                uint8_t sib = p[i];
                int base = sib & 7;
                ++i;
                if (mod == 0 && base == 5)      i += 4; // disp32, no base (not RIP-rel)
                else if (mod == 1)              i += 1;
                else if (mod == 2)              i += 4;
            } else if (mod == 0 && rm == 5) {
                d.riprel = true;
                d.disp_off = i;
                i += 4;
            } else if (mod == 1) { i += 1; }
            else if (mod == 2)  { i += 4; }
        }
        // Group 3: F6/F7 with reg 0 or 1 carry an immediate operand.
        if (!two && (op == 0xF6 || op == 0xF7) && (modrm_reg == 0 || modrm_reg == 1))
            imm = (op == 0xF6) ? 1 : (opsize16 ? 2 : 4);
    }

    if (d.branch && d.rel_size) d.rel_off = i;
    i += imm;

    if (i < 1 || i > 15) return false;
    d.len = i;
    return true;
}

// ---------------------------------------------------------------------------
// Relay-page allocation inside +/-2GB of the target
// ---------------------------------------------------------------------------
void* alloc_near(void* target, size_t size) {
    SYSTEM_INFO si{};
    GetSystemInfo(&si);
    const uintptr_t gran = si.dwAllocationGranularity ? si.dwAllocationGranularity : 0x10000;
    const uintptr_t t = reinterpret_cast<uintptr_t>(target);
    const uintptr_t kReach = 0x7FFF0000ull;

    for (uintptr_t delta = gran; delta < kReach; delta += gran) {
        uintptr_t cands[2];
        cands[0] = t + delta;
        cands[1] = (t > delta) ? (t - delta) : 0;
        for (int k = 0; k < 2; ++k) {
            uintptr_t c = cands[k];
            if (c < 0x10000) continue;
            c &= ~(gran - 1);
            MEMORY_BASIC_INFORMATION mbi{};
            if (!VirtualQuery(reinterpret_cast<LPCVOID>(c), &mbi, sizeof(mbi))) continue;
            if (mbi.State != MEM_FREE) continue;
            void* m = VirtualAlloc(reinterpret_cast<LPVOID>(c), size,
                                   MEM_RESERVE | MEM_COMMIT, PAGE_EXECUTE_READWRITE);
            if (m) return m;
        }
    }
    return nullptr;
}

void emit_abs_jmp(uint8_t* at, uint64_t dest) {
    at[0] = 0xFF; at[1] = 0x25;
    at[2] = 0x00; at[3] = 0x00; at[4] = 0x00; at[5] = 0x00; // jmp [rip+0]
    memcpy(at + 6, &dest, 8);
}

} // namespace

int instruction_length(const void* code) {
    if (!code) return 0;
    __try {
        decoded d{};
        return decode_one(static_cast<const uint8_t*>(code), d) ? d.len : 0;
    } __except (probe_filter(GetExceptionCode(), GetExceptionInformation())) {
        return 0;
    }
}

bool install(void* target, void* hook, void** original) {
    if (!target || !hook) return false;
    lock_init();
    EnterCriticalSection(&g_lock);

    // Reuse the slot already owned by this target when it has been hooked
    // before. The self-heal pass re-installs a hook something else restored;
    // appending a fresh record every repair would exhaust kMaxHooks after a
    // few cycles and leave the last hole silently unpatched.
    int slot = -1;
    for (int i = 0; i < g_hook_count; ++i) {
        if (g_hooks[i].target == target) { slot = i; break; }
    }
    if (slot < 0) {
        if (g_hook_count >= kMaxHooks) { LeaveCriticalSection(&g_lock); return false; }
        slot = g_hook_count++;
    } else if (g_hooks[slot].relay) {
        VirtualFree(g_hooks[slot].relay, 0, MEM_RELEASE);
        g_hooks[slot].relay = nullptr;
        g_hooks[slot].active = false;
    }

    uint8_t* t = static_cast<uint8_t*>(target);

    // Steal whole instructions until >= 5 bytes are covered.
    decoded d[kMaxSteal]{};
    int off = 0, n = 0;
    while (off < 5 && n < kMaxSteal) {
        if (!decode_one(t + off, d[n])) {
            FVEM_LOGF("[fvem] detour: undecodable prologue at %p (offset %d)",
                          static_cast<void*>(t), off);
            LeaveCriticalSection(&g_lock);
            return false;
        }
        if (d[n].branch && d[n].rel_size == 1) {
            FVEM_LOGF("[fvem] detour: rel8 branch in prologue at %p, refusing",
                          static_cast<void*>(t));
            LeaveCriticalSection(&g_lock);
            return false;
        }
        off += d[n].len;
        ++n;
    }
    if (off < 5 || off > kMaxSteal) { LeaveCriticalSection(&g_lock); return false; }

    uint8_t* page = static_cast<uint8_t*>(alloc_near(t, 0x1000));
    if (!page) {
        FVEM_LOGF("[fvem] detour: no relay page within +/-2GB of %p",
                      static_cast<void*>(t));
        LeaveCriticalSection(&g_lock);
        return false;
    }
    uint8_t* stub  = page;
    uint8_t* tramp = page + 0x40;

    // Trampoline: relocated stolen bytes, then an absolute jump back.
    memcpy(tramp, t, off);
    const intptr_t delta = reinterpret_cast<intptr_t>(t) - reinterpret_cast<intptr_t>(tramp);
    for (int k = 0; k < n; ++k) {
        if (d[k].riprel && d[k].disp_off >= 0) {
            int32_t* disp = reinterpret_cast<int32_t*>(tramp + d[k].disp_off);
            int64_t fixed = static_cast<int64_t>(*disp) + delta;
            if (fixed < INT32_MIN || fixed > INT32_MAX) {
                VirtualFree(page, 0, MEM_RELEASE);
                LeaveCriticalSection(&g_lock);
                return false;
            }
            *disp = static_cast<int32_t>(fixed);
        }
        if (d[k].branch && d[k].rel_size == 4 && d[k].rel_off >= 0) {
            int32_t* rel = reinterpret_cast<int32_t*>(tramp + d[k].rel_off);
            int64_t fixed = static_cast<int64_t>(*rel) + delta;
            if (fixed < INT32_MIN || fixed > INT32_MAX) {
                VirtualFree(page, 0, MEM_RELEASE);
                LeaveCriticalSection(&g_lock);
                return false;
            }
            *rel = static_cast<int32_t>(fixed);
        }
    }
    emit_abs_jmp(tramp + off, reinterpret_cast<uint64_t>(t + off));

    // Stub: absolute jump to the detour.
    emit_abs_jmp(stub, reinterpret_cast<uint64_t>(hook));

    // F2 (UNDETECTED_FULL_PLAN): relay content is final — stub + trampoline
    // are written once per install (the self-heal re-install reuses this same
    // path after freeing the old page). Flip the page RX so no private RWX
    // region survives next to the hooked modules.
    {
        DWORD rx_old = 0;
        VirtualProtect(page, 0x1000, PAGE_EXECUTE_READ, &rx_old);
    }

    // Patch the target.
    DWORD old_prot = 0;
    if (!VirtualProtect(t, off, PAGE_EXECUTE_READWRITE, &old_prot)) {
        VirtualFree(page, 0, MEM_RELEASE);
        LeaveCriticalSection(&g_lock);
        return false;
    }

    hook_record& rec = g_hooks[slot];
    rec.target     = t;
    rec.stolen_len = off;
    memcpy(rec.stolen, t, off);
    rec.relay      = page;
    rec.trampoline = tramp;

    const int64_t rel = reinterpret_cast<intptr_t>(stub) - reinterpret_cast<intptr_t>(t + 5);
    t[0] = 0xE9;
    memcpy(t + 1, &rel, 4);
    for (int k = 5; k < off; ++k) t[k] = 0x90;

    DWORD ignored = 0;
    VirtualProtect(t, off, old_prot, &ignored);
    FlushInstructionCache(GetCurrentProcess(), t, off);

    rec.active = true;

    if (original) *original = tramp;
    FVEM_LOGF("[fvem] detour: hooked %p (stole %d bytes, relay %p)",
                  static_cast<void*>(t), off, static_cast<void*>(page));

    LeaveCriticalSection(&g_lock);
    return true;
}

bool is_installed(const void* target) {
    if (!target) return false;
    lock_init();
    EnterCriticalSection(&g_lock);
    bool found = false;
    for (int i = 0; i < g_hook_count; ++i) {
        if (g_hooks[i].active && g_hooks[i].target == target) {
            // The jump this engine writes is the only thing that can be
            // checked cheaply; a restored prologue reads as a non-E9 byte.
            const uint8_t* p = static_cast<const uint8_t*>(target);
            __try {
                found = (p[0] == 0xE9);
            } __except (probe_filter(GetExceptionCode(), GetExceptionInformation())) {
                found = false;
            }
            break;
        }
    }
    LeaveCriticalSection(&g_lock);
    return found;
}

void remove_all() {
    lock_init();
    EnterCriticalSection(&g_lock);
    for (int i = 0; i < g_hook_count; ++i) {
        hook_record& rec = g_hooks[i];
        if (!rec.active) continue;
        DWORD old_prot = 0;
        if (VirtualProtect(rec.target, rec.stolen_len, PAGE_EXECUTE_READWRITE, &old_prot)) {
            memcpy(rec.target, rec.stolen, rec.stolen_len);
            DWORD ignored = 0;
            VirtualProtect(rec.target, rec.stolen_len, old_prot, &ignored);
            FlushInstructionCache(GetCurrentProcess(), rec.target, rec.stolen_len);
        }
        if (rec.relay) VirtualFree(rec.relay, 0, MEM_RELEASE);
        rec.active = false;
    }
    g_hook_count = 0;
    LeaveCriticalSection(&g_lock);
}

} // namespace gfx::detour
