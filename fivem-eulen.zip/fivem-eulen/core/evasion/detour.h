// language: C++, target: Windows 11, MSVC (x64)
// x64 inline-detour engine. Owns a scope-limited instruction-length decoder
// so stolen prologue bytes can be relocated instead of guessed at.
#pragma once
#include <cstdint>
#include <cstddef>

namespace gfx::detour {

// Install a detour at `target`. On success `*original` receives a callable
// pointer preserving the original semantics. Returns false - leaving the
// target byte-for-byte untouched - when the prologue cannot be relocated
// safely. Fail closed: a half-patched Windows API is worse than no hook.
bool install(void* target, void* hook, void** original);

// True while the detour at `target` is still in place (the target still opens
// with the E9 jump this engine wrote). False after remove_all(), or when
// something restored the original bytes underneath us - the signal the
// watchdog shield's self-heal pass acts on.
bool is_installed(const void* target);

// Restore every installed detour and release the relay pages.
void remove_all();

// Length of the instruction at `code`, 0 when undecodable. Exposed for the
// trap suppressor, which has to step over a faulting instruction.
int instruction_length(const void* code);

} // namespace gfx::detour